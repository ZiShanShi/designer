if (window.BI == null) {
    BI = {};
}
BI.FormulaCollections = ["month", "MONTH", "rand", "RAND", "format", "FORMAT", "trim", "TRIM", "sqrt", "SQRT", "daysofyear", "DAYSOFYEAR", "rank", "RANK", "endwith", "ENDWITH", "log10", "LOG10", "maparray", "MAPARRAY", "floor", "FLOOR", "numto", "NUMTO", "year", "YEAR", "slicearray", "SLICEARRAY", "decode", "DECODE", "enmoney", "ENMONEY", "if", "IF", "dateinweek", "DATEINWEEK", "monthdelta", "MONTHDELTA", "datedif", "DATEDIF", "substitute", "SUBSTITUTE", "left", "LEFT", "log", "LOG", "sortarray", "SORTARRAY", "datedelta", "DATEDELTA", "mid", "MID", "sum", "SUM", "exact", "EXACT", "weekdate", "WEEKDATE", "tointeger", "TOINTEGER", "min", "MIN", "even", "EVEN", "count", "COUNT", "indexofarray", "INDEXOFARRAY", "seq", "SEQ", "encode", "ENCODE", "dateinmonth", "DATEINMONTH", "greparray", "GREPARRAY", "repeat", "REPEAT", "max", "MAX", "trunc", "TRUNC", "fact", "FACT", "stdev", "STDEV", "split", "SPLIT", "inarray", "INARRAY", "reversearray", "REVERSEARRAY", "randbetween", "RANDBETWEEN", "upper", "UPPER", "abs", "ABS", "right", "RIGHT", "median", "MEDIAN", "days360", "DAYS360", "filetype", "FILETYPE", "add2array", "ADD2ARRAY", "sumsq", "SUMSQ", "todouble", "TODOUBLE", "todate", "TODATE", "day", "DAY", "lunar", "LUNAR", "ln", "LN", "array", "ARRAY", "decimal", "DECIMAL", "joinarray", "JOINARRAY", "indexof", "INDEXOF", "find", "FIND", "minute", "MINUTE", "sign", "SIGN", "index", "INDEX", "replace", "REPLACE", "uuid", "UUID", "datesubdate", "DATESUBDATE", "concatenate", "CONCATENATE", "filesize", "FILESIZE", "daysofmonth", "DAYSOFMONTH", "dateinquarter", "DATEINQUARTER", "cnmoney", "CNMONEY", "dayvalue", "DAYVALUE", "date", "DATE", "lower", "LOWER", "ceiling", "CEILING", "now", "NOW", "and", "AND", "switch", "SWITCH", "eval", "EVAL", "range", "RANGE", "rounddown", "ROUNDDOWN", "hour", "HOUR", "round", "ROUND", "yeardelta", "YEARDELTA", "dateinyear", "DATEINYEAR", "weightedaverage", "WEIGHTEDAVERAGE", "int", "INT", "daysofquarter", "DAYSOFQUARTER", "average", "AVERAGE", "removearray", "REMOVEARRAY", "webimage", "WEBIMAGE", "week", "WEEK", "filename", "FILENAME", "or", "OR", "mod", "MOD", "weekday", "WEEKDAY", "today", "TODAY", "round5", "ROUND5", "roundup", "ROUNDUP", "time", "TIME", "ennumber", "ENNUMBER", "len", "LEN", "uniquearray", "UNIQUEARRAY", "promotion", "PROMOTION", "isnull", "ISNULL", "let", "LET", "second", "SECOND", "treelayer", "TREELAYER", "exp", "EXP"];
BI.FormulaJSONs = [{
    "def": "MONTH:(serial_number)返回日期中的月。月是介于1和12之间的一个数。\nSerial_number:含有所求的月的日期.\n备注:\nFineReport将日期保存为系列数，一个系列数代表一个与之匹配的日期，以方便用户对日期进行数值式计算。\n在1900年日期系统中，FineReport电子表格将1900年1月1日保存为系列数2，将1900年1月2日保存为系列数3，\n将1900年1月3日保存为系列数4\u2026\u2026依此类推。如在1900年日期系统，1998年1月1日存为系列数35796。\n示例:\nMONTH(\"2000/1/1\")等于1。\nMONTH(\"2006/05/05\")等于5。\nMONTH(\"1997/04/20\")等于4。\nMONTH(\"2000-1-1\", \"yyyy-MM-dd\")等于1。\nMONTH(\"2006-05-05\", \"yyyy-MM-dd\")等于5。\nMONTH(\"1997-04-20\", \"yyyy-MM-dd\")等于4。\nMONTH(35796)等于1。",
    "name": "MONTH",
    "type": "DATETIME"
},
{
    "def": "ROWCOUNT(tableData)返回tableData的行数。\ntableData:TableData的名字，字符串形式的。\n备注:\n    先从私有数据源中查找，然后再从公有数据源中查找，返回的是tableData的行数。\n示例:\n以我们提供的数据源FRDemo为例\n新建数据集ds1:SELECT * FROM [CUSTOMER]\nROWCOUNT(\"ds1\")等于20。",
    "name": "ROWCOUNT",
    "type": "REPORT"
},
{
    "def": "RAND(): 返回均匀分布的随机数。每计算一次工作表，函数都会返回一个新的随机数值。\n备注:\n    要生成一个位于a和b之间的随机数，可以使用以下的公式: C=RAND()*(b-a)+a。\n    如果要使一个随机产生的数值不随单元格的重计算而改变，可以在编辑框中输入=RAND()并保持编辑状态，然后按F9，将公式永久性地改为随机数。\n示例:\n假如需要生成一个大于等于0，小于60的随机数，使用公式: =RAND()*60。\n假如需要生成一个大于等于0，小于19的随机数，使用公式: =RAND()*19。\n假如需要生成一个大于等于0，小于50的随机数，使用公式: =RAND()*50。",
    "name": "RAND",
    "type": "MATH"
},
{
    "def": "GETUSERDEPARTMENTS():返回角色部门\n示例:\nGETUSERDEPARTMENTS():返回角色所有部门，若多个部门则数组\nGETUSERDEPARTMENTS(3,2):返回角色该部门的第三层和第二层名字，\n若多个部门则返回数组，若没有第三层则只显示第二层",
    "name": "GETUSERDEPARTMENTS",
    "type": "OTHER"
},
{
    "def": "FORMAT(object,format) : 返回object的format格式。\nobject 需要被格式化对象，可以是String，数字，Object(常用的有Date, Time)。\nformat 格式化的样式。\n示例\nFORMAT(1234.5, \"#,##0.00\") => 1234.50\nFORMAT(1234.5, \"#,##0\") => 1234\nFORMAT(1234.5, \"￥#,##0.00\") => ￥1234.50\nFORMAT(1.5, \"0%\") => 150%\nFORMAT(1.5, \"0.000%\") => 150.000%\nFORMAT(6789, \"##0.0E0\") => 6.789E3\nFORMAT(6789, \"0.00E00\") => 6.79E03\nFORMAT(date(2007,1,1), \"EEEEE, MMMMM dd, yyyy\") => 星期一，一月 01，2007\nFORMAT(date(2007,1,13), \"MM/dd/yyyy\") => 01/13/2007\nFORMAT(date(2007,1,13), \"M-d-yy\") => 1-13-07\nFORMAT(time(16,23,56), \"h:mm:ss a\") => 4:23:56 下午",
    "name": "FORMAT",
    "type": "TEXT"
},
{
    "def": "TRIM(text): 清除文本中所有空格，单词间的单个空格除外，也可用于带有不规则空格的文本。\nText:需要清除空格的文本。\n示例:\nTRIM(\" Monthly Report\")等于Monthly Report。",
    "name": "TRIM",
    "type": "TEXT"
},
{
    "def": "SQRT(number): 返回一个正数的平方根。\nNumber:要求其平方根的任一正数。\n备注:\nNumber必须是一个正数，否则函数返回错误信息*NUM!。\n示例:\nSQRT(64)等于8。\nSQRT(-64)返回*NUM!。",
    "name": "SQRT",
    "type": "MATH"
},
{
    "def": "DAYSOFYEAR(year):返回某年包含的天数。\n示例：\nDAYSOFYEAR(2008)等于365，等价于DAYSOFYEAR(\"2008-01-01\")。",
    "name": "DAYSOFYEAR",
    "type": "DATETIME"
},
{
    "def": "RANK(number,ref,order): 返回一个数在一个数组中的秩。(如果把这个数组排序，该数的秩即为它在数组中的序号。)\nNumber 所求秩的数。(可以是Boolean型，true=1，false=0)\nRef    可以是数组，引用，或一系列数，非实数的值被忽略处理(接受Boolean型，true=1，false=0)。\nOrder  指定求秩的参数，非零为升序，零为降序\n\n备注\n1.  RANK对重复的数返回相同的秩，但重复的数影响后面的数的秩，比如，在一组升序排列的整数中，如果5出现了2次，并且秩为3，那么6的秩为5 (没有数的秩是4).\n\n示例\nA1:A5 = 6, 4.5, 4.5, 2, 4\nRANK(A1,A1:A5,1) 即 6 的秩为 5.\n\nRANK(3,1,2,\"go\",3,4,1) = 3, \"go\"被忽略。",
    "name": "RANK",
    "type": "OTHER"
},
{
    "def": "ODD(number):返回对指定数值进行舍入后的奇数。\nnumber:是要舍入求奇的数值。\n不论正负号如何，数值都朝着远离 0 的方向舍入。如果 number 恰好是奇数，则不须进行任何舍入处理。\n示例:\nODD(1.5) 等于 3\nODD(3) 等于 3\nODD(2) 等于 3\nODD(-1) 等于 -1",
    "name": "ODD",
    "type": "MATH"
},
{
    "def": "COLCOUNT(tableData):返回tableData中列的个数。\ntableData:tableData的名字，字符串形式的。\n备注：\n    先从私有数据源中查找，然后再从公有数据源中查找，返回的是第一个查找到的tableData中列数。\n示例:\n以我们提供的数据源FRDemo为例\n新建数据集ds1:SELECT * FROM [CUSTOMER]\nCOLCOUNT(\"ds1\")等于6。\n",
    "name": "COLCOUNT",
    "type": "REPORT"
},
{
    "def": "ENDWITH(str1，str2):判断字符串str1是否以str2结束。\n备注:\n    str1和str2都是大小写敏感的。\n示例:\nENDWITH(\"FineReport\",\"Report\")等于true。\nENDWITH(\"FineReport\",\"Fine\")等于false。\nENDWITH(\"FineReport\",\"report\")等于false。",
    "name": "ENDWITH",
    "type": "TEXT"
},
{
    "def": "LOG10(number):返回以 10 为底的对数。\nnumber: 用于常用对数计算的正实数。\n示例:\nLOG10(86) 等于 1.934498451\nLOG10(10) 等于 1\nLOG10(1E5) 等于 5\n",
    "name": "LOG10",
    "type": "MATH"
},
{
    "def": "MAPARRAY(array, fn):把一个数组中的项目转换到另一个数组中。\narray (Array): 要转换的数组 \nfn (Function): 处理数组项目的函数 \n示例：\nMAPARRAY([3,4,2,3,6,8,7], item != 3)等于[false,true,true,false,true,true,true].",
    "name": "MAPARRAY",
    "type": "ARRAY"
},
{
    "def": "FLOOR(number): 将参数number沿绝对值减小的方向去尾舍入。\nNumber:待舍入的数值。\n示例:\nFLOOR(-2.5)等于-2。\nFLOOR(2.5)等于2。\n",
    "name": "FLOOR",
    "type": "MATH"
},
{
    "def": "NUMTO(number,bool)或NUMTO(number):返回number的中文表示。其中bool用于选择中文表示的方式，当没有bool时采用默认方式显示。\n示例：NUMTO(2345,true)等于二三四五。\n示例：NUMTO(2345,false)等于二千三百四十五。\n示例：NUMTO(2345)等于二千三百四十五。",
    "name": "NUMTO",
    "type": "TEXT"
},
{
    "def": "ATANH(number): 返回数字的反双曲正切值，该函数的参数值即为反双曲正切值的双曲正切值。\nNumber:指介于-1~1之间的任意实数。\n备注:\n    指定的number必须介于-1~1之间（不包括-1，1）。\n    ATANH(TANH(number))=number，例如，ATANH(TANH(8))=8。\n示例:\nATANH(-0.5)等于-0.549306144。\nATANH(0)等于0。\nATANH(0.7)等于0.867300528。",
    "name": "ATANH",
    "type": "MATH"
},
{
    "def": "YEAR:(serial_number)返回日期中的年。Year是介于1900和9999之间的一个数。\nSerial_number:含有所求的年的日期.\n备注:\nFineReport将日期保存为系列数，一个系列数代表一个与之匹配的日期，以方便用户对日期进行数值式计算。\n在1900年日期系统中，FineReport电子表格将1900年1月1日保存为系列数2，将1900年1月2日保存为系列数3，\n将1900年1月3日保存为系列数4\u2026\u2026依此类推。如在1900年日期系统，1998年1月1日存为系列数35796。\n示例:\nYEAR(\"2000/1/1\")等于2000。\nYEAR(\"2006/05/05\")等于2006。\nYEAR(\"1997/04/20\")等于1997。\nYEAR(\"2000-1-1\", \"yyyy-MM-dd\")等于2000。\nYEAR(\"2006-05-05\", \"yyyy-MM-dd\")等于2006。\nYEAR(\"1997-04-20\", \"yyyy-MM-dd\")等于1997。\nYEAR(35796)等于1998。",
    "name": "YEAR",
    "type": "DATETIME"
},
{
    "def": "SLICEARRAY(array, start, end):返回数组从第start个到第end个元素(包括第end个元素)。\n示例：\nSLICEARRAY([3, 4, 4, 5, 1, 5, 7], 3, 6)返回[4, 5, 1, 5].\n当不使用end参数时，返回从start开始到数组结束之间的元素。\nSLICEARRAY([3, 4, 4, 5, 1, 5, 7], 3)返回[4, 5, 1, 5, 7].",
    "name": "SLICEARRAY",
    "type": "ARRAY"
},
{
    "def": "decode(string): 使用指定的编码机制（UTF-8）对 application/x-www-form-urlencoded 字符串解码。\n给定的编码用于确定任何 \" %xy\" 格式的连续序列表示的字符。\n示例:\ndecode(\"%E5%B8%86%E8%BD%AF\")等于\"帆软\"。\n",
    "name": "DECODE",
    "type": "OTHER"
},
{
    "def": "ENMONEY(value):将给定的BigDemical类型的数字转换成英文金额字符串。\n示例：\nENMONEY(23.49)等于TWENTY THREE AND CENTS FORTY NINE",
    "name": "ENMONEY",
    "type": "TEXT"
},
{
    "def": "IF(boolean,number1/string1,number2/string2):判断函数,boolean为true时返回第二个参数,为false时返回第三个。\nboolean: 用于判断的布尔值,true或者false。\nnumber1/string1: 第一个参数，如果boolean为ture,返回这个值。\nnumber2/string2: 第二个参数，如果boolean为false,返回这个值。\n示例:\nIF(true,2,8)等于2\nIF(false,\"first\",\"second\")等于second\nIF(true,\"first\",7)等于first",
    "name": "IF",
    "type": "LOGIC"
},
{
    "def": "DATEINWEEK(date, number):函数返回在某一个星期当中第几天的日期。\n示例：\ndateInWeek(\"2008-08-28\", 2)等于2008-08-26。\ndateInWeek(\"2008-08-28\", -1)等于2008-08-31。\n如果最后一个参数为-1，返回该日期所在星期的最后一天\n",
    "name": "DATEINWEEK",
    "type": "DATETIME"
},
{
    "def": "MONTHDELTA(date,delta):返回指定日期date后delta个月的日期。\n示例：\nMONTHDELTA(\"2008-08-08\", 4)等于2008-12-08。",
    "name": "MONTHDELTA",
    "type": "DATETIME"
},
{
    "def": "DATEDIF(start_date,end_date,unit):返回两个指定日期间的天数、月数或年数。\nStart_date:代表所指定时间段的初始日期。\nEnd_date:代表所指定时间段的终止日期。\nUnit:函数返回信息的类型。\n若unit=\u201cY\u201d，则DATEDIF返回指定时间段的年差数。\n若unit=\u201cM\u201d，则DATEDIF返回指定时间段的月差数。\n若unit=\u201cD\u201d，则DATEDIF返回指定时间段的日差数。\n若unit=\u201cMD\u201d，则DATEDIF忽略年和月，返回指定时间段的日差数。\n若unit=\u201cYM\u201d，则DATEDIF忽略年和日，返回指定时间段的月差数。\n若unit=\u201cYD\u201d，则DATEDIF忽略年，返回指定时间段的日差数。\n示例:\nDATEDIF(\"2001/2/28\",\"2004/3/20\",\"Y\")等于3，即在2001年2月28日与2004年3月20日之间有3个整年。\nDATEDIF(\"2001/2/28\",\"2004/3/20\",\"M\")等于37，即在2001年2月28日与2004年3月20日之间有36个整月。\nDATEDIF(\"2001/2/28\",\"2004/3/20\",\"D\")等于1116，即在2001年2月28日与2004年3月20日之间有1116个整天。\nDATEDIF(\"2001/2/28\",\"2004/3/20\",\"MD\")等于8，即忽略月和年后，2001年2月28日与2004年3月20日的差为8天。\nDATEDIF(\"2001/1/28\",\"2004/3/20\",\"YM\")等于2，即忽略日和年后，2001年1月28日与2004年3月20日的差为2个月。\nDATEDIF(\"2001/2/28\",\"2004/3/20\",\"YD\")等于21，即忽略年后，2001年2月28日与2004年3月20日的差为21天。",
    "name": "DATEDIF",
    "type": "DATETIME"
},
{
    "def": "FIELDS(connectionName,tableName):返回tableName这个表中的所有字段名。\n示例：\n数据库BASE中有个名叫task的表的内容如下：\nname start  end\na    2008   2009\nb    2009   2012\n那么FIELDS(\"BASE\",\"task\")等于[name,start,end].",
    "name": "FIELDS",
    "type": "REPORT"
},
{
    "def": "TOIMAGE(path):显示指定路径下的图片。此处默认开启了图片缓存功能以加速报表的生成.\n如不需要缓存，请在参数后面追加值FALSE，例如：TOIMAGE(\"D:/fr.png\",false).\n如需要指定图片大小,拉伸显示, 则需要添加参数,TOIMAGE(patch, true, width, height).\n示例:=toimage(\"d:/1.jpg\", true, \"50%\", 300), 第三个参数为指定宽度, 第四个参数为指定高度.\n如果参数为整数, 则直接写数字, 如果为百分比, 则需要加上引号, 如\"300%\"",
    "name": "TOIMAGE",
    "type": "OTHER"
},
{
    "def": "SUBSTITUTE(text,old_text,new_text,instance_num): 用new_text替换文本串中的old_text。\nText:需要被替换字符的文本，或含有文本的单元格引用。\nOld_text:需要被替换的部分文本。\nNew_text:用于替换old_text的文本。\nInstance_num:指定用new_text来替换第几次出现的old_text。如果指定了instance_num，则只有指定位置上的old_text被替换，否则文字串中出现的所有old_text都被new_text替换。\n备注:\n    如果需要替换文本串中的指定文本，则使用SUBSTITUTE函数；如果需要替换文本串中指定位置上的任意文本，则使用REPLACE函数。\n示例:\nSUBSTITUTE(\"data base\",\"base\",\"model\")等于\u201cdata model\u201d。\nSUBSTITUTE(\"July 28, 2000\",\"2\",\"1\",1)等于\u201cJuly 18, 2000\u201d。\nSUBSTITUTE(\"July 28, 2000\",\"2\",\"1\")等于\u201cJuly 18, 1000\u201d。\nSUBSTITUTE(\"July 28, 2000\",\"2\",\"1\",2)等于\u201cJuly 28, 1000\u201d。 ",
    "name": "SUBSTITUTE",
    "type": "TEXT"
},
{
    "def": "LEFT(text,num_chars): 根据指定的字符数返回文本串中的第一个或前几个字符。\nText:包含需要选取字符的文本串或单元格引用。\nNum_chars:指定返回的字符串长度。\n备注:\n    Num_chars的值必须等于或大于0。\n    如果num_chars大于整个文本的长度，LEFT函数将返回所有的文本。\n    如果省略num_chars，则默认值为1。\n示例:\nLEFT(\"Fine software\",8)等于\u201cFine sof\u201d。\nLEFT(\"Fine software\")等于\u201cF\u201d。\n如果单元格A3中含有\u201cChina\u201d，则LEFT(A3,2)等于\u201cCh\u201d。",
    "name": "LEFT",
    "type": "TEXT"
},
{
    "def": "LOG(number,base): 按指定的任意底数，返回数值的对数。\nNumber:需要求对数的正实数。\nBase:对数的底数。如果省略底数，默认值为10。\n示例:\nLOG(16,2)等于4。\nLOG(10)等于1。\nLOG(24,3)等于2.892789261。",
    "name": "LOG",
    "type": "MATH"
},
{
    "def": "SORTARRAY(array):返回数组array排过序的数组。\n示例：\nSORTARRAY([3, 4, 4, 5, 1, 5, 7])返回[1, 3, 4, 4, 5, 5, 7].\n注意：数组array的元素类型必须一样，并且要可比较。",
    "name": "SORTARRAY",
    "type": "ARRAY"
},
{
    "def": "DATEDELTA(date, deltadays):返回一个日期??date后deltadays的日期。\ndeltaDays可以为正值，负值，零。\n示例：\nDATEDELTA(\"2008-08-08\",  -10)等于2008-07-29。\nDATEDELTA(\"2008-08-08\",   10)等于2008-08-18。",
    "name": "DATEDELTA",
    "type": "DATETIME"
},
{
    "def": "MID(text,start_num,num_chars): 返回文本串中从指定位置开始的一定数目的字符，该数目由用户指定。\nText:包含要提取字符的文本串。\nStart_num:文本中需要提取字符的起始位置。文本中第一个字符的start_num为1，依此类推。\nNum_chars:返回字符的长度。\n备注:\n    如果start_num大于文本长度，MID函数返回\u201c\u201d（空文本）。\n    如果start_num小于文本长度，并且start_num加上num_chars大于文本长度，MID函数将从start_num指定的起始字符直至文本末的所有字符。\n    如果start_num小于1，MID函数返回错误信息*VALUE!。\n    如果num_chars是负数，MID函数返回错误信息*VALUE!。\n示例:\nMID(\"Finemore software\",10,8)返回\u201csoftware\u201d。\nMID(\"Finemore software\",30,5)返回\u201c\u201d（空文本）。\nMID(\"Finemore software\",0,8)返回*VALUE!。\nMID(\"Finemore software\",5,-1)返回*VALUE!。",
    "name": "MID",
    "type": "TEXT"
},
{
    "def": "ATAN2(x_num,y_num): 返回x、y坐标的反正切值。返回角度为x轴与过（x_num,y_num）与坐标原点（0,0）的一条直线形成的角度。该角度以弧度显示。\nX_num:指定点的x坐标。\nY_num:指定点的y坐标。\n备注:\n    正值表示从x轴开始以逆时针方式所得的角度；负值表示从x轴开始以顺时针方式所得的角度。\na > 0,b > 0 or a > 0, b < 0时，公式直接成立；\na < 0,b > 0, ATAN2(a,b)=PI()-ABS(ATAN(b/a))\na < 0,b < 0, ATAN2(a,b)=ABS(ATAN(b/a))-PI()\n    当x_num与y_num都为0时，ATAN2返回错误信息*DIV/0!。\n    用角度制显示返回数值时，把返回数值乘以180/PI()。\n    返回值以弧度表示（返回值大于-pi且小于等于pi）。\n示例:\nATAN2(-2,2)等于2.356194490192345（弧度制的3*pi/4）。\nATAN2(2,2)等于0.785398163（弧度制的pi/4）。\nATAN2(-2,2)*180/PI()等于135（角度制）。",
    "name": "ATAN2",
    "type": "MATH"
},
{
    "def": "SUM(number1,number2,\u2026): 求一个指定单元格区域中所有数字之和。\nNumber1,number2,\u2026:1到30个参数或指定单元格区域中所有数字。\n备注:\n    函数将直接键入参数中的数值、逻辑值及文本表达式计算在内。\n    若参数是数组或引用，则只有数组或单元格引用中的数值进行计算。\n示例:\nSUM(70,80)等于150。\nSUM(\"70\",80,TRUE)等于151，逻辑值\u201cTRUE\u201d作为1来计算；\u201cFALSE\u201d作为0计算；文本\u201c70\u201d作为70来计算。",
    "name": "SUM",
    "type": "MATH"
},
{
    "def": "EXACT(text1,text2): 检测两组文本是否相同。如果完全相同，EXACT函数返回TRUE；否则，返回FALSE。EXACT函数可以区分大小写，但忽略格式的不同。同时也可以利用EXACT函数来检测输入文档的文字。\nText1:需要比较的第一组文本。\nText2:需要比较的第二组文本。\n示例:\nEXACT(\"Spreadsheet\",\"Spreadsheet\")等于TRUE。\nEXACT(\"Spreadsheet\",\"S preadsheet\")等于FALSE。\nEXACT(\"Spreadsheet\",\"spreadsheet\")等于FALSE。",
    "name": "EXACT",
    "type": "TEXT"
},
{
    "def": "ACOSH(number): 返回给定数值的反双曲余弦。\nNumber:返回值的双曲余弦。\n备注:\n    参数number的值必须大于或等于1。\n    ACOSH(COSH(number))=number。\n示例:\nACOSH(1)等于0。\nACOSH(8)等于2.768659383。\nACOSH(5.5)等于2.389526435。",
    "name": "ACOSH",
    "type": "MATH"
},
{
    "def": "weekdate(year,month,weekOfMonth,dayOfWeek): 返回指定年月的指定周的周几的具体日期。\n示例：\nweekdate(2009,10,2,1)\n返回的是2009年的10月的第二个周的第一天即星期天的日期，返回的是2009-10-04\n最后一个参数dayOfWeek为-1时，表示这个周的最后一天\n示例：\nweekdate(2009,12,1,-1)\n返回的是2009年的12月的第一个周的最后一天即星期六的日期，返回的是2009-12-05\n",
    "name": "WEEKDATE",
    "type": "DATETIME"
},
{
    "def": "TOINTEGER(text): 将文本转换成Integer对象。\nText:需要转换的文本。\n示例:\nTOINTEGER(\"123\")等于 new Integer(123)。",
    "name": "TOINTEGER",
    "type": "TEXT"
},
{
    "def": "MIN(number1,number2,\u2026): 返回参数列表中的最小值。\nNumber1,number2,\u2026:1到30个需要找出最小值的参数。\n备注:\n    若参数中没有数字，函数MIN将返回0。\n    参数应为数字、空白单元格、逻辑值或是表示数值的文本串。如果参数是错误值时，MIN将返回错误信息。\n    如果数组或引用参数中包含可解析文本值，逻辑值，零值或空白单元格，这些值都将参与计算，而不可解析的文本值忽略不计。\n示例:\n如果B1:B4包含3，6，9，12，则:\nMIN(B1:B4)等于3。\nMIN(B1:B4,0)等于0。",
    "name": "MIN",
    "type": "MATH"
},
{
    "def": "STARTWITH(str1，str2):判断字符串str1是否以str2开始。\n备注:\n    str1和str2都是大小写敏感的。\n示例:\nSTARTWITH(\"FineReport\",\"Fine\")等于true。\nSTARTWITH(\"FineReport\",\"Report\")等于false。\nSTARTWITH(\"FineReport\",\"fine\")等于false。",
    "name": "STARTWITH",
    "type": "TEXT"
},
{
    "def": "COMBIN(number,number_chosen): 返回若干个指定对象的组合数。该函数与数学表达式为Cnk功能相同。\nNumber或数学表达式中的\u201cn\u201d指对象总数。\nNumber_chosen或数学表达式中的\u201ck\u201d指在对象总数中某一组合的数量。\n备注:\n    Number必须是正整数，number_chosen必须是非负整数。\n    如果number和number_chosen小于0或number小于number_chosen，函数返回错误信息*NUM!。\n    对象组合是对象的子集。与排列不同的是，组合不涉及对象内部的先后顺序，而顺序对排列是非常重要的。\n    假设number=n，number_chosen=k，则: COMBIN(n,k)=Cnk=n!/(k!(n-k)!)。\n示例:\nCOMBIN(5,6)等于*NUM!。\nCOMBIN(5,2)等于10。",
    "name": "COMBIN",
    "type": "MATH"
},
{
    "def": "EVEN(number):返回沿绝对值增大方向取整后最接近的偶数。使用该函数可以处理那些成对出现的对象。\nnumber:所要取整的数值。\n不论正负号如何，数值都朝着远离 0 的方向舍入。如果 number 恰好是偶数，则不须进行任何舍入处理。\n示例:\nEVEN(1.5) 等于 2\nEVEN(3) 等于 4\nEVEN(2) 等于 2\nEVEN(-1) 等于 -2",
    "name": "EVEN",
    "type": "MATH"
},
{
    "def": "COUNT(value1,value2,\u2026): 计算数组或数据区域中所含项的个数。\nValue1,value2,\u2026:可包含任何类型数据的参数。",
    "name": "COUNT",
    "type": "MATH"
},
{
    "def": "INDEXOFARRAY(array, index):返回数组array的第index个元素。\n示例：\nINDEXOFARRAY([\"第一个\", \"第二个\", \"第三个\"], 2)返回\"第二个\"。",
    "name": "INDEXOFARRAY",
    "type": "ARRAY"
},
{
    "def": "MAP(object, string, int, int):四个参数分别是索引值,数据集的名字,索引值所在列序号,返回值所在列序号。\n提醒：后两个参数也可以写列名代替。\n根据数据集的名字,找到对应的数据集,找到其中索引列的值为key所对应的返回值。\n数据集的查找方式是依次从报表数据集找到服务器数据集。\n索引列序号与返回值序列号的初始值为1示例:\nMAP(1001, \"employee\", 1, 2)返回employee数据集,第1列中值为1001那条记录中第2列的值。\nMAP(1001, \"employee\", \"name\", \"address\")返回employee数据集,name列中值为1001那条记录中address列的值。",
    "name": "MAP",
    "type": "REPORT"
},
{
    "def": "SEQ(): 返回数值，在整个报表执行过程中，返回该函数被第几次执行了。\n示例:\nSEQ()在第一次执行时，结果为1。\nSEQ()在第二次执行时，结果为2。",
    "name": "SEQ",
    "type": "OTHER"
},
{
    "def": "i18n为本软件内置的国际化公式,可以对一些常用的词语进行国际化.\n示例:i18n('File'), 则会在中文语言环境下显示为: 文件, 而在英文语言环境下显示为: File",
    "name": "I18N",
    "type": "REPORT"
},
{
    "def": "encode(string): 使用指定的编码机制（UTF-8）将字符串转换为 application/x-www-form-urlencoded 格式。\n该方法使用提供的编码机制获取不安全字符的字节。\n示例:\nencode(\"帆软\")等于\"%E5%B8%86%E8%BD%AF\"。\n",
    "name": "ENCODE",
    "type": "OTHER"
},
{
    "def": "层次坐标简写, 等同于=A1[A1:-1], 若需=B1[A1:-1]则HIERARCHY(A1, B1).\n若为横向, 偏移量为-2, 则写成HIERARCHY(A1, B1, -2, false), 等同于=B1[;A1:-1].\n公式中最后一个参数表示横纵向, 默认不传递, 表示纵向扩展, 若横向扩展, 则需要加上最后一个参数FALSE来区分. ",
    "name": "HIERARCHY",
    "type": "HA"
},
{
    "def": "DATEINMONTH(date, number):函数返回在某一个月当中第几天的日期。\n示例：\nDATEINMONTH(\"2008-08-08\", 20) 等于2008-08-20。\nDATEINMONTH(\"2008-08-08\", -1) 等于2008-08-31。",
    "name": "DATEINMONTH",
    "type": "DATETIME"
},
{
    "def": "TOOCTAL(int): 将一个十进制整型数转换成八进制表示的字符串。\nint:表示需要进行转换的十进制整数。\n示例:\nTOOCTAL(10)等于 \"12\"。\nTOOCTAL(20)等于 \"24\"。",
    "name": "TOOCTAL",
    "type": "MATH"
},
{
    "def": "GREPARRAY(array，fn):函数(返回true或者false)是条件，过滤此数组，最后形成一个新数组。\n示例：\nGREPARRAY([3,4,2,3,6,8,7], item != 3)等于[4,2,6,8,7].\n",
    "name": "GREPARRAY",
    "type": "ARRAY"
},
{
    "def": "REPEAT(text,number_times): 根据指定的次数重复显示文本。REPEAT函数可用来显示同一字符串，并对单元格进行填充。\nText:需要重复显示的文本或包含文本的单元格引用。\nNumber_times:指定文本重复的次数，且为正数。如果number_times为0，REPEAT函数将返回\u201c\u201d（空文本）。如果number_times不是整数，将被取整。REPEAT函数的最终结果通常不大于32767个字符。\n备注:\n    该函数可被用于在工作表中创建简单的直方图。\n示例:\nREPEAT(\"$\",4)等于\u201c$$$$\u201d。\n如果单元格B10的内容为\u201c你好\u201d，REPEAT(B10,3)等于\u201c你好你好你好\u201d。",
    "name": "REPEAT",
    "type": "TEXT"
},
{
    "def": "MAX(number1,number2,\u2026): 返回参数列表中的最大值。\nNumber1,number2,\u2026:1到30个需要找出最大值的参数。\n备注:\n    参数可以是数字、空白单元格、逻辑值或数字的文本表达式。\n    如果数组或引用参数中包含可解析文本值，逻辑值，零值或空白单元格，这些值都将参与计算，而不可解析的文本值忽略不计。\n    如果参数中没有任何数字，MAX将返回0。\n示例:\nMAX(0.1,0,1.2)等于1.2。",
    "name": "MAX",
    "type": "MATH"
},
{
    "def": "CHAR(number): 根据指定数字返回对应的字符。CHAR函数可将计算机其他类型的数字代码转换为字符。\nNumber:用于指定字符的数字，介于1~65535之间（包括1和65535）。\n示例:\nCHAR(88)等于\u201cX\u201d。\nCHAR(45)等于\u201c-\u201d。",
    "name": "CHAR",
    "type": "TEXT"
},
{
    "def": "TRUNC(number,num_digits):将数字的小数部分截去，返回整数。\nnumber:需要截尾取整的数字。\nnum_digits:用于指定取整精度的数字。\n示例:\nTRUNC(8.9) 等于 8\nTRUNC(-8.9) 等于 -8\nTRUNC(PI()) 等于 3\n",
    "name": "TRUNC",
    "type": "MATH"
},
{
    "def": "FACT(number):返回数的阶乘，一个数的阶乘等于 1*2*3*...*该数。\nnumber:要计算其阶乘的非负数。如果输入的 number 不是整数，则截尾取整。\n示例:\nFACT(1) 等于 1\nFACT(1.9) 等于 FACT(1) 等于 1\nFACT(0) 等于 1\nFACT(5) 等于 1*2*3*4*5 等于 120\n",
    "name": "FACT",
    "type": "MATH"
},
{
    "def": "STDEV(array1): 计算数据系列的标准偏差(与Excel的同名函数作用相同)。\n\n示例:\nSTDEV([1,2,3])=1。\n",
    "name": "STDEV",
    "type": "OTHER"
},
{
    "def": "SPLIT(String1,String2)：返回由String2分割String1组成的字符串数组。\nString1：以双引号表示的字符串。\nString2：以双引号表示的分隔符。例如逗号\",\"\n示例:\nSPLIT(\"hello,world,yes\",\",\") = [\"hello\",\"world\",\"yes\"]。\nSPLIT(\"this is very good\",\" \") = [\"this\",\"is\",\"very\",\"good\"]。\n备注：\n如果只有一个参数，则返回一个错误。\n如果有多个参数，则只有前两个起作用。",
    "name": "SPLIT",
    "type": "TEXT"
},
{
    "def": "INARRAY(co, array):返回co在数组array中的位置，如果co不在array中，则返回0.\n示例：\nString[] arr = {\"a\",\"b\",\"c\",\"d\"}\n那么INARRAY(\"b\", arr)等于2.",
    "name": "INARRAY",
    "type": "ARRAY"
},
{
    "def": "REVERSEARRAY(array):返回数组array的倒序数组。\n示例：\nREVERSEARRAY([\"第一个\", \"第二个\", \"第三个\"])返回[\"第三个\", \"第二个\", \"第一个\"].",
    "name": "REVERSEARRAY",
    "type": "ARRAY"
},
{
    "def": "RANDBETWEEN(value1,value2):返回value1和value2之间的一个随机整数。\n示例：\nRANDBETWEEN(12.333, 13.233)只会返回13。\nRANDBETWEEN(11.2, 13.3)有可能返回12或者13。",
    "name": "RANDBETWEEN",
    "type": "MATH"
},
{
    "def": "UPPER(text): 将文本中所有的字符转化为大写。\nText:需要转化为大写字符的文本，或是包含文本的单元格引用。\n示例:\nUPPER(\"notes\")等于\u201cNOTES\u201d。\n如果单元格E5的值为\u201cExamples\u201d，则UPPER(E5)等于\u201cEXAMPLES\u201d。",
    "name": "UPPER",
    "type": "TEXT"
},
{
    "def": "ABS(number): 返回指定数字的绝对值。绝对值是指没有正负符号的数值。\nNumber:需要求出绝对值的任意实数。\n示例:\nABS(-1.5)等于1.5。\nABS(0)等于0。\nABS(2.5)等于2.5。",
    "name": "ABS",
    "type": "MATH"
},
{
    "def": "RIGHT(text,num_chars): 根据指定的字符数从右开始返回文本串中的最后一个或几个字符。\nText:包含需要提取字符的文本串或单元格引用。\nNum_chars:指定RIGHT函数从文本串中提取的字符数。Num_chars不能小于0。如果num_chars大于文本串长度，RIGHT函数将返回整个文本。如果不指定num_chars，则默认值为1。\n示例:\nRIGHT(\"It is interesting\",6)等于\u201cesting\u201d。\nRIGHT(\"Share Holder\")等于\u201cr\u201d。\nRIGHT(\"Huge sale\",4)等于\u201csale\u201d。",
    "name": "RIGHT",
    "type": "TEXT"
},
{
    "def": "TABLEDATAFIELDS(tableData):返回tableData中所有的字段名。\n备注:\n    先从报表数据集中查找，然后再从服务器数据集中查找，返回的是tableData的列名组成的数组。\n以我们提供的数据源FRDemo为例\n新建数据集ds1:SELECT * FROM [CUSTOMER]\nTABLEDATAFIELDS(\"ds1\")等于\nCUSTOMERID,CUSTOMERAME,CITY,COUNTRY,TEL,DISTRICT。",
    "name": "TABLEDATAFIELDS",
    "type": "REPORT"
},
{
    "def": "MEDIAN(array1): 返回数据系列的中值(与Excel的同名函数作用相同)。\n\n示例:\nMEDIAN([1,2,3])=2。\n",
    "name": "MEDIAN",
    "type": "OTHER"
},
{
    "def": "占比公式, =PROPORTION(A1)等同于=A1/sum(A1[!0])",
    "name": "PROPORTION",
    "type": "HA"
},
{
    "def": "COL()返回当前单元格的列号，必须使用于条件属性中\n示例:\n如果当前单元格是A5，在A5中写入\"=col()\"则返回1。\n如果当前单元格是C6，在C6中写入\"=col()\"则返回3。",
    "name": "COL",
    "type": "REPORT"
},
{
    "def": "TOHEX(int): 将一个十进制整型数转换成十六进制表示的字符串。\nint:表示需要进行转换的十进制整数。\n示例:\nTOHEX(15)等于 \"f\"。\nTOHEX(20)等于 \"14\"。",
    "name": "TOHEX",
    "type": "MATH"
},
{
    "def": "COS(number): 返回一个角度的余弦值。\nNumber:以弧度表示的需要求余弦值的角度。\n备注:\n    要把一个角度转换成弧度值，将角度乘于PI()/180。\n    COS(n*2*PI()+number)=COS(number)（其中n为整数，number从-pi到pi）。\n示例:\nCOS(0.5)等于0.877582562。\nCOS(30*PI()/180)等于0.866025404。",
    "name": "COS",
    "type": "MATH"
},
{
    "def": "跨层累计, =CROSSLAYERTOTAL(A1, B1, C1, D1)等同于=IF(&B1 >1, D1[B1:-1] + C1, D1[A1:-1,B1:!-1] + C1), 如需横向, 则传递第五个参数false",
    "name": "CROSSLAYERTOTAL",
    "type": "HA"
},
{
    "def": "POWER(number,power): 返回指定数字的乘幂。\nNumber:底数，可以为任意实数。\nPower:指数。参数number按照该指数次幂乘方。\n备注:\n    可以使用符号\u201c^\u201d代替POWER，如: POWER(5,2)等于5^2。\n示例:\nPOWER(6,2)等于36。\nPOWER(14,5)等于537824。\nPOWER(4,2/3)等于2.519842100。\nPOWER(3,-2.3)等于0.079913677。",
    "name": "POWER",
    "type": "MATH"
},
{
    "def": "DAYS360(start_date,end_date,method):按照一年 360 天的算法（每个月以 30 天计，一年共计 12 个月），\n返回两日期间相差的天数，这在会计计算中将会用到。如果财务系统是基于一年 12 个月，每月 30 天，\n可用此函数帮助计算支付款项。\nStart_date 和 end_date :是用于计算期间天数的起止日期。\nMethod : 它指定了在计算中是采用欧洲方法还是美国方法。\nMethod 定义 :\nFALSE或忽略    美国方法 (NASD)。如果起始日期是一个月的 31 号，则等于同月的 30 号。如果终止日期是一个月的\n31号，并且起始日期早于 30 号，则终止日期等于下一个月的 1 号，否则，终止日期等于本月的 30 号。\nTRUE           欧洲方法。无论是起始日期还是终止日期为一个月的 31 号，都将等于本月的 30 号。\n备注:\nFineReport将日期保存为系列数，一个系列数代表一个与之匹配的日期，以方便用户对日期进行数值式计算。\n在1900年日期系统中，FineReport电子表格将1900年1月1日保存为系列数2，将1900年1月2日保存为系列数3，\n将1900年1月3日保存为系列数4\u2026\u2026依此类推。如在1900年日期系统，1998年1月1日存为系列数35796。\n示例:\nDAYS360(\"1998/1/30\", \"1998/2/1\") 等于 1",
    "name": "DAYS360",
    "type": "DATETIME"
},
{
    "def": "filetype(file)获取文件的类型。\n当file为单文件时，返回文件类型字符串，当file为多文件时，返回文件类型的字符串数组。\n如果file不为文件类型，则返回错误信息。\n示例：\n假设文件控件在B2单元格，而B2单元格依次上传了三个不同类型文件{A.doc, C.xls ,B.txt }，则filetype(B2)返回值为[\u201cdoc\u201d, \u201cxls\u201d, \u201ctxt\u201d]。",
    "name": "FILETYPE",
    "type": "OTHER"
},
{
    "def": "ADDARRAY(array, insertArray, start):在数组第start个位置插入insertArray中的所有元素，再返回该数组。\n示例：\nADDARRAY([3, 4, 1, 5, 7], [23, 43, 22], 3)返回[3, 4, 23, 43, 22, 1, 5, 7].\nADDARRAY([3, 4, 1, 5, 7], \"测试\", 3)返回[3, 4, \"测试\", 1, 5, 7].\n注意：如果start为小于1的数或者不写start参数，则默认从数组的第一位开始插入数组元素。",
    "name": "ADD2ARRAY",
    "type": "ARRAY"
},
{
    "def": "BITNOT(int):将一个十进制整数进行二进制取反运算。\nint:需要进行转换的十进制数。\n示例：\nBITNOT(3)等于-4。\nBITNOT(12)等于-13。",
    "name": "BITNOT",
    "type": "LOGIC"
},
{
    "def": "TABLEAS(connectionName):返回名为connectionName的数据库中的所有表名。\n示例：\n假设在FRDemo这个数据库中，有3个表：a,b,c;\n那么TABLES(\"FRDemo\")等于[a,b,c].",
    "name": "TABLES",
    "type": "REPORT"
},
{
    "def": "",
    "name": "TOBIGDECIMAL",
    "type": "DELETE"
},
{
    "def": "RECORDS(connection, table,field):返回数据库表table中字段名field下的所有元素。\n示例：\n数据库BASE中有个名叫task的表的内容如下：\nname start  end\na    2008   2009\nb    2009   2012\n那么RECORDS(\"BASE\",\"task\",\"end\")等于[2009,2012].\n\nRECORDS(connection, table,field,row)返回table中field字段下的第row行的记录，field可以为列名也可以为列号。\n    RECORDS(\"BASE\",\"task\",\"end\",2)等于2012.\n    RECORDS(\"BASE\",\"task\",2,2)等于2009.",
    "name": "RECORDS",
    "type": "REPORT"
},
{
    "def": "SUMSQ(number1,number2, ...):返回所有参数的平方和。\nnumber1, number2, ...:为 1 到 30 个需要求平方和的参数，也可以使用数组或对数组的引用来代替以逗号分隔的参数。\n示例:\nSUMSQ(3, 4) 等于 25\n",
    "name": "SUMSQ",
    "type": "MATH"
},
{
    "def": "TODOUBLE(text): 将文本转换成Double对象。\nText:需要转换的文本。\n示例:\nTODOUBLE(\"123.21\")等于 new Double(123.21)。",
    "name": "TODOUBLE",
    "type": "TEXT"
},
{
    "def": "TODATE()函数可以将各种日期形式的参数转换为日期类型。\n它有三种参数的形式：\n1 参数是一个日期型的参数，那么直接将这个参数返回。\n示例：\nTODATE(DATE(2007,12,12))返回2007年12月12日组成的日期。\n2 参数是以从1970年1月1日0时0分0秒开始的毫秒数，返回对应的时间。\n示例：\nTODATE(1023542354746)返回2002年6月8日。\n3 参数是日期格式的文本，那么返回这个文本对应的日期。\n示例：\nTODATE(\"2007/10/15\")返回2007年10月5日组成的日期。\nTODATE(\"2007-6-8\")返回2007年6月8日组成的日期。\n4 有两个参数，第一个参数是一个日期格式的文本，第二个参数是用来解析日期的格式。\n示例：\nTODATE(\"1/15/07\",\"mm/dd/yy\")返回07年1月15日组成的日期。\n特别的，\"yyyyMMdd\"是用来解析形如\u201c20081230\u201d之类的日期格式的。比如TODATE(\"20110830\",\"yyyyMMdd\")返回11年08月30日组成的日期\n5 有三个参数，第一个参数是一个日期格式的文本，第二个参数是用来解析日期的格式，第三个参数为解析日期的语言，如：zh（中文），en（英文）。\n示例：\nTODATE(\"星期三 1/15/07\",\"EEE mm/dd/yy\", \"zh\")返回07年1月15日组成的日期，使用\u201czh（中文）\u201d才能够正常解析\u201c星期三\u201d这个字符串。",
    "name": "TODATE",
    "type": "DATETIME"
},
{
    "def": "PROPER(text): 将文本中的第一个字母和所有非字母字符后的第一个字母转化成大写，其他字母变为小写。\nText:需要转化为文本的公式、由双引号引用的文本串或是单元格引用。\n示例:\nPROPER(\"Finemore Integrated Office\")等于\u201cFinemore Integrated Office\u201d。\nPROPER(\"100 percent\")等于\u201c100 Percent\u201d。\nPROPER(\"SpreaDSheEt\")等于\u201cSpreadsheet\u201d。",
    "name": "PROPER",
    "type": "TEXT"
},
{
    "def": "DAY:(serial_number)返回日期中的日。DAY是介于1和31之间的一个数。\nSerial_number:含有所求的年的日期.\n备注:\nFineReport将日期保存为系列数，一个系列数代表一个与之匹配的日期，以方便用户对日期进行数值式计算。\n在1900年日期系统中，FineReport电子表格将1900年1月1日保存为系列数2，将1900年1月2日保存为系列数3，\n将1900年1月3日保存为系列数4\u2026\u2026依此类推。如在1900年日期系统，1998年1月1日存为系列数35796。\n示例:\nDAY(\"2000/1/1\")等于1。\nDAY(\"2006/05/05\")等于5。\nDAY(\"1997/04/20\")等于20。\nDAY(\"2000-1-1\", \"yyyy-MM-dd\")等于1。\nDAY(\"2006-05-05\", \"yyyy-MM-dd\")等于5。\nDAY(\"1997-04-20\", \"yyyy-MM-dd\")等于20。\nDAY(35796)等于1。",
    "name": "DAY",
    "type": "DATETIME"
},
{
    "def": "TABLEDATAS():返回报表数据集和服务器数据集名字。\n示例：\n服务器数据集有：ds1,ds2,ds3;报表数据集有dsr1,dsr2.\nTABLEDATAS()等于[dsr1,dsr2,ds1,ds2,ds3].\n而TABLEDATAS(0)返回服务器数据集名字；TABLEDATAS(1)返回报表数据集名字；\nTABLEDATAS(0)等于[ds1,ds2,ds3];TABLEDATAS(1)等于[dsr1,dsr2].",
    "name": "TABLEDATAS",
    "type": "REPORT"
},
{
    "def": "LUNAR(year,day,month): 返回当前日期对应的农历时间。\nyear,month,day:分别对应年月日。\n示例:\n如果需要查询2011年7月21日对应的农历时间，则只需输入LUNAR(2011,7,21)结果将显示为：辛卯年六月廿一\n同样，如输入LUNAR(2001,7,21)，则显示：辛巳年六月初一 。本公式支持的时间段为1900-2100年。",
    "name": "LUNAR",
    "type": "DATETIME"
},
{
    "def": "TAN(number): 返回指定角度的正切值。\nNumber:待求正切值的角度，以弧度表示。如果参数是以度为单位的，乘以Pi()/180后转换为弧度。\n示例:\nTAN(0.8)等于1.029638557。\nTAN(45*Pi()/180)等于1。",
    "name": "TAN",
    "type": "MATH"
},
{
    "def": "",
    "name": "JVM",
    "type": "DELETE"
},
{
    "def": "LN(number):返回一个数的自然对数。自然对数以常数项 e（2.71828182845904）为底。\nnumber:是用于计算其自然对数的正实数。\n示例:\nLN(86) 等于 4.45437\nLN(2.7182818) 等于 1\nLN(EXP(3)) 等于 3\nEXP(LN(4)) 等于 4\n",
    "name": "LN",
    "type": "MATH"
},
{
    "def": "ARRAY(arg1,arg2...):返回一个由arg1,arg2,...组成的数组.\narg1,arg2,...:字符串或者数字.\n示例:\nARRAY(\"hello\") = [\"hello\"].\nARRAY(\"hello\",\"world\") = [\"hello\",\"world\"].\nARRAY(\"hello\",98) = [\"hello\",98].\nARRAY(67,98) = [67,98].",
    "name": "ARRAY",
    "type": "ARRAY"
},
{
    "def": "TOBINARY(int): 将一个十进制整型数转换成二进制表示的字符串。\nint:表示需要进行转换的十进制整数。\n示例:\nTOBINARY(10)等于 \"1010\"。\nTOBINARY(20)等于 \"10100\"。",
    "name": "TOBINARY",
    "type": "MATH"
},
{
    "def": "NVL(value1,value2,value3,...):在所有参数中返回第一个不是null的值value1:可以为任意数，也可以为null。\nvalue2:可以为任意数，也可以为null。\n当字符串长度为0时, 返回也为null\n示例:\nNVL(12,20)等于12。\nNVL(null,12)等于12。\nNVL(null,null)等于null。\nNVL(20,null)等于20。\nNVL(null,null,10)等于10。",
    "name": "NVL",
    "type": "OTHER"
},
{
    "def": "CORREL(array1,array2): 求两个相同长度数据系列的相关系数(与Excel的同名函数作用相同)。\n如果数组或引用参数包含文本、逻辑值或空白单元格，则这些值将被忽略；但包含零值的单元格将计算在内。\n函数计算结果出现负数表示负相关。相关系数的取值范围是[-1,1]之间的数。相关系数的绝对值越大，表示误差越小。 Array1 和 Array2 的数据点的个数必须相同，例如：\nCORREL([1,2,3],[2,4,6])=1。\n",
    "name": "CORREL",
    "type": "OTHER"
},
{
    "def": "COLNAME(tableData,colIndex)返回的是tableData中列序号colIndex的列名。\ntableData:表示TableData的名字，字符串形式。\ncolIndex:表示列序号。\n备注:\n    TableData先从私有数据源中查找，再从公有数据源中查找。\n示例:\nCOLNAME(\"Check\"，3)等于AcceName。\nCOLNAME(\"country\"，4)等于Area。",
    "name": "COLNAME",
    "type": "REPORT"
},
{
    "def": "DECIMAL(number): 返回number的大数类型，常用于精确计算。",
    "name": "DECIMAL",
    "type": "MATH"
},
{
    "def": "VALUE(tableData,col,row)返回tableData中列号为col的值, 行号为row。\ntableData:tableData的名字，字符串形式的。\nrow:行号。\ncol:列号。\n备注:\n    先从报表数据集中查找，然后再从服务器数据集中查找，返回的是tableData的行数。\n示例:\nVALUE(\"country\",5,3)等于South America。\nVALUE(\"Simple\",8,3)等于jonnason。\n示例：VALUE(\"country\",5,\"大陆\")等于South America。\n\nVALUE(tableData,col)返回tableData中列号为col的一列值。\nVALUE(tableData,targetCol, orgCol, element)返回tableData中第targetCol列中的元素，这些元素对应的第orgCol列的值为element。\n示例：\ntableData : co\n国家 省份\n\n中国 江苏\n中国 浙江\n中国 北京\n美国 纽约\n美国 新泽西\nVALUE(\"co\",2, 1, \"中国\")等于[\"江苏\", \"浙江\", \"北京\"]。\n特别说明：列号也可以写为列名。\nVALUE(tableData,targetCol, orgCol, element, idx)返回VALUE(tableData,targetCol, orgCol, element)数组的第idx个值。\n特别说明：idx的值小于0时，会取数组的第一个值，idx的值大于数组长度时，会取数组的最后一个值。\n",
    "name": "VALUE",
    "type": "REPORT"
},
{
    "def": "CLASS(object):返回object对象的所属的类。",
    "name": "CLASS",
    "type": "OTHER"
},
{
    "def": "JOINARRAY(array,sepa):返回一个由sepa作为分隔符的字符串.\narray:[arg1,arg2...]格式的数组;\nsepa:分隔符。\n示例:\nJOINARRAY([1,2],\";\") = [1;2].\nJOINARRAY([hello,world],\"-\") = [hello-world].",
    "name": "JOINARRAY",
    "type": "ARRAY"
},
{
    "def": "DATETONUMBER(date):返回自 1970 年 1 月 1 日 00:00:00 GMT 经过的毫秒数。\n示例：\nDATETONUMBER(\"2008-08-08\")等于1218124800000。",
    "name": "DATETONUMBER",
    "type": "DATETIME"
},
{
    "def": "PRODUCT(number1,number2, ...):将所有以参数形式给出的数字相乘，并返回乘积值。\nnumber1, number2, ...:为 1 到 30 个需要相乘的数字参数。\n示例:\nPRODUCT(3,4) 等于 12\nPRODUCT(3,4,5) 等于 60\n\n",
    "name": "PRODUCT",
    "type": "MATH"
},
{
    "def": "INDEXOF(str1，index):返回字符串str1在index位置上的字符。\n备注:\n    index是从0开始计数的。\n示例:\nINDEXOF(\"FineReport\",0)等于'F'。\nINDEXOF(\"FineReport\",2)等于'n'。\nINDEXOF(\"FineReport\",9)等于't'。\n\nINDEXOF(array, index):返回数组在index位置上的元素。\n备注：\n    index是从1开始计数的。\n示例：\nString[] array = {\"a\", \"b\", \"c\"}\nINDEXOF(array, 1)等于\"a\".\n",
    "name": "INDEXOF",
    "type": "TEXT"
},
{
    "def": "ACOS(number): 返回指定数值的反余弦值。反余弦值为一个角度，返回角度以弧度形式表示。\nNumber:需要返回角度的余弦值。\n备注:\n    函数的参数必须在-1和1之间，包括-1和1。\n    返回的角度值在0和Pi之间。\n    如果要把返回的角度用度数来表示，用180/PI()乘返回值即可。\n示例:\nACOS(1)等于0（弧度）。\nACOS(0.5)等于1.047197551（Pi/3弧度）。\nACOS(0.5)*180/PI()等于60（度）。",
    "name": "ACOS",
    "type": "MATH"
},
{
    "def": "FIND(find_text,within_text,start_num):从指定的索引(start_num)处开始，返回第一次出现的指定子字符串(find_text)在此字符串(within_text)中的索引。\nFind_text:需要查找的文本或包含文本的单元格引用。\nWithin_text:包含需要查找文本的文本或单元格引用。\nStart_num:指定进行查找字符的索引位置。within_text里的索引从1开始。如果省略start_num，则假设值为1。\n备注:\n    如果find_text不在within_text中，FIND函数返回值为0。\n    如果start_num不大于0，FIND函数返回错误信息*VALUE!。\n    如果start_num大于within_text的长度，FIND函数返回值为0。\n    如果find_text是空白文本，FIND函数将在搜索串中匹配第一个字符（即编号为start_num或1的字符）。\n示例:\nFIND(\"I\",\"Information\")等于1。\nFIND(\"i\",\"Information\")等于9。\nFIND(\"o\",\"Information\",2)等于4。\nFIND(\"o\",\"Information\",12)等于0。\nFIND(\"o\",\"Information\",-1)等于*VALUE!。",
    "name": "FIND",
    "type": "TEXT"
},
{
    "def": "MINUTE(serial_number):返回某一指定时间的分钟数，其值是介于0与59之间的一个整数。\nserial_number:包含所求分钟数的时间。\n示例:\nMINUTE(\"15:36:25\")等于36。\nMINUTE(\"15:36:25\", \"HH:mm:ss\")等于36。",
    "name": "MINUTE",
    "type": "DATETIME"
},
{
    "def": "SIGN(number):返回数字的符号。当数字为正数时返回 1，为零时返回 0，为负数时返回 -1。\nNumber:为任意实数。\n示例:\nSIGN(10) 等于 1\nSIGN(4-4) 等于 0\nSIGN(-0.00001) 等于 -1\n",
    "name": "SIGN",
    "type": "MATH"
},
{
    "def": "INDEX(key,val1,val2,...):返回key在val1,val2,...所组成的序列中的位置,不存在于序列中则返回参数的个数.\n备注:\n    key和valn可以是任意类型\n示例:\nINDEX(2,2)等于1。\nINDEX(2,1,2)等于2。\nINDEX(2,4,5,6)等于4。\nINDEX(\"b\",\"b\",\"o\",\"y\")等于1。",
    "name": "INDEX",
    "type": "OTHER"
},
{
    "def": "REVERSE(value):返回与value相反的逻辑值。\n示例：\nREVERSE(true)等于false。",
    "name": "REVERSE",
    "type": "LOGIC"
},
{
    "def": "REPLACE(text, texttoreplace, replacetext):根据指定字符串，用其他文本来代替原始文本中的内容。\ntext：需要被替换部分字符的文本或单元格引用。\ntexttoreplace：指定的字符串或正则表达式。\nreplacetext:需要替换部分旧文本的文本。\n示例：\nREPLACE(\"abcd\", \"a\", \"re\")等于\"rebcd\"。\nREPLACE(\"a**d\", \"**d\", \"rose\")等于\"arose\"。\nREPLACE(old_text,start_num,num_chars,new_text): 根据指定的字符数，用其他文本串来替换某个文本串中的部分内容。\nOld_text:需要被替换部分字符的文本或单元格引用。\nStart_num:需要用new_text来替换old_text中字符的起始位置。\nNum_chars:需要用new_text来替换old_text中字符的个数。\nNew_text:需要替换部分旧文本的文本。\n示例:\nREPLACE(\"0123456789\",5,4,\"*\")等于\u201c0123*89\u201d。\nREPLACE(\"1980\",3,2,\"99\")等于\u201c1999\u201d。",
    "name": "REPLACE",
    "type": "TEXT"
},
{
    "def": "UUID():返回随机的UUID。\n示例:UUID()返回36位随机机器数。\n       UUID(32)返回32位随机机器数。",
    "name": "UUID",
    "type": "OTHER"
},
{
    "def": "DATESUBDATE(date1, date2, op):返回两个日期之间的时间差。\nop表示返回的时间单位：\n\"s\"，以秒为单位。\n\"m\"，以分钟为单位。\n\"h\"，以小时为单位。\n\"d\"，以天为单位。\n\"w\"，以周为单位。\n示例：\nDATESUBDATE(\"2008-08-08\", \"2008-06-06\",\"h\")等于1512。",
    "name": "DATESUBDATE",
    "type": "DATETIME"
},
{
    "def": "CONCATENATE(text1,text2,...): 将数个字符串合并成一个字符串。\nText1,text2,...:需要合并成单个文本的文本项，可以是字符，数字或是单元格引用。\n示例:\nCONCATENATE(\"Average \",\"Price\")等于\u201cAverage Price\u201d。\nCONCATENATE(\"1\",\"2\")等于12。",
    "name": "CONCATENATE",
    "type": "TEXT"
},
{
    "def": "filesize(file)获取文件的大小，单位为Kb。\n当file为单文件时，返回文件大小，当file为多文件时，返回文件大小的数组。\n如果file不为文件类型，则返回错误信息。\n示例：\n假设文件控件在B2单元格，而B2单元格依次上传了两个大小分别为100字节和10240字节的文件，则filename(B2)返回值为[0.098, 10.0]。",
    "name": "FILESIZE",
    "type": "OTHER"
},
{
    "def": "DAYSOFMONTH(date):返回从1900年1月后某年某月包含的天数。\n示例：\nDAYSOFMONTH(\"1900-02-01\")等于28。\nDAYSOFMONTH(\"2008/04/04\")等于30。",
    "name": "DAYSOFMONTH",
    "type": "DATETIME"
},
{
    "def": "DATEINQUARTER(date, number): 函数返回在某一个季度当中第几天的日期。\n示例：\nDATEINQUARTER(\"2009-05-05\", 20)等于 2009-04-20。",
    "name": "DATEINQUARTER",
    "type": "DATETIME"
},
{
    "def": "逐层累计, =LAYERTOTAL(B1, C1, D1)等同于=D1[B1:-1] + C1, 如需横向, 则传递第四个参数false.如LAYERTOTAL(B1, C1, D1, false)",
    "name": "LAYERTOTAL",
    "type": "HA"
},
{
    "def": "CNMONEY(number,unit)返回人民币大写。\nnumber:需要转换的数值型的数。\nunit:单位，\"s\",\"b\",\"q\",\"w\",\"sw\",\"bw\",\"qw\",\"y\",\"sy\",\"by\",\"qy\",\"wy\"分别代表\u201c拾\u201d，\u201c佰\u201d，\u201c仟\u201d，\u201c万\u201d，\u201c拾万\u201d，\u201c佰万\u201d，\u201c仟万\u201d，\u201c亿\u201d，\u201c拾亿\u201d，\u201c佰亿\u201d，\u201c仟亿\u201d，\u201c万亿\u201d。\n备注:\n    单位可以为空，如果为空，则直接将number转换为人民币大写，否则先将number与单位的进制相乘，然后再将相乘的结果转换为人民币大写。\n示例:\nCNMONEY(1200)等于壹仟贰佰圆整。\nCNMONEY(12.5,\"w\")等于壹拾贰万伍仟圆整。\nCNMONEY(56.3478,\"bw\")等于伍仟陆佰叁拾肆万柒仟捌佰圆整。\nCNMONEY(3.4567,\"y\")等于叁亿肆仟伍佰陆拾柒万圆整。",
    "name": "CNMONEY",
    "type": "TEXT"
},
{
    "def": "DAYVALUE(date):返回1900年至 date日期所经历的天数。\n示例：\nDAYVALUE(\"2008/08/08\")等于39668。",
    "name": "DAYVALUE",
    "type": "DATETIME"
},
{
    "def": "SQL(connectionName,sql,columnIndex,rowIndex)返回通过sql语句从connectionName中获得数据表的第columnIndex列第rowIndex行所对应的元素。\nconnectionName：数据库库的名字，字符串形式；\nsql:SQL语句，字符串形式；\ncolumnIndex:列序号，整形;\nrowIndex:行序号，整形。\n备注:行序号可以不写，这样返回值为数据列。\n示例：\n以我们提供的数据源HSQL为例\nSQL(\"HSQL\",\"SELECT * FROM CUSTOMER\",2,2)等于王先生。",
    "name": "SQL",
    "type": "REPORT"
},
{
    "def": "DATE(year,month,day): 返回一个表示某一特定日期的系列数。\nYear:代表年，可为一到四位数。\nMonth:代表月份。\n若1 month 12，则函数把参数值作为月。\n若month>12，则函数从年的一月份开始往上累加。例如: DATE(2000,25,2)等于2002年1月2日的系列数。\nDay:代表日。\n若日期小于等于某指定月的天数，则函数将此参数值作为日。\n若日期大于某指定月的天数，则函数从指定月份的第一天开始往上累加。若日期大于两个或多个月的总天数，则函数把减去两个月或多个月的余数加到第三或第四个月上，依此类推。例如:DATE(2000,3,35)等于2000年4月4日的系列数。\n备注:\n   若需要处理公式中日期的一部分，如年或月等，则可用此公式。\n   若年，月和日是函数而不是函数中的常量，则此公式最能体现其作用。\n示例:\nDATE(1978, 9, 19) 等于1978-09-19.\nDATE(1211, 12, 1) 等于1211-12-01.   ",
    "name": "DATE",
    "type": "DATETIME"
},
{
    "def": "BITOPERATIOIN(int,int,op) 位运算，返回两个整数根据op进行位运算后的结果。\nint:十进制整数。\nop:位运算操作符，支持\"&\"(与),\"|\"(或),\"^\"(异或),\"<<\"(左移),\">>\"(右移)。\n示例：\nBITOPERATION(4,2,\"&\")表示4与2进行\"与\"运算,结果等于0。\nBITOPERATION(4,2,\"|\")表示4与2进行\"或\"运算,结果等于6。\nBITOPERATION(4,2,\"^\")表示4与2进行\"异或\"运算,结果等于6。\nBITOPERATION(4,2,\"<<\")表示4按位左移2位，结果等于16。\nBITOPERATION(4,2,\">>\")表示4按位右移2位，结果等于1。\nBITOPERATION(4,2,\"^~\")表示4与2进行\"同或\"运算,结果为-7。",
    "name": "BITOPERATION",
    "type": "LOGIC"
},
{
    "def": "LOWER(text): 将所有的大写字母转化为小写字母。\nText:需要转化为小写字母的文本串。LOWER函数不转化文本串中非字母的字符。\n示例:\nLOWER(\"A.M.10:30\")等于\u201ca.m.10:30\u201d。\nLOWER(\"China\")等于\u201cchina\u201d。",
    "name": "LOWER",
    "type": "TEXT"
},
{
    "def": "CEILING(number): 将参数number沿绝对值增大的方向，舍入为最接近的整数\nNumber:指待舍入的数值。\nCEILING(-2.5)等于-3。\nCEILING(0.5)等于1。",
    "name": "CEILING",
    "type": "MATH"
},
{
    "def": "SINH(number):返回某一数字的双曲正弦值。\nnumber:为任意实数。\n示例:\nSINH(1) 等于 1.175201194\nSINH(-1) 等于 -1.175201194",
    "name": "SINH",
    "type": "MATH"
},
{
    "def": "NOW():获取当前时间。\n示例：\n如果系统时间是2012年5月12日 15点18分38秒\n则NOW()等于2012-05-12 15:18:36。",
    "name": "NOW",
    "type": "DATETIME"
},
{
    "def": "AND(logical1,logical2,\u2026): 当所有参数的值为真时，返回TRUE；当任意参数的值为假时，返回FALSE。\nLogical1,logical2,\u2026:指1到30个需要检验TRUE或FALSE的条件值。\n备注:\n    参数必须是逻辑值，或是含有逻辑值的数组或引用。\n    如果数组或引用中含有文本或空的单元格，则忽略其值。\n    如果在指定的单元格区域中没有逻辑值，AND函数将返回错误信息*NAME?。\n示例:\nAND(1+7=8,5+7=12)等于TRUE。\nAND(1+7=8,5+7=11)等于FALSE。\n如果单元格A1到A4的值分别为TRUE、TRUE、FALSE和TRUE，则:\nAND(A1:A4)等于FALSE。\n如果单元格A5的值在0~50之间，则: AND(0<A5,A5<50)等于TRUE。",
    "name": "AND",
    "type": "LOGIC"
},
{
    "def": "排名公式, =SORT(A1)等同于=COUNT(A1[!0]{A1 > $A1}) + 1, 默认升序排列, 如需要降序, 则传递参数false,\n =SORT(A1, false)等同于=COUNT(A1[!0]{A1 < $A1}) + 1.",
    "name": "SORT",
    "type": "HA"
},
{
    "def": "SIN(number): 计算给定角度的正弦值。\nNumber:待求正弦值的以弧度表示的角度。\n备注:\n    如果参数的单位是度，将其乘以PI()/180即可转换成弧度。\n示例:\nSIN(10)等于-0.5440211108893698。\nSIN(45*PI()/180)等于0.707106781。",
    "name": "SIN",
    "type": "MATH"
},
{
    "def": "switch(表达式, 值1, 结果1, 值2, 结果2, ...)\n如果表达式的结果是值1，整个函数返回结果1\n如果表达式的结果是值2，整个函数返回结果2\n如果表达式的结果是值3，整个函数返回结果3\n等等\n",
    "name": "SWITCH",
    "type": "LOGIC"
},
{
    "def": "ROW()返回当前单元格的行号，必须使用于条件属性中\n示例:\n如果当前单元格为A5，在A5中写入\"=ROW()\"则返回5。\n如果当前单元格为B8，在B8中写入\"=ROW()\"则返回8。",
    "name": "ROW",
    "type": "REPORT"
},
{
    "def": "EVAL(exp)返回表达式exp计算后的结果。\nexp:一个表达式形式字符串。\n备注:\n    只要EVAL中的参数exp最终可以转化成一表达式形式的字符串，比如\"sum(2,4)\",\"2+7\"等等，那么它就可以被计算。\nEVAL(\"2+5\")等于7。\nEVAL(\"count(2,3)\")等于2。\nEVAL(\"sum\"+\"(2,3,5)\")等于10。\nEVAL(IF(true, \"sum\", \"count\") + \"(1,2,3,4)\")等于10。\nEVAL(IF(false, \"sum\", \"count\") + \"(1,2,3,4)\")等于4。",
    "name": "EVAL",
    "type": "OTHER"
},
{
    "def": "ATAN(number): 计算指定数值的反正切值。指定数值是返回角度的正切值，返回角度以弧度形式表示。\nNumber:返回角度的正切。\n备注:\n    返回角度在-pi/2到pi/2之间。\n    如果返回角度等于-pi/2或pi/2，ATAN将返回错误信息*NUM!。\n    用角度形式返回数值时，返回数值乘以180/PI()。\n示例:\nATAN(-1)等于-0.785398163（-pi/4弧度）。\nATAN(0)等于0（弧度）。\nATAN(2)*180/PI()等于63.43494882（度）。",
    "name": "ATAN",
    "type": "MATH"
},
{
    "def": "RANGE(from，to，step)函数表示从整数from开始，以step为每一步的大小，直到整数to的一个数字序列。\n例如：\nRANGE(1,5,1)表示从1开始，直到5(包括5)，每一步大小为1，那么它返回一个数字序列为[1,2,3,4,5]。\nRANGE(-1,6,2)表示从-1开始，直到6(包括6)，每一步大小为2，那么它返回一个数字序列为[-1,1,3,5]。\n备注：RANGE函数有三种参数形式：\n1 RANGE(to)，默认的from为1，step为1，例如：\n  RANGE(4)返回[1,2,3,4]。\n  RANGE(-5)返回[]。\n2 RANGE(from,to)，默认的step为1，例如:\n  RANGE(-1,3)返回[-1,0,1,2,3]。\n  RANGE(0,5)返回[0,1,2,3,4,5]。\n3 RANGE(from,to,step)，三个参数的情况参照上面的注释，例如：\n  RANGE(6,-1,-2)返回[6,4,2,0]。\n  RANGE(4,1,1)返回[]。",
    "name": "RANGE",
    "type": "ARRAY"
},
{
    "def": "TANH(number):返回某一数字的双曲正切值。\nnumber:为任意实数。\n双曲正切的计算公式如下：\n示例:\nTANH(-2) 等于 -0.96403\nTANH(0) 等于 0\nTANH(0.5) 等于 0.462117\n",
    "name": "TANH",
    "type": "MATH"
},
{
    "def": "ROUNDDOWN(number,num_digits):靠近零值，向下（绝对值减小的方向）舍入数字。\nnumber:为需要向下舍入的任意实数。\nnum_digits:舍入后的数字的位数。\n函数 ROUNDDOWN 和函数 ROUND 功能相似，不同之处在于函数 ROUNDDOWN 总是向下舍入数字。\n示例:\nROUNDDOWN(3.2, 0) 等于 3\nROUNDDOWN(76.9,0) 等于 76\nROUNDDOWN(3.14159, 3) 等于 3.141\nROUNDDOWN(-3.14159, 1) 等于 -3.1\nROUNDDOWN(31415.92654, -2) 等于 31,400\n",
    "name": "ROUNDDOWN",
    "type": "MATH"
},
{
    "def": "循环引用, =CIRCULAR(A1, B1, C1, D1)等同于=IF(&A1 = 1, 0, B1[A1:-1] + C1[A1:-1] \u2013 D1[A1:-1]),如需横向, 则传递第五个参数false",
    "name": "CIRCULAR",
    "type": "HA"
},
{
    "def": "HOUR(serial_number):返回某一指定时间的小时数。函数指定HOUR为0（0:00）到23（23:00)之间的一个整数。\nSerial_number:包含所求小时的时间。\n示例:\nHOUR(\"11:32:40\")等于11。\nHOUR(\"11:32:40\", \"HH:mm:ss\")等于11。",
    "name": "HOUR",
    "type": "DATETIME"
},
{
    "def": "ROUND(number,num_digits):返回某个数字按指定位数舍入后的数字。\nnumber:需要进行舍入的数字。\nnum_digits:指定的位数，按此位数进行舍入。\n如果 num_digits 大于 0，则舍入到指定的小数位。\n如果 num_digits 等于 0，则舍入到最接近的整数。\n如果 num_digits 小于 0，则在小数点左侧进行舍入。\n示例:\nROUND(2.15, 1) 等于 2.2\nROUND(2.149, 1) 等于 2.1\nROUND(-1.475, 2) 等于 -1.48\nROUND(21.5, -1) 等于 20\n因浮点数存在精度计算丢失问题, 导致计算结果里可能带上9999, 0000这些, \n因此加入第三个参数来控制是否需要去除9999. true表示需要过滤9999, 0000这些数据.",
    "name": "ROUND",
    "type": "MATH"
},
{
    "def": "YEARDELTA(date, delta):返回指定日期后delta年的日期。\n示例：\nYEARDELTA(\"2008-10-10\",10)等于2018-10-10。",
    "name": "YEARDELTA",
    "type": "DATETIME"
},
{
    "def": "DATEINYEAR(date, number):函数返回在一年当中第几天的日期。\n示例：\nDATEINYEAR(2008,100)等于2008-04-09，等价于DATEINYEAR(\"2008-08-08\",100)，也返回2008-04-09.\nDATEINYEAR(2008,-1)等于2008-12-31，等价于DATEINYEAR(\"2008-08-08\",-1)，也返回2008-12-31.",
    "name": "DATEINYEAR",
    "type": "DATETIME"
},
{
    "def": "ASIN(number): 返回指定数值的反正弦值。反正弦值为一个角度，返回角度以弧度形式表示。\nNumber:需要返回角度的正弦值。\n备注:\n    指定数值必须在-1到1之间（含1与-1）。\n    返回角度在-pi/2到pi/2之间（含-pi/2与pi/2）。\n    用角度形式返回数值时，返回数值乘以180/PI()。\n示例:\nASIN(0.5)等于0.523598776（pi/6弧度）。\nASIN(1)等于1.570796327（pi/2弧度）。\nASIN(0.5)*180/PI()等于30（度）。",
    "name": "ASIN",
    "type": "MATH"
},
{
    "def": "WEIGHTEDAVERAGE(A1:A4,B1:B4): 返回指定数据的加权平均值。\n加权平均数是不同比重数据的平均数，加权平均数就是把原始数据按照合理的比例来计算。\nA1:A4,B1:B4:用于计算平均值的参数，A1~A4为数据，B1~B4为权值。\n示例:\n如果A1:A4为10,9,8,7，B1:B4为0.2,0.1,0.3,0.4则:\nWEIGHTEDAVERAGE(A1:A4,B1:B4)等于8.1。",
    "name": "WEIGHTEDAVERAGE",
    "type": "MATH"
},
{
    "def": "INT(number): 返回数字下舍入（数值减小的方向）后最接近的整数值。\nNumber:需要下舍入为整数的实数。\n示例:\nINT(4.8)等于4。\nINT(-4.8)等于-5。\nINT(4.3)等于4。\nINT(-4.3)等于-5。\n公式INT(A1)将返回A1单元格中的一个正实数的整数数部分。",
    "name": "INT",
    "type": "MATH"
},
{
    "def": "REGEXP(str, pattern):字符串str是否与正则表达式pattern相匹配。\n示例：\nREGEXP(\"aaaaac\",\"a*c\")等于true。\nREGEXP(\"abc\",\"a*c\")等于false。\n\nREGEXP(str, pattern,  intNumber):字符串str是否与具有给定模式 intNumber的正则表达式pattern相匹配。\n示例：\nCASE_INSENSITIVE = 0         启用不区分大小写的匹配。 默认情况下，不区分大小写的匹配假定仅匹配 US-ASCII 字符集中的字符。可以通过指                                                         定 UNICODE_CASE 标志连同此标志来启用 Unicode 感知的、不区分大小写的匹配。 \nMULTILINE = 1                          启用多行模式。\nDOTALL = 2                               启用 dotall 模式。在 dotall 模式中，表达式 . 可以匹配任何字符，包括行结束符。默认情况下，此表达式不匹配行                                                         结束符。\nUNICODE_CASE = 3               启用 Unicode 感知的大小写折叠。指定此标志后，由 CASE_INSENSITIVE 标志启用时，不区分大小写的匹配将以                                                        符合 Unicode Standard 的方式完成。\nCANON_EQ = 4                         启用规范等价。 指定此标志后，当且仅当其完整规范分解匹配时，两个字符才可视为匹配。\nUNIX_LINES = 5                        启用 Unix 行模式。 在此模式中，.、^ 和 $ 的行为中仅识别 '\\n' 行结束符。\nLITERAL = 6                               启用模式的字面值解析。 指定此标志后，指定模式的输入字符串就会作为字面值字符序列来对待。输入序列中的                                                          元字符或转义序列不具有任何特殊意义。 标志 CASE_INSENSITIVE 和 UNICODE_CASE 在与此标志一起使用时将                                                        对匹配产生影响。其他标志都变得多余了。\nCOMMENTS = 7                        模式中允许空白和注释。 此模式将忽略空白和在结束行之前以 # 开头的嵌入式注释。\n \nREGEXP(\"Aaaaabbbbc\",\"a*b*c\", 3)等于true。\nREGEXP(\"Aaaaabbbbc\",\"a*b*c\", 1)等于false。\n\n",
    "name": "REGEXP",
    "type": "TEXT"
},
{
    "def": "GETUSERJOBTITLES():返回角色职务\n示例:\nGETUSERDEPARTMENTS():返回角色所有职务，若多个部门职务则返回职务数组",
    "name": "GETUSERJOBTITLES",
    "type": "OTHER"
},
{
    "def": "DAYSOFQUARTER(date): 返回从1900年1月后某年某季度的天数。\n示例：\nDAYSOFQUARTER(\"2009-02-01\")等于90。\nDAYSOFQUARTER(\"2009/05/05\")等于91。",
    "name": "DAYSOFQUARTER",
    "type": "DATETIME"
},
{
    "def": "AVERAGE(number1,number2,\u2026,countstring): 返回指定数据的平均值。\nNumber1,number2\u2026:用于计算平均值的参数; countString:文字、逻辑值是否参与计数。\n备注:\n    参数必须是数字，或是含有数字的名称，数组或引用。\n    如果数组或引用参数中含有文字，逻辑值，默认参与计数，countString为false则不参与计数；\n    空单元格始终不参与计数，但是，单元格中的零值参与。\n示例:\n如果A1:A6被命名为\u201cages\u201d，分别等于10，23，文字，29，33及25，则:\nAVERAGE(A1:A6)等于20。\nAVERAGE(A1:A6, false)等于24。\nAVERAGE(ages)等于20。\n如果还有一个年龄为27的，求所有年龄的平均值为: AVERAGE(A1:A6,27)等于21。",
    "name": "AVERAGE",
    "type": "MATH"
},
{
    "def": "RADIANS(angle): 将角度转换成弧度。\nAngle:需要转换为弧度的角度。\n示例:\nRADIANS(90)等于1.570796327（π/2弧度）。",
    "name": "RADIANS",
    "type": "MATH"
},
{
    "def": "REMOVEARRAY(array, start, deleteCount):从数组array中删除从第start个元素开始的deleteCount个数组元素，并返回删除后的数组。\n示例：\nREMOVEARRAY([3, 4, 4, 2, 6, 7, 87], 4, 2)返回[3, 4, 4, 7, 87].\n",
    "name": "REMOVEARRAY",
    "type": "ARRAY"
},
{
    "def": "WEBIMAGE(path):在web页面上显示指定路径下的图片。",
    "name": "WEBIMAGE",
    "type": "OTHER"
},
{
    "def": "WEEK(serial_num):返回一个代表一年中的第几周的数字。\nSerial_num:表示输入的日期。\n备注:\nFineReport将日期保存为系列数，一个系列数代表一个与之匹配的日期，以方便用户对日期进行数值式计算。\n在1900年日期系统中，FineReport电子表格将1900年1月1日保存为系列数2，将1900年1月2日保存为系列数3，\n将1900年1月3日保存为系列数4\u2026\u2026依此类推。如在1900年日期系统，1998年1月1日存为系列数35796。\n示例:\nWEEK(\"2010/1/1\")等于52。\nWEEK(\"2010/1/6\")等于1。\nWEEK(35796)等于1。",
    "name": "WEEK",
    "type": "DATETIME"
},
{
    "def": "filename(file)获取文件的文件名。\n当file为单文件时，返回文件名字符串，当file为多文件时，返回文件名的字符串数组。\n如果file不为文件类型，则返回错误信息。\n示例：\n假设文件控件在B2单元格，而B2单元格依次上传了三个不同类型文件{A.doc, C.xls ,B.cpt }，则filename(B2)返回值为[\u201cA.doc\u201d, \u201cC.xls\u201d, \u201cB.cpt\u201d]。",
    "name": "FILENAME",
    "type": "OTHER"
},
{
    "def": "COSH(number): 返回一个数值的双曲线余弦值。\nNumber:需要求其双曲线余弦值的一个实数。\n备注:\n   双曲线余弦值计算公式为: ，其中e是自然对数的底，e=2.71828182845904。\n示例:\nCOSH(3)等于10.06766200。\nCOSH(5)等于74.20994852。\nCOSH(6)等于201.7156361。",
    "name": "COSH",
    "type": "MATH"
},
{
    "def": "OR(logical1,logical2,\u2026): 当所有参数的值为假时，返回FALSE；当任意参数的值为真时，返回TRUE。\nLogical1,logical2,\u2026:指1到30个需要检验TRUE或FALSE的条件值。\n备注:\n    参数必须是逻辑值，或是含有逻辑值的数组或引用。\n    如果数组或引用中含有文本或空的单元格，则忽略其值。\n    如果在指定的单元格区域中没有逻辑值，AND函数将返回错误信息*NAME?。\n示例:\nOR(1+7=9,5+7=11)等于FALSE。\nOR(1+7=8,5+7=11)等于TRUE。",
    "name": "OR",
    "type": "LOGIC"
},
{
    "def": "MOD(number,divisor):返回两数相除的余数。结果的正负号与除数相同。\nnumber:为被除数。\ndivisor:为除数。\n示例:\nMOD(3, 2) 等于 1\nMOD(-3, 2) 等于 1\nMOD(3, -2) 等于 -1\nMOD(-3, -2) 等于 -1\n",
    "name": "MOD",
    "type": "MATH"
},
{
    "def": "WEEKDAY(Serial_number):获取日期并返回星期数。返回值为介于0到6之间的某一整数，分别代表星期中的某一天（从星期日到星期六）。\nSerial_number:输入的日期\n备注:\nFineReport将日期保存为系列数，一个系列数代表一个与之匹配的日期，以方便用户对日期进行数值式计算。\n在1900年日期系统中，FineReport电子表格将1900年1月1日保存为系列数2，将1900年1月2日保存为系列数3，\n将1900年1月3日保存为系列数4\u2026\u2026依此类推。如在1900年日期系统，1998年1月1日存为系列数35796。\n举例:\nWEEKDAY(\"2005/9/10\")等于6（星期六）。\nWEEKDAY(\"2005/9/11\")等于0（星期日）。\nWEEKDAY(35796)等于4（星期四）。\n",
    "name": "WEEKDAY",
    "type": "DATETIME"
},
{
    "def": "TODAY():获取当前日期。\n示例：\n如果系统日期是2005年9月10日\n则TODAY()等于2005-9-10。",
    "name": "TODAY",
    "type": "DATETIME"
},
{
    "def": "ROUND5(number,num_digits):这个是四舍五入，奇进偶不进。\nnumber:需要进行舍入的数字。\nnum_digits:指定的位数，按此位数进行舍入。\n如果 num_digits 大于 0，则舍入到指定的小数位。\n如果 num_digits 等于 0，则舍入到最接近的整数。\n如果 num_digits 小于 0，则在小数点左侧进行舍入。\n示例:\nROUND5(2.125, 2) 等于 2.12\nROUND5(2.135, 2) 等于 2.14\n",
    "name": "ROUND5",
    "type": "MATH"
},
{
    "def": "ROUNDUP(number,num_digits):远离零值，向上（绝对值增大的方向）舍入数字。\nnumber:为需要向上舍入的任意实数。\nnum_digits:舍入后的数字的位数。\n函数 ROUNDUP 和函数 ROUND 功能相似，不同之处在于函数 ROUNDUP 总是向上舍入数字。\n示例:\nROUNDUP(3.2,0) 等于 4\nROUNDUP(76.9,0) 等于 77\nROUNDUP(3.14159, 3) 等于 3.142\nROUNDUP(-3.14159, 1) 等于 -3.2\nROUNDUP(31415.92654, -2) 等于 31,500\n\n",
    "name": "ROUNDUP",
    "type": "MATH"
},
{
    "def": "环比公式, =MOM(A1, B1)等同于=IF(&A1 > 1, B1 / B1[A1:-1],0), 其中如果需要指定偏移量x, 则传递第三个参数x, 第四个参数表示横纵向.\n如=MOM(A1, B1, -2, false)等同于=IF(&A1 > 1, B1 / B1[;A1:-2], 0)",
    "name": "MOM",
    "type": "HA"
},
{
    "def": "TIME(hour,minute,second): 返回代表指定时间的小数。介于0:00:00（12:00:00 A.M.）与23:59:59（11:59:59 P.M.）之间的时间可返回0到0.99999999之间的对应数值。\nHour:介于0到23之间的数。\nMinute:介于0到59之间的数。\nSecond:介于0到59之间的数。\n示例:\nTIME(14,40,0)等于2:40 PM。\nTIME(19,43,24)等于7:43 PM。",
    "name": "TIME",
    "type": "DATETIME"
},
{
    "def": "ASINH(number): 返回指定数值的反双曲正弦值。反双曲正弦值的双曲正弦等于指定数值。即: ASINH(SINH(number))=number。\nNumber:任意实数。\n示例:\nASINH(-5)等于-2.312438341。\nASINH(8)等于2.776472281。\nASINH(16)等于3.466711038。",
    "name": "ASINH",
    "type": "MATH"
},
{
    "def": "EENNUMBER(value)：将给定的BigDecimal类型的数字（100以内）取整后转化成英文金额的字符串。\n示例：\nENNUMBER(23.49)等于TWENTY THREE。\n注：若出现结果为空，需要将数字强制转换为BigDecimal类型，例如：ENNUMBER(TOBIGDECIMAL(80))",
    "name": "ENNUMBER",
    "type": "TEXT"
},
{
    "def": "CODE(text): 计算文本串中第一个字符的数字代码。返回的代码对应于计算机使用的字符集。\nText:需要计算第一个字符代码的文本或单元格引用。\n示例:\nCODE(\"S\")等于83。\nCODE(\"Spreadsheet\")等于83。",
    "name": "CODE",
    "type": "TEXT"
},
{
    "def": "DEGREES(angle): 将弧度转化为度。\nangle:待转换的弧度角。\n示例:\nDEGREES(PI()/2)等于90。\nDEGREES(3.1415926)等于179.9999969。",
    "name": "DEGREES",
    "type": "MATH"
},
{
    "def": "LEN(args): 返回文本串中的字符数或者数组的长度。\n需要注意的是：参数args为文本串时，空格也计为字符。\n参数args为数组时，直接返回数组长度。\n示例:\nLEN(\"Evermore software\")等于17。\nLEN(\" \")等于1。\nLEN(['a','b'])等于2。\n",
    "name": "LEN",
    "type": "TEXT"
},
{
    "def": "DATETIME():获取当前日期和时间。\n示例：\n如果系统时间是2005年9月10日 15点18分38秒\n则DATETIME()等于2005-9-10 15:18:36。",
    "name": "DATETIME",
    "type": "DELETE"
},
{
    "def": "UNIQUEARRAY(array):去掉数组array中的重复元素。\n示例：\nUNIQUEARRAY([14, 2, 3, 4, 3, 2, 5, 6, 2, 7, 9, 12, 3])返回[14, 2, 3, 4, 5, 6, 7, 9, 12].",
    "name": "UNIQUEARRAY",
    "type": "ARRAY"
},
{
    "def": "PROMOTION(value1,value2):返回value2在value1上提升的比例。\n示例：\nPROMOTION(12, 14)等于0.166666666，即提升了16.6666666%.\nPROMOTION(-12, 14)等于2.166666666，即提升了216.6666666%.",
    "name": "PROMOTION",
    "type": "MATH"
},
{
    "def": "PI(number): 是一个数学常量函数，当number为空时，函数返回精确到15位的数值3.141592653589793；当参数不为空时，number表示PI的倍数。\n示例:\nSIN(PI()/2)等于1。\n计算圆的面积的公式: S=PI()*(r^2)，其中S为圆的面积，R为圆的半径。\nPI(3)等于9.42477796076938。",
    "name": "PI",
    "type": "MATH"
},
{
    "def": "ISNULL(object):判断对象中所有的值是否全部都是NULL或者为空字符串。",
    "name": "ISNULL",
    "type": "OTHER"
},
{
    "def": "LET(变量名,变量值,变量名,变量值,..., 表达式):局部变量赋值函数,参数的个数N必须为奇数, 最后一个是表达式，前面是N-1(偶数)为局部变量赋值对。\n变量名: 必须是合法的变量名，以字母开头，可以包括字母，数字和下划线\n表达式: 根据前面的N-1个参数赋值后计算出来的结果，这些变量赋值只在这个表达式内部有效\n示例:\nLET(a, 5,b, 6, a+b)等于11\n",
    "name": "LET",
    "type": "OTHER"
},
{
    "def": "SECOND(serial_number):返回某一指定时间的秒数，其值是介于0与59之间的一个整数。\nSerial_number:包含所求秒数的时间。\n示例:\nSECOND(\"15:36:25\")等于25。\nSECOND(\"15:36:25\", \"HH:mm:ss\")等于25。",
    "name": "SECOND",
    "type": "DATETIME"
},
{
    "def": "treelayer(TreeObject, Int, Boolean, String)：\n返回tree对象第n层的值，并且可以设置返回值类型及分隔符。\nTreeObject：tree对象，如$tree。\nInt：想要获得层级的数值，最上层为1，第二层为2，依此类推,若无则返回最底层\n。Boolean：返回值类型为字符串还是数组，默认false，返回数组；为true时返回字符串。\nString：当Boolean为true返回字符串时的分隔符，以双引号表示，默认为逗号\",\"，如\";\"。\n示例：\n假设$tree勾选的值为中国-江苏-南京,中国-浙江-杭州，则treelayer($tree, true, \u201d\\\u2019,\\\u2019\u201d)：返回\u201d\u2019,\u2019\u201d分割的所选中节点字符串\u201d南京\u2019,\u2019杭州\u201dtreelayer($tree, 2)：以数组形式返回第二层[\u201c江苏\u201d,\u201d浙江\u201d]。treelayer($tree, 2, true, \u201d\\\u2019,\\\u2019\u201d)：返回\u201d\u2019,\u2019\u201d分割的字符串江苏\u2019,\u2019浙江。",
    "name": "TREELAYER",
    "type": "OTHER"
},
{
    "def": "EXP(number): 返回e的n次幂。常数e为自然对数的底数，等于2.71828182845904。\nNumber:为任意实数，作为常数e的指数。\n备注:\n    如果要返回其他常数作为底数的幂，可以使用指数运算符（^）。例如: 在4^2中，4是底数，而2是指数。\n    EXP函数与LN函数互为反函数。\n示例:\nEXP(0)等于1。\nEXP(3)等于20.08553692。\nEXP(LN(2))等于2。",
    "name": "EXP",
    "type": "MATH"
},
{
    "def": "读取配置文件",
    "name": "TOTEXT",
    "type": "DELETE"
}];