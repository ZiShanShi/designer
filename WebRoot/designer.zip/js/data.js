Pool = {
    source: {},
    groups: {
        "0cd22ec1-95c4-4ab0-9231-c2ea7b7a8cbc": {
            "children": [{
                "id": "82a96a4b03ac17e6"
            },
            {
                "id": "88040c7fcffc1b57"
            },
            {
                "id": "ad418089bbba2601"
            }],
            "name": "功能数据",
            "id": "0cd22ec1-95c4-4ab0-9231-c2ea7b7a8cbc",
            "initTime": 1467195205579
        },
        "cafce1fa-ea32-4fdc-a9fd-f2463d0f4be6": {
            "children": [{
                "id": "9effb692f7b0b939"
            },
            {
                "id": "ebf9428ee6e19776"
            },
            {
                "id": "85b0786f836e4abc"
            },
            {
                "id": "df42da579ecbf532"
            },
            {
                "id": "b7d069eb5b80aa24"
            },
            {
                "id": "b4a11a29e70c3d99"
            },
            {
                "id": "3f8a35b08263871a"
            },
            {
                "id": "4dd8f28be71a3d94"
            },
            {
                "id": "7fb820101efd3bf4"
            }],
            "name": "行业数据",
            "id": "cafce1fa-ea32-4fdc-a9fd-f2463d0f4be6",
            "initTime": 1467882127159
        }
    },
    packages: {
        "ebf9428ee6e19776": {
            "tables": [{
                "id": "回款维度表"
            },
            {
                "id": "成本事实表"
            },
            {
                "id": "城市地区维度表"
            },
            {
                "id": "库存事实表"
            },
            {
                "id": "签约事实表"
            },
            {
                "id": "回款事实表"
            },
            {
                "id": "合同维度表"
            },
            {
                "id": "产品维度表"
            },
            {
                "id": "项目维度表"
            },
            {
                "id": "房间维度表"
            }],
            "name": "地产行业",
            "id": "ebf9428ee6e19776",
            "position": 1466068851038,
            "type": 1,
            "userId": -999
        },
        "7fb820101efd3bf4": {
            "tables": [{
                "id": "业务流水表"
            },
            {
                "id": "机构表"
            },
            {
                "id": "用户登录权限表"
            }],
            "name": "银行",
            "id": "7fb820101efd3bf4",
            "position": 1520563621868,
            "type": 1,
            "userId": -999
        },
        "df42da579ecbf532": {
            "tables": [{
                "id": "医药_客户地区维度"
            },
            {
                "id": "医药_库存周转事实表"
            },
            {
                "id": "医药_产品维度表"
            }],
            "name": "医药行业",
            "id": "df42da579ecbf532",
            "position": 1467882231206,
            "type": 1,
            "userId": -999
        },
        "9effb692f7b0b939": {
            "tables": [{
                "id": "销售明细"
            },
            {
                "id": "品类维度"
            },
            {
                "id": "门店维度"
            },
            {
                "id": "品牌维度"
            }],
            "name": "零售行业",
            "id": "9effb692f7b0b939",
            "position": 1466067312013,
            "type": 1,
            "userId": -999
        },
        "88040c7fcffc1b57": {
            "tables": [{
                "id": "浏览器占比变化"
            },
            {
                "id": "样式数据三"
            },
            {
                "id": "全国环境监测数据"
            },
            {
                "id": "十大热门出境游热门目的地国家"
            },
            {
                "id": "样式数据二"
            },
            {
                "id": "ExcelView之客户跟踪表"
            },
            {
                "id": "出游年龄占比"
            },
            {
                "id": "热门景区门票预定TOP20"
            },
            {
                "id": "北京春运迁徙数据"
            },
            {
                "id": "出境方式占比"
            },
            {
                "id": "南京苏果营业数据"
            },
            {
                "id": "样式数据一"
            },
            {
                "id": "十大文化古镇"
            },
            {
                "id": "西安兰特雨量监测数据"
            },
            {
                "id": "流向"
            },
            {
                "id": "十大热门旅游城市"
            }],
            "name": "样式数据",
            "id": "88040c7fcffc1b57",
            "position": 1467287006143,
            "type": 1,
            "userId": -999
        },
        "b7d069eb5b80aa24": {
            "tables": [{
                "id": "化工_产品收入率趋势"
            },
            {
                "id": "化工_设备运行状况展示"
            },
            {
                "id": "化工_生成进度表展示"
            },
            {
                "id": "化工_库存展示"
            },
            {
                "id": "化工_能耗指标趋势"
            },
            {
                "id": "化工_原料成本趋势展示"
            },
            {
                "id": "化工_重大事件明细表"
            }],
            "name": "化工与金属",
            "id": "b7d069eb5b80aa24",
            "position": 1467882251263,
            "type": 1,
            "userId": -999
        },
        "b4a11a29e70c3d99": {
            "tables": [{
                "id": "银行_业务维度表"
            },
            {
                "id": "银行_财务分析事实表"
            },
            {
                "id": "银行_用户维度表"
            },
            {
                "id": "银行_机构维度表"
            },
            {
                "id": "银行_产品维度表"
            }],
            "name": "银行金融",
            "id": "b4a11a29e70c3d99",
            "position": 1467882296241,
            "type": 1,
            "userId": -999
        },
        "82a96a4b03ac17e6": {
            "tables": [{
                "id": "分公司维度表"
            },
            {
                "id": "产品名称维度"
            },
            {
                "id": "客户维度表"
            },
            {
                "id": "合同回款事实"
            },
            {
                "id": "销售员维度表"
            },
            {
                "id": "销售事实表"
            },
            {
                "id": "合同事实表"
            }],
            "name": "销售DEMO",
            "id": "82a96a4b03ac17e6",
            "position": 1466068510137,
            "type": 1,
            "userId": -999
        },
        "85b0786f836e4abc": {
            "tables": [{
                "id": "地区维度表"
            },
            {
                "id": "访问阶段统计事实表"
            },
            {
                "id": "推广渠道维度表"
            },
            {
                "id": "用户信息维度表"
            },
            {
                "id": "访问统计事实表"
            }],
            "name": "互联网行业",
            "id": "85b0786f836e4abc",
            "position": 1467882153303,
            "type": 1,
            "userId": -999
        },
        "4dd8f28be71a3d94": {
            "tables": [{
                "id": "区域维度表"
            },
            {
                "id": "宽带业务"
            }],
            "name": "通信行业",
            "id": "4dd8f28be71a3d94",
            "position": 1481605719770,
            "type": 1,
            "userId": -999
        },
        "ad418089bbba2601": {
            "tables": [{
                "id": "雇员2"
            },
            {
                "id": "订单"
            },
            {
                "id": "雇员"
            },
            {
                "id": "产品"
            },
            {
                "id": "订单明细"
            },
            {
                "id": "供应商产品表"
            },
            {
                "id": "供应商信息表"
            },
            {
                "id": "人员变动表"
            },
            {
                "id": "分界口货车出入情况"
            }],
            "name": "高级报表",
            "id": "ad418089bbba2601",
            "position": 1512117429660,
            "type": 1,
            "userId": -999
        },
        "3f8a35b08263871a": {
            "tables": [{
                "id": "租赁_存量业务"
            },
            {
                "id": "租赁_车辆租赁业务"
            }],
            "name": "租赁行业",
            "id": "3f8a35b08263871a",
            "position": 1470032189875,
            "type": 1,
            "userId": -999
        }
    },
    connections: {
        "connectionSet": [{
            "foreignKey": {
                "fieldName": "客户对应销售员",
                "fieldSize": 64,
                "isUsable": true,
                "tableId": "客户维度表",
                "id": "客户维度表/客户对应销售员",
                "tableTranName": "客户维度表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "客户维度表/客户对应销售员"
            },
            "primaryKey": {
                "fieldName": "SALES_NAME",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "销售员维度表",
                "id": "销售员维度表/SALES_NAME",
                "tableTranName": "销售员维度表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "销售员维度表/SALES_NAME"
            }
        },
        {
            "foreignKey": {
                "fieldName": "PRODUCTGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "签约事实表",
                "id": "签约事实表/PRODUCTGUID",
                "tableTranName": "签约事实表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "签约事实表/PRODUCTGUID"
            },
            "primaryKey": {
                "fieldName": "PRODUCTGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "产品维度表",
                "id": "产品维度表/PRODUCTGUID",
                "tableTranName": "产品维度表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "产品维度表/PRODUCTGUID"
            }
        },
        {
            "foreignKey": {
                "fieldName": "购买的产品",
                "fieldSize": 10,
                "isUsable": true,
                "tableId": "合同事实表",
                "id": "合同事实表/购买的产品",
                "tableTranName": "合同事实表",
                "fieldType": 32,
                "isEnable": true,
                "fieldId": "合同事实表/购买的产品"
            },
            "primaryKey": {
                "fieldName": "产品ID",
                "fieldSize": 10,
                "isUsable": true,
                "tableId": "产品名称维度",
                "id": "产品名称维度/产品ID",
                "tableTranName": "产品名称维度",
                "fieldType": 32,
                "isEnable": true,
                "fieldId": "产品名称维度/产品ID"
            }
        },
        {
            "foreignKey": {
                "fieldName": "AREAGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "库存事实表",
                "id": "库存事实表/AREAGUID",
                "tableTranName": "库存事实表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "库存事实表/AREAGUID"
            },
            "primaryKey": {
                "fieldName": "AREAGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "城市地区维度表",
                "id": "城市地区维度表/AREAGUID",
                "tableTranName": "城市地区维度表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "城市地区维度表/AREAGUID"
            }
        },
        {
            "foreignKey": {
                "fieldName": "PRODUCTGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "回款事实表",
                "id": "回款事实表/PRODUCTGUID",
                "tableTranName": "回款事实表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "回款事实表/PRODUCTGUID"
            },
            "primaryKey": {
                "fieldName": "PRODUCTGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "产品维度表",
                "id": "产品维度表/PRODUCTGUID",
                "tableTranName": "产品维度表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "产品维度表/PRODUCTGUID"
            }
        },
        {
            "foreignKey": {
                "fieldName": "合同ID",
                "fieldSize": 128,
                "isUsable": true,
                "tableId": "合同回款事实",
                "id": "合同回款事实/合同ID",
                "tableTranName": "合同回款事实",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "合同回款事实/合同ID"
            },
            "primaryKey": {
                "fieldName": "合同ID",
                "fieldSize": 200,
                "isUsable": true,
                "tableId": "合同事实表",
                "id": "合同事实表/合同ID",
                "tableTranName": "合同事实表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "合同事实表/合同ID"
            }
        },
        {
            "foreignKey": {
                "fieldName": "品牌编号",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "销售明细",
                "id": "销售明细/品牌编号",
                "tableTranName": "销售明细",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "销售明细/品牌编号"
            },
            "primaryKey": {
                "fieldName": "品牌编号",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "品牌维度",
                "id": "品牌维度/品牌编号",
                "tableTranName": "品牌维度",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "品牌维度/品牌编号"
            }
        },
        {
            "foreignKey": {
                "fieldName": "客户编码",
                "fieldSize": 64,
                "isUsable": true,
                "tableId": "医药_库存周转事实表",
                "id": "医药_库存周转事实表/客户编码",
                "tableTranName": "医药_库存周转事实表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "医药_库存周转事实表/客户编码"
            },
            "primaryKey": {
                "fieldName": "客户编码",
                "fieldSize": 64,
                "isUsable": true,
                "tableId": "医药_客户地区维度",
                "id": "医药_客户地区维度/客户编码",
                "tableTranName": "医药_客户地区维度",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "医药_客户地区维度/客户编码"
            }
        },
        {
            "foreignKey": {
                "fieldName": "PROJGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/PROJGUID",
                "tableTranName": "成本事实表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "成本事实表/PROJGUID"
            },
            "primaryKey": {
                "fieldName": "PROJGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "项目维度表",
                "id": "项目维度表/PROJGUID",
                "tableTranName": "项目维度表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "项目维度表/PROJGUID"
            }
        },
        {
            "foreignKey": {
                "fieldName": "地区ID",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "访问统计事实表",
                "id": "访问统计事实表/地区ID",
                "tableTranName": "访问统计事实表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "访问统计事实表/地区ID"
            },
            "primaryKey": {
                "fieldName": "GB_ID",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "地区维度表",
                "id": "地区维度表/GB_ID",
                "tableTranName": "地区维度表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "地区维度表/GB_ID"
            }
        },
        {
            "foreignKey": {
                "fieldName": "供应商ID",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "供应商产品表",
                "id": "供应商产品表/供应商ID",
                "tableTranName": "供应商产品表",
                "fieldType": 32,
                "isEnable": true,
                "fieldId": "供应商产品表/供应商ID"
            },
            "primaryKey": {
                "fieldName": "供应商ID",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "供应商信息表",
                "id": "供应商信息表/供应商ID",
                "tableTranName": "供应商信息表",
                "fieldType": 32,
                "isEnable": true,
                "fieldId": "供应商信息表/供应商ID"
            }
        },
        {
            "foreignKey": {
                "fieldName": "PROJGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "回款事实表",
                "id": "回款事实表/PROJGUID",
                "tableTranName": "回款事实表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "回款事实表/PROJGUID"
            },
            "primaryKey": {
                "fieldName": "PROJGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "项目维度表",
                "id": "项目维度表/PROJGUID",
                "tableTranName": "项目维度表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "项目维度表/PROJGUID"
            }
        },
        {
            "foreignKey": {
                "fieldName": "产品编码",
                "fieldSize": 64,
                "isUsable": true,
                "tableId": "医药_库存周转事实表",
                "id": "医药_库存周转事实表/产品编码",
                "tableTranName": "医药_库存周转事实表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "医药_库存周转事实表/产品编码"
            },
            "primaryKey": {
                "fieldName": "产品编码",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "医药_产品维度表",
                "id": "医药_产品维度表/产品编码",
                "tableTranName": "医药_产品维度表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "医药_产品维度表/产品编码"
            }
        },
        {
            "foreignKey": {
                "fieldName": "AREAGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/AREAGUID",
                "tableTranName": "成本事实表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "成本事实表/AREAGUID"
            },
            "primaryKey": {
                "fieldName": "AREAGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "城市地区维度表",
                "id": "城市地区维度表/AREAGUID",
                "tableTranName": "城市地区维度表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "城市地区维度表/AREAGUID"
            }
        },
        {
            "foreignKey": {
                "fieldName": "机构ID",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "银行_财务分析事实表",
                "id": "银行_财务分析事实表/机构ID",
                "tableTranName": "银行_财务分析事实表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "银行_财务分析事实表/机构ID"
            },
            "primaryKey": {
                "fieldName": "JGID",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "银行_机构维度表",
                "id": "银行_机构维度表/JGID",
                "tableTranName": "银行_机构维度表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "银行_机构维度表/JGID"
            }
        },
        {
            "foreignKey": {
                "fieldName": "客户ID",
                "fieldSize": 200,
                "isUsable": true,
                "tableId": "合同事实表",
                "id": "合同事实表/客户ID",
                "tableTranName": "合同事实表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "合同事实表/客户ID"
            },
            "primaryKey": {
                "fieldName": "客户ID",
                "fieldSize": 64,
                "isUsable": true,
                "tableId": "客户维度表",
                "id": "客户维度表/客户ID",
                "tableTranName": "客户维度表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "客户维度表/客户ID"
            }
        },
        {
            "foreignKey": {
                "fieldName": "ROOMGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "签约事实表",
                "id": "签约事实表/ROOMGUID",
                "tableTranName": "签约事实表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "签约事实表/ROOMGUID"
            },
            "primaryKey": {
                "fieldName": "ROOMGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "房间维度表",
                "id": "房间维度表/ROOMGUID",
                "tableTranName": "房间维度表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "房间维度表/ROOMGUID"
            }
        },
        {
            "foreignKey": {
                "fieldName": "类别",
                "fieldSize": 10,
                "isUsable": true,
                "tableId": "销售明细",
                "id": "销售明细/类别",
                "tableTranName": "销售明细",
                "fieldType": 32,
                "isEnable": true,
                "fieldId": "销售明细/类别"
            },
            "primaryKey": {
                "fieldName": "类别",
                "fieldSize": 10,
                "isUsable": true,
                "tableId": "品类维度",
                "id": "品类维度/类别",
                "tableTranName": "品类维度",
                "fieldType": 32,
                "isEnable": true,
                "fieldId": "品类维度/类别"
            }
        },
        {
            "foreignKey": {
                "fieldName": "渠道ID",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "访问统计事实表",
                "id": "访问统计事实表/渠道ID",
                "tableTranName": "访问统计事实表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "访问统计事实表/渠道ID"
            },
            "primaryKey": {
                "fieldName": "渠道ID",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "推广渠道维度表",
                "id": "推广渠道维度表/渠道ID",
                "tableTranName": "推广渠道维度表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "推广渠道维度表/渠道ID"
            }
        },
        {
            "foreignKey": {
                "fieldName": "PRODUCTGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "库存事实表",
                "id": "库存事实表/PRODUCTGUID",
                "tableTranName": "库存事实表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "库存事实表/PRODUCTGUID"
            },
            "primaryKey": {
                "fieldName": "PRODUCTGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "产品维度表",
                "id": "产品维度表/PRODUCTGUID",
                "tableTranName": "产品维度表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "产品维度表/PRODUCTGUID"
            }
        },
        {
            "foreignKey": {
                "fieldName": "区域ID",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "宽带业务",
                "id": "宽带业务/区域ID",
                "tableTranName": "宽带业务",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "宽带业务/区域ID"
            },
            "primaryKey": {
                "fieldName": "AREA_ID",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "区域维度表",
                "id": "区域维度表/AREA_ID",
                "tableTranName": "区域维度表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "区域维度表/AREA_ID"
            }
        },
        {
            "foreignKey": {
                "fieldName": "GETINGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "回款事实表",
                "id": "回款事实表/GETINGUID",
                "tableTranName": "回款事实表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "回款事实表/GETINGUID"
            },
            "primaryKey": {
                "fieldName": "GETINGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "回款维度表",
                "id": "回款维度表/GETINGUID",
                "tableTranName": "回款维度表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "回款维度表/GETINGUID"
            }
        },
        {
            "foreignKey": {
                "fieldName": "机构",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "用户登录权限表",
                "id": "用户登录权限表/机构",
                "tableTranName": "用户登录权限表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "用户登录权限表/机构"
            },
            "primaryKey": {
                "fieldName": "机构",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "机构表",
                "id": "机构表/机构",
                "tableTranName": "机构表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "机构表/机构"
            }
        },
        {
            "foreignKey": {
                "fieldName": "客户ID",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "银行_财务分析事实表",
                "id": "银行_财务分析事实表/客户ID",
                "tableTranName": "银行_财务分析事实表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "银行_财务分析事实表/客户ID"
            },
            "primaryKey": {
                "fieldName": "用户ID",
                "fieldSize": 64,
                "isUsable": true,
                "tableId": "银行_用户维度表",
                "id": "银行_用户维度表/用户ID",
                "tableTranName": "银行_用户维度表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "银行_用户维度表/用户ID"
            }
        },
        {
            "foreignKey": {
                "fieldName": "用户ID",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "访问统计事实表",
                "id": "访问统计事实表/用户ID",
                "tableTranName": "访问统计事实表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "访问统计事实表/用户ID"
            },
            "primaryKey": {
                "fieldName": "用户ID",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "用户信息维度表",
                "id": "用户信息维度表/用户ID",
                "tableTranName": "用户信息维度表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "用户信息维度表/用户ID"
            }
        },
        {
            "foreignKey": {
                "fieldName": "BUILDPRODUCTTYPEGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/BUILDPRODUCTTYPEGUID",
                "tableTranName": "成本事实表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "成本事实表/BUILDPRODUCTTYPEGUID"
            },
            "primaryKey": {
                "fieldName": "PRODUCTGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "产品维度表",
                "id": "产品维度表/PRODUCTGUID",
                "tableTranName": "产品维度表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "产品维度表/PRODUCTGUID"
            }
        },
        {
            "foreignKey": {
                "fieldName": "省份",
                "fieldSize": 64,
                "isUsable": true,
                "tableId": "客户维度表",
                "id": "客户维度表/省份",
                "tableTranName": "客户维度表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "客户维度表/省份"
            },
            "primaryKey": {
                "fieldName": "省份",
                "fieldSize": 200,
                "isUsable": true,
                "tableId": "分公司维度表",
                "id": "分公司维度表/省份",
                "tableTranName": "分公司维度表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "分公司维度表/省份"
            }
        },
        {
            "foreignKey": {
                "fieldName": "AREAGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "回款事实表",
                "id": "回款事实表/AREAGUID",
                "tableTranName": "回款事实表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "回款事实表/AREAGUID"
            },
            "primaryKey": {
                "fieldName": "AREAGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "城市地区维度表",
                "id": "城市地区维度表/AREAGUID",
                "tableTranName": "城市地区维度表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "城市地区维度表/AREAGUID"
            }
        },
        {
            "foreignKey": {
                "fieldName": "AREAGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "签约事实表",
                "id": "签约事实表/AREAGUID",
                "tableTranName": "签约事实表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "签约事实表/AREAGUID"
            },
            "primaryKey": {
                "fieldName": "AREAGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "城市地区维度表",
                "id": "城市地区维度表/AREAGUID",
                "tableTranName": "城市地区维度表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "城市地区维度表/AREAGUID"
            }
        },
        {
            "foreignKey": {
                "fieldName": "业务ID",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "银行_财务分析事实表",
                "id": "银行_财务分析事实表/业务ID",
                "tableTranName": "银行_财务分析事实表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "银行_财务分析事实表/业务ID"
            },
            "primaryKey": {
                "fieldName": "业务代码",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "银行_业务维度表",
                "id": "银行_业务维度表/业务代码",
                "tableTranName": "银行_业务维度表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "银行_业务维度表/业务代码"
            }
        },
        {
            "foreignKey": {
                "fieldName": "ROOMGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "库存事实表",
                "id": "库存事实表/ROOMGUID",
                "tableTranName": "库存事实表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "库存事实表/ROOMGUID"
            },
            "primaryKey": {
                "fieldName": "ROOMGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "房间维度表",
                "id": "房间维度表/ROOMGUID",
                "tableTranName": "房间维度表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "房间维度表/ROOMGUID"
            }
        },
        {
            "foreignKey": {
                "fieldName": "用户ID",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "访问阶段统计事实表",
                "id": "访问阶段统计事实表/用户ID",
                "tableTranName": "访问阶段统计事实表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "访问阶段统计事实表/用户ID"
            },
            "primaryKey": {
                "fieldName": "用户ID",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "用户信息维度表",
                "id": "用户信息维度表/用户ID",
                "tableTranName": "用户信息维度表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "用户信息维度表/用户ID"
            }
        },
        {
            "foreignKey": {
                "fieldName": "机构号",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "业务流水表",
                "id": "业务流水表/机构号",
                "tableTranName": "业务流水表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "业务流水表/机构号"
            },
            "primaryKey": {
                "fieldName": "机构",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "机构表",
                "id": "机构表/机构",
                "tableTranName": "机构表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "机构表/机构"
            }
        },
        {
            "foreignKey": {
                "fieldName": "PA产品号",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "银行_财务分析事实表",
                "id": "银行_财务分析事实表/PA产品号",
                "tableTranName": "银行_财务分析事实表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "银行_财务分析事实表/PA产品号"
            },
            "primaryKey": {
                "fieldName": "PA产品号",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "银行_产品维度表",
                "id": "银行_产品维度表/PA产品号",
                "tableTranName": "银行_产品维度表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "银行_产品维度表/PA产品号"
            }
        },
        {
            "foreignKey": {
                "fieldName": "CONTRACTGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "签约事实表",
                "id": "签约事实表/CONTRACTGUID",
                "tableTranName": "签约事实表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "签约事实表/CONTRACTGUID"
            },
            "primaryKey": {
                "fieldName": "CONTRACTGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "合同维度表",
                "id": "合同维度表/CONTRACTGUID",
                "tableTranName": "合同维度表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "合同维度表/CONTRACTGUID"
            }
        },
        {
            "foreignKey": {
                "fieldName": "店号",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "销售明细",
                "id": "销售明细/店号",
                "tableTranName": "销售明细",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "销售明细/店号"
            },
            "primaryKey": {
                "fieldName": "店号",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "门店维度",
                "id": "门店维度/店号",
                "tableTranName": "门店维度",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "门店维度/店号"
            }
        },
        {
            "foreignKey": {
                "fieldName": "PROJGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "签约事实表",
                "id": "签约事实表/PROJGUID",
                "tableTranName": "签约事实表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "签约事实表/PROJGUID"
            },
            "primaryKey": {
                "fieldName": "PROJGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "项目维度表",
                "id": "项目维度表/PROJGUID",
                "tableTranName": "项目维度表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "项目维度表/PROJGUID"
            }
        },
        {
            "foreignKey": {
                "fieldName": "ROOMGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "回款事实表",
                "id": "回款事实表/ROOMGUID",
                "tableTranName": "回款事实表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "回款事实表/ROOMGUID"
            },
            "primaryKey": {
                "fieldName": "ROOMGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "房间维度表",
                "id": "房间维度表/ROOMGUID",
                "tableTranName": "房间维度表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "房间维度表/ROOMGUID"
            }
        },
        {
            "foreignKey": {
                "fieldName": "PROJGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "库存事实表",
                "id": "库存事实表/PROJGUID",
                "tableTranName": "库存事实表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "库存事实表/PROJGUID"
            },
            "primaryKey": {
                "fieldName": "PROJGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "项目维度表",
                "id": "项目维度表/PROJGUID",
                "tableTranName": "项目维度表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "项目维度表/PROJGUID"
            }
        },
        {
            "foreignKey": {
                "fieldName": "客户ID",
                "fieldSize": 50,
                "isUsable": true,
                "tableId": "销售事实表",
                "id": "销售事实表/客户ID",
                "tableTranName": "销售事实表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "销售事实表/客户ID"
            },
            "primaryKey": {
                "fieldName": "客户ID",
                "fieldSize": 64,
                "isUsable": true,
                "tableId": "客户维度表",
                "id": "客户维度表/客户ID",
                "tableTranName": "客户维度表",
                "fieldType": 16,
                "isEnable": true,
                "fieldId": "客户维度表/客户ID"
            }
        }]
    },
    relations: {
        "城市地区维度表": {
            "成本事实表": [[{
                "foreignKey": {
                    "fieldId": "成本事实表/AREAGUID"
                },
                "primaryKey": {
                    "fieldId": "城市地区维度表/AREAGUID"
                }
            }]],
            "库存事实表": [[{
                "foreignKey": {
                    "fieldId": "库存事实表/AREAGUID"
                },
                "primaryKey": {
                    "fieldId": "城市地区维度表/AREAGUID"
                }
            }]],
            "签约事实表": [[{
                "foreignKey": {
                    "fieldId": "签约事实表/AREAGUID"
                },
                "primaryKey": {
                    "fieldId": "城市地区维度表/AREAGUID"
                }
            }]],
            "回款事实表": [[{
                "foreignKey": {
                    "fieldId": "回款事实表/AREAGUID"
                },
                "primaryKey": {
                    "fieldId": "城市地区维度表/AREAGUID"
                }
            }]]
        },
        "房间维度表": {
            "库存事实表": [[{
                "foreignKey": {
                    "fieldId": "库存事实表/ROOMGUID"
                },
                "primaryKey": {
                    "fieldId": "房间维度表/ROOMGUID"
                }
            }]],
            "签约事实表": [[{
                "foreignKey": {
                    "fieldId": "签约事实表/ROOMGUID"
                },
                "primaryKey": {
                    "fieldId": "房间维度表/ROOMGUID"
                }
            }]],
            "回款事实表": [[{
                "foreignKey": {
                    "fieldId": "回款事实表/ROOMGUID"
                },
                "primaryKey": {
                    "fieldId": "房间维度表/ROOMGUID"
                }
            }]]
        },
        "推广渠道维度表": {
            "访问统计事实表": [[{
                "foreignKey": {
                    "fieldId": "访问统计事实表/渠道ID"
                },
                "primaryKey": {
                    "fieldId": "推广渠道维度表/渠道ID"
                }
            }]]
        },
        "机构表": {
            "业务流水表": [[{
                "foreignKey": {
                    "fieldId": "业务流水表/机构号"
                },
                "primaryKey": {
                    "fieldId": "机构表/机构"
                }
            }]],
            "用户登录权限表": [[{
                "foreignKey": {
                    "fieldId": "用户登录权限表/机构"
                },
                "primaryKey": {
                    "fieldId": "机构表/机构"
                }
            }]]
        },
        "回款维度表": {
            "回款事实表": [[{
                "foreignKey": {
                    "fieldId": "回款事实表/GETINGUID"
                },
                "primaryKey": {
                    "fieldId": "回款维度表/GETINGUID"
                }
            }]]
        },
        "客户维度表": {
            "合同回款事实": [[{
                "foreignKey": {
                    "fieldId": "合同事实表/客户ID"
                },
                "primaryKey": {
                    "fieldId": "客户维度表/客户ID"
                }
            },
            {
                "foreignKey": {
                    "fieldId": "合同回款事实/合同ID"
                },
                "primaryKey": {
                    "fieldId": "合同事实表/合同ID"
                }
            }]],
            "销售事实表": [[{
                "foreignKey": {
                    "fieldId": "销售事实表/客户ID"
                },
                "primaryKey": {
                    "fieldId": "客户维度表/客户ID"
                }
            }]],
            "合同事实表": [[{
                "foreignKey": {
                    "fieldId": "合同事实表/客户ID"
                },
                "primaryKey": {
                    "fieldId": "客户维度表/客户ID"
                }
            }]]
        },
        "项目维度表": {
            "成本事实表": [[{
                "foreignKey": {
                    "fieldId": "成本事实表/PROJGUID"
                },
                "primaryKey": {
                    "fieldId": "项目维度表/PROJGUID"
                }
            }]],
            "库存事实表": [[{
                "foreignKey": {
                    "fieldId": "库存事实表/PROJGUID"
                },
                "primaryKey": {
                    "fieldId": "项目维度表/PROJGUID"
                }
            }]],
            "签约事实表": [[{
                "foreignKey": {
                    "fieldId": "签约事实表/PROJGUID"
                },
                "primaryKey": {
                    "fieldId": "项目维度表/PROJGUID"
                }
            }]],
            "回款事实表": [[{
                "foreignKey": {
                    "fieldId": "回款事实表/PROJGUID"
                },
                "primaryKey": {
                    "fieldId": "项目维度表/PROJGUID"
                }
            }]]
        },
        "供应商信息表": {
            "供应商产品表": [[{
                "foreignKey": {
                    "fieldId": "供应商产品表/供应商ID"
                },
                "primaryKey": {
                    "fieldId": "供应商信息表/供应商ID"
                }
            }]]
        },
        "区域维度表": {
            "宽带业务": [[{
                "foreignKey": {
                    "fieldId": "宽带业务/区域ID"
                },
                "primaryKey": {
                    "fieldId": "区域维度表/AREA_ID"
                }
            }]]
        },
        "银行_机构维度表": {
            "银行_财务分析事实表": [[{
                "foreignKey": {
                    "fieldId": "银行_财务分析事实表/机构ID"
                },
                "primaryKey": {
                    "fieldId": "银行_机构维度表/JGID"
                }
            }]]
        },
        "银行_用户维度表": {
            "银行_财务分析事实表": [[{
                "foreignKey": {
                    "fieldId": "银行_财务分析事实表/客户ID"
                },
                "primaryKey": {
                    "fieldId": "银行_用户维度表/用户ID"
                }
            }]]
        },
        "品牌维度": {
            "销售明细": [[{
                "foreignKey": {
                    "fieldId": "销售明细/品牌编号"
                },
                "primaryKey": {
                    "fieldId": "品牌维度/品牌编号"
                }
            }]]
        },
        "合同事实表": {
            "合同回款事实": [[{
                "foreignKey": {
                    "fieldId": "合同回款事实/合同ID"
                },
                "primaryKey": {
                    "fieldId": "合同事实表/合同ID"
                }
            }]]
        },
        "银行_产品维度表": {
            "银行_财务分析事实表": [[{
                "foreignKey": {
                    "fieldId": "银行_财务分析事实表/PA产品号"
                },
                "primaryKey": {
                    "fieldId": "银行_产品维度表/PA产品号"
                }
            }]]
        },
        "品类维度": {
            "销售明细": [[{
                "foreignKey": {
                    "fieldId": "销售明细/类别"
                },
                "primaryKey": {
                    "fieldId": "品类维度/类别"
                }
            }]]
        },
        "销售员维度表": {
            "客户维度表": [[{
                "foreignKey": {
                    "fieldId": "客户维度表/客户对应销售员"
                },
                "primaryKey": {
                    "fieldId": "销售员维度表/SALES_NAME"
                }
            }]],
            "合同回款事实": [[{
                "foreignKey": {
                    "fieldId": "客户维度表/客户对应销售员"
                },
                "primaryKey": {
                    "fieldId": "销售员维度表/SALES_NAME"
                }
            },
            {
                "foreignKey": {
                    "fieldId": "合同事实表/客户ID"
                },
                "primaryKey": {
                    "fieldId": "客户维度表/客户ID"
                }
            },
            {
                "foreignKey": {
                    "fieldId": "合同回款事实/合同ID"
                },
                "primaryKey": {
                    "fieldId": "合同事实表/合同ID"
                }
            }]],
            "销售事实表": [[{
                "foreignKey": {
                    "fieldId": "客户维度表/客户对应销售员"
                },
                "primaryKey": {
                    "fieldId": "销售员维度表/SALES_NAME"
                }
            },
            {
                "foreignKey": {
                    "fieldId": "销售事实表/客户ID"
                },
                "primaryKey": {
                    "fieldId": "客户维度表/客户ID"
                }
            }]],
            "合同事实表": [[{
                "foreignKey": {
                    "fieldId": "客户维度表/客户对应销售员"
                },
                "primaryKey": {
                    "fieldId": "销售员维度表/SALES_NAME"
                }
            },
            {
                "foreignKey": {
                    "fieldId": "合同事实表/客户ID"
                },
                "primaryKey": {
                    "fieldId": "客户维度表/客户ID"
                }
            }]]
        },
        "用户信息维度表": {
            "访问阶段统计事实表": [[{
                "foreignKey": {
                    "fieldId": "访问阶段统计事实表/用户ID"
                },
                "primaryKey": {
                    "fieldId": "用户信息维度表/用户ID"
                }
            }]],
            "访问统计事实表": [[{
                "foreignKey": {
                    "fieldId": "访问统计事实表/用户ID"
                },
                "primaryKey": {
                    "fieldId": "用户信息维度表/用户ID"
                }
            }]]
        },
        "医药_产品维度表": {
            "医药_库存周转事实表": [[{
                "foreignKey": {
                    "fieldId": "医药_库存周转事实表/产品编码"
                },
                "primaryKey": {
                    "fieldId": "医药_产品维度表/产品编码"
                }
            }]]
        },
        "产品名称维度": {
            "合同回款事实": [[{
                "foreignKey": {
                    "fieldId": "合同事实表/购买的产品"
                },
                "primaryKey": {
                    "fieldId": "产品名称维度/产品ID"
                }
            },
            {
                "foreignKey": {
                    "fieldId": "合同回款事实/合同ID"
                },
                "primaryKey": {
                    "fieldId": "合同事实表/合同ID"
                }
            }]],
            "合同事实表": [[{
                "foreignKey": {
                    "fieldId": "合同事实表/购买的产品"
                },
                "primaryKey": {
                    "fieldId": "产品名称维度/产品ID"
                }
            }]]
        },
        "医药_客户地区维度": {
            "医药_库存周转事实表": [[{
                "foreignKey": {
                    "fieldId": "医药_库存周转事实表/客户编码"
                },
                "primaryKey": {
                    "fieldId": "医药_客户地区维度/客户编码"
                }
            }]]
        },
        "分公司维度表": {
            "客户维度表": [[{
                "foreignKey": {
                    "fieldId": "客户维度表/省份"
                },
                "primaryKey": {
                    "fieldId": "分公司维度表/省份"
                }
            }]],
            "合同回款事实": [[{
                "foreignKey": {
                    "fieldId": "客户维度表/省份"
                },
                "primaryKey": {
                    "fieldId": "分公司维度表/省份"
                }
            },
            {
                "foreignKey": {
                    "fieldId": "合同事实表/客户ID"
                },
                "primaryKey": {
                    "fieldId": "客户维度表/客户ID"
                }
            },
            {
                "foreignKey": {
                    "fieldId": "合同回款事实/合同ID"
                },
                "primaryKey": {
                    "fieldId": "合同事实表/合同ID"
                }
            }]],
            "销售事实表": [[{
                "foreignKey": {
                    "fieldId": "客户维度表/省份"
                },
                "primaryKey": {
                    "fieldId": "分公司维度表/省份"
                }
            },
            {
                "foreignKey": {
                    "fieldId": "销售事实表/客户ID"
                },
                "primaryKey": {
                    "fieldId": "客户维度表/客户ID"
                }
            }]],
            "合同事实表": [[{
                "foreignKey": {
                    "fieldId": "客户维度表/省份"
                },
                "primaryKey": {
                    "fieldId": "分公司维度表/省份"
                }
            },
            {
                "foreignKey": {
                    "fieldId": "合同事实表/客户ID"
                },
                "primaryKey": {
                    "fieldId": "客户维度表/客户ID"
                }
            }]]
        },
        "地区维度表": {
            "访问统计事实表": [[{
                "foreignKey": {
                    "fieldId": "访问统计事实表/地区ID"
                },
                "primaryKey": {
                    "fieldId": "地区维度表/GB_ID"
                }
            }]]
        },
        "银行_业务维度表": {
            "银行_财务分析事实表": [[{
                "foreignKey": {
                    "fieldId": "银行_财务分析事实表/业务ID"
                },
                "primaryKey": {
                    "fieldId": "银行_业务维度表/业务代码"
                }
            }]]
        },
        "产品维度表": {
            "成本事实表": [[{
                "foreignKey": {
                    "fieldId": "成本事实表/BUILDPRODUCTTYPEGUID"
                },
                "primaryKey": {
                    "fieldId": "产品维度表/PRODUCTGUID"
                }
            }]],
            "库存事实表": [[{
                "foreignKey": {
                    "fieldId": "库存事实表/PRODUCTGUID"
                },
                "primaryKey": {
                    "fieldId": "产品维度表/PRODUCTGUID"
                }
            }]],
            "签约事实表": [[{
                "foreignKey": {
                    "fieldId": "签约事实表/PRODUCTGUID"
                },
                "primaryKey": {
                    "fieldId": "产品维度表/PRODUCTGUID"
                }
            }]],
            "回款事实表": [[{
                "foreignKey": {
                    "fieldId": "回款事实表/PRODUCTGUID"
                },
                "primaryKey": {
                    "fieldId": "产品维度表/PRODUCTGUID"
                }
            }]]
        },
        "合同维度表": {
            "签约事实表": [[{
                "foreignKey": {
                    "fieldId": "签约事实表/CONTRACTGUID"
                },
                "primaryKey": {
                    "fieldId": "合同维度表/CONTRACTGUID"
                }
            }]]
        },
        "门店维度": {
            "销售明细": [[{
                "foreignKey": {
                    "fieldId": "销售明细/店号"
                },
                "primaryKey": {
                    "fieldId": "门店维度/店号"
                }
            }]]
        }
    },
    translations: {
        "37794e51400b4d23": "北京春运迁徙数据",
        "7c6968d97bb7db25": "互联网_用户信息表",
        "合同维度表/CONTRACTTYPENAME": "合同类型名称",
        "b74ec9868c4423c4": "员工部门",
        "房间维度表/FLOOR": "楼层",
        "72ba4e18f1e3fc7b": "合同金额",
        "035dcd0af566aa02": "销售区域",
        "签约事实表/QSDATE": "签约日期",
        "60a597f021b0094c": "签约事实表",
        "合同维度表/PAYFORMNAME": "付款方式",
        "d9e4f5d7dbf26f1d": "销售活动",
        "分界口货车出入情况": "分界口货车出入情况",
        "c40cfd941a872845": "化工-设备运行状况展示",
        "449800a2c606b738": "银行_产品表",
        "346ceb74d65d60bb": "DEMO_HOUSE",
        "9e3fbd487113463f": "地区ID",
        "18977407cfb4585d": "化工-重大事件明细表",
        "城市地区维度表/CITY_BUNAME": "城市公司",
        "afa0a85da4961b53": "DEMO_ACTIVITY_FEE",
        "回款维度表/ABCDATE": "回款期",
        "区域维度表/AREA_ID": "区域ID",
        "c6f9c03e5833d106": "客户信息",
        "1129dd0abb787425": "化工-能耗指标趋势",
        "1a0a6abd2b284939": "DEMO_CONTRACT",
        "7cd5b786dea3e625": "城市地区维度表",
        "c024b5415e15f3e8": "是否基础包",
        "fb7504afb78f6e13": "地区名称",
        "d2d3752614cca340": "品牌",
        "92d971f4433606b2": "new_pl",
        "168c8bedafe08fbd": "地区ID",
        "回款维度表/ITEMNAME": "款项名称",
        "样式数据三": "样式数据三",
        "cd30cbe9ddb2644d": "excel数据集",
        "895264e91b0b9130": "合同维度表",
        "f7b49e27c2079e64": "互联网-推广渠道表",
        "3a7a88637bf5b819": "互联网_推广渠道表",
        "69a45b2ed6606a39": "合同信息",
        "574eacc01257d75a": "全国环境监测数据",
        "ec07c6f2697ab61d": "银行_财务分析",
        "推广渠道维度表": "推广渠道维度表",
        "861e34972c9ff3be": "NEW_SINX",
        "285583bd98221864": "ExcelView之客户跟踪表",
        "a2ffaa3f59f539f9": "兰特水电站雨量监测",
        "客户维度表": "客户维度表",
        "a79ed88d030bc06c": "是否合约",
        "员工信息/USER_DUTY": "员工职位",
        "项目维度表/PROJNAME": "项目名称",
        "供应商信息表": "供应商信息表",
        "样式数据一": "样式数据一",
        "访问阶段统计事实表": "访问阶段统计事实表",
        "合同维度表/STATUS": "销售状态",
        "b7c4a66d1b383caa": "excel数据集1",
        "5467e37a535efd99": "区域经理",
        "f6798041af70e325": "银行-业务表",
        "a3eb7591824b5315": "SB_ZZS_2003_FB2",
        "雇员": "雇员",
        "06b9709d0f691c46": "是否4G用户",
        "785aebf4763c84d3": "银行-财务分析",
        "19166dd46b0c43d0": "员工编号",
        "13de9dea63a10548": "客户群",
        "476a1ed2eb65ae0c": "excel数据集1",
        "地区维度表": "地区维度表",
        "22e865dee54d0e79": "互联网-用户信息表",
        "合同维度表/CLOSEREASON": "关闭原因",
        "3e048992e708e498": "员工信息",
        "成本事实表/BUILDRATE": "建筑面积",
        "房间维度表/ROOMINFO": "房间信息",
        "bd67e3668d2b9f7f": "产品维度表",
        "员工信息/USER_USERNAME": "员工用户名",
        "房间维度表/WEST": "朝向",
        "7a12339c8479e0eb": "员工编号",
        "7ec0d6e79e109055": "客户的ID",
        "7957344ee0489a4a": "合同的回款信息",
        "成本事实表/COSTDISPLAY": "产品成本",
        "浏览器占比变化--雷达图": "浏览器占比变化--雷达图",
        "2df2de99259a7ffa": "DEMO_CAPITAL_RETURN",
        "66e70cce0174061b": "回款金额",
        "宽带业务": "宽带业务",
        "017382976e04916b": "医药-产品维度表",
        "员工信息/USER_NAME": "员工中文名",
        "031987ecc4e85f0b": "合同信息",
        "房间维度表/DJPRICE": "底价",
        "059b1089fbc3009f": "回款事实表",
        "签约事实表/ROOMTOTAL": "房间总价",
        "西安兰特雨量监测数据": "西安兰特雨量监测数据",
        "银行_机构维度表": "银行_机构维度表",
        "项目维度表/PARENTPROJNAME": "父项目名称",
        "全国环境监测数据": "全国环境监测数据",
        "客户维度表/客户ID": "客户的ID",
        "项目维度表/PARENTPROJGUID": "父项目GUID",
        "库存事实表/SALEAREA": "可售面积",
        "374d16460ae4fa2d": "库存事实表",
        "回款维度表/GETDATE": "汇款日期",
        "成本事实表/SALEAREA": "可售面积",
        "cf5ff8a12374b2ca": "sql数据集",
        "819f61bd99fe7227": "员工手机号码",
        "员工信息/USER_EMAIL": "员工邮箱地址",
        "2968d7a93fc2d3db": "sinX",
        "13b7a7b334743925": "lt_ryxx",
        "0fbb44aa18730f77": "机构父ID",
        "成本事实表/JZTZZZCB": "结转调整直接成本",
        "b87f641d4b7441c3": "excel数据集2",
        "回款事实表/STATUS": "状态",
        "61a4edec63c968f0": "excel数据集",
        "1c735c8f74b4f550": "员工邮箱地址",
        "房间维度表/ROOMSTRU": "房间结构",
        "分公司维度表/所属办事处": "分公司名称",
        "样式数据二": "样式数据二",
        "产品维度表/PRODUCTNAME": "产品名称",
        "项目维度表/PROJCODE": "项目全代码",
        "fcc360e38c94a75d": "客户的ID",
        "2cb130f40d3ed8cd": "地区父ID",
        "c8ad3d35bf1b2e1d": "员工中文名",
        "d6c449b6232eec39": "化工_重大事件明细表",
        "cc423e3f4f6087d7": "化工_原料成本趋势展示",
        "80b0fea94c05fe61": "员工职位",
        "b851925be343de13": "西安兰特雨量监测数据",
        "区域维度表/AREA_NAME": "区域名字",
        "822ed54072861d5d": "互联网-访问记录表",
        "城市地区维度表/AREA": "省",
        "02ef11852d392bbf": "化工_生成进度表展示",
        "06c1ef90552f8f81": "互联网-停留阶段记录",
        "97f3b599ce21a369": "房间维度表",
        "8201c9a4e041de4f": "合同金额",
        "80fee1632e64f797": "回款金额",
        "区域维度表": "区域维度表",
        "ec4f3010341a9f1c": "是否4G服务",
        "69b3f47b29084262": "类目",
        "ff27d101789391be": "员工手机号码",
        "c80b9d2802629667": "化工_设备运行状况展示",
        "银行_产品维度表": "银行_产品维度表",
        "房间维度表/VIRTUALSTATUS": "虚拟销售状态",
        "fc0a1d24895dd938": "销售明细",
        "销售员维度表": "销售员维度表",
        "eb3ecea40d9fcc07": "区域经理",
        "7a4197db44f18304": "化工-原料成本趋势展示",
        "ce975e2593f4a39d": "租赁_存量业务",
        "cbb93dc47ca36542": "excel数据集",
        "a2af58f2db546eb8": "员工用户名",
        "成本事实表/TOTALUNITCOSTDISPLAY": "单方全成本",
        "31edbfaaea9e726a": "NEW_三角函数柱形图",
        "aaa_jigou": "aaa_jigou",
        "员工信息/USER_MOBILE": "员工手机号码",
        "f2c2d768288f8326": "客户经理",
        "合同维度表/QSDATE": "签约日期",
        "产品": "产品",
        "回款维度表/CONTRACTTYPENAME": "合同类型名称",
        "cee02ce801da0fad": "化工-库存展示",
        "成本事实表/WYFTDCHZJCB": "物业分摊调差后直接成本",
        "80f3a45c448aedce": "品牌",
        "0fe67ff4dce1aa93": "用户名对应的密码",
        "954668b010f7cd2a": "融合销售品",
        "销售事实表": "销售事实表",
        "ec11ef89875aeab9": "样式数据二",
        "af0afc4d56eec2fa": "回款维度表",
        "f6bafba1dcac9643": "互联网_访问阶段统计",
        "0a4ecbcf0f49ea0b": "区域信息",
        "819b911cc2ae1455": "DEMO_CUSTOMER",
        "2ca65693e118a199": "销售员信息",
        "银行_财务分析事实表": "银行_财务分析事实表",
        "66df58a02dcea5ec": "分公司名称",
        "2a1e0c1e1cc93281": "终端类型",
        "48c196966ce22e9e": "销售区域",
        "回款维度表/ABCNAME": "回款类型",
        "24f37a2a4c357bdc": "用户名对应的密码",
        "签约事实表/CJPRICE": "成交单价",
        "b07d95308670d089": "活动费用",
        "59689911d00f4acc": "分公司信息",
        "订单明细": "订单明细",
        "0ff0e5201aeae093": "医药_库存周转事实表",
        "b56996fb8325b036": "活动费用",
        "5350bde96d5b2e3d": "门店信息",
        "77bf945e58ce64a1": "excel数据集",
        "c7a0e4ec8c262f35": "销售活动",
        "71dc5dab6cc38939": "互联网-地区维度表",
        "2203872f396e8e87": "宽带业务",
        "合同维度表/DISCNTREMARK": "折扣说明",
        "合同维度表/CJPRICE": "成交单价",
        "库存事实表/TOTAL": "标价总价",
        "城市地区维度表/CITY": "市",
        "12ae30de539f044c": "银行_机构表",
        "e4f047e036e881e1": "融合套餐归并",
        "5335a7aba9343392": "成本事实表",
        "49430d5df78f4e9d": "项目维度表",
        "北京春运迁徙数据": "北京春运迁徙数据",
        "e2bc43566593ba51": "分公司名称",
        "7ab7996a03a8c1d5": "NEW_COSX",
        "3821534fdaf15030": "柱形图",
        "3ea5199715cae3b5": "员工邮箱地址",
        "3932345de4d37ff6": "样式数据二",
        "回款事实表/ABCDATE": "回款日期",
        "签约事实表/RMBHTTOTAL": "合同总价(人民币)",
        "496b194c7d0aac12": "银行_业务表",
        "b99227bc13803216": "降雨量折线图",
        "合同维度表/SALEAREA": "销售面积",
        "签约事实表/BLDAREA": "销售面积",
        "合同回款事实/付款金额": "回款金额",
        "b659843acc0858df": "客户的ID",
        "房间维度表/SALEAREA": "销售面积",
        "7b8fe5c61ef57165": "分局",
        "员工信息/USER_PASSWORD": "用户名对应的密码",
        "11d201166cde30bb": "分公司信息",
        "产品维度表/PRODUCTCLASS": "产品分类",
        "库存事实表/DDATE": "库存日期",
        "a31474b1eef12c56": "员工中文名",
        "5fdf8623242430d9": "机构ID",
        "4e124727fe7b79c8": "医药-库存周转事实表",
        "0e3a51a985e19c13": "样式数据一",
        "银行_用户维度表": "银行_用户维度表",
        "品牌维度": "品牌维度",
        "合同事实表": "合同事实表",
        "968fb6fea9d9f7e2": "入网时间",
        "dcb28bc68897379b": "DEMO_HOUSE1",
        "合同事实表/总金额": "合同金额",
        "6ae949ea675f9bee": "员工部门",
        "d7071d6db9cc2c60": "品类",
        "c53b82de729dbec7": "员工职位",
        "34e75ea14919ee6b": "样式数据三",
        "签约事实表/PRICE": "销售单价",
        "用户信息维度表": "用户信息维度表",
        "访问统计事实表": "访问统计事实表",
        "合同维度表/ROOMTOTAL": "房间总价",
        "b3cfcd3bb986d595": "南京苏果营业数据",
        "库存事实表/TOTALDJ": "底价总价",
        "合同维度表/TOTAL": "标准总价",
        "成本事实表/DFZJCB": "单方直接成本",
        "b0ceff9da1d8a89d": "new_salesdetail",
        "e5567c96ebe1a76a": "银行_用户表",
        "项目维度表/PROJSHORTNAME": "项目简称",
        "630413626c774ebc": "医药-客户地区维度",
        "9405c0570f5a5e1c": "产品名称",
        "ed763db3c7a9544a": "客户信息",
        "1b0f0ba040bf5c14": "套餐月费",
        "aaa_user": "aaa_user",
        "销售员维度表/SALES_PARENT": "区域经理",
        "供应商产品表": "供应商产品表",
        "3387e56f870475bd": "是否4G卡",
        "fd402af9241d1fc7": "医药_客户地区维度",
        "回款事实表/GETDATE": "回款日期1",
        "f9bc115ee0da7bf0": "银行-用户表",
        "签约事实表/TOTAL": "标准总价",
        "6ce2abede215ce11": "excel数据集",
        "雇员2": "雇员2",
        "合同回款事实": "合同回款事实",
        "d541c10f8fcfd87b": "员工用户名",
        "96dd32aa11c9b6e5": "sql数据集",
        "d00d05879abed2a1": "DIM_AREA",
        "员工信息/USER_NUMBER": "员工编号",
        "签约事实表/HTTOTAL": "合同总价",
        "南京苏果营业数据": "南京苏果营业数据",
        "14a0a1a8ec94c7e8": "用户",
        "产品名称维度": "产品名称维度",
        "分公司维度表": "分公司维度表",
        "932dc8e8d4533ae1": "螺旋分析用",
        "银行_机构维度表/机构名称-层级5": "机构名称-三级支行",
        "银行_机构维度表/机构名称-层级4": "机构名称-二级支行",
        "银行_业务维度表": "银行_业务维度表",
        "7888f3b61376c676": "new_dian",
        "银行_机构维度表/机构名称-层级3": "机构名称-一级支行",
        "合同维度表/PRICE": "建筑单价",
        "银行_机构维度表/机构名称-层级2": "机构名称-分行",
        "门店维度": "门店维度",
        "aefc910b92e140a2": "合同金额",
        "银行_机构维度表/机构名称-层级1": "机构名称-总行",
        "房间维度表/TOTAL": "标准总价",
        "aaa_交易": "aaa_交易",
        "浏览器占比变化": "浏览器占比变化",
        "d9fc7bd9eab90b2d": "4G业务",
        "城市地区维度表/REGION": "区域",
        "ed2bb18dc2816686": "互联网_地区维度表",
        "03a43b253cf0a8f6": "银行-机构表",
        "48fd762d07476654": "合同的回款信息",
        "6567d6bd874e68e6": "化工_产品收入率趋势",
        "b71bcaeb473fe09b": "租赁_车辆租赁业务",
        "地区维度表/SSX_NAME": "地区",
        "房间维度表/STATUS": "销售状态",
        "回款事实表/AMOUNT": "回款金额",
        "9d7527938673513d": "样式数据三",
        "成本事实表/UNITPRICENEW": "单方可售直接成本",
        "员工信息/USER_DEPARTMENT": "员工部门",
        "2206e431a4929478": "分公司名称",
        "销售员维度表/SALES_NAME": "客户经理",
        "646e282ddbd7438c": "员工信息",
        "e49fd7228a35e401": "南京苏果营业数据（虚构）",
        "a0e3f4499f0024c4": "付费类型",
        "71f5d15b3433be7f": "客户经理",
        "6b29c992aa38e395": "excel数据集",
        "0de3e944c596fd17": "销售员信息",
        "3f6e8627cd1398ee": "excel数据集",
        "订单": "订单",
        "9c6edbb23d486261": "互联网_访问统计表",
        "ff6322b87d717098": "产品规格",
        "品类维度": "品类维度",
        "618d30c69e6ea6ae": "样式数据一",
        "销售员维度表/SALES_REGION": "销售区域",
        "ExcelView之客户跟踪表": "ExcelView之客户跟踪表",
        "3121a9763318a118": "银行_用户表",
        "回款维度表/ITEMTYPE": "款项类型",
        "a0b0983c5b9a3906": "化工-生成进度表展示",
        "fc3d397c87ac8e2e": "化工-产品收入率趋势",
        "f4215f38743f366f": "产品名称",
        "房间维度表/PRICE": "建筑单价",
        "4253b36903b20366": "医药_产品维度表",
        "0b308b67e3e67b86": "化工_能耗指标趋势",
        "ced229f7c1fc7e62": "回款金额",
        "939b4e4b5db1989c": "化工_库存展示",
        "人员变动表": "人员变动表",
        "成本事实表/OCCUPYAREA": "占地面积",
        "dee4f892cdfcaf41": "sql数据集",
        "房间维度表/QFXFTYPE": "期房类型",
        "667bff5f99f4af5f": "是否副卡",
        "合同维度表/DISCNTVALUE": "折扣",
        "房间维度表/TOTALDJ": "总底价",
        "ffb009686ab23825": "银行-产品表"
    },
    tables: {
        "城市地区维度表": {
            "tableType": 0,
            "id": "城市地区维度表",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "AREAGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "城市地区维度表",
                "id": "城市地区维度表/AREAGUID",
                "tableTranName": "城市地区维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "AREA",
                "fieldSize": 30,
                "isUsable": true,
                "tableId": "城市地区维度表",
                "id": "城市地区维度表/AREA",
                "tableTranName": "城市地区维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "CITY",
                "fieldSize": 30,
                "isUsable": true,
                "tableId": "城市地区维度表",
                "id": "城市地区维度表/CITY",
                "tableTranName": "城市地区维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "REGION",
                "fieldSize": 25,
                "isUsable": true,
                "tableId": "城市地区维度表",
                "id": "城市地区维度表/REGION",
                "tableTranName": "城市地区维度表",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "城市地区维度表记录数",
                "isUsable": true,
                "tableId": "城市地区维度表",
                "id": "城市地区维度表记录数",
                "fieldType": 64
            }]]
        },
        "化工_生成进度表展示": {
            "tableType": 0,
            "id": "化工_生成进度表展示",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "材料",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "化工_生成进度表展示",
                "id": "化工_生成进度表展示/材料",
                "tableTranName": "化工_生成进度表展示",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "类别",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "化工_生成进度表展示",
                "id": "化工_生成进度表展示/类别",
                "tableTranName": "化工_生成进度表展示",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "存留比例",
                "fieldSize": 17,
                "isUsable": true,
                "tableId": "化工_生成进度表展示",
                "id": "化工_生成进度表展示/存留比例",
                "tableTranName": "化工_生成进度表展示",
                "fieldType": 32,
                "isEnable": true
            }], [], [], [{
                "fieldName": "化工_生成进度表展示记录数",
                "isUsable": true,
                "tableId": "化工_生成进度表展示",
                "id": "化工_生成进度表展示记录数",
                "fieldType": 64
            }]]
        },
        "银行_财务分析事实表": {
            "tableType": 0,
            "id": "银行_财务分析事实表",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "ID_NUMBER",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "银行_财务分析事实表",
                "id": "银行_财务分析事实表/ID_NUMBER",
                "tableTranName": "银行_财务分析事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "机构ID",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "银行_财务分析事实表",
                "id": "银行_财务分析事实表/机构ID",
                "tableTranName": "银行_财务分析事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "条线ID",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "银行_财务分析事实表",
                "id": "银行_财务分析事实表/条线ID",
                "tableTranName": "银行_财务分析事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "PA产品号",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "银行_财务分析事实表",
                "id": "银行_财务分析事实表/PA产品号",
                "tableTranName": "银行_财务分析事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "客户ID",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "银行_财务分析事实表",
                "id": "银行_财务分析事实表/客户ID",
                "tableTranName": "银行_财务分析事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "币种",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "银行_财务分析事实表",
                "id": "银行_财务分析事实表/币种",
                "tableTranName": "银行_财务分析事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "月均余额",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "银行_财务分析事实表",
                "id": "银行_财务分析事实表/月均余额",
                "tableTranName": "银行_财务分析事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "当月发生",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "银行_财务分析事实表",
                "id": "银行_财务分析事实表/当月发生",
                "tableTranName": "银行_财务分析事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "当前余额",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "银行_财务分析事实表",
                "id": "银行_财务分析事实表/当前余额",
                "tableTranName": "银行_财务分析事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "交易笔数",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "银行_财务分析事实表",
                "id": "银行_财务分析事实表/交易笔数",
                "tableTranName": "银行_财务分析事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "外部利息收入",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "银行_财务分析事实表",
                "id": "银行_财务分析事实表/外部利息收入",
                "tableTranName": "银行_财务分析事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "外部利息支出",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "银行_财务分析事实表",
                "id": "银行_财务分析事实表/外部利息支出",
                "tableTranName": "银行_财务分析事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "内部资金转移收入",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "银行_财务分析事实表",
                "id": "银行_财务分析事实表/内部资金转移收入",
                "tableTranName": "银行_财务分析事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "内部资金转移支出",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "银行_财务分析事实表",
                "id": "银行_财务分析事实表/内部资金转移支出",
                "tableTranName": "银行_财务分析事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "外部利息净收入",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "银行_财务分析事实表",
                "id": "银行_财务分析事实表/外部利息净收入",
                "tableTranName": "银行_财务分析事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "营业税金及附加_总行分摊",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "银行_财务分析事实表",
                "id": "银行_财务分析事实表/营业税金及附加_总行分摊",
                "tableTranName": "银行_财务分析事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "营业税金及附加_分行分摊",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "银行_财务分析事实表",
                "id": "银行_财务分析事实表/营业税金及附加_分行分摊",
                "tableTranName": "银行_财务分析事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "营业税金及附加_支行分摊",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "银行_财务分析事实表",
                "id": "银行_财务分析事实表/营业税金及附加_支行分摊",
                "tableTranName": "银行_财务分析事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "资产减值损失",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "银行_财务分析事实表",
                "id": "银行_财务分析事实表/资产减值损失",
                "tableTranName": "银行_财务分析事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "税后净利润_完全利润",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "银行_财务分析事实表",
                "id": "银行_财务分析事实表/税后净利润_完全利润",
                "tableTranName": "银行_财务分析事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "经济资本",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "银行_财务分析事实表",
                "id": "银行_财务分析事实表/经济资本",
                "tableTranName": "银行_财务分析事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "资本成本",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "银行_财务分析事实表",
                "id": "银行_财务分析事实表/资本成本",
                "tableTranName": "银行_财务分析事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "EVA",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "银行_财务分析事实表",
                "id": "银行_财务分析事实表/EVA",
                "tableTranName": "银行_财务分析事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "RAROC",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "银行_财务分析事实表",
                "id": "银行_财务分析事实表/RAROC",
                "tableTranName": "银行_财务分析事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "业务ID",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "银行_财务分析事实表",
                "id": "银行_财务分析事实表/业务ID",
                "tableTranName": "银行_财务分析事实表",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "银行_财务分析事实表记录数",
                "isUsable": true,
                "tableId": "银行_财务分析事实表",
                "id": "银行_财务分析事实表记录数",
                "fieldType": 64
            }]]
        },
        "分界口货车出入情况": {
            "tableType": 0,
            "id": "分界口货车出入情况",
            "connectionName": "FRDemo",
            "fields": [[{
                "fieldName": "ID",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "分界口货车出入情况",
                "id": "分界口货车出入情况/ID",
                "tableTranName": "分界口货车出入情况",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "累计方式",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "分界口货车出入情况",
                "id": "分界口货车出入情况/累计方式",
                "tableTranName": "分界口货车出入情况",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "出入车地点及管内到达",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "分界口货车出入情况",
                "id": "分界口货车出入情况/出入车地点及管内到达",
                "tableTranName": "分界口货车出入情况",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "交出\\接入",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "分界口货车出入情况",
                "id": "分界口货车出入情况/交出\\接入",
                "tableTranName": "分界口货车出入情况",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "车型",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "分界口货车出入情况",
                "id": "分界口货车出入情况/车型",
                "tableTranName": "分界口货车出入情况",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "值",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "分界口货车出入情况",
                "id": "分界口货车出入情况/值",
                "tableTranName": "分界口货车出入情况",
                "fieldType": 32,
                "isEnable": true
            }], [], [], [{
                "fieldName": "分界口货车出入情况记录数",
                "isUsable": true,
                "tableId": "分界口货车出入情况",
                "id": "分界口货车出入情况记录数",
                "fieldType": 64
            }]]
        },
        "化工_库存展示": {
            "tableType": 0,
            "id": "化工_库存展示",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "材料名称",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "化工_库存展示",
                "id": "化工_库存展示/材料名称",
                "tableTranName": "化工_库存展示",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "库存量",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "化工_库存展示",
                "id": "化工_库存展示/库存量",
                "tableTranName": "化工_库存展示",
                "fieldType": 32,
                "isEnable": true
            }], [], [], [{
                "fieldName": "化工_库存展示记录数",
                "isUsable": true,
                "tableId": "化工_库存展示",
                "id": "化工_库存展示记录数",
                "fieldType": 64
            }]]
        },
        "机构表": {
            "tableType": 0,
            "id": "机构表",
            "connectionName": "",
            "fields": [[{
                "fieldName": "机构",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "机构表",
                "id": "机构表/机构",
                "tableTranName": "机构表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "上级机构",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "机构表",
                "id": "机构表/上级机构",
                "tableTranName": "机构表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "机构名称",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "机构表",
                "id": "机构表/机构名称",
                "tableTranName": "机构表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "机构-层级1",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "机构表",
                "id": "机构表/机构-层级1",
                "tableTranName": "机构表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "机构-层级2",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "机构表",
                "id": "机构表/机构-层级2",
                "tableTranName": "机构表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "机构-层级3",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "机构表",
                "id": "机构表/机构-层级3",
                "tableTranName": "机构表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "机构名称-层级1",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "机构表",
                "id": "机构表/机构名称-层级1",
                "tableTranName": "机构表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "机构名称-层级2",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "机构表",
                "id": "机构表/机构名称-层级2",
                "tableTranName": "机构表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "机构名称-层级3",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "机构表",
                "id": "机构表/机构名称-层级3",
                "tableTranName": "机构表",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "机构表记录数",
                "isUsable": true,
                "tableId": "机构表",
                "id": "机构表记录数",
                "fieldType": 64
            }]]
        },
        "宽带业务": {
            "tableType": 0,
            "id": "宽带业务",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "区域ID",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "宽带业务",
                "id": "宽带业务/区域ID",
                "tableTranName": "宽带业务",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "分局",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "宽带业务",
                "id": "宽带业务/分局",
                "tableTranName": "宽带业务",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "竣工日期",
                "fieldSize": 8,
                "isUsable": true,
                "tableId": "宽带业务",
                "id": "宽带业务/竣工日期",
                "tableTranName": "宽带业务",
                "fieldType": 48,
                "isEnable": true
            },
            {
                "fieldName": "种类",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "宽带业务",
                "id": "宽带业务/种类",
                "tableTranName": "宽带业务",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "速率",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "宽带业务",
                "id": "宽带业务/速率",
                "tableTranName": "宽带业务",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "接入方式",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "宽带业务",
                "id": "宽带业务/接入方式",
                "tableTranName": "宽带业务",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "是否WLAN",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "宽带业务",
                "id": "宽带业务/是否WLAN",
                "tableTranName": "宽带业务",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "是否酒店",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "宽带业务",
                "id": "宽带业务/是否酒店",
                "tableTranName": "宽带业务",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "是否纯ITV",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "宽带业务",
                "id": "宽带业务/是否纯ITV",
                "tableTranName": "宽带业务",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "是否校园",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "宽带业务",
                "id": "宽带业务/是否校园",
                "tableTranName": "宽带业务",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "组合销售品",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "宽带业务",
                "id": "宽带业务/组合销售品",
                "tableTranName": "宽带业务",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "组合类型",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "宽带业务",
                "id": "宽带业务/组合类型",
                "tableTranName": "宽带业务",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "类型细类",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "宽带业务",
                "id": "宽带业务/类型细类",
                "tableTranName": "宽带业务",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "网格",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "宽带业务",
                "id": "宽带业务/网格",
                "tableTranName": "宽带业务",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "预后付",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "宽带业务",
                "id": "宽带业务/预后付",
                "tableTranName": "宽带业务",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "产品类型",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "宽带业务",
                "id": "宽带业务/产品类型",
                "tableTranName": "宽带业务",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "基本销售品",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "宽带业务",
                "id": "宽带业务/基本销售品",
                "tableTranName": "宽带业务",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "是否有ITV",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "宽带业务",
                "id": "宽带业务/是否有ITV",
                "tableTranName": "宽带业务",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "宽带业务记录数",
                "isUsable": true,
                "tableId": "宽带业务",
                "id": "宽带业务记录数",
                "fieldType": 64
            }]]
        },
        "回款维度表": {
            "tableType": 0,
            "id": "回款维度表",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "GETINGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "回款维度表",
                "id": "回款维度表/GETINGUID",
                "tableTranName": "回款维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "ITEMNAME",
                "fieldSize": 30,
                "isUsable": true,
                "tableId": "回款维度表",
                "id": "回款维度表/ITEMNAME",
                "tableTranName": "回款维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "ITEMTYPE",
                "fieldSize": 20,
                "isUsable": true,
                "tableId": "回款维度表",
                "id": "回款维度表/ITEMTYPE",
                "tableTranName": "回款维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "ABCDATE",
                "fieldSize": 8,
                "isUsable": true,
                "tableId": "回款维度表",
                "id": "回款维度表/ABCDATE",
                "tableTranName": "回款维度表",
                "fieldType": 48,
                "isEnable": true
            },
            {
                "fieldName": "ABCNAME",
                "fieldSize": 10,
                "isUsable": true,
                "tableId": "回款维度表",
                "id": "回款维度表/ABCNAME",
                "tableTranName": "回款维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "GETDATE",
                "fieldSize": 8,
                "isUsable": true,
                "tableId": "回款维度表",
                "id": "回款维度表/GETDATE",
                "tableTranName": "回款维度表",
                "fieldType": 48,
                "isEnable": true
            },
            {
                "fieldName": "CONTRACTTYPENAME",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "回款维度表",
                "id": "回款维度表/CONTRACTTYPENAME",
                "tableTranName": "回款维度表",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "回款维度表记录数",
                "isUsable": true,
                "tableId": "回款维度表",
                "id": "回款维度表记录数",
                "fieldType": 64
            }]]
        },
        "签约事实表": {
            "tableType": 0,
            "id": "签约事实表",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "AREAGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "签约事实表",
                "id": "签约事实表/AREAGUID",
                "tableTranName": "签约事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "BUGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "签约事实表",
                "id": "签约事实表/BUGUID",
                "tableTranName": "签约事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "PROJGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "签约事实表",
                "id": "签约事实表/PROJGUID",
                "tableTranName": "签约事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "BLDGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "签约事实表",
                "id": "签约事实表/BLDGUID",
                "tableTranName": "签约事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "PRODUCTGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "签约事实表",
                "id": "签约事实表/PRODUCTGUID",
                "tableTranName": "签约事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "ROOMGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "签约事实表",
                "id": "签约事实表/ROOMGUID",
                "tableTranName": "签约事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "CONTRACTGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "签约事实表",
                "id": "签约事实表/CONTRACTGUID",
                "tableTranName": "签约事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "QSDATE",
                "fieldSize": 8,
                "isUsable": true,
                "tableId": "签约事实表",
                "id": "签约事实表/QSDATE",
                "tableTranName": "签约事实表",
                "fieldType": 48,
                "isEnable": true
            },
            {
                "fieldName": "RMBHTTOTAL",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "签约事实表",
                "id": "签约事实表/RMBHTTOTAL",
                "tableTranName": "签约事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "BLDAREA",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "签约事实表",
                "id": "签约事实表/BLDAREA",
                "tableTranName": "签约事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "PRICE",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "签约事实表",
                "id": "签约事实表/PRICE",
                "tableTranName": "签约事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "CJPRICE",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "签约事实表",
                "id": "签约事实表/CJPRICE",
                "tableTranName": "签约事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "ROOMTOTAL",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "签约事实表",
                "id": "签约事实表/ROOMTOTAL",
                "tableTranName": "签约事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "HTTOTAL",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "签约事实表",
                "id": "签约事实表/HTTOTAL",
                "tableTranName": "签约事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "TOTAL",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "签约事实表",
                "id": "签约事实表/TOTAL",
                "tableTranName": "签约事实表",
                "fieldType": 32,
                "isEnable": true
            }], [], [], [{
                "fieldName": "签约事实表记录数",
                "isUsable": true,
                "tableId": "签约事实表",
                "id": "签约事实表记录数",
                "fieldType": 64
            }]]
        },
        "订单明细": {
            "tableType": 0,
            "id": "订单明细",
            "connectionName": "FRDemo",
            "fields": [[{
                "fieldName": "产品ID",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "订单明细",
                "id": "订单明细/产品ID",
                "tableTranName": "订单明细",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "金额",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "订单明细",
                "id": "订单明细/金额",
                "tableTranName": "订单明细",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "供应商id",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "订单明细",
                "id": "订单明细/供应商id",
                "tableTranName": "订单明细",
                "fieldType": 32,
                "isEnable": true
            }], [], [], [{
                "fieldName": "订单明细记录数",
                "isUsable": true,
                "tableId": "订单明细",
                "id": "订单明细记录数",
                "fieldType": 64
            }]]
        },
        "供应商产品表": {
            "tableType": 0,
            "id": "供应商产品表",
            "connectionName": "FRDemo",
            "fields": [[{
                "fieldName": "产品ID",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "供应商产品表",
                "id": "供应商产品表/产品ID",
                "tableTranName": "供应商产品表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "产品名称",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "供应商产品表",
                "id": "供应商产品表/产品名称",
                "tableTranName": "供应商产品表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "供应商ID",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "供应商产品表",
                "id": "供应商产品表/供应商ID",
                "tableTranName": "供应商产品表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "类别ID",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "供应商产品表",
                "id": "供应商产品表/类别ID",
                "tableTranName": "供应商产品表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "单位数量",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "供应商产品表",
                "id": "供应商产品表/单位数量",
                "tableTranName": "供应商产品表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "单价",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "供应商产品表",
                "id": "供应商产品表/单价",
                "tableTranName": "供应商产品表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "库存量",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "供应商产品表",
                "id": "供应商产品表/库存量",
                "tableTranName": "供应商产品表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "订购量",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "供应商产品表",
                "id": "供应商产品表/订购量",
                "tableTranName": "供应商产品表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "再订购量",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "供应商产品表",
                "id": "供应商产品表/再订购量",
                "tableTranName": "供应商产品表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "中止",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "供应商产品表",
                "id": "供应商产品表/中止",
                "tableTranName": "供应商产品表",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "供应商产品表记录数",
                "isUsable": true,
                "tableId": "供应商产品表",
                "id": "供应商产品表记录数",
                "fieldType": 64
            }]]
        },
        "西安兰特雨量监测数据": {
            "tableType": 0,
            "id": "西安兰特雨量监测数据",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "监测时间",
                "fieldSize": 8,
                "isUsable": true,
                "tableId": "西安兰特雨量监测数据",
                "id": "西安兰特雨量监测数据/监测时间",
                "tableTranName": "西安兰特雨量监测数据",
                "fieldType": 48,
                "isEnable": true
            },
            {
                "fieldName": "流量",
                "fieldSize": 17,
                "isUsable": true,
                "tableId": "西安兰特雨量监测数据",
                "id": "西安兰特雨量监测数据/流量",
                "tableTranName": "西安兰特雨量监测数据",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "降雨量",
                "fieldSize": 17,
                "isUsable": true,
                "tableId": "西安兰特雨量监测数据",
                "id": "西安兰特雨量监测数据/降雨量",
                "tableTranName": "西安兰特雨量监测数据",
                "fieldType": 32,
                "isEnable": true
            }], [], [], [{
                "fieldName": "西安兰特雨量监测数据记录数",
                "isUsable": true,
                "tableId": "西安兰特雨量监测数据",
                "id": "西安兰特雨量监测数据记录数",
                "fieldType": 64
            }]]
        },
        "银行_机构维度表": {
            "tableType": 0,
            "id": "银行_机构维度表",
            "connectionName": "",
            "fields": [[{
                "fieldName": "机构名称",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "银行_机构维度表",
                "id": "银行_机构维度表/机构名称",
                "tableTranName": "银行_机构维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "PARENT_ID",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "银行_机构维度表",
                "id": "银行_机构维度表/PARENT_ID",
                "tableTranName": "银行_机构维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "机构名称-层级5",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "银行_机构维度表",
                "id": "银行_机构维度表/机构名称-层级5",
                "tableTranName": "银行_机构维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "机构名称-层级4",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "银行_机构维度表",
                "id": "银行_机构维度表/机构名称-层级4",
                "tableTranName": "银行_机构维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "JGID",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "银行_机构维度表",
                "id": "银行_机构维度表/JGID",
                "tableTranName": "银行_机构维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "机构名称-层级3",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "银行_机构维度表",
                "id": "银行_机构维度表/机构名称-层级3",
                "tableTranName": "银行_机构维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "机构名称-层级2",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "银行_机构维度表",
                "id": "银行_机构维度表/机构名称-层级2",
                "tableTranName": "银行_机构维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "机构名称-层级1",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "银行_机构维度表",
                "id": "银行_机构维度表/机构名称-层级1",
                "tableTranName": "银行_机构维度表",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "银行_机构维度表记录数",
                "isUsable": true,
                "tableId": "银行_机构维度表",
                "id": "银行_机构维度表记录数",
                "fieldType": 64
            }]]
        },
        "十大热门旅游城市": {
            "tableType": 0,
            "id": "十大热门旅游城市",
            "connectionName": "",
            "fields": [[{
                "fieldName": "排名",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "十大热门旅游城市",
                "id": "十大热门旅游城市/排名",
                "tableTranName": "十大热门旅游城市",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "热门旅游城市",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "十大热门旅游城市",
                "id": "十大热门旅游城市/热门旅游城市",
                "tableTranName": "十大热门旅游城市",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "旅游人次",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "十大热门旅游城市",
                "id": "十大热门旅游城市/旅游人次",
                "tableTranName": "十大热门旅游城市",
                "fieldType": 32,
                "isEnable": true
            }], [], [], [{
                "fieldName": "十大热门旅游城市记录数",
                "isUsable": true,
                "tableId": "十大热门旅游城市",
                "id": "十大热门旅游城市记录数",
                "fieldType": 64
            }]]
        },
        "销售明细": {
            "tableType": 0,
            "id": "销售明细",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "销售日期",
                "fieldSize": 8,
                "isUsable": true,
                "tableId": "销售明细",
                "id": "销售明细/销售日期",
                "tableTranName": "销售明细",
                "fieldType": 48,
                "isEnable": true
            },
            {
                "fieldName": "店号",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "销售明细",
                "id": "销售明细/店号",
                "tableTranName": "销售明细",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "类别",
                "fieldSize": 10,
                "isUsable": true,
                "tableId": "销售明细",
                "id": "销售明细/类别",
                "tableTranName": "销售明细",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "品牌编号",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "销售明细",
                "id": "销售明细/品牌编号",
                "tableTranName": "销售明细",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "楼层",
                "fieldSize": 10,
                "isUsable": true,
                "tableId": "销售明细",
                "id": "销售明细/楼层",
                "tableTranName": "销售明细",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "销售额",
                "fieldSize": 10,
                "isUsable": true,
                "tableId": "销售明细",
                "id": "销售明细/销售额",
                "tableTranName": "销售明细",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "毛利",
                "fieldSize": 10,
                "isUsable": true,
                "tableId": "销售明细",
                "id": "销售明细/毛利",
                "tableTranName": "销售明细",
                "fieldType": 32,
                "isEnable": true
            }], [], [], [{
                "fieldName": "销售明细记录数",
                "isUsable": true,
                "tableId": "销售明细",
                "id": "销售明细记录数",
                "fieldType": 64
            }]]
        },
        "全国环境监测数据": {
            "tableType": 0,
            "id": "全国环境监测数据",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "监测点编码",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "全国环境监测数据",
                "id": "全国环境监测数据/监测点编码",
                "tableTranName": "全国环境监测数据",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "监测点名称",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "全国环境监测数据",
                "id": "全国环境监测数据/监测点名称",
                "tableTranName": "全国环境监测数据",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "监测城市",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "全国环境监测数据",
                "id": "全国环境监测数据/监测城市",
                "tableTranName": "全国环境监测数据",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "监测点经度",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "全国环境监测数据",
                "id": "全国环境监测数据/监测点经度",
                "tableTranName": "全国环境监测数据",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "监测点纬度",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "全国环境监测数据",
                "id": "全国环境监测数据/监测点纬度",
                "tableTranName": "全国环境监测数据",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "PM值",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "全国环境监测数据",
                "id": "全国环境监测数据/PM值",
                "tableTranName": "全国环境监测数据",
                "fieldType": 32,
                "isEnable": true
            }], [], [], [{
                "fieldName": "全国环境监测数据记录数",
                "isUsable": true,
                "tableId": "全国环境监测数据",
                "id": "全国环境监测数据记录数",
                "fieldType": 64
            }]]
        },
        "雇员2": {
            "tableType": 0,
            "id": "雇员2",
            "connectionName": "FRDemo",
            "fields": [[{
                "fieldName": "雇员ID",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "雇员2",
                "id": "雇员2/雇员ID",
                "tableTranName": "雇员2",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "货主地区",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "雇员2",
                "id": "雇员2/货主地区",
                "tableTranName": "雇员2",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "产品ID",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "雇员2",
                "id": "雇员2/产品ID",
                "tableTranName": "雇员2",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "金额",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "雇员2",
                "id": "雇员2/金额",
                "tableTranName": "雇员2",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "雇员2记录数",
                "isUsable": true,
                "tableId": "雇员2",
                "id": "雇员2记录数",
                "fieldType": 64
            }]]
        },
        "合同回款事实": {
            "tableType": 0,
            "id": "合同回款事实",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "合同ID",
                "fieldSize": 128,
                "isUsable": true,
                "tableId": "合同回款事实",
                "id": "合同回款事实/合同ID",
                "tableTranName": "合同回款事实",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "付款时间",
                "fieldSize": 23,
                "isUsable": true,
                "tableId": "合同回款事实",
                "id": "合同回款事实/付款时间",
                "tableTranName": "合同回款事实",
                "fieldType": 48,
                "isEnable": true
            },
            {
                "fieldName": "付款金额",
                "fieldSize": 10,
                "isUsable": true,
                "tableId": "合同回款事实",
                "id": "合同回款事实/付款金额",
                "tableTranName": "合同回款事实",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "记录人",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "合同回款事实",
                "id": "合同回款事实/记录人",
                "tableTranName": "合同回款事实",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "合同回款事实记录数",
                "isUsable": true,
                "tableId": "合同回款事实",
                "id": "合同回款事实记录数",
                "fieldType": 64
            }]]
        },
        "回款事实表": {
            "tableType": 0,
            "id": "回款事实表",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "AREAGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "回款事实表",
                "id": "回款事实表/AREAGUID",
                "tableTranName": "回款事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "BUGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "回款事实表",
                "id": "回款事实表/BUGUID",
                "tableTranName": "回款事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "PROJGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "回款事实表",
                "id": "回款事实表/PROJGUID",
                "tableTranName": "回款事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "BLDGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "回款事实表",
                "id": "回款事实表/BLDGUID",
                "tableTranName": "回款事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "ROOMGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "回款事实表",
                "id": "回款事实表/ROOMGUID",
                "tableTranName": "回款事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "PRODUCTGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "回款事实表",
                "id": "回款事实表/PRODUCTGUID",
                "tableTranName": "回款事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "GETINGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "回款事实表",
                "id": "回款事实表/GETINGUID",
                "tableTranName": "回款事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "AMOUNT",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "回款事实表",
                "id": "回款事实表/AMOUNT",
                "tableTranName": "回款事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "GETDATE",
                "fieldSize": 8,
                "isUsable": true,
                "tableId": "回款事实表",
                "id": "回款事实表/GETDATE",
                "tableTranName": "回款事实表",
                "fieldType": 48,
                "isEnable": true
            },
            {
                "fieldName": "ABCDATE",
                "fieldSize": 8,
                "isUsable": true,
                "tableId": "回款事实表",
                "id": "回款事实表/ABCDATE",
                "tableTranName": "回款事实表",
                "fieldType": 48,
                "isEnable": true
            },
            {
                "fieldName": "STATUS",
                "fieldSize": 64,
                "isUsable": true,
                "tableId": "回款事实表",
                "id": "回款事实表/STATUS",
                "tableTranName": "回款事实表",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "回款事实表记录数",
                "isUsable": true,
                "tableId": "回款事实表",
                "id": "回款事实表记录数",
                "fieldType": 64
            }]]
        },
        "出游年龄占比": {
            "tableType": 0,
            "id": "出游年龄占比",
            "connectionName": "",
            "fields": [[{
                "fieldName": "年龄",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "出游年龄占比",
                "id": "出游年龄占比/年龄",
                "tableTranName": "出游年龄占比",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "占比",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "出游年龄占比",
                "id": "出游年龄占比/占比",
                "tableTranName": "出游年龄占比",
                "fieldType": 32,
                "isEnable": true
            }], [], [], [{
                "fieldName": "出游年龄占比记录数",
                "isUsable": true,
                "tableId": "出游年龄占比",
                "id": "出游年龄占比记录数",
                "fieldType": 64
            }]]
        },
        "用户登录权限表": {
            "tableType": 0,
            "id": "用户登录权限表",
            "connectionName": "FRDemo",
            "fields": [[{
                "fieldName": "账号",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "用户登录权限表",
                "id": "用户登录权限表/账号",
                "tableTranName": "用户登录权限表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "密码",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "用户登录权限表",
                "id": "用户登录权限表/密码",
                "tableTranName": "用户登录权限表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "机构",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "用户登录权限表",
                "id": "用户登录权限表/机构",
                "tableTranName": "用户登录权限表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "职务",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "用户登录权限表",
                "id": "用户登录权限表/职务",
                "tableTranName": "用户登录权限表",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "用户登录权限表记录数",
                "isUsable": true,
                "tableId": "用户登录权限表",
                "id": "用户登录权限表记录数",
                "fieldType": 64
            }]]
        },
        "北京春运迁徙数据": {
            "tableType": 0,
            "id": "北京春运迁徙数据",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "迁出城市",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "北京春运迁徙数据",
                "id": "北京春运迁徙数据/迁出城市",
                "tableTranName": "北京春运迁徙数据",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "迁出城市经度",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "北京春运迁徙数据",
                "id": "北京春运迁徙数据/迁出城市经度",
                "tableTranName": "北京春运迁徙数据",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "迁出城市纬度",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "北京春运迁徙数据",
                "id": "北京春运迁徙数据/迁出城市纬度",
                "tableTranName": "北京春运迁徙数据",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "迁入城市",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "北京春运迁徙数据",
                "id": "北京春运迁徙数据/迁入城市",
                "tableTranName": "北京春运迁徙数据",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "迁入城市经度",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "北京春运迁徙数据",
                "id": "北京春运迁徙数据/迁入城市经度",
                "tableTranName": "北京春运迁徙数据",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "迁入城市纬度",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "北京春运迁徙数据",
                "id": "北京春运迁徙数据/迁入城市纬度",
                "tableTranName": "北京春运迁徙数据",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "迁徙人数",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "北京春运迁徙数据",
                "id": "北京春运迁徙数据/迁徙人数",
                "tableTranName": "北京春运迁徙数据",
                "fieldType": 32,
                "isEnable": true
            }], [], [], [{
                "fieldName": "北京春运迁徙数据记录数",
                "isUsable": true,
                "tableId": "北京春运迁徙数据",
                "id": "北京春运迁徙数据记录数",
                "fieldType": 64
            }]]
        },
        "出境方式占比": {
            "tableType": 0,
            "id": "出境方式占比",
            "connectionName": "",
            "fields": [[{
                "fieldName": "出境方式",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "出境方式占比",
                "id": "出境方式占比/出境方式",
                "tableTranName": "出境方式占比",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "占比",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "出境方式占比",
                "id": "出境方式占比/占比",
                "tableTranName": "出境方式占比",
                "fieldType": 32,
                "isEnable": true
            }], [], [], [{
                "fieldName": "出境方式占比记录数",
                "isUsable": true,
                "tableId": "出境方式占比",
                "id": "出境方式占比记录数",
                "fieldType": 64
            }]]
        },
        "医药_产品维度表": {
            "tableType": 0,
            "id": "医药_产品维度表",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "产品编码",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "医药_产品维度表",
                "id": "医药_产品维度表/产品编码",
                "tableTranName": "医药_产品维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "产品名称",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "医药_产品维度表",
                "id": "医药_产品维度表/产品名称",
                "tableTranName": "医药_产品维度表",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "医药_产品维度表记录数",
                "isUsable": true,
                "tableId": "医药_产品维度表",
                "id": "医药_产品维度表记录数",
                "fieldType": 64
            }]]
        },
        "南京苏果营业数据": {
            "tableType": 0,
            "id": "南京苏果营业数据",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "编号",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "南京苏果营业数据",
                "id": "南京苏果营业数据/编号",
                "tableTranName": "南京苏果营业数据",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "店名",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "南京苏果营业数据",
                "id": "南京苏果营业数据/店名",
                "tableTranName": "南京苏果营业数据",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "地址",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "南京苏果营业数据",
                "id": "南京苏果营业数据/地址",
                "tableTranName": "南京苏果营业数据",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "营业额",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "南京苏果营业数据",
                "id": "南京苏果营业数据/营业额",
                "tableTranName": "南京苏果营业数据",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "会员人数",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "南京苏果营业数据",
                "id": "南京苏果营业数据/会员人数",
                "tableTranName": "南京苏果营业数据",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "经度",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "南京苏果营业数据",
                "id": "南京苏果营业数据/经度",
                "tableTranName": "南京苏果营业数据",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "纬度",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "南京苏果营业数据",
                "id": "南京苏果营业数据/纬度",
                "tableTranName": "南京苏果营业数据",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "南京苏果营业数据记录数",
                "isUsable": true,
                "tableId": "南京苏果营业数据",
                "id": "南京苏果营业数据记录数",
                "fieldType": 64
            }]]
        },
        "医药_客户地区维度": {
            "tableType": 0,
            "id": "医药_客户地区维度",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "客户编码",
                "fieldSize": 64,
                "isUsable": true,
                "tableId": "医药_客户地区维度",
                "id": "医药_客户地区维度/客户编码",
                "tableTranName": "医药_客户地区维度",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "省区",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "医药_客户地区维度",
                "id": "医药_客户地区维度/省区",
                "tableTranName": "医药_客户地区维度",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "客户名称",
                "fieldSize": 64,
                "isUsable": true,
                "tableId": "医药_客户地区维度",
                "id": "医药_客户地区维度/客户名称",
                "tableTranName": "医药_客户地区维度",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "医药_客户地区维度记录数",
                "isUsable": true,
                "tableId": "医药_客户地区维度",
                "id": "医药_客户地区维度记录数",
                "fieldType": 64
            }]]
        },
        "分公司维度表": {
            "tableType": 0,
            "id": "分公司维度表",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "省份",
                "fieldSize": 200,
                "isUsable": true,
                "tableId": "分公司维度表",
                "id": "分公司维度表/省份",
                "tableTranName": "分公司维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "办事处经度",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "分公司维度表",
                "id": "分公司维度表/办事处经度",
                "tableTranName": "分公司维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "办事处纬度",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "分公司维度表",
                "id": "分公司维度表/办事处纬度",
                "tableTranName": "分公司维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "所属办事处",
                "fieldSize": 200,
                "isUsable": true,
                "tableId": "分公司维度表",
                "id": "分公司维度表/所属办事处",
                "tableTranName": "分公司维度表",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "分公司维度表记录数",
                "isUsable": true,
                "tableId": "分公司维度表",
                "id": "分公司维度表记录数",
                "fieldType": 64
            }]]
        },
        "产品名称维度": {
            "tableType": 0,
            "id": "产品名称维度",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "产品ID",
                "fieldSize": 10,
                "isUsable": true,
                "tableId": "产品名称维度",
                "id": "产品名称维度/产品ID",
                "tableTranName": "产品名称维度",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "产品名称",
                "fieldSize": 200,
                "isUsable": true,
                "tableId": "产品名称维度",
                "id": "产品名称维度/产品名称",
                "tableTranName": "产品名称维度",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "产品名称维度记录数",
                "isUsable": true,
                "tableId": "产品名称维度",
                "id": "产品名称维度记录数",
                "fieldType": 64
            }]]
        },
        "银行_业务维度表": {
            "tableType": 0,
            "id": "银行_业务维度表",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "业务代码",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "银行_业务维度表",
                "id": "银行_业务维度表/业务代码",
                "tableTranName": "银行_业务维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "业务名称",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "银行_业务维度表",
                "id": "银行_业务维度表/业务名称",
                "tableTranName": "银行_业务维度表",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "银行_业务维度表记录数",
                "isUsable": true,
                "tableId": "银行_业务维度表",
                "id": "银行_业务维度表记录数",
                "fieldType": 64
            }]]
        },
        "合同维度表": {
            "tableType": 0,
            "id": "合同维度表",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "CONTRACTGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "合同维度表",
                "id": "合同维度表/CONTRACTGUID",
                "tableTranName": "合同维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "SALEAREA",
                "fieldSize": 20,
                "isUsable": true,
                "tableId": "合同维度表",
                "id": "合同维度表/SALEAREA",
                "tableTranName": "合同维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "PRICE",
                "fieldSize": 20,
                "isUsable": true,
                "tableId": "合同维度表",
                "id": "合同维度表/PRICE",
                "tableTranName": "合同维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "TOTAL",
                "fieldSize": 20,
                "isUsable": true,
                "tableId": "合同维度表",
                "id": "合同维度表/TOTAL",
                "tableTranName": "合同维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "PAYFORMNAME",
                "fieldSize": 30,
                "isUsable": true,
                "tableId": "合同维度表",
                "id": "合同维度表/PAYFORMNAME",
                "tableTranName": "合同维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "DISCNTVALUE",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "合同维度表",
                "id": "合同维度表/DISCNTVALUE",
                "tableTranName": "合同维度表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "CJPRICE",
                "fieldSize": 20,
                "isUsable": true,
                "tableId": "合同维度表",
                "id": "合同维度表/CJPRICE",
                "tableTranName": "合同维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "ROOMTOTAL",
                "fieldSize": 20,
                "isUsable": true,
                "tableId": "合同维度表",
                "id": "合同维度表/ROOMTOTAL",
                "tableTranName": "合同维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "STATUS",
                "fieldSize": 20,
                "isUsable": true,
                "tableId": "合同维度表",
                "id": "合同维度表/STATUS",
                "tableTranName": "合同维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "CLOSEREASON",
                "fieldSize": 30,
                "isUsable": true,
                "tableId": "合同维度表",
                "id": "合同维度表/CLOSEREASON",
                "tableTranName": "合同维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "QSDATE",
                "fieldSize": 30,
                "isUsable": true,
                "tableId": "合同维度表",
                "id": "合同维度表/QSDATE",
                "tableTranName": "合同维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "DISCNTREMARK",
                "fieldSize": 256,
                "isUsable": true,
                "tableId": "合同维度表",
                "id": "合同维度表/DISCNTREMARK",
                "tableTranName": "合同维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "CONTRACTTYPENAME",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "合同维度表",
                "id": "合同维度表/CONTRACTTYPENAME",
                "tableTranName": "合同维度表",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "合同维度表记录数",
                "isUsable": true,
                "tableId": "合同维度表",
                "id": "合同维度表记录数",
                "fieldType": 64
            }]]
        },
        "门店维度": {
            "tableType": 0,
            "id": "门店维度",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "店号",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "门店维度",
                "id": "门店维度/店号",
                "tableTranName": "门店维度",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "店名",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "门店维度",
                "id": "门店维度/店名",
                "tableTranName": "门店维度",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "所属大区",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "门店维度",
                "id": "门店维度/所属大区",
                "tableTranName": "门店维度",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "所属小区",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "门店维度",
                "id": "门店维度/所属小区",
                "tableTranName": "门店维度",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "店性质",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "门店维度",
                "id": "门店维度/店性质",
                "tableTranName": "门店维度",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "店风格",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "门店维度",
                "id": "门店维度/店风格",
                "tableTranName": "门店维度",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "合并统计店名",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "门店维度",
                "id": "门店维度/合并统计店名",
                "tableTranName": "门店维度",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "门店维度记录数",
                "isUsable": true,
                "tableId": "门店维度",
                "id": "门店维度记录数",
                "fieldType": 64
            }]]
        },
        "医药_库存周转事实表": {
            "tableType": 0,
            "id": "医药_库存周转事实表",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "客户编码",
                "fieldSize": 64,
                "isUsable": true,
                "tableId": "医药_库存周转事实表",
                "id": "医药_库存周转事实表/客户编码",
                "tableTranName": "医药_库存周转事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "产品编码",
                "fieldSize": 64,
                "isUsable": true,
                "tableId": "医药_库存周转事实表",
                "id": "医药_库存周转事实表/产品编码",
                "tableTranName": "医药_库存周转事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "库存金额",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "医药_库存周转事实表",
                "id": "医药_库存周转事实表/库存金额",
                "tableTranName": "医药_库存周转事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "月均销量",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "医药_库存周转事实表",
                "id": "医药_库存周转事实表/月均销量",
                "tableTranName": "医药_库存周转事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "周转月",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "医药_库存周转事实表",
                "id": "医药_库存周转事实表/周转月",
                "tableTranName": "医药_库存周转事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "周转天",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "医药_库存周转事实表",
                "id": "医药_库存周转事实表/周转天",
                "tableTranName": "医药_库存周转事实表",
                "fieldType": 32,
                "isEnable": true
            }], [], [], [{
                "fieldName": "医药_库存周转事实表记录数",
                "isUsable": true,
                "tableId": "医药_库存周转事实表",
                "id": "医药_库存周转事实表记录数",
                "fieldType": 64
            }]]
        },
        "成本事实表": {
            "tableType": 0,
            "id": "成本事实表",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "AREAGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/AREAGUID",
                "tableTranName": "成本事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "BUGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/BUGUID",
                "tableTranName": "成本事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "PROJGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/PROJGUID",
                "tableTranName": "成本事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "PARENTPROJGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/PARENTPROJGUID",
                "tableTranName": "成本事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "BUILDPRODUCTTYPEGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/BUILDPRODUCTTYPEGUID",
                "tableTranName": "成本事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "DFZJCB",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/DFZJCB",
                "tableTranName": "成本事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "TOTALUNITCOSTDISPLAY",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/TOTALUNITCOSTDISPLAY",
                "tableTranName": "成本事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "OCCUPYAREA",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/OCCUPYAREA",
                "tableTranName": "成本事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "SALEAREA",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/SALEAREA",
                "tableTranName": "成本事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "BUILDRATE",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/BUILDRATE",
                "tableTranName": "成本事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "OCCUPYRATE",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/OCCUPYRATE",
                "tableTranName": "成本事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "SALERATE",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/SALERATE",
                "tableTranName": "成本事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "COST",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/COST",
                "tableTranName": "成本事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "UNITPRICE",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/UNITPRICE",
                "tableTranName": "成本事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "COSTRATE",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/COSTRATE",
                "tableTranName": "成本事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "OCCUPYAREANEW",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/OCCUPYAREANEW",
                "tableTranName": "成本事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "OCCUPYRATENEW",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/OCCUPYRATENEW",
                "tableTranName": "成本事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "OCCUPYCOSTNEW",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/OCCUPYCOSTNEW",
                "tableTranName": "成本事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "COSTNEW",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/COSTNEW",
                "tableTranName": "成本事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "UNITPRICENEW",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/UNITPRICENEW",
                "tableTranName": "成本事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "TOTALUNITCOSTNEW",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/TOTALUNITCOSTNEW",
                "tableTranName": "成本事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "OCCUPYSTAT",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/OCCUPYSTAT",
                "tableTranName": "成本事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "OCCUPYAREADISPLAY",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/OCCUPYAREADISPLAY",
                "tableTranName": "成本事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "COSTDISPLAY",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/COSTDISPLAY",
                "tableTranName": "成本事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "UNITPRICEDISPLAY",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/UNITPRICEDISPLAY",
                "tableTranName": "成本事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "PRODUCTDIFF",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/PRODUCTDIFF",
                "tableTranName": "成本事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "CODIFF",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/CODIFF",
                "tableTranName": "成本事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "TOTALUNITCOST",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/TOTALUNITCOST",
                "tableTranName": "成本事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "BUILDAREA",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/BUILDAREA",
                "tableTranName": "成本事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "WYFTDCHZJCB",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/WYFTDCHZJCB",
                "tableTranName": "成本事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "JZTZZZCB",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/JZTZZZCB",
                "tableTranName": "成本事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "DDATE",
                "fieldSize": 8,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/DDATE",
                "tableTranName": "成本事实表",
                "fieldType": 48,
                "isEnable": true
            },
            {
                "fieldName": "INCR_FLAG",
                "fieldSize": 23,
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表/INCR_FLAG",
                "tableTranName": "成本事实表",
                "fieldType": 48,
                "isEnable": true
            }], [], [], [{
                "fieldName": "成本事实表记录数",
                "isUsable": true,
                "tableId": "成本事实表",
                "id": "成本事实表记录数",
                "fieldType": 64
            }]]
        },
        "浏览器占比变化": {
            "tableType": 0,
            "id": "浏览器占比变化",
            "connectionName": "",
            "fields": [[{
                "fieldName": "浏览器",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "浏览器占比变化",
                "id": "浏览器占比变化/浏览器",
                "tableTranName": "浏览器占比变化",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "年份",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "浏览器占比变化",
                "id": "浏览器占比变化/年份",
                "tableTranName": "浏览器占比变化",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "数量",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "浏览器占比变化",
                "id": "浏览器占比变化/数量",
                "tableTranName": "浏览器占比变化",
                "fieldType": 32,
                "isEnable": true
            }], [], [], [{
                "fieldName": "浏览器占比变化记录数",
                "isUsable": true,
                "tableId": "浏览器占比变化",
                "id": "浏览器占比变化记录数",
                "fieldType": 64
            }]]
        },
        "业务流水表": {
            "tableType": 0,
            "id": "业务流水表",
            "connectionName": "FRDemo",
            "fields": [[{
                "fieldName": "交易流水号",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "业务流水表",
                "id": "业务流水表/交易流水号",
                "tableTranName": "业务流水表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "地区号",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "业务流水表",
                "id": "业务流水表/地区号",
                "tableTranName": "业务流水表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "机构号",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "业务流水表",
                "id": "业务流水表/机构号",
                "tableTranName": "业务流水表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "柜员号",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "业务流水表",
                "id": "业务流水表/柜员号",
                "tableTranName": "业务流水表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "票号",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "业务流水表",
                "id": "业务流水表/票号",
                "tableTranName": "业务流水表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "交易码",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "业务流水表",
                "id": "业务流水表/交易码",
                "tableTranName": "业务流水表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "交易名称",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "业务流水表",
                "id": "业务流水表/交易名称",
                "tableTranName": "业务流水表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "账号",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "业务流水表",
                "id": "业务流水表/账号",
                "tableTranName": "业务流水表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "账户名称",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "业务流水表",
                "id": "业务流水表/账户名称",
                "tableTranName": "业务流水表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "交易金额",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "业务流水表",
                "id": "业务流水表/交易金额",
                "tableTranName": "业务流水表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "评价结果",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "业务流水表",
                "id": "业务流水表/评价结果",
                "tableTranName": "业务流水表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "等待时间",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "业务流水表",
                "id": "业务流水表/等待时间",
                "tableTranName": "业务流水表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "交易时间",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "业务流水表",
                "id": "业务流水表/交易时间",
                "tableTranName": "业务流水表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "办理时间",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "业务流水表",
                "id": "业务流水表/办理时间",
                "tableTranName": "业务流水表",
                "fieldType": 32,
                "isEnable": true
            }], [], [], [{
                "fieldName": "业务流水表记录数",
                "isUsable": true,
                "tableId": "业务流水表",
                "id": "业务流水表记录数",
                "fieldType": 64
            }]]
        },
        "样式数据三": {
            "tableType": 0,
            "id": "样式数据三",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "ID",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "样式数据三",
                "id": "样式数据三/ID",
                "tableTranName": "样式数据三",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "X",
                "fieldSize": 17,
                "isUsable": true,
                "tableId": "样式数据三",
                "id": "样式数据三/X",
                "tableTranName": "样式数据三",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "COSX",
                "fieldSize": 17,
                "isUsable": true,
                "tableId": "样式数据三",
                "id": "样式数据三/COSX",
                "tableTranName": "样式数据三",
                "fieldType": 32,
                "isEnable": true
            }], [], [], [{
                "fieldName": "样式数据三记录数",
                "isUsable": true,
                "tableId": "样式数据三",
                "id": "样式数据三记录数",
                "fieldType": 64
            }]]
        },
        "十大热门出境游热门目的地国家": {
            "tableType": 0,
            "id": "十大热门出境游热门目的地国家",
            "connectionName": "",
            "fields": [[{
                "fieldName": "排名",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "十大热门出境游热门目的地国家",
                "id": "十大热门出境游热门目的地国家/排名",
                "tableTranName": "十大热门出境游热门目的地国家",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "境外游热门目的地国家",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "十大热门出境游热门目的地国家",
                "id": "十大热门出境游热门目的地国家/境外游热门目的地国家",
                "tableTranName": "十大热门出境游热门目的地国家",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "值",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "十大热门出境游热门目的地国家",
                "id": "十大热门出境游热门目的地国家/值",
                "tableTranName": "十大热门出境游热门目的地国家",
                "fieldType": 32,
                "isEnable": true
            }], [], [], [{
                "fieldName": "十大热门出境游热门目的地国家记录数",
                "isUsable": true,
                "tableId": "十大热门出境游热门目的地国家",
                "id": "十大热门出境游热门目的地国家记录数",
                "fieldType": 64
            }]]
        },
        "样式数据二": {
            "tableType": 0,
            "id": "样式数据二",
            "connectionName": "",
            "fields": [[{
                "fieldName": "序号",
                "fieldSize": 100,
                "isUsable": true,
                "tableId": "样式数据二",
                "id": "样式数据二/序号",
                "tableTranName": "样式数据二",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "类目",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "样式数据二",
                "id": "样式数据二/类目",
                "tableTranName": "样式数据二",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "指标一",
                "fieldSize": 17,
                "isUsable": true,
                "tableId": "样式数据二",
                "id": "样式数据二/指标一",
                "tableTranName": "样式数据二",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "指标三",
                "fieldSize": 100,
                "isUsable": true,
                "tableId": "样式数据二",
                "id": "样式数据二/指标三",
                "tableTranName": "样式数据二",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "指标二",
                "fieldSize": 17,
                "isUsable": true,
                "tableId": "样式数据二",
                "id": "样式数据二/指标二",
                "tableTranName": "样式数据二",
                "fieldType": 32,
                "isEnable": true
            }], [], [], [{
                "fieldName": "样式数据二记录数",
                "isUsable": true,
                "tableId": "样式数据二",
                "id": "样式数据二记录数",
                "fieldType": 64
            }]]
        },
        "房间维度表": {
            "tableType": 0,
            "id": "房间维度表",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "ROOMGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "房间维度表",
                "id": "房间维度表/ROOMGUID",
                "tableTranName": "房间维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "FLOOR",
                "fieldSize": 20,
                "isUsable": true,
                "tableId": "房间维度表",
                "id": "房间维度表/FLOOR",
                "tableTranName": "房间维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "STATUS",
                "fieldSize": 10,
                "isUsable": true,
                "tableId": "房间维度表",
                "id": "房间维度表/STATUS",
                "tableTranName": "房间维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "VIRTUALSTATUS",
                "fieldSize": 10,
                "isUsable": true,
                "tableId": "房间维度表",
                "id": "房间维度表/VIRTUALSTATUS",
                "tableTranName": "房间维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "WEST",
                "fieldSize": 20,
                "isUsable": true,
                "tableId": "房间维度表",
                "id": "房间维度表/WEST",
                "tableTranName": "房间维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "ROOMSTRU",
                "fieldSize": 30,
                "isUsable": true,
                "tableId": "房间维度表",
                "id": "房间维度表/ROOMSTRU",
                "tableTranName": "房间维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "SALEAREA",
                "fieldSize": 20,
                "isUsable": true,
                "tableId": "房间维度表",
                "id": "房间维度表/SALEAREA",
                "tableTranName": "房间维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "PRICE",
                "fieldSize": 20,
                "isUsable": true,
                "tableId": "房间维度表",
                "id": "房间维度表/PRICE",
                "tableTranName": "房间维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "TOTAL",
                "fieldSize": 20,
                "isUsable": true,
                "tableId": "房间维度表",
                "id": "房间维度表/TOTAL",
                "tableTranName": "房间维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "DJPRICE",
                "fieldSize": 20,
                "isUsable": true,
                "tableId": "房间维度表",
                "id": "房间维度表/DJPRICE",
                "tableTranName": "房间维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "TOTALDJ",
                "fieldSize": 20,
                "isUsable": true,
                "tableId": "房间维度表",
                "id": "房间维度表/TOTALDJ",
                "tableTranName": "房间维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "ROOMINFO",
                "fieldSize": 100,
                "isUsable": true,
                "tableId": "房间维度表",
                "id": "房间维度表/ROOMINFO",
                "tableTranName": "房间维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "QFXFTYPE",
                "fieldSize": 25,
                "isUsable": true,
                "tableId": "房间维度表",
                "id": "房间维度表/QFXFTYPE",
                "tableTranName": "房间维度表",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "房间维度表记录数",
                "isUsable": true,
                "tableId": "房间维度表",
                "id": "房间维度表记录数",
                "fieldType": 64
            }]]
        },
        "热门景区门票预定TOP20": {
            "tableType": 0,
            "id": "热门景区门票预定TOP20",
            "connectionName": "",
            "fields": [[{
                "fieldName": "排名",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "热门景区门票预定TOP20",
                "id": "热门景区门票预定TOP20/排名",
                "tableTranName": "热门景区门票预定TOP20",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "热门景区",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "热门景区门票预定TOP20",
                "id": "热门景区门票预定TOP20/热门景区",
                "tableTranName": "热门景区门票预定TOP20",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "值",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "热门景区门票预定TOP20",
                "id": "热门景区门票预定TOP20/值",
                "tableTranName": "热门景区门票预定TOP20",
                "fieldType": 32,
                "isEnable": true
            }], [], [], [{
                "fieldName": "热门景区门票预定TOP20记录数",
                "isUsable": true,
                "tableId": "热门景区门票预定TOP20",
                "id": "热门景区门票预定TOP20记录数",
                "fieldType": 64
            }]]
        },
        "推广渠道维度表": {
            "tableType": 0,
            "id": "推广渠道维度表",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "渠道ID",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "推广渠道维度表",
                "id": "推广渠道维度表/渠道ID",
                "tableTranName": "推广渠道维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "一级渠道名",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "推广渠道维度表",
                "id": "推广渠道维度表/一级渠道名",
                "tableTranName": "推广渠道维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "二级渠道名",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "推广渠道维度表",
                "id": "推广渠道维度表/二级渠道名",
                "tableTranName": "推广渠道维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "三级渠道名",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "推广渠道维度表",
                "id": "推广渠道维度表/三级渠道名",
                "tableTranName": "推广渠道维度表",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "推广渠道维度表记录数",
                "isUsable": true,
                "tableId": "推广渠道维度表",
                "id": "推广渠道维度表记录数",
                "fieldType": 64
            }]]
        },
        "客户维度表": {
            "tableType": 0,
            "id": "客户维度表",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "客户ID",
                "fieldSize": 64,
                "isUsable": true,
                "tableId": "客户维度表",
                "id": "客户维度表/客户ID",
                "tableTranName": "客户维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "客户名称",
                "fieldSize": 128,
                "isUsable": true,
                "tableId": "客户维度表",
                "id": "客户维度表/客户名称",
                "tableTranName": "客户维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "客户对应销售员",
                "fieldSize": 64,
                "isUsable": true,
                "tableId": "客户维度表",
                "id": "客户维度表/客户对应销售员",
                "tableTranName": "客户维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "国家",
                "fieldSize": 64,
                "isUsable": true,
                "tableId": "客户维度表",
                "id": "客户维度表/国家",
                "tableTranName": "客户维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "省份",
                "fieldSize": 64,
                "isUsable": true,
                "tableId": "客户维度表",
                "id": "客户维度表/省份",
                "tableTranName": "客户维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "城市",
                "fieldSize": 64,
                "isUsable": true,
                "tableId": "客户维度表",
                "id": "客户维度表/城市",
                "tableTranName": "客户维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "客户状态",
                "fieldSize": 64,
                "isUsable": true,
                "tableId": "客户维度表",
                "id": "客户维度表/客户状态",
                "tableTranName": "客户维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "客户类型",
                "fieldSize": 64,
                "isUsable": true,
                "tableId": "客户维度表",
                "id": "客户维度表/客户类型",
                "tableTranName": "客户维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "客户规模",
                "fieldSize": 10,
                "isUsable": true,
                "tableId": "客户维度表",
                "id": "客户维度表/客户规模",
                "tableTranName": "客户维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "客户来源",
                "fieldSize": 100,
                "isUsable": true,
                "tableId": "客户维度表",
                "id": "客户维度表/客户来源",
                "tableTranName": "客户维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "是否为重要客户",
                "fieldSize": 10,
                "isUsable": true,
                "tableId": "客户维度表",
                "id": "客户维度表/是否为重要客户",
                "tableTranName": "客户维度表",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "客户维度表记录数",
                "isUsable": true,
                "tableId": "客户维度表",
                "id": "客户维度表记录数",
                "fieldType": 64
            }]]
        },
        "化工_设备运行状况展示": {
            "tableType": 0,
            "id": "化工_设备运行状况展示",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "系列",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "化工_设备运行状况展示",
                "id": "化工_设备运行状况展示/系列",
                "tableTranName": "化工_设备运行状况展示",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "设备",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "化工_设备运行状况展示",
                "id": "化工_设备运行状况展示/设备",
                "tableTranName": "化工_设备运行状况展示",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "运行时间",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "化工_设备运行状况展示",
                "id": "化工_设备运行状况展示/运行时间",
                "tableTranName": "化工_设备运行状况展示",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "化工_设备运行状况展示记录数",
                "isUsable": true,
                "tableId": "化工_设备运行状况展示",
                "id": "化工_设备运行状况展示记录数",
                "fieldType": 64
            }]]
        },
        "项目维度表": {
            "tableType": 0,
            "id": "项目维度表",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "PROJGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "项目维度表",
                "id": "项目维度表/PROJGUID",
                "tableTranName": "项目维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "PROJNAME",
                "fieldSize": 400,
                "isUsable": true,
                "tableId": "项目维度表",
                "id": "项目维度表/PROJNAME",
                "tableTranName": "项目维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "PROJSHORTNAME",
                "fieldSize": 40,
                "isUsable": true,
                "tableId": "项目维度表",
                "id": "项目维度表/PROJSHORTNAME",
                "tableTranName": "项目维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "PARENTPROJGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "项目维度表",
                "id": "项目维度表/PARENTPROJGUID",
                "tableTranName": "项目维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "PARENTPROJNAME",
                "fieldSize": 400,
                "isUsable": true,
                "tableId": "项目维度表",
                "id": "项目维度表/PARENTPROJNAME",
                "tableTranName": "项目维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "PROJCODE",
                "fieldSize": 100,
                "isUsable": true,
                "tableId": "项目维度表",
                "id": "项目维度表/PROJCODE",
                "tableTranName": "项目维度表",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "项目维度表记录数",
                "isUsable": true,
                "tableId": "项目维度表",
                "id": "项目维度表记录数",
                "fieldType": 64
            }]]
        },
        "供应商信息表": {
            "tableType": 0,
            "id": "供应商信息表",
            "connectionName": "FRDemo",
            "fields": [[{
                "fieldName": "供应商ID",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "供应商信息表",
                "id": "供应商信息表/供应商ID",
                "tableTranName": "供应商信息表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "公司名称",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "供应商信息表",
                "id": "供应商信息表/公司名称",
                "tableTranName": "供应商信息表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "联系人姓名",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "供应商信息表",
                "id": "供应商信息表/联系人姓名",
                "tableTranName": "供应商信息表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "联系人职务",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "供应商信息表",
                "id": "供应商信息表/联系人职务",
                "tableTranName": "供应商信息表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "地址",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "供应商信息表",
                "id": "供应商信息表/地址",
                "tableTranName": "供应商信息表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "城市",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "供应商信息表",
                "id": "供应商信息表/城市",
                "tableTranName": "供应商信息表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "地区",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "供应商信息表",
                "id": "供应商信息表/地区",
                "tableTranName": "供应商信息表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "邮政编码",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "供应商信息表",
                "id": "供应商信息表/邮政编码",
                "tableTranName": "供应商信息表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "国家",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "供应商信息表",
                "id": "供应商信息表/国家",
                "tableTranName": "供应商信息表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "电话",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "供应商信息表",
                "id": "供应商信息表/电话",
                "tableTranName": "供应商信息表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "传真",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "供应商信息表",
                "id": "供应商信息表/传真",
                "tableTranName": "供应商信息表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "主页",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "供应商信息表",
                "id": "供应商信息表/主页",
                "tableTranName": "供应商信息表",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "供应商信息表记录数",
                "isUsable": true,
                "tableId": "供应商信息表",
                "id": "供应商信息表记录数",
                "fieldType": 64
            }]]
        },
        "样式数据一": {
            "tableType": 0,
            "id": "样式数据一",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "序号",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "样式数据一",
                "id": "样式数据一/序号",
                "tableTranName": "样式数据一",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "X",
                "fieldSize": 17,
                "isUsable": true,
                "tableId": "样式数据一",
                "id": "样式数据一/X",
                "tableTranName": "样式数据一",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "SINX",
                "fieldSize": 17,
                "isUsable": true,
                "tableId": "样式数据一",
                "id": "样式数据一/SINX",
                "tableTranName": "样式数据一",
                "fieldType": 32,
                "isEnable": true
            }], [], [], [{
                "fieldName": "样式数据一记录数",
                "isUsable": true,
                "tableId": "样式数据一",
                "id": "样式数据一记录数",
                "fieldType": 64
            }]]
        },
        "访问阶段统计事实表": {
            "tableType": 0,
            "id": "访问阶段统计事实表",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "访问ID",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "访问阶段统计事实表",
                "id": "访问阶段统计事实表/访问ID",
                "tableTranName": "访问阶段统计事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "用户ID",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "访问阶段统计事实表",
                "id": "访问阶段统计事实表/用户ID",
                "tableTranName": "访问阶段统计事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "访问平台",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "访问阶段统计事实表",
                "id": "访问阶段统计事实表/访问平台",
                "tableTranName": "访问阶段统计事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "统计日期",
                "fieldSize": 8,
                "isUsable": true,
                "tableId": "访问阶段统计事实表",
                "id": "访问阶段统计事实表/统计日期",
                "tableTranName": "访问阶段统计事实表",
                "fieldType": 48,
                "isEnable": true
            },
            {
                "fieldName": "访问最后阶段",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "访问阶段统计事实表",
                "id": "访问阶段统计事实表/访问最后阶段",
                "tableTranName": "访问阶段统计事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "总停留时间",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "访问阶段统计事实表",
                "id": "访问阶段统计事实表/总停留时间",
                "tableTranName": "访问阶段统计事实表",
                "fieldType": 32,
                "isEnable": true
            }], [], [], [{
                "fieldName": "访问阶段统计事实表记录数",
                "isUsable": true,
                "tableId": "访问阶段统计事实表",
                "id": "访问阶段统计事实表记录数",
                "fieldType": 64
            }]]
        },
        "区域维度表": {
            "tableType": 0,
            "id": "区域维度表",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "AREA_NAME",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "区域维度表",
                "id": "区域维度表/AREA_NAME",
                "tableTranName": "区域维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "AREA_ID",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "区域维度表",
                "id": "区域维度表/AREA_ID",
                "tableTranName": "区域维度表",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "区域维度表记录数",
                "isUsable": true,
                "tableId": "区域维度表",
                "id": "区域维度表记录数",
                "fieldType": 64
            }]]
        },
        "银行_用户维度表": {
            "tableType": 0,
            "id": "银行_用户维度表",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "用户ID",
                "fieldSize": 64,
                "isUsable": true,
                "tableId": "银行_用户维度表",
                "id": "银行_用户维度表/用户ID",
                "tableTranName": "银行_用户维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "用户名称",
                "fieldSize": 64,
                "isUsable": true,
                "tableId": "银行_用户维度表",
                "id": "银行_用户维度表/用户名称",
                "tableTranName": "银行_用户维度表",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "银行_用户维度表记录数",
                "isUsable": true,
                "tableId": "银行_用户维度表",
                "id": "银行_用户维度表记录数",
                "fieldType": 64
            }]]
        },
        "品牌维度": {
            "tableType": 0,
            "id": "品牌维度",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "品牌编号",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "品牌维度",
                "id": "品牌维度/品牌编号",
                "tableTranName": "品牌维度",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "品牌描述",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "品牌维度",
                "id": "品牌维度/品牌描述",
                "tableTranName": "品牌维度",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "品牌维度记录数",
                "isUsable": true,
                "tableId": "品牌维度",
                "id": "品牌维度记录数",
                "fieldType": 64
            }]]
        },
        "化工_原料成本趋势展示": {
            "tableType": 0,
            "id": "化工_原料成本趋势展示",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "工厂",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "化工_原料成本趋势展示",
                "id": "化工_原料成本趋势展示/工厂",
                "tableTranName": "化工_原料成本趋势展示",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "日期",
                "fieldSize": 8,
                "isUsable": true,
                "tableId": "化工_原料成本趋势展示",
                "id": "化工_原料成本趋势展示/日期",
                "tableTranName": "化工_原料成本趋势展示",
                "fieldType": 48,
                "isEnable": true
            },
            {
                "fieldName": "原料成本",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "化工_原料成本趋势展示",
                "id": "化工_原料成本趋势展示/原料成本",
                "tableTranName": "化工_原料成本趋势展示",
                "fieldType": 32,
                "isEnable": true
            }], [], [], [{
                "fieldName": "化工_原料成本趋势展示记录数",
                "isUsable": true,
                "tableId": "化工_原料成本趋势展示",
                "id": "化工_原料成本趋势展示记录数",
                "fieldType": 64
            }]]
        },
        "合同事实表": {
            "tableType": 0,
            "id": "合同事实表",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "合同ID",
                "fieldSize": 200,
                "isUsable": true,
                "tableId": "合同事实表",
                "id": "合同事实表/合同ID",
                "tableTranName": "合同事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "客户ID",
                "fieldSize": 200,
                "isUsable": true,
                "tableId": "合同事实表",
                "id": "合同事实表/客户ID",
                "tableTranName": "合同事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "合同类型",
                "fieldSize": 20,
                "isUsable": true,
                "tableId": "合同事实表",
                "id": "合同事实表/合同类型",
                "tableTranName": "合同事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "总金额",
                "fieldSize": 10,
                "isUsable": true,
                "tableId": "合同事实表",
                "id": "合同事实表/总金额",
                "tableTranName": "合同事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "合同付款类型",
                "fieldSize": 20,
                "isUsable": true,
                "tableId": "合同事实表",
                "id": "合同事实表/合同付款类型",
                "tableTranName": "合同事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "注册时间",
                "fieldSize": 8,
                "isUsable": true,
                "tableId": "合同事实表",
                "id": "合同事实表/注册时间",
                "tableTranName": "合同事实表",
                "fieldType": 48,
                "isEnable": true
            },
            {
                "fieldName": "购买数量",
                "fieldSize": 10,
                "isUsable": true,
                "tableId": "合同事实表",
                "id": "合同事实表/购买数量",
                "tableTranName": "合同事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "合同签约时间",
                "fieldSize": 23,
                "isUsable": true,
                "tableId": "合同事实表",
                "id": "合同事实表/合同签约时间",
                "tableTranName": "合同事实表",
                "fieldType": 48,
                "isEnable": true
            },
            {
                "fieldName": "购买的产品",
                "fieldSize": 10,
                "isUsable": true,
                "tableId": "合同事实表",
                "id": "合同事实表/购买的产品",
                "tableTranName": "合同事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "是否已经交货",
                "fieldSize": 20,
                "isUsable": true,
                "tableId": "合同事实表",
                "id": "合同事实表/是否已经交货",
                "tableTranName": "合同事实表",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "合同事实表记录数",
                "isUsable": true,
                "tableId": "合同事实表",
                "id": "合同事实表记录数",
                "fieldType": 64
            }]]
        },
        "银行_产品维度表": {
            "tableType": 0,
            "id": "银行_产品维度表",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "PA产品号",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "银行_产品维度表",
                "id": "银行_产品维度表/PA产品号",
                "tableTranName": "银行_产品维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "PA产品名称",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "银行_产品维度表",
                "id": "银行_产品维度表/PA产品名称",
                "tableTranName": "银行_产品维度表",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "银行_产品维度表记录数",
                "isUsable": true,
                "tableId": "银行_产品维度表",
                "id": "银行_产品维度表记录数",
                "fieldType": 64
            }]]
        },
        "化工_产品收入率趋势": {
            "tableType": 0,
            "id": "化工_产品收入率趋势",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "产品名称",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "化工_产品收入率趋势",
                "id": "化工_产品收入率趋势/产品名称",
                "tableTranName": "化工_产品收入率趋势",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "日期",
                "fieldSize": 8,
                "isUsable": true,
                "tableId": "化工_产品收入率趋势",
                "id": "化工_产品收入率趋势/日期",
                "tableTranName": "化工_产品收入率趋势",
                "fieldType": 48,
                "isEnable": true
            },
            {
                "fieldName": "实际生产量",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "化工_产品收入率趋势",
                "id": "化工_产品收入率趋势/实际生产量",
                "tableTranName": "化工_产品收入率趋势",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "当日目标",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "化工_产品收入率趋势",
                "id": "化工_产品收入率趋势/当日目标",
                "tableTranName": "化工_产品收入率趋势",
                "fieldType": 32,
                "isEnable": true
            }], [], [], [{
                "fieldName": "化工_产品收入率趋势记录数",
                "isUsable": true,
                "tableId": "化工_产品收入率趋势",
                "id": "化工_产品收入率趋势记录数",
                "fieldType": 64
            }]]
        },
        "库存事实表": {
            "tableType": 0,
            "id": "库存事实表",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "AREAGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "库存事实表",
                "id": "库存事实表/AREAGUID",
                "tableTranName": "库存事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "BUGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "库存事实表",
                "id": "库存事实表/BUGUID",
                "tableTranName": "库存事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "PROJGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "库存事实表",
                "id": "库存事实表/PROJGUID",
                "tableTranName": "库存事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "BLDGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "库存事实表",
                "id": "库存事实表/BLDGUID",
                "tableTranName": "库存事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "PRODUCTGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "库存事实表",
                "id": "库存事实表/PRODUCTGUID",
                "tableTranName": "库存事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "ROOMGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "库存事实表",
                "id": "库存事实表/ROOMGUID",
                "tableTranName": "库存事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "SALEAREA",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "库存事实表",
                "id": "库存事实表/SALEAREA",
                "tableTranName": "库存事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "TOTALDJ",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "库存事实表",
                "id": "库存事实表/TOTALDJ",
                "tableTranName": "库存事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "TOTAL",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "库存事实表",
                "id": "库存事实表/TOTAL",
                "tableTranName": "库存事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "DDATE",
                "fieldSize": 8,
                "isUsable": true,
                "tableId": "库存事实表",
                "id": "库存事实表/DDATE",
                "tableTranName": "库存事实表",
                "fieldType": 48,
                "isEnable": true
            }], [], [], [{
                "fieldName": "库存事实表记录数",
                "isUsable": true,
                "tableId": "库存事实表",
                "id": "库存事实表记录数",
                "fieldType": 64
            }]]
        },
        "订单": {
            "tableType": 0,
            "id": "订单",
            "connectionName": "FRDemo",
            "fields": [[{
                "fieldName": "订单ID",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "订单",
                "id": "订单/订单ID",
                "tableTranName": "订单",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "客户ID",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "订单",
                "id": "订单/客户ID",
                "tableTranName": "订单",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "雇员ID",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "订单",
                "id": "订单/雇员ID",
                "tableTranName": "订单",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "订购日期",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "订单",
                "id": "订单/订购日期",
                "tableTranName": "订单",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "到货日期",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "订单",
                "id": "订单/到货日期",
                "tableTranName": "订单",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "发货日期",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "订单",
                "id": "订单/发货日期",
                "tableTranName": "订单",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "运货商",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "订单",
                "id": "订单/运货商",
                "tableTranName": "订单",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "运货费",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "订单",
                "id": "订单/运货费",
                "tableTranName": "订单",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "货主名称",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "订单",
                "id": "订单/货主名称",
                "tableTranName": "订单",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "货主地址",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "订单",
                "id": "订单/货主地址",
                "tableTranName": "订单",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "货主城市",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "订单",
                "id": "订单/货主城市",
                "tableTranName": "订单",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "货主省份",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "订单",
                "id": "订单/货主省份",
                "tableTranName": "订单",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "货主地区",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "订单",
                "id": "订单/货主地区",
                "tableTranName": "订单",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "货主邮政编码",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "订单",
                "id": "订单/货主邮政编码",
                "tableTranName": "订单",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "货主国家",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "订单",
                "id": "订单/货主国家",
                "tableTranName": "订单",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "是否已付",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "订单",
                "id": "订单/是否已付",
                "tableTranName": "订单",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "订单记录数",
                "isUsable": true,
                "tableId": "订单",
                "id": "订单记录数",
                "fieldType": 64
            }]]
        },
        "雇员": {
            "tableType": 0,
            "id": "雇员",
            "connectionName": "FRDemo",
            "fields": [[{
                "fieldName": "雇员ID",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "雇员",
                "id": "雇员/雇员ID",
                "tableTranName": "雇员",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "姓名",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "雇员",
                "id": "雇员/姓名",
                "tableTranName": "雇员",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "职务",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "雇员",
                "id": "雇员/职务",
                "tableTranName": "雇员",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "性别",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "雇员",
                "id": "雇员/性别",
                "tableTranName": "雇员",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "出生日期",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "雇员",
                "id": "雇员/出生日期",
                "tableTranName": "雇员",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "雇用日期",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "雇员",
                "id": "雇员/雇用日期",
                "tableTranName": "雇员",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "地址",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "雇员",
                "id": "雇员/地址",
                "tableTranName": "雇员",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "城市",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "雇员",
                "id": "雇员/城市",
                "tableTranName": "雇员",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "地区",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "雇员",
                "id": "雇员/地区",
                "tableTranName": "雇员",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "邮政编码",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "雇员",
                "id": "雇员/邮政编码",
                "tableTranName": "雇员",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "国家",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "雇员",
                "id": "雇员/国家",
                "tableTranName": "雇员",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "家庭电话",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "雇员",
                "id": "雇员/家庭电话",
                "tableTranName": "雇员",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "手机",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "雇员",
                "id": "雇员/手机",
                "tableTranName": "雇员",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "照片",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "雇员",
                "id": "雇员/照片",
                "tableTranName": "雇员",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "备注",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "雇员",
                "id": "雇员/备注",
                "tableTranName": "雇员",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "雇员记录数",
                "isUsable": true,
                "tableId": "雇员",
                "id": "雇员记录数",
                "fieldType": 64
            }]]
        },
        "品类维度": {
            "tableType": 0,
            "id": "品类维度",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "类别",
                "fieldSize": 10,
                "isUsable": true,
                "tableId": "品类维度",
                "id": "品类维度/类别",
                "tableTranName": "品类维度",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "品类描述",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "品类维度",
                "id": "品类维度/品类描述",
                "tableTranName": "品类维度",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "品类维度记录数",
                "isUsable": true,
                "tableId": "品类维度",
                "id": "品类维度记录数",
                "fieldType": 64
            }]]
        },
        "销售员维度表": {
            "tableType": 0,
            "id": "销售员维度表",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "SALES_NAME",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "销售员维度表",
                "id": "销售员维度表/SALES_NAME",
                "tableTranName": "销售员维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "SALES_PARENT",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "销售员维度表",
                "id": "销售员维度表/SALES_PARENT",
                "tableTranName": "销售员维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "SALES_REGION",
                "fieldSize": 2,
                "isUsable": true,
                "tableId": "销售员维度表",
                "id": "销售员维度表/SALES_REGION",
                "tableTranName": "销售员维度表",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "销售员维度表记录数",
                "isUsable": true,
                "tableId": "销售员维度表",
                "id": "销售员维度表记录数",
                "fieldType": 64
            }]]
        },
        "ExcelView之客户跟踪表": {
            "tableType": 0,
            "id": "ExcelView之客户跟踪表",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "客户ID",
                "fieldSize": 64,
                "isUsable": true,
                "tableId": "ExcelView之客户跟踪表",
                "id": "ExcelView之客户跟踪表/客户ID",
                "tableTranName": "ExcelView之客户跟踪表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "客户名称",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "ExcelView之客户跟踪表",
                "id": "ExcelView之客户跟踪表/客户名称",
                "tableTranName": "ExcelView之客户跟踪表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "地址",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "ExcelView之客户跟踪表",
                "id": "ExcelView之客户跟踪表/地址",
                "tableTranName": "ExcelView之客户跟踪表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "营业类型",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "ExcelView之客户跟踪表",
                "id": "ExcelView之客户跟踪表/营业类型",
                "tableTranName": "ExcelView之客户跟踪表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "主要来往银行",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "ExcelView之客户跟踪表",
                "id": "ExcelView之客户跟踪表/主要来往银行",
                "tableTranName": "ExcelView之客户跟踪表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "其他投资事业",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "ExcelView之客户跟踪表",
                "id": "ExcelView之客户跟踪表/其他投资事业",
                "tableTranName": "ExcelView之客户跟踪表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "主要业务往来",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "ExcelView之客户跟踪表",
                "id": "ExcelView之客户跟踪表/主要业务往来",
                "tableTranName": "ExcelView之客户跟踪表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "与本公司来往日期",
                "fieldSize": 8,
                "isUsable": true,
                "tableId": "ExcelView之客户跟踪表",
                "id": "ExcelView之客户跟踪表/与本公司来往日期",
                "tableTranName": "ExcelView之客户跟踪表",
                "fieldType": 48,
                "isEnable": true
            },
            {
                "fieldName": "最近与本公司来往重要记录",
                "fieldSize": 10,
                "isUsable": true,
                "tableId": "ExcelView之客户跟踪表",
                "id": "ExcelView之客户跟踪表/最近与本公司来往重要记录",
                "tableTranName": "ExcelView之客户跟踪表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "最近交易数据跟踪",
                "fieldSize": 10,
                "isUsable": true,
                "tableId": "ExcelView之客户跟踪表",
                "id": "ExcelView之客户跟踪表/最近交易数据跟踪",
                "tableTranName": "ExcelView之客户跟踪表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "客户意见",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "ExcelView之客户跟踪表",
                "id": "ExcelView之客户跟踪表/客户意见",
                "tableTranName": "ExcelView之客户跟踪表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "信用评定",
                "fieldSize": 10,
                "isUsable": true,
                "tableId": "ExcelView之客户跟踪表",
                "id": "ExcelView之客户跟踪表/信用评定",
                "tableTranName": "ExcelView之客户跟踪表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "负责人",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "ExcelView之客户跟踪表",
                "id": "ExcelView之客户跟踪表/负责人",
                "tableTranName": "ExcelView之客户跟踪表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "成立日期",
                "fieldSize": 8,
                "isUsable": true,
                "tableId": "ExcelView之客户跟踪表",
                "id": "ExcelView之客户跟踪表/成立日期",
                "tableTranName": "ExcelView之客户跟踪表",
                "fieldType": 48,
                "isEnable": true
            },
            {
                "fieldName": "资本额",
                "fieldSize": 17,
                "isUsable": true,
                "tableId": "ExcelView之客户跟踪表",
                "id": "ExcelView之客户跟踪表/资本额",
                "tableTranName": "ExcelView之客户跟踪表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "电话",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "ExcelView之客户跟踪表",
                "id": "ExcelView之客户跟踪表/电话",
                "tableTranName": "ExcelView之客户跟踪表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "传真",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "ExcelView之客户跟踪表",
                "id": "ExcelView之客户跟踪表/传真",
                "tableTranName": "ExcelView之客户跟踪表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "平均每日营业额",
                "fieldSize": 17,
                "isUsable": true,
                "tableId": "ExcelView之客户跟踪表",
                "id": "ExcelView之客户跟踪表/平均每日营业额",
                "tableTranName": "ExcelView之客户跟踪表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "付款方式",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "ExcelView之客户跟踪表",
                "id": "ExcelView之客户跟踪表/付款方式",
                "tableTranName": "ExcelView之客户跟踪表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "收款记录",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "ExcelView之客户跟踪表",
                "id": "ExcelView之客户跟踪表/收款记录",
                "tableTranName": "ExcelView之客户跟踪表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "填表人",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "ExcelView之客户跟踪表",
                "id": "ExcelView之客户跟踪表/填表人",
                "tableTranName": "ExcelView之客户跟踪表",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "ExcelView之客户跟踪表记录数",
                "isUsable": true,
                "tableId": "ExcelView之客户跟踪表",
                "id": "ExcelView之客户跟踪表记录数",
                "fieldType": 64
            }]]
        },
        "租赁_存量业务": {
            "tableType": 0,
            "id": "租赁_存量业务",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "行业大类",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "租赁_存量业务",
                "id": "租赁_存量业务/行业大类",
                "tableTranName": "租赁_存量业务",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "行业细分",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "租赁_存量业务",
                "id": "租赁_存量业务/行业细分",
                "tableTranName": "租赁_存量业务",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "起租金额",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "租赁_存量业务",
                "id": "租赁_存量业务/起租金额",
                "tableTranName": "租赁_存量业务",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "区域",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "租赁_存量业务",
                "id": "租赁_存量业务/区域",
                "tableTranName": "租赁_存量业务",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "租赁_存量业务记录数",
                "isUsable": true,
                "tableId": "租赁_存量业务",
                "id": "租赁_存量业务记录数",
                "fieldType": 64
            }]]
        },
        "化工_能耗指标趋势": {
            "tableType": 0,
            "id": "化工_能耗指标趋势",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "消耗材料",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "化工_能耗指标趋势",
                "id": "化工_能耗指标趋势/消耗材料",
                "tableTranName": "化工_能耗指标趋势",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "日期",
                "fieldSize": 8,
                "isUsable": true,
                "tableId": "化工_能耗指标趋势",
                "id": "化工_能耗指标趋势/日期",
                "tableTranName": "化工_能耗指标趋势",
                "fieldType": 48,
                "isEnable": true
            },
            {
                "fieldName": "消耗量",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "化工_能耗指标趋势",
                "id": "化工_能耗指标趋势/消耗量",
                "tableTranName": "化工_能耗指标趋势",
                "fieldType": 32,
                "isEnable": true
            }], [], [], [{
                "fieldName": "化工_能耗指标趋势记录数",
                "isUsable": true,
                "tableId": "化工_能耗指标趋势",
                "id": "化工_能耗指标趋势记录数",
                "fieldType": 64
            }]]
        },
        "用户信息维度表": {
            "tableType": 0,
            "id": "用户信息维度表",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "用户ID",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "用户信息维度表",
                "id": "用户信息维度表/用户ID",
                "tableTranName": "用户信息维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "渠道ID",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "用户信息维度表",
                "id": "用户信息维度表/渠道ID",
                "tableTranName": "用户信息维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "用户名称",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "用户信息维度表",
                "id": "用户信息维度表/用户名称",
                "tableTranName": "用户信息维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "年龄",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "用户信息维度表",
                "id": "用户信息维度表/年龄",
                "tableTranName": "用户信息维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "性别",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "用户信息维度表",
                "id": "用户信息维度表/性别",
                "tableTranName": "用户信息维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "用户类型",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "用户信息维度表",
                "id": "用户信息维度表/用户类型",
                "tableTranName": "用户信息维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "注册日期",
                "fieldSize": 8,
                "isUsable": true,
                "tableId": "用户信息维度表",
                "id": "用户信息维度表/注册日期",
                "tableTranName": "用户信息维度表",
                "fieldType": 48,
                "isEnable": true
            },
            {
                "fieldName": "注册地区ID",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "用户信息维度表",
                "id": "用户信息维度表/注册地区ID",
                "tableTranName": "用户信息维度表",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "用户信息维度表记录数",
                "isUsable": true,
                "tableId": "用户信息维度表",
                "id": "用户信息维度表记录数",
                "fieldType": 64
            }]]
        },
        "访问统计事实表": {
            "tableType": 0,
            "id": "访问统计事实表",
            "connectionName": "",
            "fields": [[{
                "fieldName": "总停留时间",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "访问统计事实表",
                "id": "访问统计事实表/总停留时间",
                "tableTranName": "访问统计事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "渠道ID",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "访问统计事实表",
                "id": "访问统计事实表/渠道ID",
                "tableTranName": "访问统计事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "访问ID",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "访问统计事实表",
                "id": "访问统计事实表/访问ID",
                "tableTranName": "访问统计事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "统计年月",
                "fieldSize": 100,
                "isUsable": true,
                "tableId": "访问统计事实表",
                "id": "访问统计事实表/统计年月",
                "tableTranName": "访问统计事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "访问平台",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "访问统计事实表",
                "id": "访问统计事实表/访问平台",
                "tableTranName": "访问统计事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "统计日期",
                "fieldSize": 8,
                "isUsable": true,
                "tableId": "访问统计事实表",
                "id": "访问统计事实表/统计日期",
                "tableTranName": "访问统计事实表",
                "fieldType": 48,
                "isEnable": true
            },
            {
                "fieldName": "用户ID",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "访问统计事实表",
                "id": "访问统计事实表/用户ID",
                "tableTranName": "访问统计事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "浏览量",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "访问统计事实表",
                "id": "访问统计事实表/浏览量",
                "tableTranName": "访问统计事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "跳出次数",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "访问统计事实表",
                "id": "访问统计事实表/跳出次数",
                "tableTranName": "访问统计事实表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "地区ID",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "访问统计事实表",
                "id": "访问统计事实表/地区ID",
                "tableTranName": "访问统计事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "访问次数",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "访问统计事实表",
                "id": "访问统计事实表/访问次数",
                "tableTranName": "访问统计事实表",
                "fieldType": 32,
                "isEnable": true
            }], [], [], [{
                "fieldName": "访问统计事实表记录数",
                "isUsable": true,
                "tableId": "访问统计事实表",
                "id": "访问统计事实表记录数",
                "fieldType": 64
            }]]
        },
        "地区维度表": {
            "tableType": 0,
            "id": "地区维度表",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "GB_ID",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "地区维度表",
                "id": "地区维度表/GB_ID",
                "tableTranName": "地区维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "SSX_NAME",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "地区维度表",
                "id": "地区维度表/SSX_NAME",
                "tableTranName": "地区维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "PARENT_ID",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "地区维度表",
                "id": "地区维度表/PARENT_ID",
                "tableTranName": "地区维度表",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "地区维度表记录数",
                "isUsable": true,
                "tableId": "地区维度表",
                "id": "地区维度表记录数",
                "fieldType": 64
            }]]
        },
        "产品": {
            "tableType": 0,
            "id": "产品",
            "connectionName": "FRDemo",
            "fields": [[{
                "fieldName": "类别_类别名称",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "产品",
                "id": "产品/类别_类别名称",
                "tableTranName": "产品",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "产品_产品ID",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "产品",
                "id": "产品/产品_产品ID",
                "tableTranName": "产品",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "产品_产品名称",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "产品",
                "id": "产品/产品_产品名称",
                "tableTranName": "产品",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "产品_供应商ID",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "产品",
                "id": "产品/产品_供应商ID",
                "tableTranName": "产品",
                "fieldType": 32,
                "isEnable": true
            }], [], [], [{
                "fieldName": "产品记录数",
                "isUsable": true,
                "tableId": "产品",
                "id": "产品记录数",
                "fieldType": 64
            }]]
        },
        "产品维度表": {
            "tableType": 0,
            "id": "产品维度表",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "PRODUCTGUID",
                "fieldSize": 36,
                "isUsable": true,
                "tableId": "产品维度表",
                "id": "产品维度表/PRODUCTGUID",
                "tableTranName": "产品维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "PRODUCTNAME",
                "fieldSize": 100,
                "isUsable": true,
                "tableId": "产品维度表",
                "id": "产品维度表/PRODUCTNAME",
                "tableTranName": "产品维度表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "PRODUCTCLASS",
                "fieldSize": 32,
                "isUsable": true,
                "tableId": "产品维度表",
                "id": "产品维度表/PRODUCTCLASS",
                "tableTranName": "产品维度表",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "产品维度表记录数",
                "isUsable": true,
                "tableId": "产品维度表",
                "id": "产品维度表记录数",
                "fieldType": 64
            }]]
        },
        "人员变动表": {
            "tableType": 0,
            "id": "人员变动表",
            "connectionName": "FRDemo",
            "fields": [[{
                "fieldName": "公司名称",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "人员变动表",
                "id": "人员变动表/公司名称",
                "tableTranName": "人员变动表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "人员编码",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "人员变动表",
                "id": "人员变动表/人员编码",
                "tableTranName": "人员变动表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "人员姓名",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "人员变动表",
                "id": "人员变动表/人员姓名",
                "tableTranName": "人员变动表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "变动原因",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "人员变动表",
                "id": "人员变动表/变动原因",
                "tableTranName": "人员变动表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "劳动关系类别",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "人员变动表",
                "id": "人员变动表/劳动关系类别",
                "tableTranName": "人员变动表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "学历",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "人员变动表",
                "id": "人员变动表/学历",
                "tableTranName": "人员变动表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "年度",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "人员变动表",
                "id": "人员变动表/年度",
                "tableTranName": "人员变动表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "月度",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "人员变动表",
                "id": "人员变动表/月度",
                "tableTranName": "人员变动表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "类型",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "人员变动表",
                "id": "人员变动表/类型",
                "tableTranName": "人员变动表",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "人员变动表记录数",
                "isUsable": true,
                "tableId": "人员变动表",
                "id": "人员变动表记录数",
                "fieldType": 64
            }]]
        },
        "十大文化古镇": {
            "tableType": 0,
            "id": "十大文化古镇",
            "connectionName": "",
            "fields": [[{
                "fieldName": "排名",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "十大文化古镇",
                "id": "十大文化古镇/排名",
                "tableTranName": "十大文化古镇",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "文化古镇",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "十大文化古镇",
                "id": "十大文化古镇/文化古镇",
                "tableTranName": "十大文化古镇",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "值",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "十大文化古镇",
                "id": "十大文化古镇/值",
                "tableTranName": "十大文化古镇",
                "fieldType": 32,
                "isEnable": true
            }], [], [], [{
                "fieldName": "十大文化古镇记录数",
                "isUsable": true,
                "tableId": "十大文化古镇",
                "id": "十大文化古镇记录数",
                "fieldType": 64
            }]]
        },
        "租赁_车辆租赁业务": {
            "tableType": 0,
            "id": "租赁_车辆租赁业务",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "客户名称",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "租赁_车辆租赁业务",
                "id": "租赁_车辆租赁业务/客户名称",
                "tableTranName": "租赁_车辆租赁业务",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "区域",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "租赁_车辆租赁业务",
                "id": "租赁_车辆租赁业务/区域",
                "tableTranName": "租赁_车辆租赁业务",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "省份",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "租赁_车辆租赁业务",
                "id": "租赁_车辆租赁业务/省份",
                "tableTranName": "租赁_车辆租赁业务",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "业务经理",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "租赁_车辆租赁业务",
                "id": "租赁_车辆租赁业务/业务经理",
                "tableTranName": "租赁_车辆租赁业务",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "时间",
                "fieldSize": 8,
                "isUsable": true,
                "tableId": "租赁_车辆租赁业务",
                "id": "租赁_车辆租赁业务/时间",
                "tableTranName": "租赁_车辆租赁业务",
                "fieldType": 48,
                "isEnable": true
            },
            {
                "fieldName": "起租金额_万元",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "租赁_车辆租赁业务",
                "id": "租赁_车辆租赁业务/起租金额_万元",
                "tableTranName": "租赁_车辆租赁业务",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "起租设备数量",
                "fieldSize": 16,
                "isUsable": true,
                "tableId": "租赁_车辆租赁业务",
                "id": "租赁_车辆租赁业务/起租设备数量",
                "tableTranName": "租赁_车辆租赁业务",
                "fieldType": 32,
                "isEnable": true
            }], [], [], [{
                "fieldName": "租赁_车辆租赁业务记录数",
                "isUsable": true,
                "tableId": "租赁_车辆租赁业务",
                "id": "租赁_车辆租赁业务记录数",
                "fieldType": 64
            }]]
        },
        "流向": {
            "tableType": 0,
            "id": "流向",
            "connectionName": "",
            "fields": [[{
                "fieldName": "出发地",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "流向",
                "id": "流向/出发地",
                "tableTranName": "流向",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "目的地",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "流向",
                "id": "流向/目的地",
                "tableTranName": "流向",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "人次",
                "fieldSize": 0,
                "isUsable": true,
                "tableId": "流向",
                "id": "流向/人次",
                "tableTranName": "流向",
                "fieldType": 32,
                "isEnable": true
            }], [], [], [{
                "fieldName": "流向记录数",
                "isUsable": true,
                "tableId": "流向",
                "id": "流向记录数",
                "fieldType": 64
            }]]
        },
        "销售事实表": {
            "tableType": 0,
            "id": "销售事实表",
            "connectionName": "BIdemo",
            "fields": [[{
                "fieldName": "销售活动ID",
                "fieldSize": 50,
                "isUsable": true,
                "tableId": "销售事实表",
                "id": "销售事实表/销售活动ID",
                "tableTranName": "销售事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "客户ID",
                "fieldSize": 50,
                "isUsable": true,
                "tableId": "销售事实表",
                "id": "销售事实表/客户ID",
                "tableTranName": "销售事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "活动时间",
                "fieldSize": 8,
                "isUsable": true,
                "tableId": "销售事实表",
                "id": "销售事实表/活动时间",
                "tableTranName": "销售事实表",
                "fieldType": 48,
                "isEnable": true
            },
            {
                "fieldName": "活动内容",
                "fieldSize": 3000,
                "isUsable": true,
                "tableId": "销售事实表",
                "id": "销售事实表/活动内容",
                "tableTranName": "销售事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "活动时间段",
                "fieldSize": 20,
                "isUsable": true,
                "tableId": "销售事实表",
                "id": "销售事实表/活动时间段",
                "tableTranName": "销售事实表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "是否结束",
                "fieldSize": 20,
                "isUsable": true,
                "tableId": "销售事实表",
                "id": "销售事实表/是否结束",
                "tableTranName": "销售事实表",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "销售事实表记录数",
                "isUsable": true,
                "tableId": "销售事实表",
                "id": "销售事实表记录数",
                "fieldType": 64
            }]]
        },
        "化工_重大事件明细表": {
            "tableType": 0,
            "id": "化工_重大事件明细表",
            "connectionName": "",
            "fields": [[{
                "fieldName": "事故通报",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "化工_重大事件明细表",
                "id": "化工_重大事件明细表/事故通报",
                "tableTranName": "化工_重大事件明细表",
                "fieldType": 16,
                "isEnable": true
            },
            {
                "fieldName": "等级_数值",
                "fieldSize": 100,
                "isUsable": true,
                "tableId": "化工_重大事件明细表",
                "id": "化工_重大事件明细表/等级_数值",
                "tableTranName": "化工_重大事件明细表",
                "fieldType": 32,
                "isEnable": true
            },
            {
                "fieldName": "等级",
                "fieldSize": 255,
                "isUsable": true,
                "tableId": "化工_重大事件明细表",
                "id": "化工_重大事件明细表/等级",
                "tableTranName": "化工_重大事件明细表",
                "fieldType": 16,
                "isEnable": true
            }], [], [], [{
                "fieldName": "化工_重大事件明细表记录数",
                "isUsable": true,
                "tableId": "化工_重大事件明细表",
                "id": "化工_重大事件明细表记录数",
                "fieldType": 64
            }]]
        }
    },
    fields: {
        "成本事实表/PARENTPROJGUID": {
            "fieldName": "PARENTPROJGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/PARENTPROJGUID",
            "tableTranName": "成本事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "CONTRACTGUID": {
            "fieldName": "CONTRACTGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "合同维度表",
            "id": "合同维度表/CONTRACTGUID",
            "tableTranName": "合同维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "FLOOR": {
            "fieldName": "FLOOR",
            "fieldSize": 20,
            "isUsable": true,
            "tableId": "房间维度表",
            "id": "房间维度表/FLOOR",
            "tableTranName": "房间维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "省份": {
            "fieldName": "省份",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "租赁_车辆租赁业务",
            "id": "租赁_车辆租赁业务/省份",
            "tableTranName": "租赁_车辆租赁业务",
            "fieldType": 16,
            "isEnable": true
        },
        "ABCDATE": {
            "fieldName": "ABCDATE",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "回款事实表",
            "id": "回款事实表/ABCDATE",
            "tableTranName": "回款事实表",
            "fieldType": 48,
            "isEnable": true
        },
        "起租金额": {
            "fieldName": "起租金额",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "租赁_存量业务",
            "id": "租赁_存量业务/起租金额",
            "tableTranName": "租赁_存量业务",
            "fieldType": 32,
            "isEnable": true
        },
        "租赁_车辆租赁业务/起租金额_万元": {
            "fieldName": "起租金额_万元",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "租赁_车辆租赁业务",
            "id": "租赁_车辆租赁业务/起租金额_万元",
            "tableTranName": "租赁_车辆租赁业务",
            "fieldType": 32,
            "isEnable": true
        },
        "成本事实表/BUILDAREA": {
            "fieldName": "BUILDAREA",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/BUILDAREA",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "用户登录权限表/机构": {
            "fieldName": "机构",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "用户登录权限表",
            "id": "用户登录权限表/机构",
            "tableTranName": "用户登录权限表",
            "fieldType": 16,
            "isEnable": true
        },
        "十大热门出境游热门目的地国家/境外游热门目的地国家": {
            "fieldName": "境外游热门目的地国家",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "十大热门出境游热门目的地国家",
            "id": "十大热门出境游热门目的地国家/境外游热门目的地国家",
            "tableTranName": "十大热门出境游热门目的地国家",
            "fieldType": 16,
            "isEnable": true
        },
        "访问最后阶段": {
            "fieldName": "访问最后阶段",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "访问阶段统计事实表",
            "id": "访问阶段统计事实表/访问最后阶段",
            "tableTranName": "访问阶段统计事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "区域维度表/AREA_ID": {
            "fieldName": "AREA_ID",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "区域维度表",
            "id": "区域维度表/AREA_ID",
            "tableTranName": "区域维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "医药_库存周转事实表/周转天": {
            "fieldName": "周转天",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "医药_库存周转事实表",
            "id": "医药_库存周转事实表/周转天",
            "tableTranName": "医药_库存周转事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "银行_机构维度表/PARENT_ID": {
            "fieldName": "PARENT_ID",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "银行_机构维度表",
            "id": "银行_机构维度表/PARENT_ID",
            "tableTranName": "银行_机构维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "宽带业务/预后付": {
            "fieldName": "预后付",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/预后付",
            "tableTranName": "宽带业务",
            "fieldType": 16,
            "isEnable": true
        },
        "BUGUID": {
            "fieldName": "BUGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "回款事实表",
            "id": "回款事实表/BUGUID",
            "tableTranName": "回款事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "产品/产品_产品ID": {
            "fieldName": "产品_产品ID",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "产品",
            "id": "产品/产品_产品ID",
            "tableTranName": "产品",
            "fieldType": 32,
            "isEnable": true
        },
        "值": {
            "fieldName": "值",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "分界口货车出入情况",
            "id": "分界口货车出入情况/值",
            "tableTranName": "分界口货车出入情况",
            "fieldType": 32,
            "isEnable": true
        },
        "样式数据一/序号": {
            "fieldName": "序号",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "样式数据一",
            "id": "样式数据一/序号",
            "tableTranName": "样式数据一",
            "fieldType": 16,
            "isEnable": true
        },
        "回款事实表/PRODUCTGUID": {
            "fieldName": "PRODUCTGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "回款事实表",
            "id": "回款事实表/PRODUCTGUID",
            "tableTranName": "回款事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "产品名称维度记录数": {
            "fieldName": "产品名称维度记录数",
            "isUsable": true,
            "tableId": "产品名称维度",
            "id": "产品名称维度记录数",
            "fieldType": 64
        },
        "回款维度表/ITEMNAME": {
            "fieldName": "ITEMNAME",
            "fieldSize": 30,
            "isUsable": true,
            "tableId": "回款维度表",
            "id": "回款维度表/ITEMNAME",
            "tableTranName": "回款维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "AREA_ID": {
            "fieldName": "AREA_ID",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "区域维度表",
            "id": "区域维度表/AREA_ID",
            "tableTranName": "区域维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "材料": {
            "fieldName": "材料",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "化工_生成进度表展示",
            "id": "化工_生成进度表展示/材料",
            "tableTranName": "化工_生成进度表展示",
            "fieldType": 16,
            "isEnable": true
        },
        "PROJGUID": {
            "fieldName": "PROJGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "项目维度表",
            "id": "项目维度表/PROJGUID",
            "tableTranName": "项目维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "供应商信息表/城市": {
            "fieldName": "城市",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商信息表",
            "id": "供应商信息表/城市",
            "tableTranName": "供应商信息表",
            "fieldType": 16,
            "isEnable": true
        },
        "店号": {
            "fieldName": "店号",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "门店维度",
            "id": "门店维度/店号",
            "tableTranName": "门店维度",
            "fieldType": 16,
            "isEnable": true
        },
        "交易金额": {
            "fieldName": "交易金额",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "业务流水表",
            "id": "业务流水表/交易金额",
            "tableTranName": "业务流水表",
            "fieldType": 32,
            "isEnable": true
        },
        "货主省份": {
            "fieldName": "货主省份",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "订单",
            "id": "订单/货主省份",
            "tableTranName": "订单",
            "fieldType": 16,
            "isEnable": true
        },
        "访问统计事实表/总停留时间": {
            "fieldName": "总停留时间",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "访问统计事实表",
            "id": "访问统计事实表/总停留时间",
            "tableTranName": "访问统计事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "访问统计事实表/统计年月": {
            "fieldName": "统计年月",
            "fieldSize": 100,
            "isUsable": true,
            "tableId": "访问统计事实表",
            "id": "访问统计事实表/统计年月",
            "tableTranName": "访问统计事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "X": {
            "fieldName": "X",
            "fieldSize": 17,
            "isUsable": true,
            "tableId": "样式数据一",
            "id": "样式数据一/X",
            "tableTranName": "样式数据一",
            "fieldType": 32,
            "isEnable": true
        },
        "一级渠道名": {
            "fieldName": "一级渠道名",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "推广渠道维度表",
            "id": "推广渠道维度表/一级渠道名",
            "tableTranName": "推广渠道维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "机构表/上级机构": {
            "fieldName": "上级机构",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "机构表",
            "id": "机构表/上级机构",
            "tableTranName": "机构表",
            "fieldType": 16,
            "isEnable": true
        },
        "店名": {
            "fieldName": "店名",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "南京苏果营业数据",
            "id": "南京苏果营业数据/店名",
            "tableTranName": "南京苏果营业数据",
            "fieldType": 16,
            "isEnable": true
        },
        "迁出城市经度": {
            "fieldName": "迁出城市经度",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "北京春运迁徙数据",
            "id": "北京春运迁徙数据/迁出城市经度",
            "tableTranName": "北京春运迁徙数据",
            "fieldType": 16,
            "isEnable": true
        },
        "购买的产品": {
            "fieldName": "购买的产品",
            "fieldSize": 10,
            "isUsable": true,
            "tableId": "合同事实表",
            "id": "合同事实表/购买的产品",
            "tableTranName": "合同事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "银行_财务分析事实表/营业税金及附加_总行分摊": {
            "fieldName": "营业税金及附加_总行分摊",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/营业税金及附加_总行分摊",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "人员变动表/年度": {
            "fieldName": "年度",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "人员变动表",
            "id": "人员变动表/年度",
            "tableTranName": "人员变动表",
            "fieldType": 16,
            "isEnable": true
        },
        "销售事实表/活动时间段": {
            "fieldName": "活动时间段",
            "fieldSize": 20,
            "isUsable": true,
            "tableId": "销售事实表",
            "id": "销售事实表/活动时间段",
            "tableTranName": "销售事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "合同事实表/客户ID": {
            "fieldName": "客户ID",
            "fieldSize": 200,
            "isUsable": true,
            "tableId": "合同事实表",
            "id": "合同事实表/客户ID",
            "tableTranName": "合同事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "全国环境监测数据/监测点编码": {
            "fieldName": "监测点编码",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "全国环境监测数据",
            "id": "全国环境监测数据/监测点编码",
            "tableTranName": "全国环境监测数据",
            "fieldType": 16,
            "isEnable": true
        },
        "合同维度表/CLOSEREASON": {
            "fieldName": "CLOSEREASON",
            "fieldSize": 30,
            "isUsable": true,
            "tableId": "合同维度表",
            "id": "合同维度表/CLOSEREASON",
            "tableTranName": "合同维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "供应商产品表/中止": {
            "fieldName": "中止",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商产品表",
            "id": "供应商产品表/中止",
            "tableTranName": "供应商产品表",
            "fieldType": 16,
            "isEnable": true
        },
        "TOTALUNITCOST": {
            "fieldName": "TOTALUNITCOST",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/TOTALUNITCOST",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "地区ID": {
            "fieldName": "地区ID",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "访问统计事实表",
            "id": "访问统计事实表/地区ID",
            "tableTranName": "访问统计事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "银行_用户维度表/用户名称": {
            "fieldName": "用户名称",
            "fieldSize": 64,
            "isUsable": true,
            "tableId": "银行_用户维度表",
            "id": "银行_用户维度表/用户名称",
            "tableTranName": "银行_用户维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "租赁_车辆租赁业务/时间": {
            "fieldName": "时间",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "租赁_车辆租赁业务",
            "id": "租赁_车辆租赁业务/时间",
            "tableTranName": "租赁_车辆租赁业务",
            "fieldType": 48,
            "isEnable": true
        },
        "医药_产品维度表/产品编码": {
            "fieldName": "产品编码",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "医药_产品维度表",
            "id": "医药_产品维度表/产品编码",
            "tableTranName": "医药_产品维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "供应商产品表/产品ID": {
            "fieldName": "产品ID",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商产品表",
            "id": "供应商产品表/产品ID",
            "tableTranName": "供应商产品表",
            "fieldType": 32,
            "isEnable": true
        },
        "宽带业务/种类": {
            "fieldName": "种类",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/种类",
            "tableTranName": "宽带业务",
            "fieldType": 16,
            "isEnable": true
        },
        "月度": {
            "fieldName": "月度",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "人员变动表",
            "id": "人员变动表/月度",
            "tableTranName": "人员变动表",
            "fieldType": 16,
            "isEnable": true
        },
        "AREA": {
            "fieldName": "AREA",
            "fieldSize": 30,
            "isUsable": true,
            "tableId": "城市地区维度表",
            "id": "城市地区维度表/AREA",
            "tableTranName": "城市地区维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "订单/到货日期": {
            "fieldName": "到货日期",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "订单",
            "id": "订单/到货日期",
            "tableTranName": "订单",
            "fieldType": 16,
            "isEnable": true
        },
        "项目维度表/PARENTPROJNAME": {
            "fieldName": "PARENTPROJNAME",
            "fieldSize": 400,
            "isUsable": true,
            "tableId": "项目维度表",
            "id": "项目维度表/PARENTPROJNAME",
            "tableTranName": "项目维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "流向记录数": {
            "fieldName": "流向记录数",
            "isUsable": true,
            "tableId": "流向",
            "id": "流向记录数",
            "fieldType": 64
        },
        "租赁_车辆租赁业务/客户名称": {
            "fieldName": "客户名称",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "租赁_车辆租赁业务",
            "id": "租赁_车辆租赁业务/客户名称",
            "tableTranName": "租赁_车辆租赁业务",
            "fieldType": 16,
            "isEnable": true
        },
        "OCCUPYAREA": {
            "fieldName": "OCCUPYAREA",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/OCCUPYAREA",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "成本事实表/TOTALUNITCOST": {
            "fieldName": "TOTALUNITCOST",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/TOTALUNITCOST",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "当月发生": {
            "fieldName": "当月发生",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/当月发生",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "宽带业务/组合类型": {
            "fieldName": "组合类型",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/组合类型",
            "tableTranName": "宽带业务",
            "fieldType": 16,
            "isEnable": true
        },
        "库存事实表/SALEAREA": {
            "fieldName": "SALEAREA",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "库存事实表",
            "id": "库存事实表/SALEAREA",
            "tableTranName": "库存事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "监测点纬度": {
            "fieldName": "监测点纬度",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "全国环境监测数据",
            "id": "全国环境监测数据/监测点纬度",
            "tableTranName": "全国环境监测数据",
            "fieldType": 16,
            "isEnable": true
        },
        "PRODUCTGUID": {
            "fieldName": "PRODUCTGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "产品维度表",
            "id": "产品维度表/PRODUCTGUID",
            "tableTranName": "产品维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "账户名称": {
            "fieldName": "账户名称",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "业务流水表",
            "id": "业务流水表/账户名称",
            "tableTranName": "业务流水表",
            "fieldType": 16,
            "isEnable": true
        },
        "产品/产品_供应商ID": {
            "fieldName": "产品_供应商ID",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "产品",
            "id": "产品/产品_供应商ID",
            "tableTranName": "产品",
            "fieldType": 32,
            "isEnable": true
        },
        "订单/货主地址": {
            "fieldName": "货主地址",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "订单",
            "id": "订单/货主地址",
            "tableTranName": "订单",
            "fieldType": 16,
            "isEnable": true
        },
        "南京苏果营业数据/营业额": {
            "fieldName": "营业额",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "南京苏果营业数据",
            "id": "南京苏果营业数据/营业额",
            "tableTranName": "南京苏果营业数据",
            "fieldType": 32,
            "isEnable": true
        },
        "CODIFF": {
            "fieldName": "CODIFF",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/CODIFF",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "人员变动表记录数": {
            "fieldName": "人员变动表记录数",
            "isUsable": true,
            "tableId": "人员变动表",
            "id": "人员变动表记录数",
            "fieldType": 64
        },
        "房间维度表/ROOMSTRU": {
            "fieldName": "ROOMSTRU",
            "fieldSize": 30,
            "isUsable": true,
            "tableId": "房间维度表",
            "id": "房间维度表/ROOMSTRU",
            "tableTranName": "房间维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "成本事实表/BUGUID": {
            "fieldName": "BUGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/BUGUID",
            "tableTranName": "成本事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "UNITPRICE": {
            "fieldName": "UNITPRICE",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/UNITPRICE",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "交易码": {
            "fieldName": "交易码",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "业务流水表",
            "id": "业务流水表/交易码",
            "tableTranName": "业务流水表",
            "fieldType": 32,
            "isEnable": true
        },
        "出游年龄占比记录数": {
            "fieldName": "出游年龄占比记录数",
            "isUsable": true,
            "tableId": "出游年龄占比",
            "id": "出游年龄占比记录数",
            "fieldType": 64
        },
        "业务流水表/等待时间": {
            "fieldName": "等待时间",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "业务流水表",
            "id": "业务流水表/等待时间",
            "tableTranName": "业务流水表",
            "fieldType": 32,
            "isEnable": true
        },
        "门店维度记录数": {
            "fieldName": "门店维度记录数",
            "isUsable": true,
            "tableId": "门店维度",
            "id": "门店维度记录数",
            "fieldType": 64
        },
        "区域ID": {
            "fieldName": "区域ID",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/区域ID",
            "tableTranName": "宽带业务",
            "fieldType": 16,
            "isEnable": true
        },
        "房间维度表/VIRTUALSTATUS": {
            "fieldName": "VIRTUALSTATUS",
            "fieldSize": 10,
            "isUsable": true,
            "tableId": "房间维度表",
            "id": "房间维度表/VIRTUALSTATUS",
            "tableTranName": "房间维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "业务流水表/账号": {
            "fieldName": "账号",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "业务流水表",
            "id": "业务流水表/账号",
            "tableTranName": "业务流水表",
            "fieldType": 32,
            "isEnable": true
        },
        "ExcelView之客户跟踪表/负责人": {
            "fieldName": "负责人",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/负责人",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 16,
            "isEnable": true
        },
        "SALES_NAME": {
            "fieldName": "SALES_NAME",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "销售员维度表",
            "id": "销售员维度表/SALES_NAME",
            "tableTranName": "销售员维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "行业细分": {
            "fieldName": "行业细分",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "租赁_存量业务",
            "id": "租赁_存量业务/行业细分",
            "tableTranName": "租赁_存量业务",
            "fieldType": 16,
            "isEnable": true
        },
        "周转天": {
            "fieldName": "周转天",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "医药_库存周转事实表",
            "id": "医药_库存周转事实表/周转天",
            "tableTranName": "医药_库存周转事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "化工_设备运行状况展示记录数": {
            "fieldName": "化工_设备运行状况展示记录数",
            "isUsable": true,
            "tableId": "化工_设备运行状况展示",
            "id": "化工_设备运行状况展示记录数",
            "fieldType": 64
        },
        "销售员维度表记录数": {
            "fieldName": "销售员维度表记录数",
            "isUsable": true,
            "tableId": "销售员维度表",
            "id": "销售员维度表记录数",
            "fieldType": 64
        },
        "银行_财务分析事实表/资产减值损失": {
            "fieldName": "资产减值损失",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/资产减值损失",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "金额": {
            "fieldName": "金额",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "订单明细",
            "id": "订单明细/金额",
            "tableTranName": "订单明细",
            "fieldType": 16,
            "isEnable": true
        },
        "ITEMNAME": {
            "fieldName": "ITEMNAME",
            "fieldSize": 30,
            "isUsable": true,
            "tableId": "回款维度表",
            "id": "回款维度表/ITEMNAME",
            "tableTranName": "回款维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "样式数据三/X": {
            "fieldName": "X",
            "fieldSize": 17,
            "isUsable": true,
            "tableId": "样式数据三",
            "id": "样式数据三/X",
            "tableTranName": "样式数据三",
            "fieldType": 32,
            "isEnable": true
        },
        "银行_财务分析事实表/交易笔数": {
            "fieldName": "交易笔数",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/交易笔数",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "内部资金转移支出": {
            "fieldName": "内部资金转移支出",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/内部资金转移支出",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "银行_财务分析事实表/经济资本": {
            "fieldName": "经济资本",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/经济资本",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "ExcelView之客户跟踪表/平均每日营业额": {
            "fieldName": "平均每日营业额",
            "fieldSize": 17,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/平均每日营业额",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 32,
            "isEnable": true
        },
        "PA产品号": {
            "fieldName": "PA产品号",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "银行_产品维度表",
            "id": "银行_产品维度表/PA产品号",
            "tableTranName": "银行_产品维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "ID": {
            "fieldName": "ID",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "分界口货车出入情况",
            "id": "分界口货车出入情况/ID",
            "tableTranName": "分界口货车出入情况",
            "fieldType": 32,
            "isEnable": true
        },
        "访问阶段统计事实表/访问平台": {
            "fieldName": "访问平台",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "访问阶段统计事实表",
            "id": "访问阶段统计事实表/访问平台",
            "tableTranName": "访问阶段统计事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "租赁_车辆租赁业务/省份": {
            "fieldName": "省份",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "租赁_车辆租赁业务",
            "id": "租赁_车辆租赁业务/省份",
            "tableTranName": "租赁_车辆租赁业务",
            "fieldType": 16,
            "isEnable": true
        },
        "银行_机构维度表/JGID": {
            "fieldName": "JGID",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "银行_机构维度表",
            "id": "银行_机构维度表/JGID",
            "tableTranName": "银行_机构维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "城市地区维度表/CITY": {
            "fieldName": "CITY",
            "fieldSize": 30,
            "isUsable": true,
            "tableId": "城市地区维度表",
            "id": "城市地区维度表/CITY",
            "tableTranName": "城市地区维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "分界口货车出入情况记录数": {
            "fieldName": "分界口货车出入情况记录数",
            "isUsable": true,
            "tableId": "分界口货车出入情况",
            "id": "分界口货车出入情况记录数",
            "fieldType": 64
        },
        "ExcelView之客户跟踪表/主要来往银行": {
            "fieldName": "主要来往银行",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/主要来往银行",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 16,
            "isEnable": true
        },
        "资本额": {
            "fieldName": "资本额",
            "fieldSize": 17,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/资本额",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 32,
            "isEnable": true
        },
        "订单明细/金额": {
            "fieldName": "金额",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "订单明细",
            "id": "订单明细/金额",
            "tableTranName": "订单明细",
            "fieldType": 16,
            "isEnable": true
        },
        "最近交易数据跟踪": {
            "fieldName": "最近交易数据跟踪",
            "fieldSize": 10,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/最近交易数据跟踪",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 32,
            "isEnable": true
        },
        "货主名称": {
            "fieldName": "货主名称",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "订单",
            "id": "订单/货主名称",
            "tableTranName": "订单",
            "fieldType": 16,
            "isEnable": true
        },
        "客户维度表/是否为重要客户": {
            "fieldName": "是否为重要客户",
            "fieldSize": 10,
            "isUsable": true,
            "tableId": "客户维度表",
            "id": "客户维度表/是否为重要客户",
            "tableTranName": "客户维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "供应商产品表/库存量": {
            "fieldName": "库存量",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商产品表",
            "id": "供应商产品表/库存量",
            "tableTranName": "供应商产品表",
            "fieldType": 32,
            "isEnable": true
        },
        "银行_财务分析事实表/月均余额": {
            "fieldName": "月均余额",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/月均余额",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "化工_原料成本趋势展示/工厂": {
            "fieldName": "工厂",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "化工_原料成本趋势展示",
            "id": "化工_原料成本趋势展示/工厂",
            "tableTranName": "化工_原料成本趋势展示",
            "fieldType": 16,
            "isEnable": true
        },
        "签约事实表/RMBHTTOTAL": {
            "fieldName": "RMBHTTOTAL",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "签约事实表",
            "id": "签约事实表/RMBHTTOTAL",
            "tableTranName": "签约事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "合同事实表/合同付款类型": {
            "fieldName": "合同付款类型",
            "fieldSize": 20,
            "isUsable": true,
            "tableId": "合同事实表",
            "id": "合同事实表/合同付款类型",
            "tableTranName": "合同事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "合同回款事实记录数": {
            "fieldName": "合同回款事实记录数",
            "isUsable": true,
            "tableId": "合同回款事实",
            "id": "合同回款事实记录数",
            "fieldType": 64
        },
        "资产减值损失": {
            "fieldName": "资产减值损失",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/资产减值损失",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "租赁_存量业务/行业大类": {
            "fieldName": "行业大类",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "租赁_存量业务",
            "id": "租赁_存量业务/行业大类",
            "tableTranName": "租赁_存量业务",
            "fieldType": 16,
            "isEnable": true
        },
        "租赁_车辆租赁业务/业务经理": {
            "fieldName": "业务经理",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "租赁_车辆租赁业务",
            "id": "租赁_车辆租赁业务/业务经理",
            "tableTranName": "租赁_车辆租赁业务",
            "fieldType": 16,
            "isEnable": true
        },
        "签约事实表/BLDGUID": {
            "fieldName": "BLDGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "签约事实表",
            "id": "签约事实表/BLDGUID",
            "tableTranName": "签约事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "产品维度表/PRODUCTCLASS": {
            "fieldName": "PRODUCTCLASS",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "产品维度表",
            "id": "产品维度表/PRODUCTCLASS",
            "tableTranName": "产品维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "流向/目的地": {
            "fieldName": "目的地",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "流向",
            "id": "流向/目的地",
            "tableTranName": "流向",
            "fieldType": 16,
            "isEnable": true
        },
        "运行时间": {
            "fieldName": "运行时间",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "化工_设备运行状况展示",
            "id": "化工_设备运行状况展示/运行时间",
            "tableTranName": "化工_设备运行状况展示",
            "fieldType": 16,
            "isEnable": true
        },
        "银行_业务维度表/业务名称": {
            "fieldName": "业务名称",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "银行_业务维度表",
            "id": "银行_业务维度表/业务名称",
            "tableTranName": "银行_业务维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "客户规模": {
            "fieldName": "客户规模",
            "fieldSize": 10,
            "isUsable": true,
            "tableId": "客户维度表",
            "id": "客户维度表/客户规模",
            "tableTranName": "客户维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "出境方式": {
            "fieldName": "出境方式",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "出境方式占比",
            "id": "出境方式占比/出境方式",
            "tableTranName": "出境方式占比",
            "fieldType": 16,
            "isEnable": true
        },
        "访问统计事实表/访问平台": {
            "fieldName": "访问平台",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "访问统计事实表",
            "id": "访问统计事实表/访问平台",
            "tableTranName": "访问统计事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "产品ID": {
            "fieldName": "产品ID",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商产品表",
            "id": "供应商产品表/产品ID",
            "tableTranName": "供应商产品表",
            "fieldType": 32,
            "isEnable": true
        },
        "签约事实表/PRICE": {
            "fieldName": "PRICE",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "签约事实表",
            "id": "签约事实表/PRICE",
            "tableTranName": "签约事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "成本事实表/SALERATE": {
            "fieldName": "SALERATE",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/SALERATE",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "CITY": {
            "fieldName": "CITY",
            "fieldSize": 30,
            "isUsable": true,
            "tableId": "城市地区维度表",
            "id": "城市地区维度表/CITY",
            "tableTranName": "城市地区维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "雇员/地区": {
            "fieldName": "地区",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "雇员",
            "id": "雇员/地区",
            "tableTranName": "雇员",
            "fieldType": 16,
            "isEnable": true
        },
        "成本事实表/DFZJCB": {
            "fieldName": "DFZJCB",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/DFZJCB",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "库存事实表/TOTALDJ": {
            "fieldName": "TOTALDJ",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "库存事实表",
            "id": "库存事实表/TOTALDJ",
            "tableTranName": "库存事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "合同维度表/TOTAL": {
            "fieldName": "TOTAL",
            "fieldSize": 20,
            "isUsable": true,
            "tableId": "合同维度表",
            "id": "合同维度表/TOTAL",
            "tableTranName": "合同维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "访问次数": {
            "fieldName": "访问次数",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "访问统计事实表",
            "id": "访问统计事实表/访问次数",
            "tableTranName": "访问统计事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "机构表记录数": {
            "fieldName": "机构表记录数",
            "isUsable": true,
            "tableId": "机构表",
            "id": "机构表记录数",
            "fieldType": 64
        },
        "OCCUPYCOSTNEW": {
            "fieldName": "OCCUPYCOSTNEW",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/OCCUPYCOSTNEW",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "十大文化古镇/排名": {
            "fieldName": "排名",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "十大文化古镇",
            "id": "十大文化古镇/排名",
            "tableTranName": "十大文化古镇",
            "fieldType": 32,
            "isEnable": true
        },
        "DISCNTREMARK": {
            "fieldName": "DISCNTREMARK",
            "fieldSize": 256,
            "isUsable": true,
            "tableId": "合同维度表",
            "id": "合同维度表/DISCNTREMARK",
            "tableTranName": "合同维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "品牌维度/品牌描述": {
            "fieldName": "品牌描述",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "品牌维度",
            "id": "品牌维度/品牌描述",
            "tableTranName": "品牌维度",
            "fieldType": 16,
            "isEnable": true
        },
        "WEST": {
            "fieldName": "WEST",
            "fieldSize": 20,
            "isUsable": true,
            "tableId": "房间维度表",
            "id": "房间维度表/WEST",
            "tableTranName": "房间维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "消耗量": {
            "fieldName": "消耗量",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "化工_能耗指标趋势",
            "id": "化工_能耗指标趋势/消耗量",
            "tableTranName": "化工_能耗指标趋势",
            "fieldType": 32,
            "isEnable": true
        },
        "南京苏果营业数据/纬度": {
            "fieldName": "纬度",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "南京苏果营业数据",
            "id": "南京苏果营业数据/纬度",
            "tableTranName": "南京苏果营业数据",
            "fieldType": 16,
            "isEnable": true
        },
        "合同签约时间": {
            "fieldName": "合同签约时间",
            "fieldSize": 23,
            "isUsable": true,
            "tableId": "合同事实表",
            "id": "合同事实表/合同签约时间",
            "tableTranName": "合同事实表",
            "fieldType": 48,
            "isEnable": true
        },
        "销售员维度表/SALES_PARENT": {
            "fieldName": "SALES_PARENT",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "销售员维度表",
            "id": "销售员维度表/SALES_PARENT",
            "tableTranName": "销售员维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "主页": {
            "fieldName": "主页",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商信息表",
            "id": "供应商信息表/主页",
            "tableTranName": "供应商信息表",
            "fieldType": 16,
            "isEnable": true
        },
        "STATUS": {
            "fieldName": "STATUS",
            "fieldSize": 10,
            "isUsable": true,
            "tableId": "房间维度表",
            "id": "房间维度表/STATUS",
            "tableTranName": "房间维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "化工_生成进度表展示/存留比例": {
            "fieldName": "存留比例",
            "fieldSize": 17,
            "isUsable": true,
            "tableId": "化工_生成进度表展示",
            "id": "化工_生成进度表展示/存留比例",
            "tableTranName": "化工_生成进度表展示",
            "fieldType": 32,
            "isEnable": true
        },
        "人员变动表/学历": {
            "fieldName": "学历",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "人员变动表",
            "id": "人员变动表/学历",
            "tableTranName": "人员变动表",
            "fieldType": 16,
            "isEnable": true
        },
        "订单/发货日期": {
            "fieldName": "发货日期",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "订单",
            "id": "订单/发货日期",
            "tableTranName": "订单",
            "fieldType": 16,
            "isEnable": true
        },
        "UNITPRICEDISPLAY": {
            "fieldName": "UNITPRICEDISPLAY",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/UNITPRICEDISPLAY",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "回款事实表/GETDATE": {
            "fieldName": "GETDATE",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "回款事实表",
            "id": "回款事实表/GETDATE",
            "tableTranName": "回款事实表",
            "fieldType": 48,
            "isEnable": true
        },
        "毛利": {
            "fieldName": "毛利",
            "fieldSize": 10,
            "isUsable": true,
            "tableId": "销售明细",
            "id": "销售明细/毛利",
            "tableTranName": "销售明细",
            "fieldType": 32,
            "isEnable": true
        },
        "浏览器占比变化/数量": {
            "fieldName": "数量",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "浏览器占比变化",
            "id": "浏览器占比变化/数量",
            "tableTranName": "浏览器占比变化",
            "fieldType": 32,
            "isEnable": true
        },
        "产品/产品_产品名称": {
            "fieldName": "产品_产品名称",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "产品",
            "id": "产品/产品_产品名称",
            "tableTranName": "产品",
            "fieldType": 16,
            "isEnable": true
        },
        "客户ID": {
            "fieldName": "客户ID",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "订单",
            "id": "订单/客户ID",
            "tableTranName": "订单",
            "fieldType": 16,
            "isEnable": true
        },
        "ExcelView之客户跟踪表/收款记录": {
            "fieldName": "收款记录",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/收款记录",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 16,
            "isEnable": true
        },
        "银行_机构维度表记录数": {
            "fieldName": "银行_机构维度表记录数",
            "isUsable": true,
            "tableId": "银行_机构维度表",
            "id": "银行_机构维度表记录数",
            "fieldType": 64
        },
        "成本事实表/OCCUPYSTAT": {
            "fieldName": "OCCUPYSTAT",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/OCCUPYSTAT",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "医药_库存周转事实表/库存金额": {
            "fieldName": "库存金额",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "医药_库存周转事实表",
            "id": "医药_库存周转事实表/库存金额",
            "tableTranName": "医药_库存周转事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "PARENT_ID": {
            "fieldName": "PARENT_ID",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "银行_机构维度表",
            "id": "银行_机构维度表/PARENT_ID",
            "tableTranName": "银行_机构维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "客户维度表/客户对应销售员": {
            "fieldName": "客户对应销售员",
            "fieldSize": 64,
            "isUsable": true,
            "tableId": "客户维度表",
            "id": "客户维度表/客户对应销售员",
            "tableTranName": "客户维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "货主城市": {
            "fieldName": "货主城市",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "订单",
            "id": "订单/货主城市",
            "tableTranName": "订单",
            "fieldType": 16,
            "isEnable": true
        },
        "西安兰特雨量监测数据记录数": {
            "fieldName": "西安兰特雨量监测数据记录数",
            "isUsable": true,
            "tableId": "西安兰特雨量监测数据",
            "id": "西安兰特雨量监测数据记录数",
            "fieldType": 64
        },
        "经度": {
            "fieldName": "经度",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "南京苏果营业数据",
            "id": "南京苏果营业数据/经度",
            "tableTranName": "南京苏果营业数据",
            "fieldType": 16,
            "isEnable": true
        },
        "成本事实表/AREAGUID": {
            "fieldName": "AREAGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/AREAGUID",
            "tableTranName": "成本事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "GETDATE": {
            "fieldName": "GETDATE",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "回款事实表",
            "id": "回款事实表/GETDATE",
            "tableTranName": "回款事实表",
            "fieldType": 48,
            "isEnable": true
        },
        "ExcelView之客户跟踪表/填表人": {
            "fieldName": "填表人",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/填表人",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 16,
            "isEnable": true
        },
        "客户维度表/国家": {
            "fieldName": "国家",
            "fieldSize": 64,
            "isUsable": true,
            "tableId": "客户维度表",
            "id": "客户维度表/国家",
            "tableTranName": "客户维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "医药_产品维度表记录数": {
            "fieldName": "医药_产品维度表记录数",
            "isUsable": true,
            "tableId": "医药_产品维度表",
            "id": "医药_产品维度表记录数",
            "fieldType": 64
        },
        "月均余额": {
            "fieldName": "月均余额",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/月均余额",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "业务流水表/办理时间": {
            "fieldName": "办理时间",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "业务流水表",
            "id": "业务流水表/办理时间",
            "tableTranName": "业务流水表",
            "fieldType": 32,
            "isEnable": true
        },
        "出发地": {
            "fieldName": "出发地",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "流向",
            "id": "流向/出发地",
            "tableTranName": "流向",
            "fieldType": 16,
            "isEnable": true
        },
        "ExcelView之客户跟踪表/客户名称": {
            "fieldName": "客户名称",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/客户名称",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 16,
            "isEnable": true
        },
        "库存事实表/BUGUID": {
            "fieldName": "BUGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "库存事实表",
            "id": "库存事实表/BUGUID",
            "tableTranName": "库存事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "房间维度表/STATUS": {
            "fieldName": "STATUS",
            "fieldSize": 10,
            "isUsable": true,
            "tableId": "房间维度表",
            "id": "房间维度表/STATUS",
            "tableTranName": "房间维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "付款时间": {
            "fieldName": "付款时间",
            "fieldSize": 23,
            "isUsable": true,
            "tableId": "合同回款事实",
            "id": "合同回款事实/付款时间",
            "tableTranName": "合同回款事实",
            "fieldType": 48,
            "isEnable": true
        },
        "内部资金转移收入": {
            "fieldName": "内部资金转移收入",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/内部资金转移收入",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "PROJCODE": {
            "fieldName": "PROJCODE",
            "fieldSize": 100,
            "isUsable": true,
            "tableId": "项目维度表",
            "id": "项目维度表/PROJCODE",
            "tableTranName": "项目维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "雇员2记录数": {
            "fieldName": "雇员2记录数",
            "isUsable": true,
            "tableId": "雇员2",
            "id": "雇员2记录数",
            "fieldType": 64
        },
        "签约事实表/PRODUCTGUID": {
            "fieldName": "PRODUCTGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "签约事实表",
            "id": "签约事实表/PRODUCTGUID",
            "tableTranName": "签约事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "销售员维度表/SALES_NAME": {
            "fieldName": "SALES_NAME",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "销售员维度表",
            "id": "销售员维度表/SALES_NAME",
            "tableTranName": "销售员维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "类目": {
            "fieldName": "类目",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "样式数据二",
            "id": "样式数据二/类目",
            "tableTranName": "样式数据二",
            "fieldType": 16,
            "isEnable": true
        },
        "样式数据三/ID": {
            "fieldName": "ID",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "样式数据三",
            "id": "样式数据三/ID",
            "tableTranName": "样式数据三",
            "fieldType": 16,
            "isEnable": true
        },
        "业务流水表/交易码": {
            "fieldName": "交易码",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "业务流水表",
            "id": "业务流水表/交易码",
            "tableTranName": "业务流水表",
            "fieldType": 32,
            "isEnable": true
        },
        "北京春运迁徙数据/迁入城市经度": {
            "fieldName": "迁入城市经度",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "北京春运迁徙数据",
            "id": "北京春运迁徙数据/迁入城市经度",
            "tableTranName": "北京春运迁徙数据",
            "fieldType": 16,
            "isEnable": true
        },
        "十大文化古镇/值": {
            "fieldName": "值",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "十大文化古镇",
            "id": "十大文化古镇/值",
            "tableTranName": "十大文化古镇",
            "fieldType": 32,
            "isEnable": true
        },
        "回款维度表记录数": {
            "fieldName": "回款维度表记录数",
            "isUsable": true,
            "tableId": "回款维度表",
            "id": "回款维度表记录数",
            "fieldType": 64
        },
        "化工_产品收入率趋势/产品名称": {
            "fieldName": "产品名称",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "化工_产品收入率趋势",
            "id": "化工_产品收入率趋势/产品名称",
            "tableTranName": "化工_产品收入率趋势",
            "fieldType": 16,
            "isEnable": true
        },
        "供应商ID": {
            "fieldName": "供应商ID",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商信息表",
            "id": "供应商信息表/供应商ID",
            "tableTranName": "供应商信息表",
            "fieldType": 32,
            "isEnable": true
        },
        "宽带业务/类型细类": {
            "fieldName": "类型细类",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/类型细类",
            "tableTranName": "宽带业务",
            "fieldType": 16,
            "isEnable": true
        },
        "材料名称": {
            "fieldName": "材料名称",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "化工_库存展示",
            "id": "化工_库存展示/材料名称",
            "tableTranName": "化工_库存展示",
            "fieldType": 16,
            "isEnable": true
        },
        "原料成本": {
            "fieldName": "原料成本",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "化工_原料成本趋势展示",
            "id": "化工_原料成本趋势展示/原料成本",
            "tableTranName": "化工_原料成本趋势展示",
            "fieldType": 32,
            "isEnable": true
        },
        "合同维度表/DISCNTVALUE": {
            "fieldName": "DISCNTVALUE",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "合同维度表",
            "id": "合同维度表/DISCNTVALUE",
            "tableTranName": "合同维度表",
            "fieldType": 32,
            "isEnable": true
        },
        "房间维度表/TOTALDJ": {
            "fieldName": "TOTALDJ",
            "fieldSize": 20,
            "isUsable": true,
            "tableId": "房间维度表",
            "id": "房间维度表/TOTALDJ",
            "tableTranName": "房间维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "地区": {
            "fieldName": "地区",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商信息表",
            "id": "供应商信息表/地区",
            "tableTranName": "供应商信息表",
            "fieldType": 16,
            "isEnable": true
        },
        "全国环境监测数据/监测点纬度": {
            "fieldName": "监测点纬度",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "全国环境监测数据",
            "id": "全国环境监测数据/监测点纬度",
            "tableTranName": "全国环境监测数据",
            "fieldType": 16,
            "isEnable": true
        },
        "签约事实表/QSDATE": {
            "fieldName": "QSDATE",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "签约事实表",
            "id": "签约事实表/QSDATE",
            "tableTranName": "签约事实表",
            "fieldType": 48,
            "isEnable": true
        },
        "OCCUPYAREANEW": {
            "fieldName": "OCCUPYAREANEW",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/OCCUPYAREANEW",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "医药_客户地区维度/客户名称": {
            "fieldName": "客户名称",
            "fieldSize": 64,
            "isUsable": true,
            "tableId": "医药_客户地区维度",
            "id": "医药_客户地区维度/客户名称",
            "tableTranName": "医药_客户地区维度",
            "fieldType": 16,
            "isEnable": true
        },
        "医药_库存周转事实表/周转月": {
            "fieldName": "周转月",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "医药_库存周转事实表",
            "id": "医药_库存周转事实表/周转月",
            "tableTranName": "医药_库存周转事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "是否有ITV": {
            "fieldName": "是否有ITV",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/是否有ITV",
            "tableTranName": "宽带业务",
            "fieldType": 16,
            "isEnable": true
        },
        "成本事实表/OCCUPYAREANEW": {
            "fieldName": "OCCUPYAREANEW",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/OCCUPYAREANEW",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "库存事实表/ROOMGUID": {
            "fieldName": "ROOMGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "库存事实表",
            "id": "库存事实表/ROOMGUID",
            "tableTranName": "库存事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "供应商信息表/主页": {
            "fieldName": "主页",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商信息表",
            "id": "供应商信息表/主页",
            "tableTranName": "供应商信息表",
            "fieldType": 16,
            "isEnable": true
        },
        "回款维度表/ABCDATE": {
            "fieldName": "ABCDATE",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "回款维度表",
            "id": "回款维度表/ABCDATE",
            "tableTranName": "回款维度表",
            "fieldType": 48,
            "isEnable": true
        },
        "PRODUCTDIFF": {
            "fieldName": "PRODUCTDIFF",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/PRODUCTDIFF",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "成本事实表/UNITPRICE": {
            "fieldName": "UNITPRICE",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/UNITPRICE",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "OCCUPYSTAT": {
            "fieldName": "OCCUPYSTAT",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/OCCUPYSTAT",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "事故通报": {
            "fieldName": "事故通报",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "化工_重大事件明细表",
            "id": "化工_重大事件明细表/事故通报",
            "tableTranName": "化工_重大事件明细表",
            "fieldType": 16,
            "isEnable": true
        },
        "BLDGUID": {
            "fieldName": "BLDGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "回款事实表",
            "id": "回款事实表/BLDGUID",
            "tableTranName": "回款事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "合同事实表/合同ID": {
            "fieldName": "合同ID",
            "fieldSize": 200,
            "isUsable": true,
            "tableId": "合同事实表",
            "id": "合同事实表/合同ID",
            "tableTranName": "合同事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "宽带业务/是否WLAN": {
            "fieldName": "是否WLAN",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/是否WLAN",
            "tableTranName": "宽带业务",
            "fieldType": 16,
            "isEnable": true
        },
        "门店维度/所属小区": {
            "fieldName": "所属小区",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "门店维度",
            "id": "门店维度/所属小区",
            "tableTranName": "门店维度",
            "fieldType": 16,
            "isEnable": true
        },
        "迁入城市": {
            "fieldName": "迁入城市",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "北京春运迁徙数据",
            "id": "北京春运迁徙数据/迁入城市",
            "tableTranName": "北京春运迁徙数据",
            "fieldType": 16,
            "isEnable": true
        },
        "银行_用户维度表/用户ID": {
            "fieldName": "用户ID",
            "fieldSize": 64,
            "isUsable": true,
            "tableId": "银行_用户维度表",
            "id": "银行_用户维度表/用户ID",
            "tableTranName": "银行_用户维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "联系人姓名": {
            "fieldName": "联系人姓名",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商信息表",
            "id": "供应商信息表/联系人姓名",
            "tableTranName": "供应商信息表",
            "fieldType": 16,
            "isEnable": true
        },
        "供应商信息表记录数": {
            "fieldName": "供应商信息表记录数",
            "isUsable": true,
            "tableId": "供应商信息表",
            "id": "供应商信息表记录数",
            "fieldType": 64
        },
        "工厂": {
            "fieldName": "工厂",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "化工_原料成本趋势展示",
            "id": "化工_原料成本趋势展示/工厂",
            "tableTranName": "化工_原料成本趋势展示",
            "fieldType": 16,
            "isEnable": true
        },
        "CJPRICE": {
            "fieldName": "CJPRICE",
            "fieldSize": 20,
            "isUsable": true,
            "tableId": "合同维度表",
            "id": "合同维度表/CJPRICE",
            "tableTranName": "合同维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "供应商产品表/产品名称": {
            "fieldName": "产品名称",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商产品表",
            "id": "供应商产品表/产品名称",
            "tableTranName": "供应商产品表",
            "fieldType": 16,
            "isEnable": true
        },
        "客户名称": {
            "fieldName": "客户名称",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "租赁_车辆租赁业务",
            "id": "租赁_车辆租赁业务/客户名称",
            "tableTranName": "租赁_车辆租赁业务",
            "fieldType": 16,
            "isEnable": true
        },
        "是否纯ITV": {
            "fieldName": "是否纯ITV",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/是否纯ITV",
            "tableTranName": "宽带业务",
            "fieldType": 16,
            "isEnable": true
        },
        "用户信息维度表/渠道ID": {
            "fieldName": "渠道ID",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "用户信息维度表",
            "id": "用户信息维度表/渠道ID",
            "tableTranName": "用户信息维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "南京苏果营业数据/地址": {
            "fieldName": "地址",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "南京苏果营业数据",
            "id": "南京苏果营业数据/地址",
            "tableTranName": "南京苏果营业数据",
            "fieldType": 16,
            "isEnable": true
        },
        "化工_能耗指标趋势/消耗材料": {
            "fieldName": "消耗材料",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "化工_能耗指标趋势",
            "id": "化工_能耗指标趋势/消耗材料",
            "tableTranName": "化工_能耗指标趋势",
            "fieldType": 16,
            "isEnable": true
        },
        "劳动关系类别": {
            "fieldName": "劳动关系类别",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "人员变动表",
            "id": "人员变动表/劳动关系类别",
            "tableTranName": "人员变动表",
            "fieldType": 16,
            "isEnable": true
        },
        "宽带业务/分局": {
            "fieldName": "分局",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/分局",
            "tableTranName": "宽带业务",
            "fieldType": 16,
            "isEnable": true
        },
        "客户对应销售员": {
            "fieldName": "客户对应销售员",
            "fieldSize": 64,
            "isUsable": true,
            "tableId": "客户维度表",
            "id": "客户维度表/客户对应销售员",
            "tableTranName": "客户维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "楼层": {
            "fieldName": "楼层",
            "fieldSize": 10,
            "isUsable": true,
            "tableId": "销售明细",
            "id": "销售明细/楼层",
            "tableTranName": "销售明细",
            "fieldType": 32,
            "isEnable": true
        },
        "签约事实表/CONTRACTGUID": {
            "fieldName": "CONTRACTGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "签约事实表",
            "id": "签约事实表/CONTRACTGUID",
            "tableTranName": "签约事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "宽带业务/网格": {
            "fieldName": "网格",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/网格",
            "tableTranName": "宽带业务",
            "fieldType": 16,
            "isEnable": true
        },
        "数量": {
            "fieldName": "数量",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "浏览器占比变化",
            "id": "浏览器占比变化/数量",
            "tableTranName": "浏览器占比变化",
            "fieldType": 32,
            "isEnable": true
        },
        "人员变动表/月度": {
            "fieldName": "月度",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "人员变动表",
            "id": "人员变动表/月度",
            "tableTranName": "人员变动表",
            "fieldType": 16,
            "isEnable": true
        },
        "成本事实表/COSTRATE": {
            "fieldName": "COSTRATE",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/COSTRATE",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "分公司维度表/办事处纬度": {
            "fieldName": "办事处纬度",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "分公司维度表",
            "id": "分公司维度表/办事处纬度",
            "tableTranName": "分公司维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "是否WLAN": {
            "fieldName": "是否WLAN",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/是否WLAN",
            "tableTranName": "宽带业务",
            "fieldType": 16,
            "isEnable": true
        },
        "签约事实表/AREAGUID": {
            "fieldName": "AREAGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "签约事实表",
            "id": "签约事实表/AREAGUID",
            "tableTranName": "签约事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "成本事实表/OCCUPYRATENEW": {
            "fieldName": "OCCUPYRATENEW",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/OCCUPYRATENEW",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "项目维度表/PROJGUID": {
            "fieldName": "PROJGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "项目维度表",
            "id": "项目维度表/PROJGUID",
            "tableTranName": "项目维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "雇员/雇用日期": {
            "fieldName": "雇用日期",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "雇员",
            "id": "雇员/雇用日期",
            "tableTranName": "雇员",
            "fieldType": 16,
            "isEnable": true
        },
        "到货日期": {
            "fieldName": "到货日期",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "订单",
            "id": "订单/到货日期",
            "tableTranName": "订单",
            "fieldType": 16,
            "isEnable": true
        },
        "化工_能耗指标趋势/日期": {
            "fieldName": "日期",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "化工_能耗指标趋势",
            "id": "化工_能耗指标趋势/日期",
            "tableTranName": "化工_能耗指标趋势",
            "fieldType": 48,
            "isEnable": true
        },
        "样式数据二/类目": {
            "fieldName": "类目",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "样式数据二",
            "id": "样式数据二/类目",
            "tableTranName": "样式数据二",
            "fieldType": 16,
            "isEnable": true
        },
        "银行_财务分析事实表/RAROC": {
            "fieldName": "RAROC",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/RAROC",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "推广渠道维度表/一级渠道名": {
            "fieldName": "一级渠道名",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "推广渠道维度表",
            "id": "推广渠道维度表/一级渠道名",
            "tableTranName": "推广渠道维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "地区号": {
            "fieldName": "地区号",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "业务流水表",
            "id": "业务流水表/地区号",
            "tableTranName": "业务流水表",
            "fieldType": 32,
            "isEnable": true
        },
        "月均销量": {
            "fieldName": "月均销量",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "医药_库存周转事实表",
            "id": "医药_库存周转事实表/月均销量",
            "tableTranName": "医药_库存周转事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "用户类型": {
            "fieldName": "用户类型",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "用户信息维度表",
            "id": "用户信息维度表/用户类型",
            "tableTranName": "用户信息维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "类型": {
            "fieldName": "类型",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "人员变动表",
            "id": "人员变动表/类型",
            "tableTranName": "人员变动表",
            "fieldType": 16,
            "isEnable": true
        },
        "营业类型": {
            "fieldName": "营业类型",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/营业类型",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 16,
            "isEnable": true
        },
        "迁入城市纬度": {
            "fieldName": "迁入城市纬度",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "北京春运迁徙数据",
            "id": "北京春运迁徙数据/迁入城市纬度",
            "tableTranName": "北京春运迁徙数据",
            "fieldType": 16,
            "isEnable": true
        },
        "浏览器": {
            "fieldName": "浏览器",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "浏览器占比变化",
            "id": "浏览器占比变化/浏览器",
            "tableTranName": "浏览器占比变化",
            "fieldType": 16,
            "isEnable": true
        },
        "访问阶段统计事实表/访问最后阶段": {
            "fieldName": "访问最后阶段",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "访问阶段统计事实表",
            "id": "访问阶段统计事实表/访问最后阶段",
            "tableTranName": "访问阶段统计事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "活动内容": {
            "fieldName": "活动内容",
            "fieldSize": 3000,
            "isUsable": true,
            "tableId": "销售事实表",
            "id": "销售事实表/活动内容",
            "tableTranName": "销售事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "订单/订单ID": {
            "fieldName": "订单ID",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "订单",
            "id": "订单/订单ID",
            "tableTranName": "订单",
            "fieldType": 32,
            "isEnable": true
        },
        "成本事实表/COSTDISPLAY": {
            "fieldName": "COSTDISPLAY",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/COSTDISPLAY",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "雇员ID": {
            "fieldName": "雇员ID",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "雇员",
            "id": "雇员/雇员ID",
            "tableTranName": "雇员",
            "fieldType": 32,
            "isEnable": true
        },
        "监测点名称": {
            "fieldName": "监测点名称",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "全国环境监测数据",
            "id": "全国环境监测数据/监测点名称",
            "tableTranName": "全国环境监测数据",
            "fieldType": 16,
            "isEnable": true
        },
        "ExcelView之客户跟踪表/客户ID": {
            "fieldName": "客户ID",
            "fieldSize": 64,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/客户ID",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 16,
            "isEnable": true
        },
        "迁出城市": {
            "fieldName": "迁出城市",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "北京春运迁徙数据",
            "id": "北京春运迁徙数据/迁出城市",
            "tableTranName": "北京春运迁徙数据",
            "fieldType": 16,
            "isEnable": true
        },
        "银行_产品维度表/PA产品名称": {
            "fieldName": "PA产品名称",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "银行_产品维度表",
            "id": "银行_产品维度表/PA产品名称",
            "tableTranName": "银行_产品维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "销售活动ID": {
            "fieldName": "销售活动ID",
            "fieldSize": 50,
            "isUsable": true,
            "tableId": "销售事实表",
            "id": "销售事实表/销售活动ID",
            "tableTranName": "销售事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "访问统计事实表/渠道ID": {
            "fieldName": "渠道ID",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "访问统计事实表",
            "id": "访问统计事实表/渠道ID",
            "tableTranName": "访问统计事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "成本事实表/UNITPRICEDISPLAY": {
            "fieldName": "UNITPRICEDISPLAY",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/UNITPRICEDISPLAY",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "渠道ID": {
            "fieldName": "渠道ID",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "访问统计事实表",
            "id": "访问统计事实表/渠道ID",
            "tableTranName": "访问统计事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "访问阶段统计事实表/访问ID": {
            "fieldName": "访问ID",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "访问阶段统计事实表",
            "id": "访问阶段统计事实表/访问ID",
            "tableTranName": "访问阶段统计事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "CONTRACTTYPENAME": {
            "fieldName": "CONTRACTTYPENAME",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "合同维度表",
            "id": "合同维度表/CONTRACTTYPENAME",
            "tableTranName": "合同维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "活动时间段": {
            "fieldName": "活动时间段",
            "fieldSize": 20,
            "isUsable": true,
            "tableId": "销售事实表",
            "id": "销售事实表/活动时间段",
            "tableTranName": "销售事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "十大热门旅游城市/排名": {
            "fieldName": "排名",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "十大热门旅游城市",
            "id": "十大热门旅游城市/排名",
            "tableTranName": "十大热门旅游城市",
            "fieldType": 32,
            "isEnable": true
        },
        "全国环境监测数据/PM值": {
            "fieldName": "PM值",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "全国环境监测数据",
            "id": "全国环境监测数据/PM值",
            "tableTranName": "全国环境监测数据",
            "fieldType": 32,
            "isEnable": true
        },
        "排名": {
            "fieldName": "排名",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "十大热门旅游城市",
            "id": "十大热门旅游城市/排名",
            "tableTranName": "十大热门旅游城市",
            "fieldType": 32,
            "isEnable": true
        },
        "是否结束": {
            "fieldName": "是否结束",
            "fieldSize": 20,
            "isUsable": true,
            "tableId": "销售事实表",
            "id": "销售事实表/是否结束",
            "tableTranName": "销售事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "是否校园": {
            "fieldName": "是否校园",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/是否校园",
            "tableTranName": "宽带业务",
            "fieldType": 16,
            "isEnable": true
        },
        "税后净利润_完全利润": {
            "fieldName": "税后净利润_完全利润",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/税后净利润_完全利润",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "PROJSHORTNAME": {
            "fieldName": "PROJSHORTNAME",
            "fieldSize": 40,
            "isUsable": true,
            "tableId": "项目维度表",
            "id": "项目维度表/PROJSHORTNAME",
            "tableTranName": "项目维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "项目维度表/PROJCODE": {
            "fieldName": "PROJCODE",
            "fieldSize": 100,
            "isUsable": true,
            "tableId": "项目维度表",
            "id": "项目维度表/PROJCODE",
            "tableTranName": "项目维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "产品维度表/PRODUCTGUID": {
            "fieldName": "PRODUCTGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "产品维度表",
            "id": "产品维度表/PRODUCTGUID",
            "tableTranName": "产品维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "公司名称": {
            "fieldName": "公司名称",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "人员变动表",
            "id": "人员变动表/公司名称",
            "tableTranName": "人员变动表",
            "fieldType": 16,
            "isEnable": true
        },
        "推广渠道维度表/渠道ID": {
            "fieldName": "渠道ID",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "推广渠道维度表",
            "id": "推广渠道维度表/渠道ID",
            "tableTranName": "推广渠道维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "城市地区维度表/AREA": {
            "fieldName": "AREA",
            "fieldSize": 30,
            "isUsable": true,
            "tableId": "城市地区维度表",
            "id": "城市地区维度表/AREA",
            "tableTranName": "城市地区维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "跳出次数": {
            "fieldName": "跳出次数",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "访问统计事实表",
            "id": "访问统计事实表/跳出次数",
            "tableTranName": "访问统计事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "订单/订购日期": {
            "fieldName": "订购日期",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "订单",
            "id": "订单/订购日期",
            "tableTranName": "订单",
            "fieldType": 16,
            "isEnable": true
        },
        "访问ID": {
            "fieldName": "访问ID",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "访问统计事实表",
            "id": "访问统计事实表/访问ID",
            "tableTranName": "访问统计事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "起租金额_万元": {
            "fieldName": "起租金额_万元",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "租赁_车辆租赁业务",
            "id": "租赁_车辆租赁业务/起租金额_万元",
            "tableTranName": "租赁_车辆租赁业务",
            "fieldType": 32,
            "isEnable": true
        },
        "回款事实表/AREAGUID": {
            "fieldName": "AREAGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "回款事实表",
            "id": "回款事实表/AREAGUID",
            "tableTranName": "回款事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "中止": {
            "fieldName": "中止",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商产品表",
            "id": "供应商产品表/中止",
            "tableTranName": "供应商产品表",
            "fieldType": 16,
            "isEnable": true
        },
        "等级_数值": {
            "fieldName": "等级_数值",
            "fieldSize": 100,
            "isUsable": true,
            "tableId": "化工_重大事件明细表",
            "id": "化工_重大事件明细表/等级_数值",
            "tableTranName": "化工_重大事件明细表",
            "fieldType": 32,
            "isEnable": true
        },
        "成本事实表/OCCUPYCOSTNEW": {
            "fieldName": "OCCUPYCOSTNEW",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/OCCUPYCOSTNEW",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "运货商": {
            "fieldName": "运货商",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "订单",
            "id": "订单/运货商",
            "tableTranName": "订单",
            "fieldType": 32,
            "isEnable": true
        },
        "合同维度表记录数": {
            "fieldName": "合同维度表记录数",
            "isUsable": true,
            "tableId": "合同维度表",
            "id": "合同维度表记录数",
            "fieldType": 64
        },
        "销售明细/销售额": {
            "fieldName": "销售额",
            "fieldSize": 10,
            "isUsable": true,
            "tableId": "销售明细",
            "id": "销售明细/销售额",
            "tableTranName": "销售明细",
            "fieldType": 32,
            "isEnable": true
        },
        "供应商产品表/订购量": {
            "fieldName": "订购量",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商产品表",
            "id": "供应商产品表/订购量",
            "tableTranName": "供应商产品表",
            "fieldType": 32,
            "isEnable": true
        },
        "柜员号": {
            "fieldName": "柜员号",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "业务流水表",
            "id": "业务流水表/柜员号",
            "tableTranName": "业务流水表",
            "fieldType": 16,
            "isEnable": true
        },
        "成本事实表/TOTALUNITCOSTDISPLAY": {
            "fieldName": "TOTALUNITCOSTDISPLAY",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/TOTALUNITCOSTDISPLAY",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "签约事实表记录数": {
            "fieldName": "签约事实表记录数",
            "isUsable": true,
            "tableId": "签约事实表",
            "id": "签约事实表记录数",
            "fieldType": 64
        },
        "西安兰特雨量监测数据/流量": {
            "fieldName": "流量",
            "fieldSize": 17,
            "isUsable": true,
            "tableId": "西安兰特雨量监测数据",
            "id": "西安兰特雨量监测数据/流量",
            "tableTranName": "西安兰特雨量监测数据",
            "fieldType": 32,
            "isEnable": true
        },
        "运货费": {
            "fieldName": "运货费",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "订单",
            "id": "订单/运货费",
            "tableTranName": "订单",
            "fieldType": 32,
            "isEnable": true
        },
        "分局": {
            "fieldName": "分局",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/分局",
            "tableTranName": "宽带业务",
            "fieldType": 16,
            "isEnable": true
        },
        "合同维度表/QSDATE": {
            "fieldName": "QSDATE",
            "fieldSize": 30,
            "isUsable": true,
            "tableId": "合同维度表",
            "id": "合同维度表/QSDATE",
            "tableTranName": "合同维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "化工_生成进度表展示/类别": {
            "fieldName": "类别",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "化工_生成进度表展示",
            "id": "化工_生成进度表展示/类别",
            "tableTranName": "化工_生成进度表展示",
            "fieldType": 16,
            "isEnable": true
        },
        "成本事实表/WYFTDCHZJCB": {
            "fieldName": "WYFTDCHZJCB",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/WYFTDCHZJCB",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "WYFTDCHZJCB": {
            "fieldName": "WYFTDCHZJCB",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/WYFTDCHZJCB",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "订单/货主国家": {
            "fieldName": "货主国家",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "订单",
            "id": "订单/货主国家",
            "tableTranName": "订单",
            "fieldType": 16,
            "isEnable": true
        },
        "PARENTPROJGUID": {
            "fieldName": "PARENTPROJGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "项目维度表",
            "id": "项目维度表/PARENTPROJGUID",
            "tableTranName": "项目维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "网格": {
            "fieldName": "网格",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/网格",
            "tableTranName": "宽带业务",
            "fieldType": 16,
            "isEnable": true
        },
        "成本事实表记录数": {
            "fieldName": "成本事实表记录数",
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表记录数",
            "fieldType": 64
        },
        "推广渠道维度表记录数": {
            "fieldName": "推广渠道维度表记录数",
            "isUsable": true,
            "tableId": "推广渠道维度表",
            "id": "推广渠道维度表记录数",
            "fieldType": 64
        },
        "回款事实表记录数": {
            "fieldName": "回款事实表记录数",
            "isUsable": true,
            "tableId": "回款事实表",
            "id": "回款事实表记录数",
            "fieldType": 64
        },
        "化工_重大事件明细表/等级_数值": {
            "fieldName": "等级_数值",
            "fieldSize": 100,
            "isUsable": true,
            "tableId": "化工_重大事件明细表",
            "id": "化工_重大事件明细表/等级_数值",
            "tableTranName": "化工_重大事件明细表",
            "fieldType": 32,
            "isEnable": true
        },
        "化工_重大事件明细表/等级": {
            "fieldName": "等级",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "化工_重大事件明细表",
            "id": "化工_重大事件明细表/等级",
            "tableTranName": "化工_重大事件明细表",
            "fieldType": 16,
            "isEnable": true
        },
        "AREA_NAME": {
            "fieldName": "AREA_NAME",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "区域维度表",
            "id": "区域维度表/AREA_NAME",
            "tableTranName": "区域维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "合同维度表/CJPRICE": {
            "fieldName": "CJPRICE",
            "fieldSize": 20,
            "isUsable": true,
            "tableId": "合同维度表",
            "id": "合同维度表/CJPRICE",
            "tableTranName": "合同维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "行业大类": {
            "fieldName": "行业大类",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "租赁_存量业务",
            "id": "租赁_存量业务/行业大类",
            "tableTranName": "租赁_存量业务",
            "fieldType": 16,
            "isEnable": true
        },
        "付款方式": {
            "fieldName": "付款方式",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/付款方式",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 16,
            "isEnable": true
        },
        "机构-层级1": {
            "fieldName": "机构-层级1",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "机构表",
            "id": "机构表/机构-层级1",
            "tableTranName": "机构表",
            "fieldType": 16,
            "isEnable": true
        },
        "机构-层级2": {
            "fieldName": "机构-层级2",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "机构表",
            "id": "机构表/机构-层级2",
            "tableTranName": "机构表",
            "fieldType": 16,
            "isEnable": true
        },
        "分公司维度表记录数": {
            "fieldName": "分公司维度表记录数",
            "isUsable": true,
            "tableId": "分公司维度表",
            "id": "分公司维度表记录数",
            "fieldType": 64
        },
        "机构-层级3": {
            "fieldName": "机构-层级3",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "机构表",
            "id": "机构表/机构-层级3",
            "tableTranName": "机构表",
            "fieldType": 16,
            "isEnable": true
        },
        "访问统计事实表/用户ID": {
            "fieldName": "用户ID",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "访问统计事实表",
            "id": "访问统计事实表/用户ID",
            "tableTranName": "访问统计事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "客户维度表记录数": {
            "fieldName": "客户维度表记录数",
            "isUsable": true,
            "tableId": "客户维度表",
            "id": "客户维度表记录数",
            "fieldType": 64
        },
        "推广渠道维度表/二级渠道名": {
            "fieldName": "二级渠道名",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "推广渠道维度表",
            "id": "推广渠道维度表/二级渠道名",
            "tableTranName": "推广渠道维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "销售明细记录数": {
            "fieldName": "销售明细记录数",
            "isUsable": true,
            "tableId": "销售明细",
            "id": "销售明细记录数",
            "fieldType": 64
        },
        "机构名称-层级5": {
            "fieldName": "机构名称-层级5",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "银行_机构维度表",
            "id": "银行_机构维度表/机构名称-层级5",
            "tableTranName": "银行_机构维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "合同回款事实/付款金额": {
            "fieldName": "付款金额",
            "fieldSize": 10,
            "isUsable": true,
            "tableId": "合同回款事实",
            "id": "合同回款事实/付款金额",
            "tableTranName": "合同回款事实",
            "fieldType": 32,
            "isEnable": true
        },
        "银行_业务维度表/业务代码": {
            "fieldName": "业务代码",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "银行_业务维度表",
            "id": "银行_业务维度表/业务代码",
            "tableTranName": "银行_业务维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "业务流水表记录数": {
            "fieldName": "业务流水表记录数",
            "isUsable": true,
            "tableId": "业务流水表",
            "id": "业务流水表记录数",
            "fieldType": 64
        },
        "业务代码": {
            "fieldName": "业务代码",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "银行_业务维度表",
            "id": "银行_业务维度表/业务代码",
            "tableTranName": "银行_业务维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "上级机构": {
            "fieldName": "上级机构",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "机构表",
            "id": "机构表/上级机构",
            "tableTranName": "机构表",
            "fieldType": 16,
            "isEnable": true
        },
        "类别_类别名称": {
            "fieldName": "类别_类别名称",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "产品",
            "id": "产品/类别_类别名称",
            "tableTranName": "产品",
            "fieldType": 16,
            "isEnable": true
        },
        "累计方式": {
            "fieldName": "累计方式",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "分界口货车出入情况",
            "id": "分界口货车出入情况/累计方式",
            "tableTranName": "分界口货车出入情况",
            "fieldType": 16,
            "isEnable": true
        },
        "供应商信息表/邮政编码": {
            "fieldName": "邮政编码",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商信息表",
            "id": "供应商信息表/邮政编码",
            "tableTranName": "供应商信息表",
            "fieldType": 16,
            "isEnable": true
        },
        "COSTRATE": {
            "fieldName": "COSTRATE",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/COSTRATE",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "化工_设备运行状况展示/系列": {
            "fieldName": "系列",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "化工_设备运行状况展示",
            "id": "化工_设备运行状况展示/系列",
            "tableTranName": "化工_设备运行状况展示",
            "fieldType": 16,
            "isEnable": true
        },
        "雇员/城市": {
            "fieldName": "城市",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "雇员",
            "id": "雇员/城市",
            "tableTranName": "雇员",
            "fieldType": 16,
            "isEnable": true
        },
        "十大热门出境游热门目的地国家记录数": {
            "fieldName": "十大热门出境游热门目的地国家记录数",
            "isUsable": true,
            "tableId": "十大热门出境游热门目的地国家",
            "id": "十大热门出境游热门目的地国家记录数",
            "fieldType": 64
        },
        "库存事实表/DDATE": {
            "fieldName": "DDATE",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "库存事实表",
            "id": "库存事实表/DDATE",
            "tableTranName": "库存事实表",
            "fieldType": 48,
            "isEnable": true
        },
        "出境方式占比/出境方式": {
            "fieldName": "出境方式",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "出境方式占比",
            "id": "出境方式占比/出境方式",
            "tableTranName": "出境方式占比",
            "fieldType": 16,
            "isEnable": true
        },
        "银行_财务分析事实表/当月发生": {
            "fieldName": "当月发生",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/当月发生",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "机构名称-层级3": {
            "fieldName": "机构名称-层级3",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "银行_机构维度表",
            "id": "银行_机构维度表/机构名称-层级3",
            "tableTranName": "银行_机构维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "样式数据三/COSX": {
            "fieldName": "COSX",
            "fieldSize": 17,
            "isUsable": true,
            "tableId": "样式数据三",
            "id": "样式数据三/COSX",
            "tableTranName": "样式数据三",
            "fieldType": 32,
            "isEnable": true
        },
        "机构名称-层级4": {
            "fieldName": "机构名称-层级4",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "银行_机构维度表",
            "id": "银行_机构维度表/机构名称-层级4",
            "tableTranName": "银行_机构维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "机构名称-层级1": {
            "fieldName": "机构名称-层级1",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "银行_机构维度表",
            "id": "银行_机构维度表/机构名称-层级1",
            "tableTranName": "银行_机构维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "机构名称-层级2": {
            "fieldName": "机构名称-层级2",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "银行_机构维度表",
            "id": "银行_机构维度表/机构名称-层级2",
            "tableTranName": "银行_机构维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "热门景区门票预定TOP20/热门景区": {
            "fieldName": "热门景区",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "热门景区门票预定TOP20",
            "id": "热门景区门票预定TOP20/热门景区",
            "tableTranName": "热门景区门票预定TOP20",
            "fieldType": 16,
            "isEnable": true
        },
        "西安兰特雨量监测数据/监测时间": {
            "fieldName": "监测时间",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "西安兰特雨量监测数据",
            "id": "西安兰特雨量监测数据/监测时间",
            "tableTranName": "西安兰特雨量监测数据",
            "fieldType": 48,
            "isEnable": true
        },
        "ExcelView之客户跟踪表/其他投资事业": {
            "fieldName": "其他投资事业",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/其他投资事业",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 16,
            "isEnable": true
        },
        "雇员/雇员ID": {
            "fieldName": "雇员ID",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "雇员",
            "id": "雇员/雇员ID",
            "tableTranName": "雇员",
            "fieldType": 32,
            "isEnable": true
        },
        "主要来往银行": {
            "fieldName": "主要来往银行",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/主要来往银行",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 16,
            "isEnable": true
        },
        "宽带业务/接入方式": {
            "fieldName": "接入方式",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/接入方式",
            "tableTranName": "宽带业务",
            "fieldType": 16,
            "isEnable": true
        },
        "访问统计事实表/浏览量": {
            "fieldName": "浏览量",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "访问统计事实表",
            "id": "访问统计事实表/浏览量",
            "tableTranName": "访问统计事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "品牌维度记录数": {
            "fieldName": "品牌维度记录数",
            "isUsable": true,
            "tableId": "品牌维度",
            "id": "品牌维度记录数",
            "fieldType": 64
        },
        "银行_财务分析事实表/资本成本": {
            "fieldName": "资本成本",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/资本成本",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "出游年龄占比/占比": {
            "fieldName": "占比",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "出游年龄占比",
            "id": "出游年龄占比/占比",
            "tableTranName": "出游年龄占比",
            "fieldType": 32,
            "isEnable": true
        },
        "合同维度表/ROOMTOTAL": {
            "fieldName": "ROOMTOTAL",
            "fieldSize": 20,
            "isUsable": true,
            "tableId": "合同维度表",
            "id": "合同维度表/ROOMTOTAL",
            "tableTranName": "合同维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "宽带业务/是否酒店": {
            "fieldName": "是否酒店",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/是否酒店",
            "tableTranName": "宽带业务",
            "fieldType": 16,
            "isEnable": true
        },
        "用户信息维度表记录数": {
            "fieldName": "用户信息维度表记录数",
            "isUsable": true,
            "tableId": "用户信息维度表",
            "id": "用户信息维度表记录数",
            "fieldType": 64
        },
        "销售明细/楼层": {
            "fieldName": "楼层",
            "fieldSize": 10,
            "isUsable": true,
            "tableId": "销售明细",
            "id": "销售明细/楼层",
            "tableTranName": "销售明细",
            "fieldType": 32,
            "isEnable": true
        },
        "宽带业务记录数": {
            "fieldName": "宽带业务记录数",
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务记录数",
            "fieldType": 64
        },
        "十大热门旅游城市记录数": {
            "fieldName": "十大热门旅游城市记录数",
            "isUsable": true,
            "tableId": "十大热门旅游城市",
            "id": "十大热门旅游城市记录数",
            "fieldType": 64
        },
        "ExcelView之客户跟踪表/最近与本公司来往重要记录": {
            "fieldName": "最近与本公司来往重要记录",
            "fieldSize": 10,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/最近与本公司来往重要记录",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 32,
            "isEnable": true
        },
        "产品名称维度/产品名称": {
            "fieldName": "产品名称",
            "fieldSize": 200,
            "isUsable": true,
            "tableId": "产品名称维度",
            "id": "产品名称维度/产品名称",
            "tableTranName": "产品名称维度",
            "fieldType": 16,
            "isEnable": true
        },
        "账号": {
            "fieldName": "账号",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "用户登录权限表",
            "id": "用户登录权限表/账号",
            "tableTranName": "用户登录权限表",
            "fieldType": 16,
            "isEnable": true
        },
        "外部利息支出": {
            "fieldName": "外部利息支出",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/外部利息支出",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "十大热门出境游热门目的地国家/排名": {
            "fieldName": "排名",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "十大热门出境游热门目的地国家",
            "id": "十大热门出境游热门目的地国家/排名",
            "tableTranName": "十大热门出境游热门目的地国家",
            "fieldType": 32,
            "isEnable": true
        },
        "客户维度表/客户状态": {
            "fieldName": "客户状态",
            "fieldSize": 64,
            "isUsable": true,
            "tableId": "客户维度表",
            "id": "客户维度表/客户状态",
            "tableTranName": "客户维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "样式数据二记录数": {
            "fieldName": "样式数据二记录数",
            "isUsable": true,
            "tableId": "样式数据二",
            "id": "样式数据二记录数",
            "fieldType": 64
        },
        "销售明细/毛利": {
            "fieldName": "毛利",
            "fieldSize": 10,
            "isUsable": true,
            "tableId": "销售明细",
            "id": "销售明细/毛利",
            "tableTranName": "销售明细",
            "fieldType": 32,
            "isEnable": true
        },
        "访问统计事实表/统计日期": {
            "fieldName": "统计日期",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "访问统计事实表",
            "id": "访问统计事实表/统计日期",
            "tableTranName": "访问统计事实表",
            "fieldType": 48,
            "isEnable": true
        },
        "成本事实表/CODIFF": {
            "fieldName": "CODIFF",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/CODIFF",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "再订购量": {
            "fieldName": "再订购量",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商产品表",
            "id": "供应商产品表/再订购量",
            "tableTranName": "供应商产品表",
            "fieldType": 32,
            "isEnable": true
        },
        "化工_库存展示记录数": {
            "fieldName": "化工_库存展示记录数",
            "isUsable": true,
            "tableId": "化工_库存展示",
            "id": "化工_库存展示记录数",
            "fieldType": 64
        },
        "DJPRICE": {
            "fieldName": "DJPRICE",
            "fieldSize": 20,
            "isUsable": true,
            "tableId": "房间维度表",
            "id": "房间维度表/DJPRICE",
            "tableTranName": "房间维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "订单/客户ID": {
            "fieldName": "客户ID",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "订单",
            "id": "订单/客户ID",
            "tableTranName": "订单",
            "fieldType": 16,
            "isEnable": true
        },
        "签约事实表/TOTAL": {
            "fieldName": "TOTAL",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "签约事实表",
            "id": "签约事实表/TOTAL",
            "tableTranName": "签约事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "南京苏果营业数据/编号": {
            "fieldName": "编号",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "南京苏果营业数据",
            "id": "南京苏果营业数据/编号",
            "tableTranName": "南京苏果营业数据",
            "fieldType": 16,
            "isEnable": true
        },
        "合同事实表记录数": {
            "fieldName": "合同事实表记录数",
            "isUsable": true,
            "tableId": "合同事实表",
            "id": "合同事实表记录数",
            "fieldType": 64
        },
        "货主地区": {
            "fieldName": "货主地区",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "订单",
            "id": "订单/货主地区",
            "tableTranName": "订单",
            "fieldType": 16,
            "isEnable": true
        },
        "医药_库存周转事实表/产品编码": {
            "fieldName": "产品编码",
            "fieldSize": 64,
            "isUsable": true,
            "tableId": "医药_库存周转事实表",
            "id": "医药_库存周转事实表/产品编码",
            "tableTranName": "医药_库存周转事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "付款金额": {
            "fieldName": "付款金额",
            "fieldSize": 10,
            "isUsable": true,
            "tableId": "合同回款事实",
            "id": "合同回款事实/付款金额",
            "tableTranName": "合同回款事实",
            "fieldType": 32,
            "isEnable": true
        },
        "变动原因": {
            "fieldName": "变动原因",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "人员变动表",
            "id": "人员变动表/变动原因",
            "tableTranName": "人员变动表",
            "fieldType": 16,
            "isEnable": true
        },
        "记录人": {
            "fieldName": "记录人",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "合同回款事实",
            "id": "合同回款事实/记录人",
            "tableTranName": "合同回款事实",
            "fieldType": 16,
            "isEnable": true
        },
        "产品/类别_类别名称": {
            "fieldName": "类别_类别名称",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "产品",
            "id": "产品/类别_类别名称",
            "tableTranName": "产品",
            "fieldType": 16,
            "isEnable": true
        },
        "人次": {
            "fieldName": "人次",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "流向",
            "id": "流向/人次",
            "tableTranName": "流向",
            "fieldType": 32,
            "isEnable": true
        },
        "供应商信息表/地区": {
            "fieldName": "地区",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商信息表",
            "id": "供应商信息表/地区",
            "tableTranName": "供应商信息表",
            "fieldType": 16,
            "isEnable": true
        },
        "合同维度表/PRICE": {
            "fieldName": "PRICE",
            "fieldSize": 20,
            "isUsable": true,
            "tableId": "合同维度表",
            "id": "合同维度表/PRICE",
            "tableTranName": "合同维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "成立日期": {
            "fieldName": "成立日期",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/成立日期",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 48,
            "isEnable": true
        },
        "SALERATE": {
            "fieldName": "SALERATE",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/SALERATE",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "外部利息收入": {
            "fieldName": "外部利息收入",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/外部利息收入",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "化工_设备运行状况展示/设备": {
            "fieldName": "设备",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "化工_设备运行状况展示",
            "id": "化工_设备运行状况展示/设备",
            "tableTranName": "化工_设备运行状况展示",
            "fieldType": 16,
            "isEnable": true
        },
        "北京春运迁徙数据/迁出城市经度": {
            "fieldName": "迁出城市经度",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "北京春运迁徙数据",
            "id": "北京春运迁徙数据/迁出城市经度",
            "tableTranName": "北京春运迁徙数据",
            "fieldType": 16,
            "isEnable": true
        },
        "客户维度表/客户来源": {
            "fieldName": "客户来源",
            "fieldSize": 100,
            "isUsable": true,
            "tableId": "客户维度表",
            "id": "客户维度表/客户来源",
            "tableTranName": "客户维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "SALES_PARENT": {
            "fieldName": "SALES_PARENT",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "销售员维度表",
            "id": "销售员维度表/SALES_PARENT",
            "tableTranName": "销售员维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "供应商产品表/单价": {
            "fieldName": "单价",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商产品表",
            "id": "供应商产品表/单价",
            "tableTranName": "供应商产品表",
            "fieldType": 32,
            "isEnable": true
        },
        "用户信息维度表/注册地区ID": {
            "fieldName": "注册地区ID",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "用户信息维度表",
            "id": "用户信息维度表/注册地区ID",
            "tableTranName": "用户信息维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "订单明细/供应商id": {
            "fieldName": "供应商id",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "订单明细",
            "id": "订单明细/供应商id",
            "tableTranName": "订单明细",
            "fieldType": 32,
            "isEnable": true
        },
        "收款记录": {
            "fieldName": "收款记录",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/收款记录",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 16,
            "isEnable": true
        },
        "AREAGUID": {
            "fieldName": "AREAGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "回款事实表",
            "id": "回款事实表/AREAGUID",
            "tableTranName": "回款事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "分界口货车出入情况/车型": {
            "fieldName": "车型",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "分界口货车出入情况",
            "id": "分界口货车出入情况/车型",
            "tableTranName": "分界口货车出入情况",
            "fieldType": 16,
            "isEnable": true
        },
        "会员人数": {
            "fieldName": "会员人数",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "南京苏果营业数据",
            "id": "南京苏果营业数据/会员人数",
            "tableTranName": "南京苏果营业数据",
            "fieldType": 32,
            "isEnable": true
        },
        "租赁_存量业务记录数": {
            "fieldName": "租赁_存量业务记录数",
            "isUsable": true,
            "tableId": "租赁_存量业务",
            "id": "租赁_存量业务记录数",
            "fieldType": 64
        },
        "供应商信息表/联系人职务": {
            "fieldName": "联系人职务",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商信息表",
            "id": "供应商信息表/联系人职务",
            "tableTranName": "供应商信息表",
            "fieldType": 16,
            "isEnable": true
        },
        "职务": {
            "fieldName": "职务",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "雇员",
            "id": "雇员/职务",
            "tableTranName": "雇员",
            "fieldType": 16,
            "isEnable": true
        },
        "所属办事处": {
            "fieldName": "所属办事处",
            "fieldSize": 200,
            "isUsable": true,
            "tableId": "分公司维度表",
            "id": "分公司维度表/所属办事处",
            "tableTranName": "分公司维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "用户登录权限表/密码": {
            "fieldName": "密码",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "用户登录权限表",
            "id": "用户登录权限表/密码",
            "tableTranName": "用户登录权限表",
            "fieldType": 16,
            "isEnable": true
        },
        "是否已经交货": {
            "fieldName": "是否已经交货",
            "fieldSize": 20,
            "isUsable": true,
            "tableId": "合同事实表",
            "id": "合同事实表/是否已经交货",
            "tableTranName": "合同事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "样式数据一/X": {
            "fieldName": "X",
            "fieldSize": 17,
            "isUsable": true,
            "tableId": "样式数据一",
            "id": "样式数据一/X",
            "tableTranName": "样式数据一",
            "fieldType": 32,
            "isEnable": true
        },
        "医药_库存周转事实表记录数": {
            "fieldName": "医药_库存周转事实表记录数",
            "isUsable": true,
            "tableId": "医药_库存周转事实表",
            "id": "医药_库存周转事实表记录数",
            "fieldType": 64
        },
        "类别ID": {
            "fieldName": "类别ID",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商产品表",
            "id": "供应商产品表/类别ID",
            "tableTranName": "供应商产品表",
            "fieldType": 32,
            "isEnable": true
        },
        "产品类型": {
            "fieldName": "产品类型",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/产品类型",
            "tableTranName": "宽带业务",
            "fieldType": 16,
            "isEnable": true
        },
        "销售事实表/销售活动ID": {
            "fieldName": "销售活动ID",
            "fieldSize": 50,
            "isUsable": true,
            "tableId": "销售事实表",
            "id": "销售事实表/销售活动ID",
            "tableTranName": "销售事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "币种": {
            "fieldName": "币种",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/币种",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "化工_产品收入率趋势记录数": {
            "fieldName": "化工_产品收入率趋势记录数",
            "isUsable": true,
            "tableId": "化工_产品收入率趋势",
            "id": "化工_产品收入率趋势记录数",
            "fieldType": 64
        },
        "发货日期": {
            "fieldName": "发货日期",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "订单",
            "id": "订单/发货日期",
            "tableTranName": "订单",
            "fieldType": 16,
            "isEnable": true
        },
        "区域": {
            "fieldName": "区域",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "租赁_车辆租赁业务",
            "id": "租赁_车辆租赁业务/区域",
            "tableTranName": "租赁_车辆租赁业务",
            "fieldType": 16,
            "isEnable": true
        },
        "房间维度表/PRICE": {
            "fieldName": "PRICE",
            "fieldSize": 20,
            "isUsable": true,
            "tableId": "房间维度表",
            "id": "房间维度表/PRICE",
            "tableTranName": "房间维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "传真": {
            "fieldName": "传真",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商信息表",
            "id": "供应商信息表/传真",
            "tableTranName": "供应商信息表",
            "fieldType": 16,
            "isEnable": true
        },
        "成本事实表/OCCUPYAREA": {
            "fieldName": "OCCUPYAREA",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/OCCUPYAREA",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "用户信息维度表/用户类型": {
            "fieldName": "用户类型",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "用户信息维度表",
            "id": "用户信息维度表/用户类型",
            "tableTranName": "用户信息维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "房间维度表/QFXFTYPE": {
            "fieldName": "QFXFTYPE",
            "fieldSize": 25,
            "isUsable": true,
            "tableId": "房间维度表",
            "id": "房间维度表/QFXFTYPE",
            "tableTranName": "房间维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "办事处纬度": {
            "fieldName": "办事处纬度",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "分公司维度表",
            "id": "分公司维度表/办事处纬度",
            "tableTranName": "分公司维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "文化古镇": {
            "fieldName": "文化古镇",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "十大文化古镇",
            "id": "十大文化古镇/文化古镇",
            "tableTranName": "十大文化古镇",
            "fieldType": 16,
            "isEnable": true
        },
        "合同维度表/CONTRACTTYPENAME": {
            "fieldName": "CONTRACTTYPENAME",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "合同维度表",
            "id": "合同维度表/CONTRACTTYPENAME",
            "tableTranName": "合同维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "银行_财务分析事实表/当前余额": {
            "fieldName": "当前余额",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/当前余额",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "浏览器占比变化/浏览器": {
            "fieldName": "浏览器",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "浏览器占比变化",
            "id": "浏览器占比变化/浏览器",
            "tableTranName": "浏览器占比变化",
            "fieldType": 16,
            "isEnable": true
        },
        "热门景区门票预定TOP20/值": {
            "fieldName": "值",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "热门景区门票预定TOP20",
            "id": "热门景区门票预定TOP20/值",
            "tableTranName": "热门景区门票预定TOP20",
            "fieldType": 32,
            "isEnable": true
        },
        "房间维度表/FLOOR": {
            "fieldName": "FLOOR",
            "fieldSize": 20,
            "isUsable": true,
            "tableId": "房间维度表",
            "id": "房间维度表/FLOOR",
            "tableTranName": "房间维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "签约事实表/BUGUID": {
            "fieldName": "BUGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "签约事实表",
            "id": "签约事实表/BUGUID",
            "tableTranName": "签约事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "JZTZZZCB": {
            "fieldName": "JZTZZZCB",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/JZTZZZCB",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "销售事实表/客户ID": {
            "fieldName": "客户ID",
            "fieldSize": 50,
            "isUsable": true,
            "tableId": "销售事实表",
            "id": "销售事实表/客户ID",
            "tableTranName": "销售事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "地区维度表记录数": {
            "fieldName": "地区维度表记录数",
            "isUsable": true,
            "tableId": "地区维度表",
            "id": "地区维度表记录数",
            "fieldType": 64
        },
        "旅游人次": {
            "fieldName": "旅游人次",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "十大热门旅游城市",
            "id": "十大热门旅游城市/旅游人次",
            "tableTranName": "十大热门旅游城市",
            "fieldType": 32,
            "isEnable": true
        },
        "租赁_存量业务/起租金额": {
            "fieldName": "起租金额",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "租赁_存量业务",
            "id": "租赁_存量业务/起租金额",
            "tableTranName": "租赁_存量业务",
            "fieldType": 32,
            "isEnable": true
        },
        "十大热门旅游城市/热门旅游城市": {
            "fieldName": "热门旅游城市",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "十大热门旅游城市",
            "id": "十大热门旅游城市/热门旅游城市",
            "tableTranName": "十大热门旅游城市",
            "fieldType": 16,
            "isEnable": true
        },
        "销售额": {
            "fieldName": "销售额",
            "fieldSize": 10,
            "isUsable": true,
            "tableId": "销售明细",
            "id": "销售明细/销售额",
            "tableTranName": "销售明细",
            "fieldType": 32,
            "isEnable": true
        },
        "分界口货车出入情况/ID": {
            "fieldName": "ID",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "分界口货车出入情况",
            "id": "分界口货车出入情况/ID",
            "tableTranName": "分界口货车出入情况",
            "fieldType": 32,
            "isEnable": true
        },
        "货主国家": {
            "fieldName": "货主国家",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "订单",
            "id": "订单/货主国家",
            "tableTranName": "订单",
            "fieldType": 16,
            "isEnable": true
        },
        "访问统计事实表/地区ID": {
            "fieldName": "地区ID",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "访问统计事实表",
            "id": "访问统计事实表/地区ID",
            "tableTranName": "访问统计事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "人员编码": {
            "fieldName": "人员编码",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "人员变动表",
            "id": "人员变动表/人员编码",
            "tableTranName": "人员变动表",
            "fieldType": 16,
            "isEnable": true
        },
        "全国环境监测数据/监测点名称": {
            "fieldName": "监测点名称",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "全国环境监测数据",
            "id": "全国环境监测数据/监测点名称",
            "tableTranName": "全国环境监测数据",
            "fieldType": 16,
            "isEnable": true
        },
        "门店维度/店风格": {
            "fieldName": "店风格",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "门店维度",
            "id": "门店维度/店风格",
            "tableTranName": "门店维度",
            "fieldType": 16,
            "isEnable": true
        },
        "出境方式占比/占比": {
            "fieldName": "占比",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "出境方式占比",
            "id": "出境方式占比/占比",
            "tableTranName": "出境方式占比",
            "fieldType": 32,
            "isEnable": true
        },
        "北京春运迁徙数据/迁入城市纬度": {
            "fieldName": "迁入城市纬度",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "北京春运迁徙数据",
            "id": "北京春运迁徙数据/迁入城市纬度",
            "tableTranName": "北京春运迁徙数据",
            "fieldType": 16,
            "isEnable": true
        },
        "人员变动表/类型": {
            "fieldName": "类型",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "人员变动表",
            "id": "人员变动表/类型",
            "tableTranName": "人员变动表",
            "fieldType": 16,
            "isEnable": true
        },
        "雇员2/雇员ID": {
            "fieldName": "雇员ID",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "雇员2",
            "id": "雇员2/雇员ID",
            "tableTranName": "雇员2",
            "fieldType": 32,
            "isEnable": true
        },
        "用户登录权限表/账号": {
            "fieldName": "账号",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "用户登录权限表",
            "id": "用户登录权限表/账号",
            "tableTranName": "用户登录权限表",
            "fieldType": 16,
            "isEnable": true
        },
        "ITEMTYPE": {
            "fieldName": "ITEMTYPE",
            "fieldSize": 20,
            "isUsable": true,
            "tableId": "回款维度表",
            "id": "回款维度表/ITEMTYPE",
            "tableTranName": "回款维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "BLDAREA": {
            "fieldName": "BLDAREA",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "签约事实表",
            "id": "签约事实表/BLDAREA",
            "tableTranName": "签约事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "TOTALUNITCOSTNEW": {
            "fieldName": "TOTALUNITCOSTNEW",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/TOTALUNITCOSTNEW",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "样式数据一/SINX": {
            "fieldName": "SINX",
            "fieldSize": 17,
            "isUsable": true,
            "tableId": "样式数据一",
            "id": "样式数据一/SINX",
            "tableTranName": "样式数据一",
            "fieldType": 32,
            "isEnable": true
        },
        "机构号": {
            "fieldName": "机构号",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "业务流水表",
            "id": "业务流水表/机构号",
            "tableTranName": "业务流水表",
            "fieldType": 16,
            "isEnable": true
        },
        "订单记录数": {
            "fieldName": "订单记录数",
            "isUsable": true,
            "tableId": "订单",
            "id": "订单记录数",
            "fieldType": 64
        },
        "银行_机构维度表/机构名称": {
            "fieldName": "机构名称",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "银行_机构维度表",
            "id": "银行_机构维度表/机构名称",
            "tableTranName": "银行_机构维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "种类": {
            "fieldName": "种类",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/种类",
            "tableTranName": "宽带业务",
            "fieldType": 16,
            "isEnable": true
        },
        "雇员2/货主地区": {
            "fieldName": "货主地区",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "雇员2",
            "id": "雇员2/货主地区",
            "tableTranName": "雇员2",
            "fieldType": 16,
            "isEnable": true
        },
        "ExcelView之客户跟踪表/资本额": {
            "fieldName": "资本额",
            "fieldSize": 17,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/资本额",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 32,
            "isEnable": true
        },
        "SSX_NAME": {
            "fieldName": "SSX_NAME",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "地区维度表",
            "id": "地区维度表/SSX_NAME",
            "tableTranName": "地区维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "ID_NUMBER": {
            "fieldName": "ID_NUMBER",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/ID_NUMBER",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "项目维度表记录数": {
            "fieldName": "项目维度表记录数",
            "isUsable": true,
            "tableId": "项目维度表",
            "id": "项目维度表记录数",
            "fieldType": 64
        },
        "门店维度/所属大区": {
            "fieldName": "所属大区",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "门店维度",
            "id": "门店维度/所属大区",
            "tableTranName": "门店维度",
            "fieldType": 16,
            "isEnable": true
        },
        "交易笔数": {
            "fieldName": "交易笔数",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/交易笔数",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "ExcelView之客户跟踪表/付款方式": {
            "fieldName": "付款方式",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/付款方式",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 16,
            "isEnable": true
        },
        "PROJNAME": {
            "fieldName": "PROJNAME",
            "fieldSize": 400,
            "isUsable": true,
            "tableId": "项目维度表",
            "id": "项目维度表/PROJNAME",
            "tableTranName": "项目维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "PA产品名称": {
            "fieldName": "PA产品名称",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "银行_产品维度表",
            "id": "银行_产品维度表/PA产品名称",
            "tableTranName": "银行_产品维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "ROOMINFO": {
            "fieldName": "ROOMINFO",
            "fieldSize": 100,
            "isUsable": true,
            "tableId": "房间维度表",
            "id": "房间维度表/ROOMINFO",
            "tableTranName": "房间维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "国家": {
            "fieldName": "国家",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商信息表",
            "id": "供应商信息表/国家",
            "tableTranName": "供应商信息表",
            "fieldType": 16,
            "isEnable": true
        },
        "订单明细/产品ID": {
            "fieldName": "产品ID",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "订单明细",
            "id": "订单明细/产品ID",
            "tableTranName": "订单明细",
            "fieldType": 32,
            "isEnable": true
        },
        "省区": {
            "fieldName": "省区",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "医药_客户地区维度",
            "id": "医药_客户地区维度/省区",
            "tableTranName": "医药_客户地区维度",
            "fieldType": 16,
            "isEnable": true
        },
        "经济资本": {
            "fieldName": "经济资本",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/经济资本",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "用户信息维度表/用户ID": {
            "fieldName": "用户ID",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "用户信息维度表",
            "id": "用户信息维度表/用户ID",
            "tableTranName": "用户信息维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "ExcelView之客户跟踪表/与本公司来往日期": {
            "fieldName": "与本公司来往日期",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/与本公司来往日期",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 48,
            "isEnable": true
        },
        "医药_产品维度表/产品名称": {
            "fieldName": "产品名称",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "医药_产品维度表",
            "id": "医药_产品维度表/产品名称",
            "tableTranName": "医药_产品维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "接入方式": {
            "fieldName": "接入方式",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/接入方式",
            "tableTranName": "宽带业务",
            "fieldType": 16,
            "isEnable": true
        },
        "雇员/性别": {
            "fieldName": "性别",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "雇员",
            "id": "雇员/性别",
            "tableTranName": "雇员",
            "fieldType": 16,
            "isEnable": true
        },
        "银行_财务分析事实表/外部利息净收入": {
            "fieldName": "外部利息净收入",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/外部利息净收入",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "等待时间": {
            "fieldName": "等待时间",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "业务流水表",
            "id": "业务流水表/等待时间",
            "tableTranName": "业务流水表",
            "fieldType": 32,
            "isEnable": true
        },
        "业务流水表/交易名称": {
            "fieldName": "交易名称",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "业务流水表",
            "id": "业务流水表/交易名称",
            "tableTranName": "业务流水表",
            "fieldType": 16,
            "isEnable": true
        },
        "房间维度表记录数": {
            "fieldName": "房间维度表记录数",
            "isUsable": true,
            "tableId": "房间维度表",
            "id": "房间维度表记录数",
            "fieldType": 64
        },
        "订单/雇员ID": {
            "fieldName": "雇员ID",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "订单",
            "id": "订单/雇员ID",
            "tableTranName": "订单",
            "fieldType": 32,
            "isEnable": true
        },
        "北京春运迁徙数据/迁徙人数": {
            "fieldName": "迁徙人数",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "北京春运迁徙数据",
            "id": "北京春运迁徙数据/迁徙人数",
            "tableTranName": "北京春运迁徙数据",
            "fieldType": 32,
            "isEnable": true
        },
        "银行_产品维度表记录数": {
            "fieldName": "银行_产品维度表记录数",
            "isUsable": true,
            "tableId": "银行_产品维度表",
            "id": "银行_产品维度表记录数",
            "fieldType": 64
        },
        "医药_客户地区维度/省区": {
            "fieldName": "省区",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "医药_客户地区维度",
            "id": "医药_客户地区维度/省区",
            "tableTranName": "医药_客户地区维度",
            "fieldType": 16,
            "isEnable": true
        },
        "等级": {
            "fieldName": "等级",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "化工_重大事件明细表",
            "id": "化工_重大事件明细表/等级",
            "tableTranName": "化工_重大事件明细表",
            "fieldType": 16,
            "isEnable": true
        },
        "系列": {
            "fieldName": "系列",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "化工_设备运行状况展示",
            "id": "化工_设备运行状况展示/系列",
            "tableTranName": "化工_设备运行状况展示",
            "fieldType": 16,
            "isEnable": true
        },
        "成本事实表/BUILDRATE": {
            "fieldName": "BUILDRATE",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/BUILDRATE",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "合同维度表/CONTRACTGUID": {
            "fieldName": "CONTRACTGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "合同维度表",
            "id": "合同维度表/CONTRACTGUID",
            "tableTranName": "合同维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "房间维度表/ROOMINFO": {
            "fieldName": "ROOMINFO",
            "fieldSize": 100,
            "isUsable": true,
            "tableId": "房间维度表",
            "id": "房间维度表/ROOMINFO",
            "tableTranName": "房间维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "流向/出发地": {
            "fieldName": "出发地",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "流向",
            "id": "流向/出发地",
            "tableTranName": "流向",
            "fieldType": 16,
            "isEnable": true
        },
        "人员变动表/人员姓名": {
            "fieldName": "人员姓名",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "人员变动表",
            "id": "人员变动表/人员姓名",
            "tableTranName": "人员变动表",
            "fieldType": 16,
            "isEnable": true
        },
        "占比": {
            "fieldName": "占比",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "出境方式占比",
            "id": "出境方式占比/占比",
            "tableTranName": "出境方式占比",
            "fieldType": 32,
            "isEnable": true
        },
        "房间维度表/WEST": {
            "fieldName": "WEST",
            "fieldSize": 20,
            "isUsable": true,
            "tableId": "房间维度表",
            "id": "房间维度表/WEST",
            "tableTranName": "房间维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "供应商信息表/联系人姓名": {
            "fieldName": "联系人姓名",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商信息表",
            "id": "供应商信息表/联系人姓名",
            "tableTranName": "供应商信息表",
            "fieldType": 16,
            "isEnable": true
        },
        "ExcelView之客户跟踪表/电话": {
            "fieldName": "电话",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/电话",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 16,
            "isEnable": true
        },
        "订单/货主地区": {
            "fieldName": "货主地区",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "订单",
            "id": "订单/货主地区",
            "tableTranName": "订单",
            "fieldType": 16,
            "isEnable": true
        },
        "化工_原料成本趋势展示记录数": {
            "fieldName": "化工_原料成本趋势展示记录数",
            "isUsable": true,
            "tableId": "化工_原料成本趋势展示",
            "id": "化工_原料成本趋势展示记录数",
            "fieldType": 64
        },
        "主要业务往来": {
            "fieldName": "主要业务往来",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/主要业务往来",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 16,
            "isEnable": true
        },
        "姓名": {
            "fieldName": "姓名",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "雇员",
            "id": "雇员/姓名",
            "tableTranName": "雇员",
            "fieldType": 16,
            "isEnable": true
        },
        "销售明细/销售日期": {
            "fieldName": "销售日期",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "销售明细",
            "id": "销售明细/销售日期",
            "tableTranName": "销售明细",
            "fieldType": 48,
            "isEnable": true
        },
        "签约事实表/ROOMTOTAL": {
            "fieldName": "ROOMTOTAL",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "签约事实表",
            "id": "签约事实表/ROOMTOTAL",
            "tableTranName": "签约事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "银行_财务分析事实表/税后净利润_完全利润": {
            "fieldName": "税后净利润_完全利润",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/税后净利润_完全利润",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "化工_原料成本趋势展示/日期": {
            "fieldName": "日期",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "化工_原料成本趋势展示",
            "id": "化工_原料成本趋势展示/日期",
            "tableTranName": "化工_原料成本趋势展示",
            "fieldType": 48,
            "isEnable": true
        },
        "供应商产品表/再订购量": {
            "fieldName": "再订购量",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商产品表",
            "id": "供应商产品表/再订购量",
            "tableTranName": "供应商产品表",
            "fieldType": 32,
            "isEnable": true
        },
        "业务流水表/账户名称": {
            "fieldName": "账户名称",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "业务流水表",
            "id": "业务流水表/账户名称",
            "tableTranName": "业务流水表",
            "fieldType": 16,
            "isEnable": true
        },
        "迁出城市纬度": {
            "fieldName": "迁出城市纬度",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "北京春运迁徙数据",
            "id": "北京春运迁徙数据/迁出城市纬度",
            "tableTranName": "北京春运迁徙数据",
            "fieldType": 16,
            "isEnable": true
        },
        "流量": {
            "fieldName": "流量",
            "fieldSize": 17,
            "isUsable": true,
            "tableId": "西安兰特雨量监测数据",
            "id": "西安兰特雨量监测数据/流量",
            "tableTranName": "西安兰特雨量监测数据",
            "fieldType": 32,
            "isEnable": true
        },
        "客户维度表/客户ID": {
            "fieldName": "客户ID",
            "fieldSize": 64,
            "isUsable": true,
            "tableId": "客户维度表",
            "id": "客户维度表/客户ID",
            "tableTranName": "客户维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "项目维度表/PARENTPROJGUID": {
            "fieldName": "PARENTPROJGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "项目维度表",
            "id": "项目维度表/PARENTPROJGUID",
            "tableTranName": "项目维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "合同事实表/购买数量": {
            "fieldName": "购买数量",
            "fieldSize": 10,
            "isUsable": true,
            "tableId": "合同事实表",
            "id": "合同事实表/购买数量",
            "tableTranName": "合同事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "银行_财务分析事实表/PA产品号": {
            "fieldName": "PA产品号",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/PA产品号",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "访问阶段统计事实表/总停留时间": {
            "fieldName": "总停留时间",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "访问阶段统计事实表",
            "id": "访问阶段统计事实表/总停留时间",
            "tableTranName": "访问阶段统计事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "回款维度表/GETDATE": {
            "fieldName": "GETDATE",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "回款维度表",
            "id": "回款维度表/GETDATE",
            "tableTranName": "回款维度表",
            "fieldType": 48,
            "isEnable": true
        },
        "PRODUCTNAME": {
            "fieldName": "PRODUCTNAME",
            "fieldSize": 100,
            "isUsable": true,
            "tableId": "产品维度表",
            "id": "产品维度表/PRODUCTNAME",
            "tableTranName": "产品维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "品类维度记录数": {
            "fieldName": "品类维度记录数",
            "isUsable": true,
            "tableId": "品类维度",
            "id": "品类维度记录数",
            "fieldType": 64
        },
        "品牌描述": {
            "fieldName": "品牌描述",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "品牌维度",
            "id": "品牌维度/品牌描述",
            "tableTranName": "品牌维度",
            "fieldType": 16,
            "isEnable": true
        },
        "成本事实表/SALEAREA": {
            "fieldName": "SALEAREA",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/SALEAREA",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "化工_重大事件明细表记录数": {
            "fieldName": "化工_重大事件明细表记录数",
            "isUsable": true,
            "tableId": "化工_重大事件明细表",
            "id": "化工_重大事件明细表记录数",
            "fieldType": 64
        },
        "客户维度表/客户规模": {
            "fieldName": "客户规模",
            "fieldSize": 10,
            "isUsable": true,
            "tableId": "客户维度表",
            "id": "客户维度表/客户规模",
            "tableTranName": "客户维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "订单/是否已付": {
            "fieldName": "是否已付",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "订单",
            "id": "订单/是否已付",
            "tableTranName": "订单",
            "fieldType": 16,
            "isEnable": true
        },
        "CLOSEREASON": {
            "fieldName": "CLOSEREASON",
            "fieldSize": 30,
            "isUsable": true,
            "tableId": "合同维度表",
            "id": "合同维度表/CLOSEREASON",
            "tableTranName": "合同维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "降雨量": {
            "fieldName": "降雨量",
            "fieldSize": 17,
            "isUsable": true,
            "tableId": "西安兰特雨量监测数据",
            "id": "西安兰特雨量监测数据/降雨量",
            "tableTranName": "西安兰特雨量监测数据",
            "fieldType": 32,
            "isEnable": true
        },
        "回款事实表/BUGUID": {
            "fieldName": "BUGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "回款事实表",
            "id": "回款事实表/BUGUID",
            "tableTranName": "回款事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "ROOMTOTAL": {
            "fieldName": "ROOMTOTAL",
            "fieldSize": 20,
            "isUsable": true,
            "tableId": "合同维度表",
            "id": "合同维度表/ROOMTOTAL",
            "tableTranName": "合同维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "实际生产量": {
            "fieldName": "实际生产量",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "化工_产品收入率趋势",
            "id": "化工_产品收入率趋势/实际生产量",
            "tableTranName": "化工_产品收入率趋势",
            "fieldType": 32,
            "isEnable": true
        },
        "注册日期": {
            "fieldName": "注册日期",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "用户信息维度表",
            "id": "用户信息维度表/注册日期",
            "tableTranName": "用户信息维度表",
            "fieldType": 48,
            "isEnable": true
        },
        "分公司维度表/所属办事处": {
            "fieldName": "所属办事处",
            "fieldSize": 200,
            "isUsable": true,
            "tableId": "分公司维度表",
            "id": "分公司维度表/所属办事处",
            "tableTranName": "分公司维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "银行_财务分析事实表/业务ID": {
            "fieldName": "业务ID",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/业务ID",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "组合销售品": {
            "fieldName": "组合销售品",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/组合销售品",
            "tableTranName": "宽带业务",
            "fieldType": 16,
            "isEnable": true
        },
        "门店维度/店性质": {
            "fieldName": "店性质",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "门店维度",
            "id": "门店维度/店性质",
            "tableTranName": "门店维度",
            "fieldType": 16,
            "isEnable": true
        },
        "备注": {
            "fieldName": "备注",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "雇员",
            "id": "雇员/备注",
            "tableTranName": "雇员",
            "fieldType": 16,
            "isEnable": true
        },
        "交易流水号": {
            "fieldName": "交易流水号",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "业务流水表",
            "id": "业务流水表/交易流水号",
            "tableTranName": "业务流水表",
            "fieldType": 32,
            "isEnable": true
        },
        "区域维度表/AREA_NAME": {
            "fieldName": "AREA_NAME",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "区域维度表",
            "id": "区域维度表/AREA_NAME",
            "tableTranName": "区域维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "产品_产品名称": {
            "fieldName": "产品_产品名称",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "产品",
            "id": "产品/产品_产品名称",
            "tableTranName": "产品",
            "fieldType": 16,
            "isEnable": true
        },
        "全国环境监测数据/监测城市": {
            "fieldName": "监测城市",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "全国环境监测数据",
            "id": "全国环境监测数据/监测城市",
            "tableTranName": "全国环境监测数据",
            "fieldType": 16,
            "isEnable": true
        },
        "GETINGUID": {
            "fieldName": "GETINGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "回款事实表",
            "id": "回款事实表/GETINGUID",
            "tableTranName": "回款事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "雇员2/产品ID": {
            "fieldName": "产品ID",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "雇员2",
            "id": "雇员2/产品ID",
            "tableTranName": "雇员2",
            "fieldType": 32,
            "isEnable": true
        },
        "起租设备数量": {
            "fieldName": "起租设备数量",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "租赁_车辆租赁业务",
            "id": "租赁_车辆租赁业务/起租设备数量",
            "tableTranName": "租赁_车辆租赁业务",
            "fieldType": 32,
            "isEnable": true
        },
        "ExcelView之客户跟踪表/客户意见": {
            "fieldName": "客户意见",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/客户意见",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 16,
            "isEnable": true
        },
        "访问统计事实表/访问次数": {
            "fieldName": "访问次数",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "访问统计事实表",
            "id": "访问统计事实表/访问次数",
            "tableTranName": "访问统计事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "分界口货车出入情况/值": {
            "fieldName": "值",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "分界口货车出入情况",
            "id": "分界口货车出入情况/值",
            "tableTranName": "分界口货车出入情况",
            "fieldType": 32,
            "isEnable": true
        },
        "产品名称维度/产品ID": {
            "fieldName": "产品ID",
            "fieldSize": 10,
            "isUsable": true,
            "tableId": "产品名称维度",
            "id": "产品名称维度/产品ID",
            "tableTranName": "产品名称维度",
            "fieldType": 32,
            "isEnable": true
        },
        "合同事实表/注册时间": {
            "fieldName": "注册时间",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "合同事实表",
            "id": "合同事实表/注册时间",
            "tableTranName": "合同事实表",
            "fieldType": 48,
            "isEnable": true
        },
        "南京苏果营业数据/店名": {
            "fieldName": "店名",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "南京苏果营业数据",
            "id": "南京苏果营业数据/店名",
            "tableTranName": "南京苏果营业数据",
            "fieldType": 16,
            "isEnable": true
        },
        "人员姓名": {
            "fieldName": "人员姓名",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "人员变动表",
            "id": "人员变动表/人员姓名",
            "tableTranName": "人员变动表",
            "fieldType": 16,
            "isEnable": true
        },
        "监测点经度": {
            "fieldName": "监测点经度",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "全国环境监测数据",
            "id": "全国环境监测数据/监测点经度",
            "tableTranName": "全国环境监测数据",
            "fieldType": 16,
            "isEnable": true
        },
        "总停留时间": {
            "fieldName": "总停留时间",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "访问统计事实表",
            "id": "访问统计事实表/总停留时间",
            "tableTranName": "访问统计事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "学历": {
            "fieldName": "学历",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "人员变动表",
            "id": "人员变动表/学历",
            "tableTranName": "人员变动表",
            "fieldType": 16,
            "isEnable": true
        },
        "门店维度/合并统计店名": {
            "fieldName": "合并统计店名",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "门店维度",
            "id": "门店维度/合并统计店名",
            "tableTranName": "门店维度",
            "fieldType": 16,
            "isEnable": true
        },
        "密码": {
            "fieldName": "密码",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "用户登录权限表",
            "id": "用户登录权限表/密码",
            "tableTranName": "用户登录权限表",
            "fieldType": 16,
            "isEnable": true
        },
        "样式数据二/序号": {
            "fieldName": "序号",
            "fieldSize": 100,
            "isUsable": true,
            "tableId": "样式数据二",
            "id": "样式数据二/序号",
            "tableTranName": "样式数据二",
            "fieldType": 16,
            "isEnable": true
        },
        "银行_财务分析事实表/客户ID": {
            "fieldName": "客户ID",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/客户ID",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "统计年月": {
            "fieldName": "统计年月",
            "fieldSize": 100,
            "isUsable": true,
            "tableId": "访问统计事实表",
            "id": "访问统计事实表/统计年月",
            "tableTranName": "访问统计事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "车型": {
            "fieldName": "车型",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "分界口货车出入情况",
            "id": "分界口货车出入情况/车型",
            "tableTranName": "分界口货车出入情况",
            "fieldType": 16,
            "isEnable": true
        },
        "银行_财务分析事实表/EVA": {
            "fieldName": "EVA",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/EVA",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "机构名称": {
            "fieldName": "机构名称",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "银行_机构维度表",
            "id": "银行_机构维度表/机构名称",
            "tableTranName": "银行_机构维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "用户登录权限表/职务": {
            "fieldName": "职务",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "用户登录权限表",
            "id": "用户登录权限表/职务",
            "tableTranName": "用户登录权限表",
            "fieldType": 16,
            "isEnable": true
        },
        "订单ID": {
            "fieldName": "订单ID",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "订单",
            "id": "订单/订单ID",
            "tableTranName": "订单",
            "fieldType": 32,
            "isEnable": true
        },
        "业务流水表/票号": {
            "fieldName": "票号",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "业务流水表",
            "id": "业务流水表/票号",
            "tableTranName": "业务流水表",
            "fieldType": 16,
            "isEnable": true
        },
        "业务流水表/交易金额": {
            "fieldName": "交易金额",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "业务流水表",
            "id": "业务流水表/交易金额",
            "tableTranName": "业务流水表",
            "fieldType": 32,
            "isEnable": true
        },
        "雇员/照片": {
            "fieldName": "照片",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "雇员",
            "id": "雇员/照片",
            "tableTranName": "雇员",
            "fieldType": 16,
            "isEnable": true
        },
        "PAYFORMNAME": {
            "fieldName": "PAYFORMNAME",
            "fieldSize": 30,
            "isUsable": true,
            "tableId": "合同维度表",
            "id": "合同维度表/PAYFORMNAME",
            "tableTranName": "合同维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "客户维度表/省份": {
            "fieldName": "省份",
            "fieldSize": 64,
            "isUsable": true,
            "tableId": "客户维度表",
            "id": "客户维度表/省份",
            "tableTranName": "客户维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "营业税金及附加_支行分摊": {
            "fieldName": "营业税金及附加_支行分摊",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/营业税金及附加_支行分摊",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "合同类型": {
            "fieldName": "合同类型",
            "fieldSize": 20,
            "isUsable": true,
            "tableId": "合同事实表",
            "id": "合同事实表/合同类型",
            "tableTranName": "合同事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "分公司维度表/省份": {
            "fieldName": "省份",
            "fieldSize": 200,
            "isUsable": true,
            "tableId": "分公司维度表",
            "id": "分公司维度表/省份",
            "tableTranName": "分公司维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "类型细类": {
            "fieldName": "类型细类",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/类型细类",
            "tableTranName": "宽带业务",
            "fieldType": 16,
            "isEnable": true
        },
        "回款维度表/ABCNAME": {
            "fieldName": "ABCNAME",
            "fieldSize": 10,
            "isUsable": true,
            "tableId": "回款维度表",
            "id": "回款维度表/ABCNAME",
            "tableTranName": "回款维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "注册地区ID": {
            "fieldName": "注册地区ID",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "用户信息维度表",
            "id": "用户信息维度表/注册地区ID",
            "tableTranName": "用户信息维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "银行_产品维度表/PA产品号": {
            "fieldName": "PA产品号",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "银行_产品维度表",
            "id": "银行_产品维度表/PA产品号",
            "tableTranName": "银行_产品维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "签约事实表/CJPRICE": {
            "fieldName": "CJPRICE",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "签约事实表",
            "id": "签约事实表/CJPRICE",
            "tableTranName": "签约事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "浏览器占比变化记录数": {
            "fieldName": "浏览器占比变化记录数",
            "isUsable": true,
            "tableId": "浏览器占比变化",
            "id": "浏览器占比变化记录数",
            "fieldType": 64
        },
        "银行_财务分析事实表/机构ID": {
            "fieldName": "机构ID",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/机构ID",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "化工_原料成本趋势展示/原料成本": {
            "fieldName": "原料成本",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "化工_原料成本趋势展示",
            "id": "化工_原料成本趋势展示/原料成本",
            "tableTranName": "化工_原料成本趋势展示",
            "fieldType": 32,
            "isEnable": true
        },
        "设备": {
            "fieldName": "设备",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "化工_设备运行状况展示",
            "id": "化工_设备运行状况展示/设备",
            "tableTranName": "化工_设备运行状况展示",
            "fieldType": 16,
            "isEnable": true
        },
        "合同回款事实/付款时间": {
            "fieldName": "付款时间",
            "fieldSize": 23,
            "isUsable": true,
            "tableId": "合同回款事实",
            "id": "合同回款事实/付款时间",
            "tableTranName": "合同回款事实",
            "fieldType": 48,
            "isEnable": true
        },
        "类别": {
            "fieldName": "类别",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "化工_生成进度表展示",
            "id": "化工_生成进度表展示/类别",
            "tableTranName": "化工_生成进度表展示",
            "fieldType": 16,
            "isEnable": true
        },
        "客户维度表/城市": {
            "fieldName": "城市",
            "fieldSize": 64,
            "isUsable": true,
            "tableId": "客户维度表",
            "id": "客户维度表/城市",
            "tableTranName": "客户维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "合同维度表/DISCNTREMARK": {
            "fieldName": "DISCNTREMARK",
            "fieldSize": 256,
            "isUsable": true,
            "tableId": "合同维度表",
            "id": "合同维度表/DISCNTREMARK",
            "tableTranName": "合同维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "销售事实表记录数": {
            "fieldName": "销售事实表记录数",
            "isUsable": true,
            "tableId": "销售事实表",
            "id": "销售事实表记录数",
            "fieldType": 64
        },
        "化工_产品收入率趋势/实际生产量": {
            "fieldName": "实际生产量",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "化工_产品收入率趋势",
            "id": "化工_产品收入率趋势/实际生产量",
            "tableTranName": "化工_产品收入率趋势",
            "fieldType": 32,
            "isEnable": true
        },
        "迁徙人数": {
            "fieldName": "迁徙人数",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "北京春运迁徙数据",
            "id": "北京春运迁徙数据/迁徙人数",
            "tableTranName": "北京春运迁徙数据",
            "fieldType": 32,
            "isEnable": true
        },
        "库存事实表/TOTAL": {
            "fieldName": "TOTAL",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "库存事实表",
            "id": "库存事实表/TOTAL",
            "tableTranName": "库存事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "产品编码": {
            "fieldName": "产品编码",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "医药_产品维度表",
            "id": "医药_产品维度表/产品编码",
            "tableTranName": "医药_产品维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "指标二": {
            "fieldName": "指标二",
            "fieldSize": 17,
            "isUsable": true,
            "tableId": "样式数据二",
            "id": "样式数据二/指标二",
            "tableTranName": "样式数据二",
            "fieldType": 32,
            "isEnable": true
        },
        "银行_财务分析事实表/币种": {
            "fieldName": "币种",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/币种",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "REGION": {
            "fieldName": "REGION",
            "fieldSize": 25,
            "isUsable": true,
            "tableId": "城市地区维度表",
            "id": "城市地区维度表/REGION",
            "tableTranName": "城市地区维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "合同事实表/合同类型": {
            "fieldName": "合同类型",
            "fieldSize": 20,
            "isUsable": true,
            "tableId": "合同事实表",
            "id": "合同事实表/合同类型",
            "tableTranName": "合同事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "回款事实表/ABCDATE": {
            "fieldName": "ABCDATE",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "回款事实表",
            "id": "回款事实表/ABCDATE",
            "tableTranName": "回款事实表",
            "fieldType": 48,
            "isEnable": true
        },
        "用户信息维度表/注册日期": {
            "fieldName": "注册日期",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "用户信息维度表",
            "id": "用户信息维度表/注册日期",
            "tableTranName": "用户信息维度表",
            "fieldType": 48,
            "isEnable": true
        },
        "COSTDISPLAY": {
            "fieldName": "COSTDISPLAY",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/COSTDISPLAY",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "成本事实表/PRODUCTDIFF": {
            "fieldName": "PRODUCTDIFF",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/PRODUCTDIFF",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "客户维度表/客户类型": {
            "fieldName": "客户类型",
            "fieldSize": 64,
            "isUsable": true,
            "tableId": "客户维度表",
            "id": "客户维度表/客户类型",
            "tableTranName": "客户维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "合同维度表/SALEAREA": {
            "fieldName": "SALEAREA",
            "fieldSize": 20,
            "isUsable": true,
            "tableId": "合同维度表",
            "id": "合同维度表/SALEAREA",
            "tableTranName": "合同维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "HTTOTAL": {
            "fieldName": "HTTOTAL",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "签约事实表",
            "id": "签约事实表/HTTOTAL",
            "tableTranName": "签约事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "房间维度表/SALEAREA": {
            "fieldName": "SALEAREA",
            "fieldSize": 20,
            "isUsable": true,
            "tableId": "房间维度表",
            "id": "房间维度表/SALEAREA",
            "tableTranName": "房间维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "电话": {
            "fieldName": "电话",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商信息表",
            "id": "供应商信息表/电话",
            "tableTranName": "供应商信息表",
            "fieldType": 16,
            "isEnable": true
        },
        "平均每日营业额": {
            "fieldName": "平均每日营业额",
            "fieldSize": 17,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/平均每日营业额",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 32,
            "isEnable": true
        },
        "BUILDAREA": {
            "fieldName": "BUILDAREA",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/BUILDAREA",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "业务名称": {
            "fieldName": "业务名称",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "银行_业务维度表",
            "id": "银行_业务维度表/业务名称",
            "tableTranName": "银行_业务维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "ExcelView之客户跟踪表/营业类型": {
            "fieldName": "营业类型",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/营业类型",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 16,
            "isEnable": true
        },
        "租赁_车辆租赁业务/区域": {
            "fieldName": "区域",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "租赁_车辆租赁业务",
            "id": "租赁_车辆租赁业务/区域",
            "tableTranName": "租赁_车辆租赁业务",
            "fieldType": 16,
            "isEnable": true
        },
        "营业额": {
            "fieldName": "营业额",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "南京苏果营业数据",
            "id": "南京苏果营业数据/营业额",
            "tableTranName": "南京苏果营业数据",
            "fieldType": 32,
            "isEnable": true
        },
        "销售明细/品牌编号": {
            "fieldName": "品牌编号",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "销售明细",
            "id": "销售明细/品牌编号",
            "tableTranName": "销售明细",
            "fieldType": 16,
            "isEnable": true
        },
        "目的地": {
            "fieldName": "目的地",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "流向",
            "id": "流向/目的地",
            "tableTranName": "流向",
            "fieldType": 16,
            "isEnable": true
        },
        "银行_业务维度表记录数": {
            "fieldName": "银行_业务维度表记录数",
            "isUsable": true,
            "tableId": "银行_业务维度表",
            "id": "银行_业务维度表记录数",
            "fieldType": 64
        },
        "产品_产品ID": {
            "fieldName": "产品_产品ID",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "产品",
            "id": "产品/产品_产品ID",
            "tableTranName": "产品",
            "fieldType": 32,
            "isEnable": true
        },
        "COSTNEW": {
            "fieldName": "COSTNEW",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/COSTNEW",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "其他投资事业": {
            "fieldName": "其他投资事业",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/其他投资事业",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 16,
            "isEnable": true
        },
        "化工_库存展示/材料名称": {
            "fieldName": "材料名称",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "化工_库存展示",
            "id": "化工_库存展示/材料名称",
            "tableTranName": "化工_库存展示",
            "fieldType": 16,
            "isEnable": true
        },
        "北京春运迁徙数据/迁出城市": {
            "fieldName": "迁出城市",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "北京春运迁徙数据",
            "id": "北京春运迁徙数据/迁出城市",
            "tableTranName": "北京春运迁徙数据",
            "fieldType": 16,
            "isEnable": true
        },
        "库存事实表/PROJGUID": {
            "fieldName": "PROJGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "库存事实表",
            "id": "库存事实表/PROJGUID",
            "tableTranName": "库存事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "医药_库存周转事实表/月均销量": {
            "fieldName": "月均销量",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "医药_库存周转事实表",
            "id": "医药_库存周转事实表/月均销量",
            "tableTranName": "医药_库存周转事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "ExcelView之客户跟踪表/最近交易数据跟踪": {
            "fieldName": "最近交易数据跟踪",
            "fieldSize": 10,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/最近交易数据跟踪",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 32,
            "isEnable": true
        },
        "人员变动表/人员编码": {
            "fieldName": "人员编码",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "人员变动表",
            "id": "人员变动表/人员编码",
            "tableTranName": "人员变动表",
            "fieldType": 16,
            "isEnable": true
        },
        "合同事实表/总金额": {
            "fieldName": "总金额",
            "fieldSize": 10,
            "isUsable": true,
            "tableId": "合同事实表",
            "id": "合同事实表/总金额",
            "tableTranName": "合同事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "合同回款事实/记录人": {
            "fieldName": "记录人",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "合同回款事实",
            "id": "合同回款事实/记录人",
            "tableTranName": "合同回款事实",
            "fieldType": 16,
            "isEnable": true
        },
        "销售明细/店号": {
            "fieldName": "店号",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "销售明细",
            "id": "销售明细/店号",
            "tableTranName": "销售明细",
            "fieldType": 16,
            "isEnable": true
        },
        "订购日期": {
            "fieldName": "订购日期",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "订单",
            "id": "订单/订购日期",
            "tableTranName": "订单",
            "fieldType": 16,
            "isEnable": true
        },
        "雇员/地址": {
            "fieldName": "地址",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "雇员",
            "id": "雇员/地址",
            "tableTranName": "雇员",
            "fieldType": 16,
            "isEnable": true
        },
        "推广渠道维度表/三级渠道名": {
            "fieldName": "三级渠道名",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "推广渠道维度表",
            "id": "推广渠道维度表/三级渠道名",
            "tableTranName": "推广渠道维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "雇员记录数": {
            "fieldName": "雇员记录数",
            "isUsable": true,
            "tableId": "雇员",
            "id": "雇员记录数",
            "fieldType": 64
        },
        "负责人": {
            "fieldName": "负责人",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/负责人",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 16,
            "isEnable": true
        },
        "纬度": {
            "fieldName": "纬度",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "南京苏果营业数据",
            "id": "南京苏果营业数据/纬度",
            "tableTranName": "南京苏果营业数据",
            "fieldType": 16,
            "isEnable": true
        },
        "租赁_存量业务/行业细分": {
            "fieldName": "行业细分",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "租赁_存量业务",
            "id": "租赁_存量业务/行业细分",
            "tableTranName": "租赁_存量业务",
            "fieldType": 16,
            "isEnable": true
        },
        "宽带业务/组合销售品": {
            "fieldName": "组合销售品",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/组合销售品",
            "tableTranName": "宽带业务",
            "fieldType": 16,
            "isEnable": true
        },
        "十大文化古镇/文化古镇": {
            "fieldName": "文化古镇",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "十大文化古镇",
            "id": "十大文化古镇/文化古镇",
            "tableTranName": "十大文化古镇",
            "fieldType": 16,
            "isEnable": true
        },
        "供应商信息表/公司名称": {
            "fieldName": "公司名称",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商信息表",
            "id": "供应商信息表/公司名称",
            "tableTranName": "供应商信息表",
            "fieldType": 16,
            "isEnable": true
        },
        "宽带业务/速率": {
            "fieldName": "速率",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/速率",
            "tableTranName": "宽带业务",
            "fieldType": 32,
            "isEnable": true
        },
        "SALES_REGION": {
            "fieldName": "SALES_REGION",
            "fieldSize": 2,
            "isUsable": true,
            "tableId": "销售员维度表",
            "id": "销售员维度表/SALES_REGION",
            "tableTranName": "销售员维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "TOTALUNITCOSTDISPLAY": {
            "fieldName": "TOTALUNITCOSTDISPLAY",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/TOTALUNITCOSTDISPLAY",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "品类维度/类别": {
            "fieldName": "类别",
            "fieldSize": 10,
            "isUsable": true,
            "tableId": "品类维度",
            "id": "品类维度/类别",
            "tableTranName": "品类维度",
            "fieldType": 32,
            "isEnable": true
        },
        "指标一": {
            "fieldName": "指标一",
            "fieldSize": 17,
            "isUsable": true,
            "tableId": "样式数据二",
            "id": "样式数据二/指标一",
            "tableTranName": "样式数据二",
            "fieldType": 32,
            "isEnable": true
        },
        "填表人": {
            "fieldName": "填表人",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/填表人",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 16,
            "isEnable": true
        },
        "注册时间": {
            "fieldName": "注册时间",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "合同事实表",
            "id": "合同事实表/注册时间",
            "tableTranName": "合同事实表",
            "fieldType": 48,
            "isEnable": true
        },
        "PRICE": {
            "fieldName": "PRICE",
            "fieldSize": 20,
            "isUsable": true,
            "tableId": "房间维度表",
            "id": "房间维度表/PRICE",
            "tableTranName": "房间维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "所属小区": {
            "fieldName": "所属小区",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "门店维度",
            "id": "门店维度/所属小区",
            "tableTranName": "门店维度",
            "fieldType": 16,
            "isEnable": true
        },
        "监测城市": {
            "fieldName": "监测城市",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "全国环境监测数据",
            "id": "全国环境监测数据/监测城市",
            "tableTranName": "全国环境监测数据",
            "fieldType": 16,
            "isEnable": true
        },
        "交出\\接入": {
            "fieldName": "交出\\接入",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "分界口货车出入情况",
            "id": "分界口货车出入情况/交出\\接入",
            "tableTranName": "分界口货车出入情况",
            "fieldType": 16,
            "isEnable": true
        },
        "指标三": {
            "fieldName": "指标三",
            "fieldSize": 100,
            "isUsable": true,
            "tableId": "样式数据二",
            "id": "样式数据二/指标三",
            "tableTranName": "样式数据二",
            "fieldType": 32,
            "isEnable": true
        },
        "医药_客户地区维度记录数": {
            "fieldName": "医药_客户地区维度记录数",
            "isUsable": true,
            "tableId": "医药_客户地区维度",
            "id": "医药_客户地区维度记录数",
            "fieldType": 64
        },
        "OCCUPYRATE": {
            "fieldName": "OCCUPYRATE",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/OCCUPYRATE",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "OCCUPYRATENEW": {
            "fieldName": "OCCUPYRATENEW",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/OCCUPYRATENEW",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "EVA": {
            "fieldName": "EVA",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/EVA",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "TOTALDJ": {
            "fieldName": "TOTALDJ",
            "fieldSize": 20,
            "isUsable": true,
            "tableId": "房间维度表",
            "id": "房间维度表/TOTALDJ",
            "tableTranName": "房间维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "存留比例": {
            "fieldName": "存留比例",
            "fieldSize": 17,
            "isUsable": true,
            "tableId": "化工_生成进度表展示",
            "id": "化工_生成进度表展示/存留比例",
            "tableTranName": "化工_生成进度表展示",
            "fieldType": 32,
            "isEnable": true
        },
        "银行_机构维度表/机构名称-层级5": {
            "fieldName": "机构名称-层级5",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "银行_机构维度表",
            "id": "银行_机构维度表/机构名称-层级5",
            "tableTranName": "银行_机构维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "雇员/手机": {
            "fieldName": "手机",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "雇员",
            "id": "雇员/手机",
            "tableTranName": "雇员",
            "fieldType": 16,
            "isEnable": true
        },
        "银行_机构维度表/机构名称-层级4": {
            "fieldName": "机构名称-层级4",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "银行_机构维度表",
            "id": "银行_机构维度表/机构名称-层级4",
            "tableTranName": "银行_机构维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "RAROC": {
            "fieldName": "RAROC",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/RAROC",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "银行_机构维度表/机构名称-层级3": {
            "fieldName": "机构名称-层级3",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "银行_机构维度表",
            "id": "银行_机构维度表/机构名称-层级3",
            "tableTranName": "银行_机构维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "银行_机构维度表/机构名称-层级2": {
            "fieldName": "机构名称-层级2",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "银行_机构维度表",
            "id": "银行_机构维度表/机构名称-层级2",
            "tableTranName": "银行_机构维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "房间维度表/TOTAL": {
            "fieldName": "TOTAL",
            "fieldSize": 20,
            "isUsable": true,
            "tableId": "房间维度表",
            "id": "房间维度表/TOTAL",
            "tableTranName": "房间维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "ExcelView之客户跟踪表/地址": {
            "fieldName": "地址",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/地址",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 16,
            "isEnable": true
        },
        "银行_机构维度表/机构名称-层级1": {
            "fieldName": "机构名称-层级1",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "银行_机构维度表",
            "id": "银行_机构维度表/机构名称-层级1",
            "tableTranName": "银行_机构维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "全国环境监测数据记录数": {
            "fieldName": "全国环境监测数据记录数",
            "isUsable": true,
            "tableId": "全国环境监测数据",
            "id": "全国环境监测数据记录数",
            "fieldType": 64
        },
        "最近与本公司来往重要记录": {
            "fieldName": "最近与本公司来往重要记录",
            "fieldSize": 10,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/最近与本公司来往重要记录",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 32,
            "isEnable": true
        },
        "供应商信息表/传真": {
            "fieldName": "传真",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商信息表",
            "id": "供应商信息表/传真",
            "tableTranName": "供应商信息表",
            "fieldType": 16,
            "isEnable": true
        },
        "ROOMGUID": {
            "fieldName": "ROOMGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "房间维度表",
            "id": "房间维度表/ROOMGUID",
            "tableTranName": "房间维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "业务流水表/机构号": {
            "fieldName": "机构号",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "业务流水表",
            "id": "业务流水表/机构号",
            "tableTranName": "业务流水表",
            "fieldType": 16,
            "isEnable": true
        },
        "租赁_存量业务/区域": {
            "fieldName": "区域",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "租赁_存量业务",
            "id": "租赁_存量业务/区域",
            "tableTranName": "租赁_存量业务",
            "fieldType": 16,
            "isEnable": true
        },
        "条线ID": {
            "fieldName": "条线ID",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/条线ID",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "成本事实表/COST": {
            "fieldName": "COST",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/COST",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "合同付款类型": {
            "fieldName": "合同付款类型",
            "fieldSize": 20,
            "isUsable": true,
            "tableId": "合同事实表",
            "id": "合同事实表/合同付款类型",
            "tableTranName": "合同事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "成本事实表/OCCUPYAREADISPLAY": {
            "fieldName": "OCCUPYAREADISPLAY",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/OCCUPYAREADISPLAY",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "与本公司来往日期": {
            "fieldName": "与本公司来往日期",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/与本公司来往日期",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 48,
            "isEnable": true
        },
        "BUILDPRODUCTTYPEGUID": {
            "fieldName": "BUILDPRODUCTTYPEGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/BUILDPRODUCTTYPEGUID",
            "tableTranName": "成本事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "照片": {
            "fieldName": "照片",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "雇员",
            "id": "雇员/照片",
            "tableTranName": "雇员",
            "fieldType": 16,
            "isEnable": true
        },
        "ExcelView之客户跟踪表记录数": {
            "fieldName": "ExcelView之客户跟踪表记录数",
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表记录数",
            "fieldType": 64
        },
        "销售事实表/活动时间": {
            "fieldName": "活动时间",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "销售事实表",
            "id": "销售事实表/活动时间",
            "tableTranName": "销售事实表",
            "fieldType": 48,
            "isEnable": true
        },
        "回款事实表/AMOUNT": {
            "fieldName": "AMOUNT",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "回款事实表",
            "id": "回款事实表/AMOUNT",
            "tableTranName": "回款事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "成本事实表/UNITPRICENEW": {
            "fieldName": "UNITPRICENEW",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/UNITPRICENEW",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "日期": {
            "fieldName": "日期",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "化工_原料成本趋势展示",
            "id": "化工_原料成本趋势展示/日期",
            "tableTranName": "化工_原料成本趋势展示",
            "fieldType": 48,
            "isEnable": true
        },
        "用户ID": {
            "fieldName": "用户ID",
            "fieldSize": 64,
            "isUsable": true,
            "tableId": "银行_用户维度表",
            "id": "银行_用户维度表/用户ID",
            "tableTranName": "银行_用户维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "业务经理": {
            "fieldName": "业务经理",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "租赁_车辆租赁业务",
            "id": "租赁_车辆租赁业务/业务经理",
            "tableTranName": "租赁_车辆租赁业务",
            "fieldType": 16,
            "isEnable": true
        },
        "ExcelView之客户跟踪表/成立日期": {
            "fieldName": "成立日期",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/成立日期",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 48,
            "isEnable": true
        },
        "PM值": {
            "fieldName": "PM值",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "全国环境监测数据",
            "id": "全国环境监测数据/PM值",
            "tableTranName": "全国环境监测数据",
            "fieldType": 32,
            "isEnable": true
        },
        "组合类型": {
            "fieldName": "组合类型",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/组合类型",
            "tableTranName": "宽带业务",
            "fieldType": 16,
            "isEnable": true
        },
        "单位数量": {
            "fieldName": "单位数量",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商产品表",
            "id": "供应商产品表/单位数量",
            "tableTranName": "供应商产品表",
            "fieldType": 16,
            "isEnable": true
        },
        "购买数量": {
            "fieldName": "购买数量",
            "fieldSize": 10,
            "isUsable": true,
            "tableId": "合同事实表",
            "id": "合同事实表/购买数量",
            "tableTranName": "合同事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "信用评定": {
            "fieldName": "信用评定",
            "fieldSize": 10,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/信用评定",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 32,
            "isEnable": true
        },
        "供应商信息表/国家": {
            "fieldName": "国家",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商信息表",
            "id": "供应商信息表/国家",
            "tableTranName": "供应商信息表",
            "fieldType": 16,
            "isEnable": true
        },
        "北京春运迁徙数据/迁入城市": {
            "fieldName": "迁入城市",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "北京春运迁徙数据",
            "id": "北京春运迁徙数据/迁入城市",
            "tableTranName": "北京春运迁徙数据",
            "fieldType": 16,
            "isEnable": true
        },
        "供应商id": {
            "fieldName": "供应商id",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "订单明细",
            "id": "订单明细/供应商id",
            "tableTranName": "订单明细",
            "fieldType": 32,
            "isEnable": true
        },
        "联系人职务": {
            "fieldName": "联系人职务",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商信息表",
            "id": "供应商信息表/联系人职务",
            "tableTranName": "供应商信息表",
            "fieldType": 16,
            "isEnable": true
        },
        "竣工日期": {
            "fieldName": "竣工日期",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/竣工日期",
            "tableTranName": "宽带业务",
            "fieldType": 48,
            "isEnable": true
        },
        "出生日期": {
            "fieldName": "出生日期",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "雇员",
            "id": "雇员/出生日期",
            "tableTranName": "雇员",
            "fieldType": 16,
            "isEnable": true
        },
        "宽带业务/区域ID": {
            "fieldName": "区域ID",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/区域ID",
            "tableTranName": "宽带业务",
            "fieldType": 16,
            "isEnable": true
        },
        "雇员/备注": {
            "fieldName": "备注",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "雇员",
            "id": "雇员/备注",
            "tableTranName": "雇员",
            "fieldType": 16,
            "isEnable": true
        },
        "订单/货主名称": {
            "fieldName": "货主名称",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "订单",
            "id": "订单/货主名称",
            "tableTranName": "订单",
            "fieldType": 16,
            "isEnable": true
        },
        "合同维度表/PAYFORMNAME": {
            "fieldName": "PAYFORMNAME",
            "fieldSize": 30,
            "isUsable": true,
            "tableId": "合同维度表",
            "id": "合同维度表/PAYFORMNAME",
            "tableTranName": "合同维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "客户维度表/客户名称": {
            "fieldName": "客户名称",
            "fieldSize": 128,
            "isUsable": true,
            "tableId": "客户维度表",
            "id": "客户维度表/客户名称",
            "tableTranName": "客户维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "库存事实表记录数": {
            "fieldName": "库存事实表记录数",
            "isUsable": true,
            "tableId": "库存事实表",
            "id": "库存事实表记录数",
            "fieldType": 64
        },
        "样式数据三记录数": {
            "fieldName": "样式数据三记录数",
            "isUsable": true,
            "tableId": "样式数据三",
            "id": "样式数据三记录数",
            "fieldType": 64
        },
        "分公司维度表/办事处经度": {
            "fieldName": "办事处经度",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "分公司维度表",
            "id": "分公司维度表/办事处经度",
            "tableTranName": "分公司维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "浏览器占比变化/年份": {
            "fieldName": "年份",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "浏览器占比变化",
            "id": "浏览器占比变化/年份",
            "tableTranName": "浏览器占比变化",
            "fieldType": 32,
            "isEnable": true
        },
        "地址": {
            "fieldName": "地址",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商信息表",
            "id": "供应商信息表/地址",
            "tableTranName": "供应商信息表",
            "fieldType": 16,
            "isEnable": true
        },
        "家庭电话": {
            "fieldName": "家庭电话",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "雇员",
            "id": "雇员/家庭电话",
            "tableTranName": "雇员",
            "fieldType": 16,
            "isEnable": true
        },
        "化工_重大事件明细表/事故通报": {
            "fieldName": "事故通报",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "化工_重大事件明细表",
            "id": "化工_重大事件明细表/事故通报",
            "tableTranName": "化工_重大事件明细表",
            "fieldType": 16,
            "isEnable": true
        },
        "QFXFTYPE": {
            "fieldName": "QFXFTYPE",
            "fieldSize": 25,
            "isUsable": true,
            "tableId": "房间维度表",
            "id": "房间维度表/QFXFTYPE",
            "tableTranName": "房间维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "库存量": {
            "fieldName": "库存量",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商产品表",
            "id": "供应商产品表/库存量",
            "tableTranName": "供应商产品表",
            "fieldType": 32,
            "isEnable": true
        },
        "销售明细/类别": {
            "fieldName": "类别",
            "fieldSize": 10,
            "isUsable": true,
            "tableId": "销售明细",
            "id": "销售明细/类别",
            "tableTranName": "销售明细",
            "fieldType": 32,
            "isEnable": true
        },
        "货主邮政编码": {
            "fieldName": "货主邮政编码",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "订单",
            "id": "订单/货主邮政编码",
            "tableTranName": "订单",
            "fieldType": 16,
            "isEnable": true
        },
        "化工_能耗指标趋势记录数": {
            "fieldName": "化工_能耗指标趋势记录数",
            "isUsable": true,
            "tableId": "化工_能耗指标趋势",
            "id": "化工_能耗指标趋势记录数",
            "fieldType": 64
        },
        "十大文化古镇记录数": {
            "fieldName": "十大文化古镇记录数",
            "isUsable": true,
            "tableId": "十大文化古镇",
            "id": "十大文化古镇记录数",
            "fieldType": 64
        },
        "销售事实表/活动内容": {
            "fieldName": "活动内容",
            "fieldSize": 3000,
            "isUsable": true,
            "tableId": "销售事实表",
            "id": "销售事实表/活动内容",
            "tableTranName": "销售事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "DDATE": {
            "fieldName": "DDATE",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "库存事实表",
            "id": "库存事实表/DDATE",
            "tableTranName": "库存事实表",
            "fieldType": 48,
            "isEnable": true
        },
        "订单/运货商": {
            "fieldName": "运货商",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "订单",
            "id": "订单/运货商",
            "tableTranName": "订单",
            "fieldType": 32,
            "isEnable": true
        },
        "DISCNTVALUE": {
            "fieldName": "DISCNTVALUE",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "合同维度表",
            "id": "合同维度表/DISCNTVALUE",
            "tableTranName": "合同维度表",
            "fieldType": 32,
            "isEnable": true
        },
        "热门景区门票预定TOP20记录数": {
            "fieldName": "热门景区门票预定TOP20记录数",
            "isUsable": true,
            "tableId": "热门景区门票预定TOP20",
            "id": "热门景区门票预定TOP20记录数",
            "fieldType": 64
        },
        "访问统计事实表/访问ID": {
            "fieldName": "访问ID",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "访问统计事实表",
            "id": "访问统计事实表/访问ID",
            "tableTranName": "访问统计事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "南京苏果营业数据记录数": {
            "fieldName": "南京苏果营业数据记录数",
            "isUsable": true,
            "tableId": "南京苏果营业数据",
            "id": "南京苏果营业数据记录数",
            "fieldType": 64
        },
        "订单/运货费": {
            "fieldName": "运货费",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "订单",
            "id": "订单/运货费",
            "tableTranName": "订单",
            "fieldType": 32,
            "isEnable": true
        },
        "统计日期": {
            "fieldName": "统计日期",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "访问统计事实表",
            "id": "访问统计事实表/统计日期",
            "tableTranName": "访问统计事实表",
            "fieldType": 48,
            "isEnable": true
        },
        "QSDATE": {
            "fieldName": "QSDATE",
            "fieldSize": 30,
            "isUsable": true,
            "tableId": "合同维度表",
            "id": "合同维度表/QSDATE",
            "tableTranName": "合同维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "城市地区维度表记录数": {
            "fieldName": "城市地区维度表记录数",
            "isUsable": true,
            "tableId": "城市地区维度表",
            "id": "城市地区维度表记录数",
            "fieldType": 64
        },
        "VIRTUALSTATUS": {
            "fieldName": "VIRTUALSTATUS",
            "fieldSize": 10,
            "isUsable": true,
            "tableId": "房间维度表",
            "id": "房间维度表/VIRTUALSTATUS",
            "tableTranName": "房间维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "化工_生成进度表展示/材料": {
            "fieldName": "材料",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "化工_生成进度表展示",
            "id": "化工_生成进度表展示/材料",
            "tableTranName": "化工_生成进度表展示",
            "fieldType": 16,
            "isEnable": true
        },
        "资本成本": {
            "fieldName": "资本成本",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/资本成本",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "银行_财务分析事实表/ID_NUMBER": {
            "fieldName": "ID_NUMBER",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/ID_NUMBER",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "手机": {
            "fieldName": "手机",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "雇员",
            "id": "雇员/手机",
            "tableTranName": "雇员",
            "fieldType": 16,
            "isEnable": true
        },
        "客户来源": {
            "fieldName": "客户来源",
            "fieldSize": 100,
            "isUsable": true,
            "tableId": "客户维度表",
            "id": "客户维度表/客户来源",
            "tableTranName": "客户维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "全国环境监测数据/监测点经度": {
            "fieldName": "监测点经度",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "全国环境监测数据",
            "id": "全国环境监测数据/监测点经度",
            "tableTranName": "全国环境监测数据",
            "fieldType": 16,
            "isEnable": true
        },
        "区域维度表记录数": {
            "fieldName": "区域维度表记录数",
            "isUsable": true,
            "tableId": "区域维度表",
            "id": "区域维度表记录数",
            "fieldType": 64
        },
        "单价": {
            "fieldName": "单价",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商产品表",
            "id": "供应商产品表/单价",
            "tableTranName": "供应商产品表",
            "fieldType": 32,
            "isEnable": true
        },
        "预后付": {
            "fieldName": "预后付",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/预后付",
            "tableTranName": "宽带业务",
            "fieldType": 16,
            "isEnable": true
        },
        "人员变动表/公司名称": {
            "fieldName": "公司名称",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "人员变动表",
            "id": "人员变动表/公司名称",
            "tableTranName": "人员变动表",
            "fieldType": 16,
            "isEnable": true
        },
        "南京苏果营业数据/经度": {
            "fieldName": "经度",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "南京苏果营业数据",
            "id": "南京苏果营业数据/经度",
            "tableTranName": "南京苏果营业数据",
            "fieldType": 16,
            "isEnable": true
        },
        "雇员/邮政编码": {
            "fieldName": "邮政编码",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "雇员",
            "id": "雇员/邮政编码",
            "tableTranName": "雇员",
            "fieldType": 16,
            "isEnable": true
        },
        "机构ID": {
            "fieldName": "机构ID",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/机构ID",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "成本事实表/OCCUPYRATE": {
            "fieldName": "OCCUPYRATE",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/OCCUPYRATE",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "项目维度表/PROJNAME": {
            "fieldName": "PROJNAME",
            "fieldSize": 400,
            "isUsable": true,
            "tableId": "项目维度表",
            "id": "项目维度表/PROJNAME",
            "tableTranName": "项目维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "合同维度表/STATUS": {
            "fieldName": "STATUS",
            "fieldSize": 20,
            "isUsable": true,
            "tableId": "合同维度表",
            "id": "合同维度表/STATUS",
            "tableTranName": "合同维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "销售事实表/是否结束": {
            "fieldName": "是否结束",
            "fieldSize": 20,
            "isUsable": true,
            "tableId": "销售事实表",
            "id": "销售事实表/是否结束",
            "tableTranName": "销售事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "合同事实表/合同签约时间": {
            "fieldName": "合同签约时间",
            "fieldSize": 23,
            "isUsable": true,
            "tableId": "合同事实表",
            "id": "合同事实表/合同签约时间",
            "tableTranName": "合同事实表",
            "fieldType": 48,
            "isEnable": true
        },
        "是否酒店": {
            "fieldName": "是否酒店",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/是否酒店",
            "tableTranName": "宽带业务",
            "fieldType": 16,
            "isEnable": true
        },
        "化工_能耗指标趋势/消耗量": {
            "fieldName": "消耗量",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "化工_能耗指标趋势",
            "id": "化工_能耗指标趋势/消耗量",
            "tableTranName": "化工_能耗指标趋势",
            "fieldType": 32,
            "isEnable": true
        },
        "货主地址": {
            "fieldName": "货主地址",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "订单",
            "id": "订单/货主地址",
            "tableTranName": "订单",
            "fieldType": 16,
            "isEnable": true
        },
        "客户编码": {
            "fieldName": "客户编码",
            "fieldSize": 64,
            "isUsable": true,
            "tableId": "医药_库存周转事实表",
            "id": "医药_库存周转事实表/客户编码",
            "tableTranName": "医药_库存周转事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "出游年龄占比/年龄": {
            "fieldName": "年龄",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "出游年龄占比",
            "id": "出游年龄占比/年龄",
            "tableTranName": "出游年龄占比",
            "fieldType": 16,
            "isEnable": true
        },
        "机构表/机构名称-层级2": {
            "fieldName": "机构名称-层级2",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "机构表",
            "id": "机构表/机构名称-层级2",
            "tableTranName": "机构表",
            "fieldType": 16,
            "isEnable": true
        },
        "合同回款事实/合同ID": {
            "fieldName": "合同ID",
            "fieldSize": 128,
            "isUsable": true,
            "tableId": "合同回款事实",
            "id": "合同回款事实/合同ID",
            "tableTranName": "合同回款事实",
            "fieldType": 16,
            "isEnable": true
        },
        "机构表/机构名称-层级3": {
            "fieldName": "机构名称-层级3",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "机构表",
            "id": "机构表/机构名称-层级3",
            "tableTranName": "机构表",
            "fieldType": 16,
            "isEnable": true
        },
        "机构表/机构名称-层级1": {
            "fieldName": "机构名称-层级1",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "机构表",
            "id": "机构表/机构名称-层级1",
            "tableTranName": "机构表",
            "fieldType": 16,
            "isEnable": true
        },
        "合同ID": {
            "fieldName": "合同ID",
            "fieldSize": 200,
            "isUsable": true,
            "tableId": "合同事实表",
            "id": "合同事实表/合同ID",
            "tableTranName": "合同事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "访问统计事实表/跳出次数": {
            "fieldName": "跳出次数",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "访问统计事实表",
            "id": "访问统计事实表/跳出次数",
            "tableTranName": "访问统计事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "医药_客户地区维度/客户编码": {
            "fieldName": "客户编码",
            "fieldSize": 64,
            "isUsable": true,
            "tableId": "医药_客户地区维度",
            "id": "医药_客户地区维度/客户编码",
            "tableTranName": "医药_客户地区维度",
            "fieldType": 16,
            "isEnable": true
        },
        "基本销售品": {
            "fieldName": "基本销售品",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/基本销售品",
            "tableTranName": "宽带业务",
            "fieldType": 16,
            "isEnable": true
        },
        "化工_设备运行状况展示/运行时间": {
            "fieldName": "运行时间",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "化工_设备运行状况展示",
            "id": "化工_设备运行状况展示/运行时间",
            "tableTranName": "化工_设备运行状况展示",
            "fieldType": 16,
            "isEnable": true
        },
        "用户信息维度表/用户名称": {
            "fieldName": "用户名称",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "用户信息维度表",
            "id": "用户信息维度表/用户名称",
            "tableTranName": "用户信息维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "门店维度/店号": {
            "fieldName": "店号",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "门店维度",
            "id": "门店维度/店号",
            "tableTranName": "门店维度",
            "fieldType": 16,
            "isEnable": true
        },
        "SINX": {
            "fieldName": "SINX",
            "fieldSize": 17,
            "isUsable": true,
            "tableId": "样式数据一",
            "id": "样式数据一/SINX",
            "tableTranName": "样式数据一",
            "fieldType": 32,
            "isEnable": true
        },
        "客户状态": {
            "fieldName": "客户状态",
            "fieldSize": 64,
            "isUsable": true,
            "tableId": "客户维度表",
            "id": "客户维度表/客户状态",
            "tableTranName": "客户维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "是否已付": {
            "fieldName": "是否已付",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "订单",
            "id": "订单/是否已付",
            "tableTranName": "订单",
            "fieldType": 16,
            "isEnable": true
        },
        "供应商信息表/电话": {
            "fieldName": "电话",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商信息表",
            "id": "供应商信息表/电话",
            "tableTranName": "供应商信息表",
            "fieldType": 16,
            "isEnable": true
        },
        "分界口货车出入情况/累计方式": {
            "fieldName": "累计方式",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "分界口货车出入情况",
            "id": "分界口货车出入情况/累计方式",
            "tableTranName": "分界口货车出入情况",
            "fieldType": 16,
            "isEnable": true
        },
        "BUILDRATE": {
            "fieldName": "BUILDRATE",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/BUILDRATE",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "宽带业务/竣工日期": {
            "fieldName": "竣工日期",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/竣工日期",
            "tableTranName": "宽带业务",
            "fieldType": 48,
            "isEnable": true
        },
        "业务流水表/评价结果": {
            "fieldName": "评价结果",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "业务流水表",
            "id": "业务流水表/评价结果",
            "tableTranName": "业务流水表",
            "fieldType": 32,
            "isEnable": true
        },
        "房间维度表/DJPRICE": {
            "fieldName": "DJPRICE",
            "fieldSize": 20,
            "isUsable": true,
            "tableId": "房间维度表",
            "id": "房间维度表/DJPRICE",
            "tableTranName": "房间维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "是否为重要客户": {
            "fieldName": "是否为重要客户",
            "fieldSize": 10,
            "isUsable": true,
            "tableId": "客户维度表",
            "id": "客户维度表/是否为重要客户",
            "tableTranName": "客户维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "订单/货主城市": {
            "fieldName": "货主城市",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "订单",
            "id": "订单/货主城市",
            "tableTranName": "订单",
            "fieldType": 16,
            "isEnable": true
        },
        "雇用日期": {
            "fieldName": "雇用日期",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "雇员",
            "id": "雇员/雇用日期",
            "tableTranName": "雇员",
            "fieldType": 16,
            "isEnable": true
        },
        "宽带业务/是否有ITV": {
            "fieldName": "是否有ITV",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/是否有ITV",
            "tableTranName": "宽带业务",
            "fieldType": 16,
            "isEnable": true
        },
        "回款事实表/ROOMGUID": {
            "fieldName": "ROOMGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "回款事实表",
            "id": "回款事实表/ROOMGUID",
            "tableTranName": "回款事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "回款事实表/GETINGUID": {
            "fieldName": "GETINGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "回款事实表",
            "id": "回款事实表/GETINGUID",
            "tableTranName": "回款事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "房间维度表/ROOMGUID": {
            "fieldName": "ROOMGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "房间维度表",
            "id": "房间维度表/ROOMGUID",
            "tableTranName": "房间维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "二级渠道名": {
            "fieldName": "二级渠道名",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "推广渠道维度表",
            "id": "推广渠道维度表/二级渠道名",
            "tableTranName": "推广渠道维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "活动时间": {
            "fieldName": "活动时间",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "销售事实表",
            "id": "销售事实表/活动时间",
            "tableTranName": "销售事实表",
            "fieldType": 48,
            "isEnable": true
        },
        "出入车地点及管内到达": {
            "fieldName": "出入车地点及管内到达",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "分界口货车出入情况",
            "id": "分界口货车出入情况/出入车地点及管内到达",
            "tableTranName": "分界口货车出入情况",
            "fieldType": 16,
            "isEnable": true
        },
        "办理时间": {
            "fieldName": "办理时间",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "业务流水表",
            "id": "业务流水表/办理时间",
            "tableTranName": "业务流水表",
            "fieldType": 32,
            "isEnable": true
        },
        "合同事实表/购买的产品": {
            "fieldName": "购买的产品",
            "fieldSize": 10,
            "isUsable": true,
            "tableId": "合同事实表",
            "id": "合同事实表/购买的产品",
            "tableTranName": "合同事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "品类维度/品类描述": {
            "fieldName": "品类描述",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "品类维度",
            "id": "品类维度/品类描述",
            "tableTranName": "品类维度",
            "fieldType": 16,
            "isEnable": true
        },
        "银行_财务分析事实表/条线ID": {
            "fieldName": "条线ID",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/条线ID",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "时间": {
            "fieldName": "时间",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "租赁_车辆租赁业务",
            "id": "租赁_车辆租赁业务/时间",
            "tableTranName": "租赁_车辆租赁业务",
            "fieldType": 48,
            "isEnable": true
        },
        "UNITPRICENEW": {
            "fieldName": "UNITPRICENEW",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/UNITPRICENEW",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "订单/货主省份": {
            "fieldName": "货主省份",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "订单",
            "id": "订单/货主省份",
            "tableTranName": "订单",
            "fieldType": 16,
            "isEnable": true
        },
        "库存金额": {
            "fieldName": "库存金额",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "医药_库存周转事实表",
            "id": "医药_库存周转事实表/库存金额",
            "tableTranName": "医药_库存周转事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "成本事实表/JZTZZZCB": {
            "fieldName": "JZTZZZCB",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/JZTZZZCB",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "回款事实表/STATUS": {
            "fieldName": "STATUS",
            "fieldSize": 64,
            "isUsable": true,
            "tableId": "回款事实表",
            "id": "回款事实表/STATUS",
            "tableTranName": "回款事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "年度": {
            "fieldName": "年度",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "人员变动表",
            "id": "人员变动表/年度",
            "tableTranName": "人员变动表",
            "fieldType": 16,
            "isEnable": true
        },
        "雇员/家庭电话": {
            "fieldName": "家庭电话",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "雇员",
            "id": "雇员/家庭电话",
            "tableTranName": "雇员",
            "fieldType": 16,
            "isEnable": true
        },
        "回款事实表/BLDGUID": {
            "fieldName": "BLDGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "回款事实表",
            "id": "回款事实表/BLDGUID",
            "tableTranName": "回款事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "产品维度表记录数": {
            "fieldName": "产品维度表记录数",
            "isUsable": true,
            "tableId": "产品维度表",
            "id": "产品维度表记录数",
            "fieldType": 64
        },
        "产品维度表/PRODUCTNAME": {
            "fieldName": "PRODUCTNAME",
            "fieldSize": 100,
            "isUsable": true,
            "tableId": "产品维度表",
            "id": "产品维度表/PRODUCTNAME",
            "tableTranName": "产品维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "供应商产品表/单位数量": {
            "fieldName": "单位数量",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商产品表",
            "id": "供应商产品表/单位数量",
            "tableTranName": "供应商产品表",
            "fieldType": 16,
            "isEnable": true
        },
        "外部利息净收入": {
            "fieldName": "外部利息净收入",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/外部利息净收入",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "用户登录权限表记录数": {
            "fieldName": "用户登录权限表记录数",
            "isUsable": true,
            "tableId": "用户登录权限表",
            "id": "用户登录权限表记录数",
            "fieldType": 64
        },
        "周转月": {
            "fieldName": "周转月",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "医药_库存周转事实表",
            "id": "医药_库存周转事实表/周转月",
            "tableTranName": "医药_库存周转事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "品牌编号": {
            "fieldName": "品牌编号",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "品牌维度",
            "id": "品牌维度/品牌编号",
            "tableTranName": "品牌维度",
            "fieldType": 16,
            "isEnable": true
        },
        "业务流水表/交易流水号": {
            "fieldName": "交易流水号",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "业务流水表",
            "id": "业务流水表/交易流水号",
            "tableTranName": "业务流水表",
            "fieldType": 32,
            "isEnable": true
        },
        "产品_供应商ID": {
            "fieldName": "产品_供应商ID",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "产品",
            "id": "产品/产品_供应商ID",
            "tableTranName": "产品",
            "fieldType": 32,
            "isEnable": true
        },
        "地区维度表/GB_ID": {
            "fieldName": "GB_ID",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "地区维度表",
            "id": "地区维度表/GB_ID",
            "tableTranName": "地区维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "境外游热门目的地国家": {
            "fieldName": "境外游热门目的地国家",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "十大热门出境游热门目的地国家",
            "id": "十大热门出境游热门目的地国家/境外游热门目的地国家",
            "tableTranName": "十大热门出境游热门目的地国家",
            "fieldType": 16,
            "isEnable": true
        },
        "评价结果": {
            "fieldName": "评价结果",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "业务流水表",
            "id": "业务流水表/评价结果",
            "tableTranName": "业务流水表",
            "fieldType": 32,
            "isEnable": true
        },
        "十大热门旅游城市/旅游人次": {
            "fieldName": "旅游人次",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "十大热门旅游城市",
            "id": "十大热门旅游城市/旅游人次",
            "tableTranName": "十大热门旅游城市",
            "fieldType": 32,
            "isEnable": true
        },
        "迁入城市经度": {
            "fieldName": "迁入城市经度",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "北京春运迁徙数据",
            "id": "北京春运迁徙数据/迁入城市经度",
            "tableTranName": "北京春运迁徙数据",
            "fieldType": 16,
            "isEnable": true
        },
        "宽带业务/基本销售品": {
            "fieldName": "基本销售品",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/基本销售品",
            "tableTranName": "宽带业务",
            "fieldType": 16,
            "isEnable": true
        },
        "雇员2/金额": {
            "fieldName": "金额",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "雇员2",
            "id": "雇员2/金额",
            "tableTranName": "雇员2",
            "fieldType": 16,
            "isEnable": true
        },
        "化工_产品收入率趋势/当日目标": {
            "fieldName": "当日目标",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "化工_产品收入率趋势",
            "id": "化工_产品收入率趋势/当日目标",
            "tableTranName": "化工_产品收入率趋势",
            "fieldType": 32,
            "isEnable": true
        },
        "成本事实表/TOTALUNITCOSTNEW": {
            "fieldName": "TOTALUNITCOSTNEW",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/TOTALUNITCOSTNEW",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "成本事实表/BUILDPRODUCTTYPEGUID": {
            "fieldName": "BUILDPRODUCTTYPEGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/BUILDPRODUCTTYPEGUID",
            "tableTranName": "成本事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "城市地区维度表/AREAGUID": {
            "fieldName": "AREAGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "城市地区维度表",
            "id": "城市地区维度表/AREAGUID",
            "tableTranName": "城市地区维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "邮政编码": {
            "fieldName": "邮政编码",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商信息表",
            "id": "供应商信息表/邮政编码",
            "tableTranName": "供应商信息表",
            "fieldType": 16,
            "isEnable": true
        },
        "成本事实表/COSTNEW": {
            "fieldName": "COSTNEW",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/COSTNEW",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "回款维度表/GETINGUID": {
            "fieldName": "GETINGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "回款维度表",
            "id": "回款维度表/GETINGUID",
            "tableTranName": "回款维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "性别": {
            "fieldName": "性别",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "雇员",
            "id": "雇员/性别",
            "tableTranName": "雇员",
            "fieldType": 16,
            "isEnable": true
        },
        "流向/人次": {
            "fieldName": "人次",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "流向",
            "id": "流向/人次",
            "tableTranName": "流向",
            "fieldType": 32,
            "isEnable": true
        },
        "热门旅游城市": {
            "fieldName": "热门旅游城市",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "十大热门旅游城市",
            "id": "十大热门旅游城市/热门旅游城市",
            "tableTranName": "十大热门旅游城市",
            "fieldType": 16,
            "isEnable": true
        },
        "回款维度表/CONTRACTTYPENAME": {
            "fieldName": "CONTRACTTYPENAME",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "回款维度表",
            "id": "回款维度表/CONTRACTTYPENAME",
            "tableTranName": "回款维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "产品名称": {
            "fieldName": "产品名称",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商产品表",
            "id": "供应商产品表/产品名称",
            "tableTranName": "供应商产品表",
            "fieldType": 16,
            "isEnable": true
        },
        "监测点编码": {
            "fieldName": "监测点编码",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "全国环境监测数据",
            "id": "全国环境监测数据/监测点编码",
            "tableTranName": "全国环境监测数据",
            "fieldType": 16,
            "isEnable": true
        },
        "GB_ID": {
            "fieldName": "GB_ID",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "地区维度表",
            "id": "地区维度表/GB_ID",
            "tableTranName": "地区维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "用户信息维度表/年龄": {
            "fieldName": "年龄",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "用户信息维度表",
            "id": "用户信息维度表/年龄",
            "tableTranName": "用户信息维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "交易名称": {
            "fieldName": "交易名称",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "业务流水表",
            "id": "业务流水表/交易名称",
            "tableTranName": "业务流水表",
            "fieldType": 16,
            "isEnable": true
        },
        "业务流水表/地区号": {
            "fieldName": "地区号",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "业务流水表",
            "id": "业务流水表/地区号",
            "tableTranName": "业务流水表",
            "fieldType": 32,
            "isEnable": true
        },
        "年份": {
            "fieldName": "年份",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "浏览器占比变化",
            "id": "浏览器占比变化/年份",
            "tableTranName": "浏览器占比变化",
            "fieldType": 32,
            "isEnable": true
        },
        "客户意见": {
            "fieldName": "客户意见",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/客户意见",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 16,
            "isEnable": true
        },
        "PARENTPROJNAME": {
            "fieldName": "PARENTPROJNAME",
            "fieldSize": 400,
            "isUsable": true,
            "tableId": "项目维度表",
            "id": "项目维度表/PARENTPROJNAME",
            "tableTranName": "项目维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "人员变动表/变动原因": {
            "fieldName": "变动原因",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "人员变动表",
            "id": "人员变动表/变动原因",
            "tableTranName": "人员变动表",
            "fieldType": 16,
            "isEnable": true
        },
        "热门景区门票预定TOP20/排名": {
            "fieldName": "排名",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "热门景区门票预定TOP20",
            "id": "热门景区门票预定TOP20/排名",
            "tableTranName": "热门景区门票预定TOP20",
            "fieldType": 32,
            "isEnable": true
        },
        "热门景区": {
            "fieldName": "热门景区",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "热门景区门票预定TOP20",
            "id": "热门景区门票预定TOP20/热门景区",
            "tableTranName": "热门景区门票预定TOP20",
            "fieldType": 16,
            "isEnable": true
        },
        "雇员/职务": {
            "fieldName": "职务",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "雇员",
            "id": "雇员/职务",
            "tableTranName": "雇员",
            "fieldType": 16,
            "isEnable": true
        },
        "AMOUNT": {
            "fieldName": "AMOUNT",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "回款事实表",
            "id": "回款事实表/AMOUNT",
            "tableTranName": "回款事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "地区维度表/PARENT_ID": {
            "fieldName": "PARENT_ID",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "地区维度表",
            "id": "地区维度表/PARENT_ID",
            "tableTranName": "地区维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "银行_用户维度表记录数": {
            "fieldName": "银行_用户维度表记录数",
            "isUsable": true,
            "tableId": "银行_用户维度表",
            "id": "银行_用户维度表记录数",
            "fieldType": 64
        },
        "业务流水表/柜员号": {
            "fieldName": "柜员号",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "业务流水表",
            "id": "业务流水表/柜员号",
            "tableTranName": "业务流水表",
            "fieldType": 16,
            "isEnable": true
        },
        "银行_财务分析事实表/内部资金转移收入": {
            "fieldName": "内部资金转移收入",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/内部资金转移收入",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "DFZJCB": {
            "fieldName": "DFZJCB",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/DFZJCB",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "总金额": {
            "fieldName": "总金额",
            "fieldSize": 10,
            "isUsable": true,
            "tableId": "合同事实表",
            "id": "合同事实表/总金额",
            "tableTranName": "合同事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "宽带业务/产品类型": {
            "fieldName": "产品类型",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/产品类型",
            "tableTranName": "宽带业务",
            "fieldType": 16,
            "isEnable": true
        },
        "样式数据二/指标二": {
            "fieldName": "指标二",
            "fieldSize": 17,
            "isUsable": true,
            "tableId": "样式数据二",
            "id": "样式数据二/指标二",
            "tableTranName": "样式数据二",
            "fieldType": 32,
            "isEnable": true
        },
        "客户类型": {
            "fieldName": "客户类型",
            "fieldSize": 64,
            "isUsable": true,
            "tableId": "客户维度表",
            "id": "客户维度表/客户类型",
            "tableTranName": "客户维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "ABCNAME": {
            "fieldName": "ABCNAME",
            "fieldSize": 10,
            "isUsable": true,
            "tableId": "回款维度表",
            "id": "回款维度表/ABCNAME",
            "tableTranName": "回款维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "PRODUCTCLASS": {
            "fieldName": "PRODUCTCLASS",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "产品维度表",
            "id": "产品维度表/PRODUCTCLASS",
            "tableTranName": "产品维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "品牌维度/品牌编号": {
            "fieldName": "品牌编号",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "品牌维度",
            "id": "品牌维度/品牌编号",
            "tableTranName": "品牌维度",
            "fieldType": 16,
            "isEnable": true
        },
        "供应商产品表记录数": {
            "fieldName": "供应商产品表记录数",
            "isUsable": true,
            "tableId": "供应商产品表",
            "id": "供应商产品表记录数",
            "fieldType": 64
        },
        "业务流水表/交易时间": {
            "fieldName": "交易时间",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "业务流水表",
            "id": "业务流水表/交易时间",
            "tableTranName": "业务流水表",
            "fieldType": 32,
            "isEnable": true
        },
        "化工_产品收入率趋势/日期": {
            "fieldName": "日期",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "化工_产品收入率趋势",
            "id": "化工_产品收入率趋势/日期",
            "tableTranName": "化工_产品收入率趋势",
            "fieldType": 48,
            "isEnable": true
        },
        "JGID": {
            "fieldName": "JGID",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "银行_机构维度表",
            "id": "银行_机构维度表/JGID",
            "tableTranName": "银行_机构维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "品类描述": {
            "fieldName": "品类描述",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "品类维度",
            "id": "品类维度/品类描述",
            "tableTranName": "品类维度",
            "fieldType": 16,
            "isEnable": true
        },
        "浏览量": {
            "fieldName": "浏览量",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "访问统计事实表",
            "id": "访问统计事实表/浏览量",
            "tableTranName": "访问统计事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "OCCUPYAREADISPLAY": {
            "fieldName": "OCCUPYAREADISPLAY",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/OCCUPYAREADISPLAY",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "分界口货车出入情况/出入车地点及管内到达": {
            "fieldName": "出入车地点及管内到达",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "分界口货车出入情况",
            "id": "分界口货车出入情况/出入车地点及管内到达",
            "tableTranName": "分界口货车出入情况",
            "fieldType": 16,
            "isEnable": true
        },
        "签约事实表/BLDAREA": {
            "fieldName": "BLDAREA",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "签约事实表",
            "id": "签约事实表/BLDAREA",
            "tableTranName": "签约事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "序号": {
            "fieldName": "序号",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "样式数据一",
            "id": "样式数据一/序号",
            "tableTranName": "样式数据一",
            "fieldType": 16,
            "isEnable": true
        },
        "SALEAREA": {
            "fieldName": "SALEAREA",
            "fieldSize": 20,
            "isUsable": true,
            "tableId": "房间维度表",
            "id": "房间维度表/SALEAREA",
            "tableTranName": "房间维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "租赁_车辆租赁业务记录数": {
            "fieldName": "租赁_车辆租赁业务记录数",
            "isUsable": true,
            "tableId": "租赁_车辆租赁业务",
            "id": "租赁_车辆租赁业务记录数",
            "fieldType": 64
        },
        "供应商产品表/类别ID": {
            "fieldName": "类别ID",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商产品表",
            "id": "供应商产品表/类别ID",
            "tableTranName": "供应商产品表",
            "fieldType": 32,
            "isEnable": true
        },
        "银行_财务分析事实表/外部利息支出": {
            "fieldName": "外部利息支出",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/外部利息支出",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "ExcelView之客户跟踪表/信用评定": {
            "fieldName": "信用评定",
            "fieldSize": 10,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/信用评定",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 32,
            "isEnable": true
        },
        "雇员/出生日期": {
            "fieldName": "出生日期",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "雇员",
            "id": "雇员/出生日期",
            "tableTranName": "雇员",
            "fieldType": 16,
            "isEnable": true
        },
        "营业税金及附加_总行分摊": {
            "fieldName": "营业税金及附加_总行分摊",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/营业税金及附加_总行分摊",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "RMBHTTOTAL": {
            "fieldName": "RMBHTTOTAL",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "签约事实表",
            "id": "签约事实表/RMBHTTOTAL",
            "tableTranName": "签约事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "三级渠道名": {
            "fieldName": "三级渠道名",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "推广渠道维度表",
            "id": "推广渠道维度表/三级渠道名",
            "tableTranName": "推广渠道维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "速率": {
            "fieldName": "速率",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/速率",
            "tableTranName": "宽带业务",
            "fieldType": 32,
            "isEnable": true
        },
        "银行_财务分析事实表/内部资金转移支出": {
            "fieldName": "内部资金转移支出",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/内部资金转移支出",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "北京春运迁徙数据记录数": {
            "fieldName": "北京春运迁徙数据记录数",
            "isUsable": true,
            "tableId": "北京春运迁徙数据",
            "id": "北京春运迁徙数据记录数",
            "fieldType": 64
        },
        "租赁_车辆租赁业务/起租设备数量": {
            "fieldName": "起租设备数量",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "租赁_车辆租赁业务",
            "id": "租赁_车辆租赁业务/起租设备数量",
            "tableTranName": "租赁_车辆租赁业务",
            "fieldType": 32,
            "isEnable": true
        },
        "银行_财务分析事实表/营业税金及附加_分行分摊": {
            "fieldName": "营业税金及附加_分行分摊",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/营业税金及附加_分行分摊",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "银行_财务分析事实表记录数": {
            "fieldName": "银行_财务分析事实表记录数",
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表记录数",
            "fieldType": 64
        },
        "库存事实表/BLDGUID": {
            "fieldName": "BLDGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "库存事实表",
            "id": "库存事实表/BLDGUID",
            "tableTranName": "库存事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "用户名称": {
            "fieldName": "用户名称",
            "fieldSize": 64,
            "isUsable": true,
            "tableId": "银行_用户维度表",
            "id": "银行_用户维度表/用户名称",
            "tableTranName": "银行_用户维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "门店维度/店名": {
            "fieldName": "店名",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "门店维度",
            "id": "门店维度/店名",
            "tableTranName": "门店维度",
            "fieldType": 16,
            "isEnable": true
        },
        "访问阶段统计事实表/统计日期": {
            "fieldName": "统计日期",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "访问阶段统计事实表",
            "id": "访问阶段统计事实表/统计日期",
            "tableTranName": "访问阶段统计事实表",
            "fieldType": 48,
            "isEnable": true
        },
        "店风格": {
            "fieldName": "店风格",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "门店维度",
            "id": "门店维度/店风格",
            "tableTranName": "门店维度",
            "fieldType": 16,
            "isEnable": true
        },
        "人员变动表/劳动关系类别": {
            "fieldName": "劳动关系类别",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "人员变动表",
            "id": "人员变动表/劳动关系类别",
            "tableTranName": "人员变动表",
            "fieldType": 16,
            "isEnable": true
        },
        "监测时间": {
            "fieldName": "监测时间",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "西安兰特雨量监测数据",
            "id": "西安兰特雨量监测数据/监测时间",
            "tableTranName": "西安兰特雨量监测数据",
            "fieldType": 48,
            "isEnable": true
        },
        "合并统计店名": {
            "fieldName": "合并统计店名",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "门店维度",
            "id": "门店维度/合并统计店名",
            "tableTranName": "门店维度",
            "fieldType": 16,
            "isEnable": true
        },
        "西安兰特雨量监测数据/降雨量": {
            "fieldName": "降雨量",
            "fieldSize": 17,
            "isUsable": true,
            "tableId": "西安兰特雨量监测数据",
            "id": "西安兰特雨量监测数据/降雨量",
            "tableTranName": "西安兰特雨量监测数据",
            "fieldType": 32,
            "isEnable": true
        },
        "订购量": {
            "fieldName": "订购量",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商产品表",
            "id": "供应商产品表/订购量",
            "tableTranName": "供应商产品表",
            "fieldType": 32,
            "isEnable": true
        },
        "医药_库存周转事实表/客户编码": {
            "fieldName": "客户编码",
            "fieldSize": 64,
            "isUsable": true,
            "tableId": "医药_库存周转事实表",
            "id": "医药_库存周转事实表/客户编码",
            "tableTranName": "医药_库存周转事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "机构表/机构-层级3": {
            "fieldName": "机构-层级3",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "机构表",
            "id": "机构表/机构-层级3",
            "tableTranName": "机构表",
            "fieldType": 16,
            "isEnable": true
        },
        "机构表/机构-层级2": {
            "fieldName": "机构-层级2",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "机构表",
            "id": "机构表/机构-层级2",
            "tableTranName": "机构表",
            "fieldType": 16,
            "isEnable": true
        },
        "样式数据一记录数": {
            "fieldName": "样式数据一记录数",
            "isUsable": true,
            "tableId": "样式数据一",
            "id": "样式数据一记录数",
            "fieldType": 64
        },
        "机构表/机构-层级1": {
            "fieldName": "机构-层级1",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "机构表",
            "id": "机构表/机构-层级1",
            "tableTranName": "机构表",
            "fieldType": 16,
            "isEnable": true
        },
        "票号": {
            "fieldName": "票号",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "业务流水表",
            "id": "业务流水表/票号",
            "tableTranName": "业务流水表",
            "fieldType": 16,
            "isEnable": true
        },
        "分界口货车出入情况/交出\\接入": {
            "fieldName": "交出\\接入",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "分界口货车出入情况",
            "id": "分界口货车出入情况/交出\\接入",
            "tableTranName": "分界口货车出入情况",
            "fieldType": 16,
            "isEnable": true
        },
        "项目维度表/PROJSHORTNAME": {
            "fieldName": "PROJSHORTNAME",
            "fieldSize": 40,
            "isUsable": true,
            "tableId": "项目维度表",
            "id": "项目维度表/PROJSHORTNAME",
            "tableTranName": "项目维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "出境方式占比记录数": {
            "fieldName": "出境方式占比记录数",
            "isUsable": true,
            "tableId": "出境方式占比",
            "id": "出境方式占比记录数",
            "fieldType": 64
        },
        "营业税金及附加_分行分摊": {
            "fieldName": "营业税金及附加_分行分摊",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/营业税金及附加_分行分摊",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "机构": {
            "fieldName": "机构",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "用户登录权限表",
            "id": "用户登录权限表/机构",
            "tableTranName": "用户登录权限表",
            "fieldType": 16,
            "isEnable": true
        },
        "样式数据二/指标一": {
            "fieldName": "指标一",
            "fieldSize": 17,
            "isUsable": true,
            "tableId": "样式数据二",
            "id": "样式数据二/指标一",
            "tableTranName": "样式数据二",
            "fieldType": 32,
            "isEnable": true
        },
        "销售日期": {
            "fieldName": "销售日期",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "销售明细",
            "id": "销售明细/销售日期",
            "tableTranName": "销售明细",
            "fieldType": 48,
            "isEnable": true
        },
        "合同事实表/是否已经交货": {
            "fieldName": "是否已经交货",
            "fieldSize": 20,
            "isUsable": true,
            "tableId": "合同事实表",
            "id": "合同事实表/是否已经交货",
            "tableTranName": "合同事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "银行_财务分析事实表/外部利息收入": {
            "fieldName": "外部利息收入",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/外部利息收入",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "库存事实表/AREAGUID": {
            "fieldName": "AREAGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "库存事实表",
            "id": "库存事实表/AREAGUID",
            "tableTranName": "库存事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "签约事实表/PROJGUID": {
            "fieldName": "PROJGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "签约事实表",
            "id": "签约事实表/PROJGUID",
            "tableTranName": "签约事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "成本事实表/INCR_FLAG": {
            "fieldName": "INCR_FLAG",
            "fieldSize": 23,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/INCR_FLAG",
            "tableTranName": "成本事实表",
            "fieldType": 48,
            "isEnable": true
        },
        "业务ID": {
            "fieldName": "业务ID",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/业务ID",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "供应商信息表/供应商ID": {
            "fieldName": "供应商ID",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商信息表",
            "id": "供应商信息表/供应商ID",
            "tableTranName": "供应商信息表",
            "fieldType": 32,
            "isEnable": true
        },
        "年龄": {
            "fieldName": "年龄",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "用户信息维度表",
            "id": "用户信息维度表/年龄",
            "tableTranName": "用户信息维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "供应商产品表/供应商ID": {
            "fieldName": "供应商ID",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商产品表",
            "id": "供应商产品表/供应商ID",
            "tableTranName": "供应商产品表",
            "fieldType": 32,
            "isEnable": true
        },
        "样式数据二/指标三": {
            "fieldName": "指标三",
            "fieldSize": 100,
            "isUsable": true,
            "tableId": "样式数据二",
            "id": "样式数据二/指标三",
            "tableTranName": "样式数据二",
            "fieldType": 32,
            "isEnable": true
        },
        "所属大区": {
            "fieldName": "所属大区",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "门店维度",
            "id": "门店维度/所属大区",
            "tableTranName": "门店维度",
            "fieldType": 16,
            "isEnable": true
        },
        "消耗材料": {
            "fieldName": "消耗材料",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "化工_能耗指标趋势",
            "id": "化工_能耗指标趋势/消耗材料",
            "tableTranName": "化工_能耗指标趋势",
            "fieldType": 16,
            "isEnable": true
        },
        "访问阶段统计事实表/用户ID": {
            "fieldName": "用户ID",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "访问阶段统计事实表",
            "id": "访问阶段统计事实表/用户ID",
            "tableTranName": "访问阶段统计事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "南京苏果营业数据/会员人数": {
            "fieldName": "会员人数",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "南京苏果营业数据",
            "id": "南京苏果营业数据/会员人数",
            "tableTranName": "南京苏果营业数据",
            "fieldType": 32,
            "isEnable": true
        },
        "办事处经度": {
            "fieldName": "办事处经度",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "分公司维度表",
            "id": "分公司维度表/办事处经度",
            "tableTranName": "分公司维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "交易时间": {
            "fieldName": "交易时间",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "业务流水表",
            "id": "业务流水表/交易时间",
            "tableTranName": "业务流水表",
            "fieldType": 32,
            "isEnable": true
        },
        "用户信息维度表/性别": {
            "fieldName": "性别",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "用户信息维度表",
            "id": "用户信息维度表/性别",
            "tableTranName": "用户信息维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "化工_库存展示/库存量": {
            "fieldName": "库存量",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "化工_库存展示",
            "id": "化工_库存展示/库存量",
            "tableTranName": "化工_库存展示",
            "fieldType": 32,
            "isEnable": true
        },
        "银行_财务分析事实表/营业税金及附加_支行分摊": {
            "fieldName": "营业税金及附加_支行分摊",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/营业税金及附加_支行分摊",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "当日目标": {
            "fieldName": "当日目标",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "化工_产品收入率趋势",
            "id": "化工_产品收入率趋势/当日目标",
            "tableTranName": "化工_产品收入率趋势",
            "fieldType": 32,
            "isEnable": true
        },
        "成本事实表/PROJGUID": {
            "fieldName": "PROJGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/PROJGUID",
            "tableTranName": "成本事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "当前余额": {
            "fieldName": "当前余额",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "银行_财务分析事实表",
            "id": "银行_财务分析事实表/当前余额",
            "tableTranName": "银行_财务分析事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "回款事实表/PROJGUID": {
            "fieldName": "PROJGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "回款事实表",
            "id": "回款事实表/PROJGUID",
            "tableTranName": "回款事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "雇员/国家": {
            "fieldName": "国家",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "雇员",
            "id": "雇员/国家",
            "tableTranName": "雇员",
            "fieldType": 16,
            "isEnable": true
        },
        "签约事实表/HTTOTAL": {
            "fieldName": "HTTOTAL",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "签约事实表",
            "id": "签约事实表/HTTOTAL",
            "tableTranName": "签约事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "供应商信息表/地址": {
            "fieldName": "地址",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商信息表",
            "id": "供应商信息表/地址",
            "tableTranName": "供应商信息表",
            "fieldType": 16,
            "isEnable": true
        },
        "编号": {
            "fieldName": "编号",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "南京苏果营业数据",
            "id": "南京苏果营业数据/编号",
            "tableTranName": "南京苏果营业数据",
            "fieldType": 16,
            "isEnable": true
        },
        "库存事实表/PRODUCTGUID": {
            "fieldName": "PRODUCTGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "库存事实表",
            "id": "库存事实表/PRODUCTGUID",
            "tableTranName": "库存事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "访问阶段统计事实表记录数": {
            "fieldName": "访问阶段统计事实表记录数",
            "isUsable": true,
            "tableId": "访问阶段统计事实表",
            "id": "访问阶段统计事实表记录数",
            "fieldType": 64
        },
        "成本事实表/DDATE": {
            "fieldName": "DDATE",
            "fieldSize": 8,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/DDATE",
            "tableTranName": "成本事实表",
            "fieldType": 48,
            "isEnable": true
        },
        "城市地区维度表/REGION": {
            "fieldName": "REGION",
            "fieldSize": 25,
            "isUsable": true,
            "tableId": "城市地区维度表",
            "id": "城市地区维度表/REGION",
            "tableTranName": "城市地区维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "ExcelView之客户跟踪表/传真": {
            "fieldName": "传真",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/传真",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 16,
            "isEnable": true
        },
        "产品记录数": {
            "fieldName": "产品记录数",
            "isUsable": true,
            "tableId": "产品",
            "id": "产品记录数",
            "fieldType": 64
        },
        "COSX": {
            "fieldName": "COSX",
            "fieldSize": 17,
            "isUsable": true,
            "tableId": "样式数据三",
            "id": "样式数据三/COSX",
            "tableTranName": "样式数据三",
            "fieldType": 32,
            "isEnable": true
        },
        "地区维度表/SSX_NAME": {
            "fieldName": "SSX_NAME",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "地区维度表",
            "id": "地区维度表/SSX_NAME",
            "tableTranName": "地区维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "COST": {
            "fieldName": "COST",
            "fieldSize": 16,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/COST",
            "tableTranName": "成本事实表",
            "fieldType": 32,
            "isEnable": true
        },
        "签约事实表/ROOMGUID": {
            "fieldName": "ROOMGUID",
            "fieldSize": 36,
            "isUsable": true,
            "tableId": "签约事实表",
            "id": "签约事实表/ROOMGUID",
            "tableTranName": "签约事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "店性质": {
            "fieldName": "店性质",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "门店维度",
            "id": "门店维度/店性质",
            "tableTranName": "门店维度",
            "fieldType": 16,
            "isEnable": true
        },
        "ExcelView之客户跟踪表/主要业务往来": {
            "fieldName": "主要业务往来",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "ExcelView之客户跟踪表",
            "id": "ExcelView之客户跟踪表/主要业务往来",
            "tableTranName": "ExcelView之客户跟踪表",
            "fieldType": 16,
            "isEnable": true
        },
        "访问统计事实表记录数": {
            "fieldName": "访问统计事实表记录数",
            "isUsable": true,
            "tableId": "访问统计事实表",
            "id": "访问统计事实表记录数",
            "fieldType": 64
        },
        "INCR_FLAG": {
            "fieldName": "INCR_FLAG",
            "fieldSize": 23,
            "isUsable": true,
            "tableId": "成本事实表",
            "id": "成本事实表/INCR_FLAG",
            "tableTranName": "成本事实表",
            "fieldType": 48,
            "isEnable": true
        },
        "TOTAL": {
            "fieldName": "TOTAL",
            "fieldSize": 20,
            "isUsable": true,
            "tableId": "房间维度表",
            "id": "房间维度表/TOTAL",
            "tableTranName": "房间维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "ROOMSTRU": {
            "fieldName": "ROOMSTRU",
            "fieldSize": 30,
            "isUsable": true,
            "tableId": "房间维度表",
            "id": "房间维度表/ROOMSTRU",
            "tableTranName": "房间维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "机构表/机构名称": {
            "fieldName": "机构名称",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "机构表",
            "id": "机构表/机构名称",
            "tableTranName": "机构表",
            "fieldType": 16,
            "isEnable": true
        },
        "宽带业务/是否校园": {
            "fieldName": "是否校园",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/是否校园",
            "tableTranName": "宽带业务",
            "fieldType": 16,
            "isEnable": true
        },
        "订单明细记录数": {
            "fieldName": "订单明细记录数",
            "isUsable": true,
            "tableId": "订单明细",
            "id": "订单明细记录数",
            "fieldType": 64
        },
        "雇员/姓名": {
            "fieldName": "姓名",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "雇员",
            "id": "雇员/姓名",
            "tableTranName": "雇员",
            "fieldType": 16,
            "isEnable": true
        },
        "销售员维度表/SALES_REGION": {
            "fieldName": "SALES_REGION",
            "fieldSize": 2,
            "isUsable": true,
            "tableId": "销售员维度表",
            "id": "销售员维度表/SALES_REGION",
            "tableTranName": "销售员维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "访问平台": {
            "fieldName": "访问平台",
            "fieldSize": 32,
            "isUsable": true,
            "tableId": "访问统计事实表",
            "id": "访问统计事实表/访问平台",
            "tableTranName": "访问统计事实表",
            "fieldType": 16,
            "isEnable": true
        },
        "回款维度表/ITEMTYPE": {
            "fieldName": "ITEMTYPE",
            "fieldSize": 20,
            "isUsable": true,
            "tableId": "回款维度表",
            "id": "回款维度表/ITEMTYPE",
            "tableTranName": "回款维度表",
            "fieldType": 16,
            "isEnable": true
        },
        "宽带业务/是否纯ITV": {
            "fieldName": "是否纯ITV",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "宽带业务",
            "id": "宽带业务/是否纯ITV",
            "tableTranName": "宽带业务",
            "fieldType": 16,
            "isEnable": true
        },
        "机构表/机构": {
            "fieldName": "机构",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "机构表",
            "id": "机构表/机构",
            "tableTranName": "机构表",
            "fieldType": 16,
            "isEnable": true
        },
        "订单/货主邮政编码": {
            "fieldName": "货主邮政编码",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "订单",
            "id": "订单/货主邮政编码",
            "tableTranName": "订单",
            "fieldType": 16,
            "isEnable": true
        },
        "十大热门出境游热门目的地国家/值": {
            "fieldName": "值",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "十大热门出境游热门目的地国家",
            "id": "十大热门出境游热门目的地国家/值",
            "tableTranName": "十大热门出境游热门目的地国家",
            "fieldType": 32,
            "isEnable": true
        },
        "化工_生成进度表展示记录数": {
            "fieldName": "化工_生成进度表展示记录数",
            "isUsable": true,
            "tableId": "化工_生成进度表展示",
            "id": "化工_生成进度表展示记录数",
            "fieldType": 64
        },
        "北京春运迁徙数据/迁出城市纬度": {
            "fieldName": "迁出城市纬度",
            "fieldSize": 255,
            "isUsable": true,
            "tableId": "北京春运迁徙数据",
            "id": "北京春运迁徙数据/迁出城市纬度",
            "tableTranName": "北京春运迁徙数据",
            "fieldType": 16,
            "isEnable": true
        },
        "城市": {
            "fieldName": "城市",
            "fieldSize": 0,
            "isUsable": true,
            "tableId": "供应商信息表",
            "id": "供应商信息表/城市",
            "tableTranName": "供应商信息表",
            "fieldType": 16,
            "isEnable": true
        }
    },
    noAuthFields: {},
    excelView: {
        "城市地区维度表": {
            "positions": {}
        },
        "7c6968d97bb7db25": {
            "positions": {}
        },
        "0a4ecbcf0f49ea0b": {
            "positions": {}
        },
        "互联网_访问统计表": {
            "positions": {}
        },
        "60a597f021b0094c": {
            "positions": {}
        },
        "银行_产品表": {
            "positions": {}
        },
        "d9e4f5d7dbf26f1d": {
            "positions": {}
        },
        "银行_财务分析事实表": {
            "positions": {}
        },
        "分界口货车出入情况": {
            "positions": {}
        },
        "化工_库存展示": {
            "positions": {}
        },
        "门店信息": {
            "positions": {}
        },
        "互联网_用户信息表": {
            "positions": {}
        },
        "银行_用户表": {
            "positions": {}
        },
        "449800a2c606b738": {
            "positions": {}
        },
        "59689911d00f4acc": {
            "positions": {}
        },
        "订单明细": {
            "positions": {}
        },
        "0ff0e5201aeae093": {
            "positions": {}
        },
        "银行_机构表": {
            "positions": {}
        },
        "十大热门旅游城市": {
            "positions": {}
        },
        "销售明细": {
            "positions": {}
        },
        "5350bde96d5b2e3d": {
            "positions": {}
        },
        "回款事实表": {
            "positions": {}
        },
        "2203872f396e8e87": {
            "positions": {}
        },
        "出游年龄占比": {
            "positions": {}
        },
        "c6f9c03e5833d106": {
            "positions": {}
        },
        "5335a7aba9343392": {
            "positions": {}
        },
        "北京春运迁徙数据": {
            "positions": {}
        },
        "互联网_推广渠道表": {
            "positions": {}
        },
        "49430d5df78f4e9d": {
            "positions": {}
        },
        "用户登录权限表": {
            "positions": {}
        },
        "医药_客户地区维度": {
            "positions": {}
        },
        "7cd5b786dea3e625": {
            "positions": {}
        },
        "银行_财务分析": {
            "positions": {}
        },
        "员工信息": {
            "positions": {}
        },
        "496b194c7d0aac12": {
            "positions": {}
        },
        "成本事实表": {
            "positions": {}
        },
        "样式数据三": {
            "positions": {}
        },
        "业务流水表": {
            "positions": {}
        },
        "十大热门出境游热门目的地国家": {
            "positions": {}
        },
        "895264e91b0b9130": {
            "positions": {}
        },
        "3a7a88637bf5b819": {
            "positions": {}
        },
        "69a45b2ed6606a39": {
            "positions": {}
        },
        "房间维度表": {
            "positions": {}
        },
        "银行_用户维度": {
            "positions": {}
        },
        "ec07c6f2697ab61d": {
            "positions": {}
        },
        "推广渠道维度表": {
            "positions": {}
        },
        "285583bd98221864": {
            "name": "客户跟踪表.xls",
            "positions": {
                "0d82ecf3c705f610": {
                    "col": 1,
                    "row": 9
                },
                "d6026eae2238710d": {
                    "col": 3,
                    "row": 0
                },
                "ecdb7cd3db1c03f5": {
                    "col": 1,
                    "row": 10
                },
                "437c10d8e1fa180c": {
                    "col": 1,
                    "row": 6
                },
                "e6578a305ce14371": {
                    "col": 3,
                    "row": 3
                },
                "f21454852488947c": {
                    "col": 1,
                    "row": 1
                },
                "221360f67a8a8c2b": {
                    "col": 3,
                    "row": 5
                },
                "3ab51714aa0f62c2": {
                    "col": 3,
                    "row": 12
                },
                "10ed872b4e477153": {
                    "col": 1,
                    "row": 5
                },
                "fe271dbc8f498e03": {
                    "col": 3,
                    "row": 1
                },
                "43c4e7318044ca34": {
                    "col": 1,
                    "row": 7
                },
                "b1b3ce0d4892ce1a": {
                    "col": 1,
                    "row": 8
                },
                "0ef6978f94fe1528": {
                    "col": 3,
                    "row": 2
                },
                "42846f62047dd07b": {
                    "col": 1,
                    "row": 4
                },
                "9ebeeb7420e67826": {
                    "col": 1,
                    "row": 0
                },
                "356b79271e4b21a5": {
                    "col": 3,
                    "row": 4
                },
                "21e4456f3484ec67": {
                    "col": 1,
                    "row": 2
                },
                "c29bf88c17ced5d2": {
                    "col": 1,
                    "row": 3
                },
                "e603b8f59c85f664": {
                    "col": 1,
                    "row": 11
                },
                "fd51e15c8b12df1b": {
                    "col": 1,
                    "row": 12
                },
                "1274d010aa942d7f": {
                    "col": 3,
                    "row": 6
                }
            },
            "excelFullName": "561c8c9d-9815-4942-97e1-39972eb1105e客户跟踪表.xls"
        },
        "客户维度表": {
            "positions": {}
        },
        "项目维度表": {
            "positions": {}
        },
        "供应商信息表": {
            "positions": {}
        },
        "样式数据一": {
            "positions": {}
        },
        "访问阶段统计事实表": {
            "positions": {}
        },
        "0e3a51a985e19c13": {
            "positions": {}
        },
        "银行_用户维度表": {
            "positions": {}
        },
        "品牌维度": {
            "positions": {}
        },
        "合同事实表": {
            "positions": {}
        },
        "化工_产品收入率趋势": {
            "positions": {}
        },
        "客户信息": {
            "positions": {}
        },
        "库存事实表": {
            "positions": {}
        },
        "雇员": {
            "positions": {}
        },
        "d7071d6db9cc2c60": {
            "positions": {}
        },
        "化工_能耗指标趋势": {
            "positions": {}
        },
        "用户信息维度表": {
            "positions": {}
        },
        "访问统计事实表": {
            "positions": {}
        },
        "地区维度表": {
            "positions": {}
        },
        "销售活动": {
            "positions": {}
        },
        "b3cfcd3bb986d595": {
            "positions": {}
        },
        "十大文化古镇": {
            "positions": {}
        },
        "区域信息": {
            "positions": {}
        },
        "bd67e3668d2b9f7f": {
            "positions": {}
        },
        "e5567c96ebe1a76a": {
            "positions": {}
        },
        "租赁_车辆租赁业务": {
            "positions": {}
        },
        "YEWU_DEV": {
            "positions": {}
        },
        "化工_生成进度表展示": {
            "positions": {}
        },
        "浏览器占比变化--雷达图": {
            "positions": {}
        },
        "宽带业务": {
            "positions": {}
        },
        "机构表": {
            "positions": {}
        },
        "回款维度表": {
            "positions": {}
        },
        "签约事实表": {
            "positions": {}
        },
        "供应商产品表": {
            "positions": {}
        },
        "059b1089fbc3009f": {
            "positions": {}
        },
        "互联网_地区维度表": {
            "positions": {}
        },
        "西安兰特雨量监测数据": {
            "positions": {}
        },
        "fd402af9241d1fc7": {
            "positions": {}
        },
        "银行_机构维度表": {
            "positions": {}
        },
        "全国环境监测数据": {
            "positions": {}
        },
        "品牌": {
            "positions": {}
        },
        "雇员2": {
            "positions": {}
        },
        "合同回款事实": {
            "positions": {}
        },
        "合同的回款信息": {
            "positions": {}
        },
        "374d16460ae4fa2d": {
            "positions": {}
        },
        "出境方式占比": {
            "positions": {}
        },
        "南京苏果营业数据": {
            "positions": {}
        },
        "医药_产品维度表": {
            "positions": {}
        },
        "分公司维度表": {
            "positions": {}
        },
        "产品名称维度": {
            "positions": {}
        },
        "银行_业务维度表": {
            "positions": {}
        },
        "销售员信息": {
            "positions": {}
        },
        "合同维度表": {
            "positions": {}
        },
        "门店维度": {
            "positions": {}
        },
        "医药_库存周转事实表": {
            "positions": {}
        },
        "浏览器占比变化": {
            "positions": {}
        },
        "样式数据二": {
            "positions": {}
        },
        "ed2bb18dc2816686": {
            "positions": {}
        },
        "48fd762d07476654": {
            "positions": {}
        },
        "cc423e3f4f6087d7": {
            "positions": {}
        },
        "合同信息": {
            "positions": {}
        },
        "b851925be343de13": {
            "positions": {}
        },
        "热门景区门票预定TOP20": {
            "positions": {}
        },
        "6567d6bd874e68e6": {
            "positions": {}
        },
        "b71bcaeb473fe09b": {
            "positions": {}
        },
        "品类": {
            "positions": {}
        },
        "银行_业务表": {
            "positions": {}
        },
        "9d7527938673513d": {
            "positions": {}
        },
        "02ef11852d392bbf": {
            "positions": {}
        },
        "化工_设备运行状况展示": {
            "positions": {}
        },
        "97f3b599ce21a369": {
            "positions": {}
        },
        "646e282ddbd7438c": {
            "positions": {}
        },
        "区域维度表": {
            "positions": {}
        },
        "化工_原料成本趋势展示": {
            "positions": {}
        },
        "c80b9d2802629667": {
            "positions": {}
        },
        "银行_产品维度表": {
            "positions": {}
        },
        "0de3e944c596fd17": {
            "positions": {}
        },
        "互联网_访问阶段统计": {
            "positions": {}
        },
        "订单": {
            "positions": {}
        },
        "fc0a1d24895dd938": {
            "positions": {}
        },
        "9c6edbb23d486261": {
            "positions": {}
        },
        "分公司信息": {
            "positions": {}
        },
        "品类维度": {
            "positions": {}
        },
        "销售员维度表": {
            "positions": {}
        },
        "ExcelView之客户跟踪表": {
            "name": "客户跟踪表.xls",
            "positions": {
                "ExcelView之客户跟踪表/其他投资事业": {
                    "col": 1,
                    "row": 5
                },
                "ExcelView之客户跟踪表/负责人": {
                    "col": 1,
                    "row": 12
                },
                "ExcelView之客户跟踪表/资本额": {
                    "col": 3,
                    "row": 1
                },
                "ExcelView之客户跟踪表/最近交易数据跟踪": {
                    "col": 1,
                    "row": 9
                },
                "ExcelView之客户跟踪表/传真": {
                    "col": 3,
                    "row": 3
                },
                "ExcelView之客户跟踪表/付款方式": {
                    "col": 3,
                    "row": 5
                },
                "ExcelView之客户跟踪表/客户名称": {
                    "col": 1,
                    "row": 1
                },
                "ExcelView之客户跟踪表/收款记录": {
                    "col": 3,
                    "row": 6
                },
                "ExcelView之客户跟踪表/主要来往银行": {
                    "col": 1,
                    "row": 4
                },
                "ExcelView之客户跟踪表/电话": {
                    "col": 3,
                    "row": 2
                },
                "ExcelView之客户跟踪表/信用评定": {
                    "col": 1,
                    "row": 11
                },
                "ExcelView之客户跟踪表/营业类型": {
                    "col": 1,
                    "row": 3
                },
                "ExcelView之客户跟踪表/客户意见": {
                    "col": 1,
                    "row": 10
                },
                "ExcelView之客户跟踪表/地址": {
                    "col": 1,
                    "row": 2
                },
                "ExcelView之客户跟踪表/平均每日营业额": {
                    "col": 3,
                    "row": 4
                },
                "ExcelView之客户跟踪表/主要业务往来": {
                    "col": 1,
                    "row": 6
                },
                "ExcelView之客户跟踪表/最近与本公司来往重要记录": {
                    "col": 1,
                    "row": 8
                },
                "ExcelView之客户跟踪表/客户ID": {
                    "col": 1,
                    "row": 0
                },
                "ExcelView之客户跟踪表/成立日期": {
                    "col": 3,
                    "row": 0
                },
                "ExcelView之客户跟踪表/填表人": {
                    "col": 3,
                    "row": 12
                },
                "ExcelView之客户跟踪表/与本公司来往日期": {
                    "col": 1,
                    "row": 7
                }
            },
            "excelFullName": "9f3d8607-2cb1-4f98-8bb1-b21bedaef28c客户跟踪表.xls"
        },
        "ce975e2593f4a39d": {
            "positions": {}
        },
        "租赁_存量业务": {
            "positions": {}
        },
        "合同回款事实表": {
            "positions": {}
        },
        "f4215f38743f366f": {
            "positions": {}
        },
        "4253b36903b20366": {
            "positions": {}
        },
        "产品": {
            "positions": {}
        },
        "产品名称": {
            "positions": {}
        },
        "产品维度表": {
            "positions": {}
        },
        "0b308b67e3e67b86": {
            "positions": {}
        },
        "939b4e4b5db1989c": {
            "positions": {}
        },
        "人员变动表": {
            "positions": {}
        },
        "80f3a45c448aedce": {
            "positions": {}
        },
        "流向": {
            "positions": {}
        },
        "销售事实表": {
            "positions": {}
        },
        "化工_重大事件明细表": {
            "positions": {}
        },
        "ec11ef89875aeab9": {
            "positions": {}
        },
        "af0afc4d56eec2fa": {
            "positions": {}
        },
        "f6bafba1dcac9643": {
            "positions": {}
        }
    },
    timeZone: {
        "offset": 28800000
    }
};
Date.timeZone = Pool.timeZone.offset;

Pool.foreignRelations = {};

for (var i in Pool.relations) {
    for (var j in Pool.relations[i]) {
        Pool.foreignRelations[j] = Pool.foreignRelations[j] || {};
        Pool.foreignRelations[j][i] = Pool.relations[i][j];
    }
}