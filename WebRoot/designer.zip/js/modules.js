BICst.CONF_ETL_DATA_SET_EMPTY_TIP="data_set_empty_tip";BICst.CONF_ETL_DATA_SET_ONLY_ONE_TIP="data_set_only_one_tip";BICst.CONF_ETL_DATA_SET_PANE="data_set_pane";BICst.CONF_ETL_SET_EMPTY_TIP="etl_empty_tip";BICst.CONF_ETL_SET_PANE="etl_set_pane";BICst.DASHBOARD_TOOLBAR_SAVEAS=1;BICst.DASHBOARD_TOOLBAR_UNDO=2;BICst.DASHBOARD_TOOLBAR_REDO=3;BICst.DETAIL_PACKAGES_FIELD=1;BICst.DETAIL_DIMENSION_REUSE=2;BICst.DETAIL_TAB_TYPE_DATA=1;BICst.DETAIL_TAB_STYLE=2;BICst.ETL_MANAGE_TABLE_NONE=-1;BICst.ETL_MANAGE_TABLE_PREVIEW=0;
BICst.ETL_MANAGE_TABLE_ADD_FIELD=1;BICst.ETL_MANAGE_TABLE_JOIN=2;BICst.ETL_MANAGE_TABLE_UNION=3;BICst.ETL_MANAGE_TABLE_CONVERT=4;BICst.ETL_MANAGE_TABLE_PARTIAL=5;BICst.ETL_MANAGE_TABLE_FILTER=6;BICst.ETL_MANAGE_TABLE_GROUP=7;BICst.ETL_MANAGE_TABLE_CIRCLE=8;BICst.ETL_MANAGE_TABLE_NEW_GROUP=9;BICst.ETL_MANAGE_TABLE_DELETE=10;BICst.ETL_MANAGE_EXCEL_CHANGE=11;BICst.ETL_MANAGE_SQL_CHANGE=12;BICst.DIMENSION_STRING_COMBO={ASCEND:100,DESCEND:101,SORT_BY_CUSTOM:102,GROUP_BY_VALUE:103,GROUP_BY_CUSTOM:104,FILTER:105,DT_RELATION:106,COPY:107,DELETE:108,INFO:109,ADDRESS:110,LNG_LAT:111,LNG:112,LAT:113,RENAME:114,SHOW_FIELD:115,SERIES_ACCUMULATION_ATTRIBUTE:116,NO_SERIES:117,SERIES_ACCUMULATION:118};
BICst.DIMENSION_NUMBER_COMBO={ASCEND:200,DESCEND:201,NOT_SORT:202,SORT_BY_CUSTOM:203,GROUP_BY_VALUE:204,GROUP_SETTING:205,FILTER:206,DT_RELATION:207,COPY:208,DELETE:209,INFO:210,CORDON:211,ADDRESS:212,LNG_LAT:213,LNG:214,LAT:215,RENAME:216,SHOW_FIELD:217,SERIES_ACCUMULATION_ATTRIBUTE:218,NO_SERIES:219,SERIES_ACCUMULATION:220};BICst.DIMENSION_DATE_COMBO={DATE:300,YEAR:301,QUARTER:302,MONTH:303,WEEK:304,ASCEND:305,DESCEND:306,FILTER:307,DT_RELATION:308,COPY:309,DELETE:310,INFO:31,ADDRESS:32,LNG_LAT:33,LNG:34,LAT:35,RENAME:36,SHOW_FIELD:37,SERIES_ACCUMULATION_ATTRIBUTE:38,NO_SERIES:39,SERIES_ACCUMULATION:40,YD:906,MD:907,YMDHMS:908,HOUR:909,MINUTE:910,SECOND:911,WEEK_COUNT:912,D:913,YM:914,YW:915,YMDH:916,YMDHM:917,YS:918,MORE_GROUP:919,DATE_FORMAT:920,DATE_FORMAT_CHINESE:921,DATE_FORMAT_SPLIT:922,SHOW_MISS_TIME:923};
BICst.TARGET_COMBO={SUMMERY_TYPE:400,CHART_TYPE:401,STYLE_SETTING:402,FILTER:403,DISPLAY:404,HIDDEN:405,COPY:406,DELETE:407,INFO:408,DEPEND_TYPE:409,CORDON:410,DATA_LABEL:411,DATA_LABEL_OTHER:412,DATA_IMAGE:413,RENAME:414,SHOW_FIELD:415,STYLE_AND_NUMBER_LEVEL:416};BICst.DETAIL_STRING_COMBO={FILTER:500,HYPERLINK:501,DELETE:502,INFO:503,RENAME:504,SHOW_FIELD:505};BICst.DETAIL_NUMBER_COMBO={FORM_SETTING:600,FILTER:601,HYPERLINK:602,DELETE:603,INFO:604,RENAME:605,SHOW_FIELD:606};BICst.DETAIL_DATE_COMBO={YMD:700,YMDHMS:701,YEAR:702,SEASON:703,MONTH:704,WEEK:705,FILTER:706,HYPERLINK:707,DELETE:708,INFO:709,RENAME:710,SHOW_FIELD:711,HOUR:713,MINUTE:714,SECOND:715,WEEK_COUNT:716,D:717,YM:718,YW:719,YMDH:720,YMDHM:721,YS:722,MORE_GROUP:723,DATE_FORMAT:724,DATE_FORMAT_SPLIT:725,DATE_FORMAT_CHINESE:726,SHOW_MISS_TIME:923};
BICst.DETAIL_FORMULA_COMBO={FORM_SETTING:800,UPDATE_FORMULA:801,HYPERLINK:802,DISPLAY:803,HIDDEN:804,RENAME:805,DELETE:806,INFO:807,SHOW_FIELD:808};BICst.CALCULATE_TARGET_COMBO={FORM_SETTING:900,UPDATE_TARGET:901,DISPLAY:902,HIDDEN:903,RENAME:904,COPY:905,DELETE:906,INFO:907};BICst.CONTROL_COMBO={DELETE:505,INFO:506,RENAME:507,SHOW_FIELD:508};BICst.STATISTICS_GROUP_DATE_COMBO={DATE:900,YEAR:901,QUARTER:902,MONTH:903,WEEK:904,DELETE:905,YD:906,MD:907,YMDHMS:908,HOUR:909,MINUTE:910,SECOND:911,WEEK_COUNT:912,D:913,YM:914,YW:915,YMDH:916,YMDHM:917,YS:918,No_Repeat_Count:899,DISPLAY:898,HIDDEN:897,RENAME:896,RECORD_COUNT:895,MORE_GROUP:919};
BICst.STATISTICS_GROUP_NUMBER_COMBO={SUM:906,AVG:907,MAX:908,MIN:909,No_Repeat_Count:910,DELETE:911,GROUP_SETTING:912,GROUP_BY_VALUE:913,DISPLAY:904,HIDDEN:905,RENAME:903,RECORD_COUNT:902};BICst.STATISTICS_GROUP_STRING_COMBO={GROUP_BY_VALUE:913,GROUP_BY_CUSTOM:914,No_Repeat_Count:915,DELETE:916,APPEND:917,DISPLAY:912,HIDDEN:911,RENAME:910,RECORD_COUNT:909};BICst.CHART_VIEW_STYLE_BAR=1;BICst.CHART_VIEW_STYLE_ACCUMULATED_BAR=2;BICst.CHART_VIEW_STYLE_LINE=3;BICst.CHART_VIEW_STYLE_SQUARE=4;BICst.FILTER_PANE_CLICK_REMOVE=-1;
BICst.FILTER_PANE_CLICK_EXPANDER=1;BICst.FILTER_PANE_CLICK_ITEM=2;BICst.UPDATE_FREQUENCY_MONTH={};BICst.UPDATE_FREQUENCY_MONTH.JANUARY=1;BICst.UPDATE_FREQUENCY_MONTH.FEBRUARY=2;BICst.UPDATE_FREQUENCY_MONTH.MARCH=3;BICst.UPDATE_FREQUENCY_MONTH.APRIL=4;BICst.UPDATE_FREQUENCY_MONTH.MAY=5;BICst.UPDATE_FREQUENCY_MONTH.JUNE=6;BICst.UPDATE_FREQUENCY_MONTH.JULY=7;BICst.UPDATE_FREQUENCY_MONTH.AUGUST=8;BICst.UPDATE_FREQUENCY_MONTH.SEPTEMBER=9;BICst.UPDATE_FREQUENCY_MONTH.OCTOBER=10;BICst.UPDATE_FREQUENCY_MONTH.NOVEMBER=11;
BICst.UPDATE_FREQUENCY_MONTH.DECEMBER=12;BICst.UPDATE_FREQUENCY_MONTH.ALL=[BICst.UPDATE_FREQUENCY_MONTH.JANUARY,BICst.UPDATE_FREQUENCY_MONTH.FEBRUARY,BICst.UPDATE_FREQUENCY_MONTH.MARCH,BICst.UPDATE_FREQUENCY_MONTH.APRIL,BICst.UPDATE_FREQUENCY_MONTH.MAY,BICst.UPDATE_FREQUENCY_MONTH.JUNE,BICst.UPDATE_FREQUENCY_MONTH.JULY,BICst.UPDATE_FREQUENCY_MONTH.AUGUST,BICst.UPDATE_FREQUENCY_MONTH.SEPTEMBER,BICst.UPDATE_FREQUENCY_MONTH.OCTOBER,BICst.UPDATE_FREQUENCY_MONTH.NOVEMBER,BICst.UPDATE_FREQUENCY_MONTH.DECEMBER];
BICst.UPDATE_FREQUENCY_RADIO={};BICst.UPDATE_FREQUENCY_RADIO.DAY=0;BICst.UPDATE_FREQUENCY_RADIO.WEEK=1;BICst.UPDATE_FREQUENCY_RADIO.MONTH=2;BICst.UPDATE_FREQUENCY_EVER_MONTH={};BICst.UPDATE_FREQUENCY_EVER_MONTH.ONE=1;BICst.UPDATE_FREQUENCY_EVER_MONTH.TWO=2;BICst.UPDATE_FREQUENCY_EVER_MONTH.THREE=3;BICst.UPDATE_FREQUENCY_EVER_MONTH.FOUR=4;BICst.UPDATE_FREQUENCY_EVER_MONTH.FIVE=5;BICst.UPDATE_FREQUENCY_EVER_MONTH.SIX=6;BICst.UPDATE_FREQUENCY_EVER_MONTH.SEVEN=7;BICst.UPDATE_FREQUENCY_EVER_MONTH.EIGHT=8;
BICst.UPDATE_FREQUENCY_EVER_MONTH.NINE=9;BICst.UPDATE_FREQUENCY_EVER_MONTH.Ten=10;BICst.UPDATE_FREQUENCY_EVER_MONTH.ELEVEN=11;BICst.UPDATE_FREQUENCY_EVER_MONTH.TWELVE=12;BICst.UPDATE_FREQUENCY_EVER_MONTH.THIRTEEN=13;BICst.UPDATE_FREQUENCY_EVER_MONTH.FOURTEEN=14;BICst.UPDATE_FREQUENCY_EVER_MONTH.FIFTEEN=15;BICst.UPDATE_FREQUENCY_EVER_MONTH.SIXTEEN=16;BICst.UPDATE_FREQUENCY_EVER_MONTH.SEVENTEEN=17;BICst.UPDATE_FREQUENCY_EVER_MONTH.EIGHTEEN=18;BICst.UPDATE_FREQUENCY_EVER_MONTH.NINETEEN=19;BICst.UPDATE_FREQUENCY_EVER_MONTH.TWENTY=20;
BICst.UPDATE_FREQUENCY_EVER_MONTH.TWENTYONE=21;BICst.UPDATE_FREQUENCY_EVER_MONTH.TWENTYTWO=22;BICst.UPDATE_FREQUENCY_EVER_MONTH.TWENTYTHREE=23;BICst.UPDATE_FREQUENCY_EVER_MONTH.TWENTYFOUR=24;BICst.UPDATE_FREQUENCY_EVER_MONTH.TWENTYFIVE=25;BICst.UPDATE_FREQUENCY_EVER_MONTH.TWENTYSIX=26;BICst.UPDATE_FREQUENCY_EVER_MONTH.TWENTYSEVEN=27;BICst.UPDATE_FREQUENCY_EVER_MONTH.TWENTYEIGHT=28;BICst.UPDATE_FREQUENCY_EVER_MONTH.TWENTYNINE=29;BICst.UPDATE_FREQUENCY_EVER_MONTH.THIRTY=30;BICst.UPDATE_FREQUENCY_EVER_MONTH.THIRTYONE=31;
BICst.CACHE={PACKAGE_PREFIX:"package_",REGION_COLUMN_SIZE_PREFIX:"region_column_size_",};
BICst.BROADCAST={TEST:"test_broadcast",WIDGETS_PREFIX:"widgets_",DIMENSIONS_PREFIX:"dimensions_",REFRESH_PREFIX:"refresh_",LINKAGE_PREFIX:"linkage_",LINKAGE_CLEAR_ALL:"linkage_clear_all",LINKAGE_CLEAR:"linkage_clear",RESET_PREFIX:"reset_",GLOBAL_STYLE_PREFIX:"global_style_",SRC_PREFIX:"src_",FIELD_DROP_PREFIX:"field_drop_",PACKAGE_PREFIX:"package_",DETAIL_EDIT_PREFIX:"detail_edit_",FIELD_DRAG_START:"__filed_drag_start__",FIELD_DRAG_STOP:"__field_drag_stop__",FILTER_LIST_PREFIX:"filter_list_",IMAGE_LIST_PREFIX:"image_list_",CHART_CLICK_PREFIX:"chart_click_",EXCEL_UPDATE_START:"excel_update_start_",EXCEL_UPDATE_END:"excel_update_end_",PACKAGE_EDIT_PREFIX:"package_edit_"};
BICst.FULL_WEEK_NAMES=[BI.i18nText("BI-Basic_Monday"),BI.i18nText("BI-Basic_Monday"),BI.i18nText("BI-Basic_Tuesday"),BI.i18nText("BI-Wednesday"),BI.i18nText("BI-Basic_Thursday"),BI.i18nText("BI-Basic_Friday"),BI.i18nText("BI-Basic_Saturday"),BI.i18nText("BI-Basic_Sunday")];BICst.FULL_MONTH_NAMES=[BI.i18nText("BI-Basic_January"),BI.i18nText("BI-Basic_January"),BI.i18nText("BI-Basic_February"),BI.i18nText("BI-Basic_March"),BI.i18nText("BI-Basic_April"),BI.i18nText("BI-Basic_May"),BI.i18nText("BI-Basic_June"),BI.i18nText("BI-Basic_July"),BI.i18nText("BI-Basic_August"),BI.i18nText("BI-Basic_September"),BI.i18nText("BI-Basic_October"),BI.i18nText("BI-Basic_November"),BI.i18nText("BI-Basic_December")];
BICst.FULL_QUARTER_NAMES=[BI.i18nText("BI-Quarter_1"),BI.i18nText("BI-Quarter_1"),BI.i18nText("BI-Quarter_2"),BI.i18nText("BI-Quarter_3"),BI.i18nText("BI-Quarter_4")];BICst.DASHBOARD_LAYOUT_ARRAY=[{text:BI.i18nText("BI-Grid_Layout"),value:BICst.DASHBOARD_LAYOUT_GRID},{text:BI.i18nText("BI-Free_Layout"),value:BICst.DASHBOARD_LAYOUT_FREE}];BICst.DETAIL_DATA_STYLE_TAB=[{text:BI.i18nText("BI-Type_Data"),value:BICst.DETAIL_TAB_TYPE_DATA},{text:BI.i18nText("BI-Basic_Attr"),value:BICst.DETAIL_TAB_STYLE}];
BICst.DETAIL_FIELD_REUSE_TAB=[{text:BI.i18nText("BI-Package_Field"),value:BICst.DETAIL_PACKAGES_FIELD},{text:BI.i18nText("BI-Reuse_Field"),value:BICst.DETAIL_DIMENSION_REUSE}];BICst.DASHBOARD_TOOLBAR=[{text:BI.i18nText("BI-Save_As"),value:BICst.DASHBOARD_TOOLBAR_SAVEAS,title:BI.i18nText("BI-Save_As"),cls:"toolbar-save-font"},{text:BI.i18nText("BI-Undo"),value:BICst.DASHBOARD_TOOLBAR_UNDO,title:BI.i18nText("BI-Undo"),cls:"toolbar-undo-font"},{text:BI.i18nText("BI-Basic_Redo"),value:BICst.DASHBOARD_TOOLBAR_REDO,title:BI.i18nText("BI-Basic_Redo"),cls:"toolbar-redo-font"}];
BICst.DASHBOARD_WIDGETS=[[{text:BI.i18nText("BI-Group_Table"),title:BI.i18nText("BI-Group_Table"),value:BICst.WIDGET.TABLE,cls:"drag-group-icon",children:[{text:BI.i18nText("BI-Group_Table"),title:BI.i18nText("BI-Group_Table"),value:BICst.WIDGET.TABLE,cls:"drag-group-icon"},{text:BI.i18nText("BI-Cross_Table"),title:BI.i18nText("BI-Cross_Table"),value:BICst.WIDGET.CROSS_TABLE,cls:"drag-cross-icon"},{text:BI.i18nText("BI-Complex_Table"),title:BI.i18nText("BI-Complex_Table"),value:BICst.WIDGET.COMPLEX_TABLE,cls:"drag-complex-icon"}]},{text:BI.i18nText("BI-Column_Chart"),title:BI.i18nText("BI-Column_Chart"),value:BICst.WIDGET.AXIS,cls:"drag-axis-icon",children:[{text:BI.i18nText("BI-Column_Chart"),title:BI.i18nText("BI-Column_Chart"),value:BICst.WIDGET.AXIS,cls:"drag-axis-icon"},{text:BI.i18nText("BI-Stacked_Chart"),title:BI.i18nText("BI-Stacked_Chart"),value:BICst.WIDGET.ACCUMULATE_AXIS,cls:"drag-axis-accu-icon"},{text:BI.i18nText("BI-Percent_Accumulate_Axis"),title:BI.i18nText("BI-Percent_Accumulate_Axis"),value:BICst.WIDGET.PERCENT_ACCUMULATE_AXIS,cls:"drag-axis-percent-accu-icon"},{text:BI.i18nText("BI-Compare_Axis"),title:BI.i18nText("BI-Compare_Axis"),value:BICst.WIDGET.COMPARE_AXIS,cls:"drag-axis-compare-icon"},{text:BI.i18nText("BI-Fall_Axis"),title:BI.i18nText("BI-Fall_Axis"),value:BICst.WIDGET.FALL_AXIS,cls:"drag-axis-fall-icon"}]},{text:BI.i18nText("BI-Bar_Chart"),title:BI.i18nText("BI-Bar_Chart"),value:BICst.WIDGET.BAR,cls:"drag-bar-icon",children:[{text:BI.i18nText("BI-Bar_Chart"),title:BI.i18nText("BI-Bar_Chart"),value:BICst.WIDGET.BAR,cls:"drag-bar-icon"},{text:BI.i18nText("BI-Stacked_Bar_Chart"),title:BI.i18nText("BI-Stacked_Bar_Chart"),value:BICst.WIDGET.ACCUMULATE_BAR,cls:"drag-bar-accu-icon"},{text:BI.i18nText("BI-Compare_Bar"),title:BI.i18nText("BI-Compare_Bar"),value:BICst.WIDGET.COMPARE_BAR,cls:"drag-bar-compare-icon"}]},{text:BI.i18nText("BI-Line_Chart"),title:BI.i18nText("BI-Line_Chart"),value:BICst.WIDGET.LINE,cls:"drag-line-icon"},{text:BI.i18nText("BI-Area_Chart"),title:BI.i18nText("BI-Area_Chart"),value:BICst.WIDGET.AREA,cls:"drag-area-icon",children:[{text:BI.i18nText("BI-Area_Chart"),title:BI.i18nText("BI-Area_Chart"),value:BICst.WIDGET.AREA,cls:"drag-area-icon"},{text:BI.i18nText("BI-Accumulate_Area"),title:BI.i18nText("BI-Accumulate_Area"),value:BICst.WIDGET.ACCUMULATE_AREA,cls:"drag-area-accu-icon"},{text:BI.i18nText("BI-Percent_Accumulate_Area"),title:BI.i18nText("BI-Percent_Accumulate_Area"),value:BICst.WIDGET.PERCENT_ACCUMULATE_AREA,cls:"drag-area-percent-accu-icon"},{text:BI.i18nText("BI-Compare_Area"),title:BI.i18nText("BI-Compare_Area"),value:BICst.WIDGET.COMPARE_AREA,cls:"drag-area-compare-icon"},{text:BI.i18nText("BI-Compare_Range_Area"),title:BI.i18nText("BI-Compare_Range_Area"),value:BICst.WIDGET.RANGE_AREA,cls:"drag-area-range-icon"}]},{text:BI.i18nText("BI-Combine_Chart"),title:BI.i18nText("BI-Combine_Chart"),value:BICst.WIDGET.COMBINE_CHART,cls:"drag-combine-icon",children:[{text:BI.i18nText("BI-Combine_Chart"),title:BI.i18nText("BI-Combine_Chart"),value:BICst.WIDGET.COMBINE_CHART,cls:"drag-combine-icon"},{text:BI.i18nText("BI-Multi_Axis_Combine_Chart"),title:BI.i18nText("BI-Multi_Axis_Combine_Chart"),value:BICst.WIDGET.MULTI_AXIS_COMBINE_CHART,cls:"drag-combine-mult-icon"}]},{text:BI.i18nText("BI-Pie_Chart"),title:BI.i18nText("BI-Pie_Chart"),value:BICst.WIDGET.PIE,cls:"drag-pie-icon",children:[{text:BI.i18nText("BI-Pie_Chart"),title:BI.i18nText("BI-Pie_Chart"),value:BICst.WIDGET.PIE,cls:"drag-pie-icon",},{text:BI.i18nText("BI-Multi_Pie_Chart"),title:BI.i18nText("BI-Multi_Pie_Chart"),value:BICst.WIDGET.MULTI_PIE,cls:"drag-multi-pie-icon",}]},{text:BI.i18nText("BI-Donut_Chart"),title:BI.i18nText("BI-Donut_Chart"),value:BICst.WIDGET.DONUT,cls:"drag-donut-icon"},{text:BI.i18nText("BI-Basic_Map"),title:BI.i18nText("BI-Basic_Map"),value:BICst.WIDGET.MAP,cls:"drag-map-china-icon"},{text:BI.i18nText("BI-GIS_Map"),title:BI.i18nText("BI-GIS_Map"),value:BICst.WIDGET.GIS_MAP,cls:"drag-map-gis-icon",children:[{text:BI.i18nText("BI-Point_Map"),title:BI.i18nText("BI-Point_Map"),value:BICst.WIDGET.GIS_MAP,cls:"drag-map-gis-icon"},{text:BI.i18nText("BI-Heat_Map"),title:BI.i18nText("BI-Heat_Map"),value:BICst.WIDGET.HEAT_MAP,cls:"drag-heat-map-icon"},{text:BI.i18nText("BI-Line_Map"),title:BI.i18nText("BI-Line_Map"),value:BICst.WIDGET.LINE_MAP,cls:"drag-line-map-icon"}]},{text:BI.i18nText("BI-Dashboard_Chart"),title:BI.i18nText("BI-Dashboard_Chart"),value:BICst.WIDGET.DASHBOARD,cls:"drag-dashboard-icon"},{text:BI.i18nText("BI-Basic_Radar"),title:BI.i18nText("BI-Basic_Radar"),value:BICst.WIDGET.RADAR,cls:"drag-radar-icon",children:[{text:BI.i18nText("BI-Basic_Radar"),title:BI.i18nText("BI-Basic_Radar"),value:BICst.WIDGET.RADAR,cls:"drag-radar-icon"},{text:BI.i18nText("BI-Accumulate_Radar"),title:BI.i18nText("BI-Accumulate_Radar"),value:BICst.WIDGET.ACCUMULATE_RADAR,cls:"drag-radar-accu-icon"}]},{text:BI.i18nText("BI-Dot_Chart"),title:BI.i18nText("BI-Dot_Chart"),value:BICst.WIDGET.DOT,cls:"drag-dot-icon"},{text:BI.i18nText("BI-Word_Cloud"),title:BI.i18nText("BI-Word_Cloud"),value:BICst.WIDGET.WORD_CLOUD,cls:"drag-word-cloud-icon"},{text:BI.i18nText("BI-Force_Bubble"),title:BI.i18nText("BI-Force_Bubble"),value:BICst.WIDGET.FORCE_BUBBLE,cls:"drag-bubble-force-icon"},{text:BI.i18nText("BI-Funnel_Chart"),title:BI.i18nText("BI-Funnel_Chart"),value:BICst.WIDGET.FUNNEL,cls:"drag-funnel-icon"},{text:BI.i18nText("BI-Rect_Tree_Chart"),title:BI.i18nText("BI-Rect_Tree_Chart"),value:BICst.WIDGET.RECT_TREE,cls:"drag-rect-tree-icon"}],[{text:BI.i18nText("BI-Detail_Table"),title:BI.i18nText("BI-Detail_Table"),value:BICst.WIDGET.DETAIL,cls:"drag-detail-icon"},{text:BI.i18nText("BI-Text_Widget"),title:BI.i18nText("BI-Text_Widget"),value:BICst.WIDGET.CONTENT,cls:"drag-input-icon"},{text:BI.i18nText("BI-Image_Widget"),title:BI.i18nText("BI-Image_Widget"),value:BICst.WIDGET.IMAGE,cls:"drag-image-icon"},{text:BI.i18nText("BI-Web_Widget"),title:BI.i18nText("BI-Web_Widget"),value:BICst.WIDGET.WEB,cls:"drag-web-icon"}],[{text:BI.i18nText("BI-Text_Control"),title:BI.i18nText("BI-Text_Control_Title"),value:BICst.WIDGET.STRING,cls:"drag-string-icon",children:[{text:BI.i18nText("BI-Text_Control"),title:BI.i18nText("BI-Text_Control_Title"),value:BICst.WIDGET.STRING,cls:"drag-string-icon"},{text:BI.i18nText("BI-List_Label_Con"),title:BI.i18nText("BI-List_Label_Con_Title"),value:BICst.WIDGET.LIST_LABEL,cls:"drag-list-label-icon"},{text:BI.i18nText("BI-String_List"),title:BI.i18nText("BI-String_List_Title"),value:BICst.WIDGET.STRING_LIST,cls:"drag-string-list-icon"}]},{text:BI.i18nText("BI-Numeric_Control"),title:BI.i18nText("BI-Numeric_Control_Title"),value:BICst.WIDGET.NUMBER,cls:"drag-number-icon",children:[{text:BI.i18nText("BI-Numeric_Control"),title:BI.i18nText("BI-Numeric_Control_Title"),value:BICst.WIDGET.NUMBER,cls:"drag-number-icon"},{text:BI.i18nText("BI-Double_Value_Slider"),title:BI.i18nText("BI-Double_Value_Slider_Title"),value:BICst.WIDGET.INTERVAL_SLIDER,cls:"drag-interval-slider-icon"}]},{text:BI.i18nText("BI-Tree_Control"),title:BI.i18nText("BI-Tree_Control_Title"),value:BICst.WIDGET.TREE,cls:"drag-tree-icon",children:[{text:BI.i18nText("BI-Tree_Control"),title:BI.i18nText("BI-Tree_Control_Title"),value:BICst.WIDGET.TREE,cls:"drag-tree-icon"},{text:BI.i18nText("BI-Tree_Label_Con"),title:BI.i18nText("BI-Tree_Label_Con_Title"),value:BICst.WIDGET.TREE_LABEL,cls:"drag-tree-label-icon"},{text:BI.i18nText("BI-Tree_List"),title:BI.i18nText("BI-Tree_List_Title"),value:BICst.WIDGET.TREE_LIST,cls:"drag-tree-list-icon"}]},{text:BI.i18nText("BI-Date_Range_Control"),title:BI.i18nText("BI-Date_Range_Control_Title"),value:BICst.WIDGET.DATE,cls:"drag-date-range-icon",children:[{text:BI.i18nText("BI-Year_Control"),title:BI.i18nText("BI-Year_Control_Title"),value:BICst.WIDGET.YEAR,cls:"drag-year-icon"},{text:BI.i18nText("BI-Year_Month_Con"),title:BI.i18nText("BI-Year_Month_Con_Title"),value:BICst.WIDGET.MONTH,cls:"drag-year-month-icon"},{text:BI.i18nText("BI-Year_Quarter_Con"),title:BI.i18nText("BI-Year_Quarter_Con_Title"),value:BICst.WIDGET.QUARTER,cls:"drag-year-season-icon"},{text:BI.i18nText("BI-Date_Control"),title:BI.i18nText("BI-Date_Control_Title"),value:BICst.WIDGET.YMD,cls:"drag-ymd-icon"},{text:BI.i18nText("BI-Date_Pane_Control"),title:BI.i18nText("BI-Date_Pane_Control_Title"),value:BICst.WIDGET.DATE_PANE,cls:"drag-date-icon"},{text:BI.i18nText("BI-Date_Range_Control"),title:BI.i18nText("BI-Date_Range_Control_Title"),value:BICst.WIDGET.DATE,cls:"drag-date-range-icon"}]},{text:BI.i18nText("BI-General_Query"),title:BI.i18nText("BI-General_Query_Title"),value:BICst.WIDGET.GENERAL_QUERY,cls:"drag-general-query-icon"},{text:BI.i18nText("BI-Query_Button"),title:BI.i18nText("BI-Query_Button"),value:BICst.WIDGET.QUERY,cls:"drag-query-icon"},{text:BI.i18nText("BI-Reset_Button"),title:BI.i18nText("BI-Reset_Button"),value:BICst.WIDGET.RESET,cls:"drag-reset-icon"}]];
BICst.SUSPENSION_MAP_TYPE=[{text:BI.i18nText("BI-Suspension_Bubble_Chart"),value:BICst.WIDGET.BUBBLE,cls:"dot-e-font"},{text:BI.i18nText("BI-Suspension_Pie_Chart"),value:BICst.WIDGET.PIE,cls:"dot-e-font"},{text:BI.i18nText("BI-Suspension_Column_Chart"),value:BICst.WIDGET.AXIS,cls:"dot-e-font"}];BICst.STATISTICS_WIDGET_SETCOMBO_ITEMS=[{value:BICst.DASHBOARD_WIDGET_EXPAND,text:BI.i18nText("BI-Detailed_Setting"),extraCls:"dashboard-widget-combo-detail-set-font"},{value:BICst.DASHBOARD_WIDGET_EXCEL,text:BI.i18nText("BI-Export_As_Excel"),extraCls:"dashboard-widget-combo-export-excel-font"},{value:BICst.DASHBOARD_WIDGET_COPY,text:BI.i18nText("BI-Basic_Copy"),extraCls:"copy-h-font"},{value:BICst.DASHBOARD_WIDGET_DELETE,text:BI.i18nText("BI-Delete_Component"),extraCls:"delete-h-font"}];
BICst.TIME_CONTROL_SETCOMBO_ITEMS=[[{value:BICst.DASHBOARD_WIDGET_EXPAND,text:BI.i18nText("BI-Detailed_Setting"),cls:"widget-combo-expand-font"}],[{value:BICst.DASHBOARD_CONTROL_CLEAR,text:BI.i18nText("BI-Clear_Selected_Value"),cls:"widget-combo-clear-font"}],[{value:BICst.DASHBOARD_WIDGET_RENAME,text:BI.i18nText("BI-Basic_Rename"),cls:"widget-combo-rename-edit-font"}],[{value:BICst.DASHBOARD_WIDGET_COPY,text:BI.i18nText("BI-Basic_Copy"),cls:"widget-combo-copy-font"}],[{value:BICst.DASHBOARD_WIDGET_DELETE,text:BI.i18nText("BI-Delete_Control"),cls:"widget-combo-delete-font"}]];
BICst.NUMBER_CONTROL_SETCOMBO_ITEMS=[[{value:BICst.DASHBOARD_WIDGET_EXPAND,text:BI.i18nText("BI-Detailed_Setting"),cls:"widget-combo-expand-font"}],[{value:BICst.DASHBOARD_CONTROL_CLEAR,text:BI.i18nText("BI-Clear_Selected_Value"),cls:"widget-combo-clear-font"}],[{value:BICst.DASHBOARD_WIDGET_RENAME,text:BI.i18nText("BI-Basic_Rename"),cls:"widget-combo-rename-edit-font"}],[{value:BICst.DASHBOARD_WIDGET_COPY,text:BI.i18nText("BI-Basic_Copy"),cls:"widget-combo-copy-font"}],[{value:BICst.DASHBOARD_WIDGET_DELETE,text:BI.i18nText("BI-Delete_Control"),cls:"widget-combo-delete-font"}]];
BICst.SINGLE_SLIDER_CONTROL_SETCOMBO_ITEMS=[[{value:BICst.DASHBOARD_WIDGET_EXPAND,text:BI.i18nText("BI-Detailed_Setting"),cls:"widget-combo-expand-font"}],[{value:BICst.DASHBOARD_WIDGET_RENAME,text:BI.i18nText("BI-Basic_Rename"),cls:"widget-combo-rename-edit-font"}],[{value:BICst.DASHBOARD_WIDGET_COPY,text:BI.i18nText("BI-Basic_Copy"),cls:"widget-combo-copy-font"}],[{value:BICst.DASHBOARD_WIDGET_DELETE,text:BI.i18nText("BI-Delete_Control"),cls:"widget-combo-delete-font"}]];BICst.GENERNAL_QUERY_CONTROL_SETCOMBO_ITEMS=[[{value:BICst.DASHBOARD_CONTROL_CLEAR,text:BI.i18nText("BI-Clear_Selected_Value"),cls:"widget-combo-clear-font"}],[{value:BICst.DASHBOARD_WIDGET_DELETE,text:BI.i18nText("BI-Delete_Control"),cls:"widget-combo-delete-font"}]];
BICst.ETL_MANAGE_ITEMS=[{text:BI.i18nText("BI-Basic_Preview")+"...",title:BI.i18nText("BI-Basic_Preview")+"...",value:BICst.ETL_MANAGE_TABLE_PREVIEW},{text:BI.i18nText("BI-Table_Add_Formula"),title:BI.i18nText("BI-Table_Add_Formula"),value:BICst.ETL_MANAGE_TABLE_ADD_FIELD},{text:BI.i18nText("BI-Join_With_Table"),title:BI.i18nText("BI-Join_With_Table"),value:BICst.ETL_MANAGE_TABLE_JOIN},{text:BI.i18nText("BI-Union_With_Table"),title:BI.i18nText("BI-Union_With_Table"),value:BICst.ETL_MANAGE_TABLE_UNION},{text:BI.i18nText("BI-To_Convert_Column_Row"),title:BI.i18nText("BI-To_Convert_Column_Row"),value:BICst.ETL_MANAGE_TABLE_CONVERT},{text:BI.i18nText("BI-Use_Part_Fields"),title:BI.i18nText("BI-Use_Part_Fields"),value:BICst.ETL_MANAGE_TABLE_PARTIAL},{text:BI.i18nText("BI-Table_Filter"),title:BI.i18nText("BI-Table_Filter"),value:BICst.ETL_MANAGE_TABLE_FILTER},{text:BI.i18nText("BI-Table_Grouping_Count"),title:BI.i18nText("BI-Table_Grouping_Count"),value:BICst.ETL_MANAGE_TABLE_GROUP},{text:BI.i18nText("BI-Table_Self_Cycle"),title:BI.i18nText("BI-Table_Self_Cycle"),value:BICst.ETL_MANAGE_TABLE_CIRCLE},{text:BI.i18nText("BI-Table_Add_Grouping_Column"),title:BI.i18nText("BI-Table_Add_Grouping_Column"),value:BICst.ETL_MANAGE_TABLE_NEW_GROUP},{text:BI.i18nText("BI-Basic_Remove"),title:BI.i18nText("BI-Basic_Remove"),value:BICst.ETL_MANAGE_TABLE_DELETE}];
BICst.TARGET_FILTER_STRING_COMBO=[[{text:BI.i18nText("BI-Basic_In"),value:BICst.TARGET_FILTER_STRING.BELONG_VALUE,cls:"dot-e-font"},{text:BI.i18nText("BI-Not_In"),value:BICst.TARGET_FILTER_STRING.NOT_BELONG_VALUE,cls:"dot-e-font"}],[{text:BI.i18nText("BI-Basic_Contain"),value:BICst.TARGET_FILTER_STRING.CONTAIN,cls:"dot-e-font"},{text:BI.i18nText("BI-Not_Contain"),value:BICst.TARGET_FILTER_STRING.NOT_CONTAIN,cls:"dot-e-font"}],[{text:BI.i18nText("BI-Is_Null"),value:BICst.TARGET_FILTER_STRING.IS_NULL,cls:"dot-e-font"},{text:BI.i18nText("BI-Not_Null"),value:BICst.TARGET_FILTER_STRING.NOT_NULL,cls:"dot-e-font"}],[{text:BI.i18nText("BI-Begin_With"),value:BICst.TARGET_FILTER_STRING.BEGIN_WITH,cls:"dot-e-font"},{text:BI.i18nText("BI-End_With"),value:BICst.TARGET_FILTER_STRING.END_WITH,cls:"dot-e-font"}]];
BICst.TARGET_FILTER_NUMBER_COMBO=[[{text:BI.i18nText("BI-Basic_In"),value:BICst.TARGET_FILTER_NUMBER.BELONG_VALUE,cls:"dot-e-font"},{text:BI.i18nText("BI-Not_In"),value:BICst.TARGET_FILTER_NUMBER.NOT_BELONG_VALUE,cls:"dot-e-font"}],[{text:BI.i18nText("BI-Basic_Equal"),value:BICst.TARGET_FILTER_NUMBER.EQUAL_TO,cls:"dot-e-font"},{text:BI.i18nText("BI-Not_Equal_To"),value:BICst.TARGET_FILTER_NUMBER.NOT_EQUAL_TO,cls:"dot-e-font"}],[{text:BI.i18nText("BI-Is_Null"),value:BICst.TARGET_FILTER_NUMBER.IS_NULL,cls:"dot-e-font"},{text:BI.i18nText("BI-Not_Null"),value:BICst.TARGET_FILTER_NUMBER.NOT_NULL,cls:"dot-e-font"}]];
BICst.BEFORE_AFTER_COMBO=[{text:BI.i18nText("BI-Qian_First"),value:0},{text:BI.i18nText("BI-Hou_Last"),value:1}];BICst.DIMENSION_FILTER_STRING_COMBO=[[{text:BI.i18nText("BI-Basic_In"),value:BICst.DIMENSION_FILTER_STRING.BELONG_VALUE,cls:"dot-e-font"},{text:BI.i18nText("BI-Not_In"),value:BICst.DIMENSION_FILTER_STRING.NOT_BELONG_VALUE,cls:"dot-e-font"}],[{text:BI.i18nText("BI-Basic_Contain"),value:BICst.DIMENSION_FILTER_STRING.CONTAIN,cls:"dot-e-font"},{text:BI.i18nText("BI-Not_Contain"),value:BICst.DIMENSION_FILTER_STRING.NOT_CONTAIN,cls:"dot-e-font"}],[{text:BI.i18nText("BI-Is_Null"),value:BICst.DIMENSION_FILTER_STRING.IS_NULL,cls:"dot-e-font"},{text:BI.i18nText("BI-Not_Null"),value:BICst.DIMENSION_FILTER_STRING.NOT_NULL,cls:"dot-e-font"}],[{text:BI.i18nText("BI-Begin_With"),value:BICst.DIMENSION_FILTER_STRING.BEGIN_WITH,cls:"dot-e-font"},{text:BI.i18nText("BI-End_With"),value:BICst.DIMENSION_FILTER_STRING.END_WITH,cls:"dot-e-font"}],[{text:BI.i18nText("BI-Top_N"),value:BICst.DIMENSION_FILTER_STRING.TOP_N,cls:"dot-e-font"},{text:BI.i18nText("BI-Last_N"),value:BICst.DIMENSION_FILTER_STRING.BOTTOM_N,cls:"dot-e-font"}]];
BICst.DIMENSION_TAR_FILTER_NUMBER_COMBO=[[{text:BI.i18nText("BI-Basic_In"),value:BICst.DIMENSION_FILTER_NUMBER.BELONG_VALUE,cls:"dot-e-font"},{text:BI.i18nText("BI-Not_In"),value:BICst.DIMENSION_FILTER_NUMBER.NOT_BELONG_VALUE,cls:"dot-e-font"}],[{text:BI.i18nText("BI-Above_Average"),value:BICst.DIMENSION_FILTER_NUMBER.MORE_THAN_AVG,cls:"dot-e-font"},{text:BI.i18nText("BI-Below_Average"),value:BICst.DIMENSION_FILTER_NUMBER.LESS_THAN_AVG,cls:"dot-e-font"}],[{text:BI.i18nText("BI-Is_Null"),value:BICst.DIMENSION_FILTER_NUMBER.IS_NULL,cls:"dot-e-font"},{text:BI.i18nText("BI-Not_Null"),value:BICst.DIMENSION_FILTER_NUMBER.NOT_NULL,cls:"dot-e-font"}],[{text:BI.i18nText("BI-Top_N"),value:BICst.DIMENSION_FILTER_NUMBER.TOP_N,cls:"dot-e-font"},{text:BI.i18nText("BI-Last_N"),value:BICst.DIMENSION_FILTER_NUMBER.BOTTOM_N,cls:"dot-e-font"}]];
BICst.DIMENSION_FILTER_DATE_COMBO=[[{text:BI.i18nText("BI-Basic_In"),value:BICst.DIMENSION_FILTER_DATE.BELONG_VALUE,cls:"dot-e-font"},{text:BI.i18nText("BI-Not_In"),value:BICst.DIMENSION_FILTER_DATE.NOT_BELONG_VALUE,cls:"dot-e-font"}],[{text:BI.i18nText("BI-Basic_Contain"),value:BICst.DIMENSION_FILTER_DATE.CONTAIN,cls:"dot-e-font"},{text:BI.i18nText("BI-Not_Contain"),value:BICst.DIMENSION_FILTER_DATE.NOT_CONTAIN,cls:"dot-e-font"}],[{text:BI.i18nText("BI-Is_Null"),value:BICst.DIMENSION_FILTER_DATE.IS_NULL,cls:"dot-e-font"},{text:BI.i18nText("BI-Not_Null"),value:BICst.DIMENSION_FILTER_DATE.NOT_NULL,cls:"dot-e-font"}],[{text:BI.i18nText("BI-Begin_With"),value:BICst.DIMENSION_FILTER_DATE.BEGIN_WITH,cls:"dot-e-font"},{text:BI.i18nText("BI-End_With"),value:BICst.DIMENSION_FILTER_DATE.END_WITH,cls:"dot-e-font"}],[{text:BI.i18nText("BI-Top_N"),value:BICst.DIMENSION_FILTER_DATE.TOP_N,cls:"dot-e-font"},{text:BI.i18nText("BI-Last_N"),value:BICst.DIMENSION_FILTER_DATE.BOTTOM_N,cls:"dot-e-font"}]];
BICst.FILTER_DATE_COMBO=[[{el:{text:BI.i18nText("BI-Basic_In"),value:BI.i18nText("BI-Basic_In")},children:[{text:BI.i18nText("BI-Periods_Time"),value:BICst.FILTER_DATE.BELONG_DATE_RANGE,cls:"dot-e-font"},{text:BI.i18nText("BI-Control_Value"),value:BICst.FILTER_DATE.BELONG_WIDGET_VALUE,cls:"dot-e-font"}]},{el:{text:BI.i18nText("BI-Not_In"),value:BI.i18nText("BI-Not_In")},children:[{text:BI.i18nText("BI-Periods_Time"),value:BICst.FILTER_DATE.NOT_BELONG_DATE_RANGE,cls:"dot-e-font"},{text:BI.i18nText("BI-Control_Value"),value:BICst.FILTER_DATE.NOT_BELONG_WIDGET_VALUE,cls:"dot-e-font"}]}],[{text:BI.i18nText("BI-Sooner_Than"),value:BICst.FILTER_DATE.EARLY_THAN,cls:"dot-e-font"},{text:BI.i18nText("BI-Later_Than"),value:BICst.FILTER_DATE.LATER_THAN,cls:"dot-e-font"}],[{text:BI.i18nText("BI-Basic_Equal"),value:BICst.FILTER_DATE.EQUAL_TO,cls:"dot-e-font"},{text:BI.i18nText("BI-Not_Equal_To"),value:BICst.FILTER_DATE.NOT_EQUAL_TO,cls:"dot-e-font"}],[{text:BI.i18nText("BI-Is_Null"),value:BICst.FILTER_DATE.IS_NULL,cls:"dot-e-font"},{text:BI.i18nText("BI-Not_Null"),value:BICst.FILTER_DATE.NOT_NULL,cls:"dot-e-font"}]];
BICst.AUTH_FILTER_DATE_COMBO=[[{text:BI.i18nText("BI-Basic_In"),value:BICst.FILTER_DATE.BELONG_DATE_RANGE,cls:"dot-e-font"},{text:BI.i18nText("BI-Not_In"),value:BICst.FILTER_DATE.NOT_BELONG_DATE_RANGE,cls:"dot-e-font"}],[{text:BI.i18nText("BI-Basic_Equal"),value:BICst.FILTER_DATE.EQUAL_TO,cls:"dot-e-font"},{text:BI.i18nText("BI-Not_Equal_To"),value:BICst.FILTER_DATE.NOT_EQUAL_TO,cls:"dot-e-font"}],[{text:BI.i18nText("BI-Is_Null"),value:BICst.FILTER_DATE.IS_NULL,cls:"dot-e-font"},{text:BI.i18nText("BI-Not_Null"),value:BICst.FILTER_DATE.NOT_NULL,cls:"dot-e-font"}]];
BICst.DATA_SETTING_FILTER_DATE_COMBO=[[{text:BI.i18nText("BI-Basic_In"),value:BICst.FILTER_DATE.BELONG_DATE_RANGE,cls:"dot-e-font"},{text:BI.i18nText("BI-Not_In"),value:BICst.FILTER_DATE.NOT_BELONG_DATE_RANGE,cls:"dot-e-font"}],[{text:BI.i18nText("BI-Basic_Equal"),value:BICst.FILTER_DATE.EQUAL_TO,cls:"dot-e-font"},{text:BI.i18nText("BI-Not_Equal_To"),value:BICst.FILTER_DATE.NOT_EQUAL_TO,cls:"dot-e-font"}],[{text:BI.i18nText("BI-Is_Null"),value:BICst.FILTER_DATE.IS_NULL,cls:"dot-e-font"},{text:BI.i18nText("BI-Not_Null"),value:BICst.FILTER_DATE.NOT_NULL,cls:"dot-e-font"}]];
BICst.Date_Range_FILTER_COMBO=[{text:BI.i18nText("BI-Last_Section_Of_Same_Interval"),value:BICst.DATE_TYPE.LAST_SAME_PERIOD},{text:BI.i18nText("BI-The_Same_Time_Period"),value:BICst.DATE_TYPE.SAME_PERIOD}];BICst.FILTER_CONDITION_TYPE=[{text:BI.i18nText("BI-Basic_And"),value:BICst.FILTER_TYPE.AND},{text:BI.i18nText("BI-Basic_Or"),value:BICst.FILTER_TYPE.OR}];BICst.AUTHORITY_FILTER_STRING_COMBO=[[{el:{text:BI.i18nText("BI-Basic_In"),value:BICst.TARGET_FILTER_STRING.BELONG_VALUE},children:[{text:BI.i18nText("BI-Field_Value"),value:BICst.TARGET_FILTER_STRING.BELONG_VALUE,cls:"dot-e-font"},{text:BI.i18nText("BI-Login_User_Info"),value:BICst.TARGET_FILTER_STRING.BELONG_USER,cls:"dot-e-font"}]},{el:{text:BI.i18nText("BI-Not_In"),value:BICst.TARGET_FILTER_STRING.NOT_BELONG_VALUE},children:[{text:BI.i18nText("BI-Field_Value"),value:BICst.TARGET_FILTER_STRING.NOT_BELONG_VALUE,cls:"dot-e-font"},{text:BI.i18nText("BI-Login_User_Info"),value:BICst.TARGET_FILTER_STRING.NOT_BELONG_USER,cls:"dot-e-font"}]}],[{text:BI.i18nText("BI-Basic_Contain"),value:BICst.TARGET_FILTER_STRING.CONTAIN,cls:"dot-e-font"},{text:BI.i18nText("BI-Not_Contain"),value:BICst.TARGET_FILTER_STRING.NOT_CONTAIN,cls:"dot-e-font"}],[{text:BI.i18nText("BI-Is_Null"),value:BICst.TARGET_FILTER_STRING.IS_NULL,cls:"dot-e-font"},{text:BI.i18nText("BI-Not_Null"),value:BICst.TARGET_FILTER_STRING.NOT_NULL,cls:"dot-e-font"}],[{text:BI.i18nText("BI-Begin_With"),value:BICst.TARGET_FILTER_STRING.BEGIN_WITH,cls:"dot-e-font"},{text:BI.i18nText("BI-End_With"),value:BICst.TARGET_FILTER_STRING.END_WITH,cls:"dot-e-font"}]];
BICst.AUTHORITY_FILTER_NUMBER_COMBO=[[{text:BI.i18nText("BI-Basic_Equal"),value:BICst.TARGET_FILTER_NUMBER.EQUAL_TO,cls:"dot-e-font"},{text:BI.i18nText("BI-Not_Equal_To"),value:BICst.TARGET_FILTER_NUMBER.NOT_EQUAL_TO,cls:"dot-e-font"}],[{el:{text:BI.i18nText("BI-Basic_In"),value:BICst.TARGET_FILTER_NUMBER.BELONG_VALUE},children:[{text:BI.i18nText("BI-Interval_Value"),value:BICst.TARGET_FILTER_NUMBER.BELONG_VALUE,cls:"dot-e-font"},{text:BI.i18nText("BI-Login_User_Info"),value:BICst.TARGET_FILTER_NUMBER.BELONG_USER,cls:"dot-e-font"}]},{el:{text:BI.i18nText("BI-Not_In"),value:BICst.TARGET_FILTER_NUMBER.NOT_BELONG_VALUE},children:[{text:BI.i18nText("BI-Interval_Value"),value:BICst.TARGET_FILTER_NUMBER.NOT_BELONG_VALUE,cls:"dot-e-font"},{text:BI.i18nText("BI-Login_User_Info"),value:BICst.TARGET_FILTER_NUMBER.NOT_BELONG_USER,cls:"dot-e-font"}]}],[{text:BI.i18nText("BI-Is_Null"),value:BICst.TARGET_FILTER_NUMBER.IS_NULL,cls:"dot-e-font"},{text:BI.i18nText("BI-Not_Null"),value:BICst.TARGET_FILTER_NUMBER.NOT_NULL,cls:"dot-e-font"}]];
BICst.FILTER_ADD_FORMULA_COMBO=[{text:BI.i18nText("BI-Condition_Expression_And"),value:BICst.FILTER_OPERATION_FORMULA_AND},{text:BI.i18nText("BI-Condition_Expression_Or"),value:BICst.FILTER_OPERATION_FORMULA_OR}];BICst.FILTER_ADD_CONDITION_COMBO=[{text:BI.i18nText("BI-Condition_And"),value:BICst.FILTER_OPERATION_CONDITION_AND},{text:BI.i18nText("BI-Condition_Or"),value:BICst.FILTER_OPERATION_CONDITION_OR}];BICst.NUMBER_INTERVAL_CUSTOM_GROUP=[{text:BI.i18nText("BI-Basic_Custom"),value:BICst.NUMBER_INTERVAL_CUSTOM_GROUP_CUSTOM},{text:BI.i18nText("BI-Basic_Auto"),value:BICst.NUMBER_INTERVAL_CUSTOM_GROUP_AUTO}];
BICst.CONF_GROUP_STRING=[{text:BI.i18nText("BI-Same_Value_A_Group"),value:BICst.GROUP.ID_GROUP},{text:BI.i18nText("BI-Custom_Grouping_Dot"),value:BICst.GROUP.CUSTOM_GROUP}];BICst.CONF_GROUP_NUMBER=[{text:BI.i18nText("BI-Same_Value_A_Group"),value:BICst.GROUP.ID_GROUP},{text:BI.i18nText("BI-Grouping_Setting"),value:BICst.GROUP.CUSTOM_NUMBER_GROUP}];BICst.CONF_GROUP_DATE=[{text:BI.i18nText("BI-YMD_Date"),value:BICst.GROUP.YMD},{text:BI.i18nText("BI-Year_Fen"),value:BICst.GROUP.Y},{text:BI.i18nText("BI-Basic_Quarter"),value:BICst.GROUP.S},{text:BI.i18nText("BI-Month_Fen"),value:BICst.GROUP.M},{text:BI.i18nText("BI-Week_XingQi"),value:BICst.GROUP.W},{text:BI.i18nText("BI-Date_Day"),value:BICst.GROUP.D},{text:BI.i18nText("BI-Week_Count"),value:BICst.GROUP.WEEK_COUNT},{text:BI.i18nText("BI-Hour_Sin"),value:BICst.GROUP.HOUR},{text:BI.i18nText("BI-Basic_Minute"),value:BICst.GROUP.MINUTE},{text:BI.i18nText("BI-Basic_Seconds"),value:BICst.GROUP.SECOND},{text:BI.i18nText("BI-Year_Quarter"),value:BICst.GROUP.YS},{text:BI.i18nText("BI-Year_Month"),value:BICst.GROUP.YM},{text:BI.i18nText("BI-Year_Week"),value:BICst.GROUP.YW},{text:BI.i18nText("BI-Basic_YMDH"),value:BICst.GROUP.YMDH},{text:BI.i18nText("BI-Basic_YMDHM"),value:BICst.GROUP.YMDHM},{text:BI.i18nText("BI-Detail_Date"),value:BICst.GROUP.YMDHMS}];
BICst.CONF_STATISTIC_STRING=[{text:BI.i18nText("BI-No_Repeat_Count"),value:BICst.SUMMARY_TYPE.COUNT},{text:BI.i18nText("BI-String_Summary_By_Connection"),value:BICst.SUMMARY_TYPE.APPEND},{text:BI.i18nText("BI-Record_Count"),value:BICst.SUMMARY_TYPE.RECORD_COUNT}];BICst.CONF_STATISTIC_NUMBER=[{text:BI.i18nText("BI-Qiu_Sum"),value:BICst.SUMMARY_TYPE.SUM},{text:BI.i18nText("BI-Qiu_Avg"),value:BICst.SUMMARY_TYPE.AVG},{text:BI.i18nText("BI-Qiu_Max"),value:BICst.SUMMARY_TYPE.MAX},{text:BI.i18nText("BI-Qiu_Min"),value:BICst.SUMMARY_TYPE.MIN},{text:BI.i18nText("BI-No_Repeat_Count"),value:BICst.SUMMARY_TYPE.COUNT},{text:BI.i18nText("BI-Record_Count"),value:BICst.SUMMARY_TYPE.RECORD_COUNT}];
BICst.CONF_STATISTIC_DATE=[{text:BI.i18nText("BI-No_Repeat_Count"),value:BICst.SUMMARY_TYPE.COUNT},{text:BI.i18nText("BI-Record_Count"),value:BICst.SUMMARY_TYPE.RECORD_COUNT}];BICst.CHART_COLORS=[{header:BI.i18nText("BI-Basic_Default"),text:["#5caae4","#70cc7f","#ebbb67","#e97e7b","#6ed3c9"],value:["#5caae4","#70cc7f","#ebbb67","#e97e7b","#6ed3c9"]},{header:BI.i18nText("BI-Basic_Bright"),text:["#9193ac","#779ae3","#e6a469","#eddc80","#9889d0"],value:["#9193ac","#779ae3","#e6a469","#eddc80","#9889d0"]},{header:BI.i18nText("BI-Basic_Elegant"),text:["#f07d0a","#009de3","#58cc7d","#e85050","#9889d0"],value:["#f07d0a","#009de3","#58cc7d","#e85050","#9889d0"]},{header:BI.i18nText("BI-Prediction_Style_One"),text:["#79d2f4","#55b5e5","#25cdea","#1ba8ed","#537af4"],value:["#79d2f4","#55b5e5","#25cdea","#1ba8ed","#537af4"]},{header:BI.i18nText("BI-Prediction_Style_Two"),text:["#f4ab98","#f1c15f","#e18169","#af7e7e","#6f6870"],value:["#f4ab98","#f1c15f","#e18169","#af7e7e","#6f6870"]}];
BICst.CHART_VALUE_AXIS_STYLE=[{text:BI.i18nText("BI-Basic_Normal"),value:["#5caae4","#70cc7f","#ebbb67","#e97e7b","#6ed3c9"]},{text:"0",value:["#5caae4","#70cc7f","#ebbb67","#e97e7b","#6ed3c9"]},{text:"0.0",value:["#5caae4","#70cc7f","#ebbb67","#e97e7b","#6ed3c9"]},{text:"0.00",value:["#5caae4","#70cc7f","#ebbb67","#e97e7b","#6ed3c9"]}];BICst.TABLE_FORM_GROUP=[{cls:"table-open-row-style-font",title:BI.i18nText("BI-TABLE_TYPE_MULTI_COLUMN_SHOW"),value:BICst.TABLE_FORM.OPEN_ROW},{cls:"table-open-col-style-font",title:BI.i18nText("BI-TABLE_TYPE_TREE_SHOW"),value:BICst.TABLE_FORM.OPEN_COL}];
BICst.TABLE_STYLE_GROUP=[{cls:"table-style1-icon",value:BICst.TABLE_STYLE.STYLE1},{cls:"table-style2-icon",value:BICst.TABLE_STYLE.STYLE2},{cls:"table-style3-icon",value:BICst.TABLE_STYLE.STYLE3}];BICst.AXIS_STYLE_GROUP=[{cls:"axis-chart-style-normal-icon",value:BICst.CHART_STYLE.STYLE_NORMAL},{cls:"axis-chart-style-gradual-icon",value:BICst.CHART_STYLE.STYLE_GRADUAL}];BICst.MULTI_PIE_GRADIENT_STYLE_GROUP=[{cls:"multi-pie-gradient-lighter-icon",value:BICst.MULTI_PIE_GRADIENT_STYLE.LIGHTER},{cls:"multi-pie-gradient-darker-icon",value:BICst.MULTI_PIE_GRADIENT_STYLE.DARKER}];
BICst.Funnel_SLANT_STYLE_GROUP=[{cls:"funnel-slant-same-icon",value:BICst.FUNNEL_SLANT_STYLE.SAME},{cls:"funnel-slant-diff-icon",value:BICst.FUNNEL_SLANT_STYLE.DIFF}];BICst.LINE_CHART_STYLE_GROUP=[{cls:"line-chart-style-broken-icon",value:BICst.CHART_SHAPE.NORMAL},{cls:"line-chart-style-curve-icon",value:BICst.CHART_SHAPE.CURVE},{cls:"line-chart-style-vertical-icon",value:BICst.CHART_SHAPE.RIGHT_ANGLE}];BICst.AREA_CHART_STYLE_GROUP=[{cls:"area-chart-style-broken-icon",value:BICst.CHART_SHAPE.NORMAL},{cls:"area-chart-style-curve-icon",value:BICst.CHART_SHAPE.CURVE},{cls:"area-chart-style-vertical-icon",value:BICst.CHART_SHAPE.RIGHT_ANGLE}];
BICst.PIE_CHART_STYLE_GROUP=[{cls:"pie-chart-style-normal-icon",value:BICst.CHART_SHAPE.NORMAL,title:BI.i18nText("BI-Pie_Chart")},{cls:"pie-chart-style-equal-arc-rose-icon",value:BICst.CHART_SHAPE.EQUAL_ARC_ROSE,title:BI.i18nText("BI-Isometric_Rose_Chart")},{cls:"pie-chart-style-not-equal-arc-rose-icon",value:BICst.CHART_SHAPE.NOT_EQUAL_ARC_ROSE,title:BI.i18nText("BI-Unequal_Rose_Chart")}];BICst.RADAR_CHART_STYLE_GROUP=[{cls:"radar-chart-style-polygon-icon",value:BICst.CHART_SHAPE.POLYGON},{cls:"radar-chart-style-circle-icon",value:BICst.CHART_SHAPE.CIRCLE}];
BICst.ACC_RADAR_CHART_STYLE_GROUP=[{cls:"acc_radar-chart-style-polygon-icon",value:BICst.CHART_SHAPE.POLYGON},{cls:"acc_radar-chart-style-circle-icon",value:BICst.CHART_SHAPE.CIRCLE}];BICst.DASHBOARD_CHART_STYLE_GROUP=[{cls:"dashboard-chart-style-360-icon",title:BI.i18nText("BI-Multi_Pointer_Dashboard_360"),value:BICst.CHART_SHAPE.NORMAL},{cls:"dashboard-chart-style-180-icon",title:BI.i18nText("BI-Multi_Pointer_Dashboard_180"),value:BICst.CHART_SHAPE.HALF_DASHBOARD},{cls:"dashboard-chart-style-percent-icon",title:BI.i18nText("BI-Percent_Scale_Slot_Dashboard"),value:BICst.CHART_SHAPE.PERCENT_SCALE_SLOT},{cls:"dashboard-chart-style-percent-scale-slot-icon",title:BI.i18nText("BI-Percent_Donut_Dashboard"),value:BICst.CHART_SHAPE.PERCENT_DASHBOARD},{cls:"dashboard-chart-style-vertical-tube-icon",title:BI.i18nText("BI-Vertical_Tube"),value:BICst.CHART_SHAPE.VERTICAL_TUBE},{cls:"dashboard-chart-style-horizontal-tube-icon",title:BI.i18nText("BI-Horizontal_Tube"),value:BICst.CHART_SHAPE.HORIZONTAL_TUBE}];
BICst.CHART_SCALE_SETTING=[{text:BI.i18nText("BI-Basic_Auto"),value:BICst.SCALE_SETTING.AUTO},{text:BI.i18nText("BI-Basic_Custom"),value:BICst.SCALE_SETTING.CUSTOM}];BICst.BUBBLE_CHART_STYLE_GROUP=[{text:BI.i18nText("BI-Bubble_Without_Shadow"),cls:"bubble-no-projector",value:BICst.CHART_SHAPE.NO_PROJECTOR},{text:BI.i18nText("BI-Bubble_With_Shadow"),cls:"bubble-with-projector",value:BICst.CHART_SHAPE.PROJECTOR}];BICst.DATA_LABEL_POSITION=[{title:BI.i18nText("BI-Basic_Inner"),cls:"datalabel-position-inner",value:BICst.DATA_LABEL.POSITION_INNER},{title:BI.i18nText("BI-Basic_Outer"),cls:"datalabel-position-outer",value:BICst.DATA_LABEL.POSITION_OUTER,},{title:BI.i18nText("BI-Basic_Center"),cls:"datalabel-position-center",value:BICst.DATA_LABEL.POSITION_CENTER}];
BICst.PIE_DATA_LABEL_POSITION=[{title:BI.i18nText("BI-Basic_Inner"),cls:"datalabel-position-inner",value:BICst.DATA_LABEL.POSITION_INNER},{title:BI.i18nText("BI-Basic_Outer"),cls:"datalabel-position-outer",value:BICst.DATA_LABEL.POSITION_OUTER,}];BICst.DATA_LABEL_FILTER_NUMBER_COMBO=[[{text:BI.i18nText("BI-Basic_In"),value:BICst.DIMENSION_FILTER_NUMBER.BELONG_VALUE,cls:"dot-e-font"},{text:BI.i18nText("BI-Not_In"),value:BICst.DIMENSION_FILTER_NUMBER.NOT_BELONG_VALUE,cls:"dot-e-font"}],[{text:BI.i18nText("BI-Basic_Equal"),value:BICst.TARGET_FILTER_NUMBER.EQUAL_TO,cls:"dot-e-font"},{text:BI.i18nText("BI-Not_Equal_To"),value:BICst.TARGET_FILTER_NUMBER.NOT_EQUAL_TO,cls:"dot-e-font"}],[{text:BI.i18nText("BI-Is_Null"),value:BICst.DIMENSION_FILTER_NUMBER.IS_NULL,cls:"dot-e-font"},{text:BI.i18nText("BI-Not_Null"),value:BICst.DIMENSION_FILTER_NUMBER.NOT_NULL,cls:"dot-e-font"}],[{text:BI.i18nText("BI-Basic_Place"),value:BICst.DIMENSION_FILTER_NUMBER.TOP_N,cls:"dot-e-font"},{text:BI.i18nText("BI-Above_Average"),value:BICst.TARGET_FILTER_NUMBER.LARGE_OR_EQUAL_CAL_LINE,cls:"dot-e-font"},{text:BI.i18nText("BI-Below_Average"),value:BICst.TARGET_FILTER_NUMBER.SMALL_THAN_CAL_LINE,cls:"dot-e-font"}]];
BICst.DATA_LABEL_FILTER_STRING_COMBO=[[{text:BI.i18nText("BI-Basic_In"),value:BICst.DIMENSION_FILTER_STRING.BELONG_VALUE,cls:"dot-e-font"},{text:BI.i18nText("BI-Not_In"),value:BICst.DIMENSION_FILTER_STRING.NOT_BELONG_VALUE,cls:"dot-e-font"}],[{text:BI.i18nText("BI-Basic_Contain"),value:BICst.DIMENSION_FILTER_STRING.CONTAIN,cls:"dot-e-font"},{text:BI.i18nText("BI-Not_Contain"),value:BICst.DIMENSION_FILTER_STRING.NOT_CONTAIN,cls:"dot-e-font"}],[{text:BI.i18nText("BI-Is_Null"),value:BICst.DIMENSION_FILTER_STRING.IS_NULL,cls:"dot-e-font"},{text:BI.i18nText("BI-Not_Null"),value:BICst.DIMENSION_FILTER_STRING.NOT_NULL,cls:"dot-e-font"}],[{text:BI.i18nText("BI-Begin_With"),value:BICst.DIMENSION_FILTER_STRING.BEGIN_WITH,cls:"dot-e-font"},{text:BI.i18nText("BI-End_With"),value:BICst.DIMENSION_FILTER_STRING.END_WITH,cls:"dot-e-font"}],[{text:BI.i18nText("BI-Not_Begin_With"),value:BICst.DIMENSION_FILTER_STRING.NOT_BEGIN_WITH,cls:"dot-e-font"},{text:BI.i18nText("BI-Not_End_With"),value:BICst.DIMENSION_FILTER_STRING.NOT_END_WITH,cls:"dot-e-font"}]];
BICst.DATA_LABEL_FILTER_RANGE_COMBO=[[{text:BI.i18nText("BI-No_Range"),value:BICst.DATA_LABEL_RANGE.ALL,cls:"dot-e-font"},{text:BI.i18nText("BI-In_Classification"),value:BICst.DATA_LABEL_RANGE.Classification,cls:"dot-e-font"},{text:BI.i18nText("BI-In_Series"),value:BICst.DATA_LABEL_RANGE.Series,cls:"dot-e-font"}]];BICst.CAL_TARGET_TYPE=[{text:BI.i18nText("BI-Basic_Formula"),value:BICst.TARGET_TYPE.FORMULA},{text:BI.i18nText("BI-Basic_Ranging"),value:BICst.TARGET_TYPE.RANK},{text:BI.i18nText("BI-Group_Ranking"),value:BICst.TARGET_TYPE.RANK_IN_GROUP},{text:BI.i18nText("BI-All_Values"),value:BICst.TARGET_TYPE.SUM_OF_ALL},{text:BI.i18nText("BI-All_Values_In_Group"),value:BICst.TARGET_TYPE.SUM_OF_ALL_IN_GROUP},{text:BI.i18nText("BI-Cumulative_Value"),value:BICst.TARGET_TYPE.SUM_OF_ABOVE},{text:BI.i18nText("BI-Cumulative_Value_In_Group"),value:BICst.TARGET_TYPE.SUM_OF_ABOVE_IN_GROUP},{text:BI.i18nText("BI-Month_On_Month_Rate"),value:BICst.TARGET_TYPE.MONTH_ON_MONTH_RATE},{text:BI.i18nText("BI-Month_On_Value"),value:BICst.TARGET_TYPE.MONTH_ON_MONTH_VALUE},{text:BI.i18nText("BI-Year_On_Year_Rate"),value:BICst.TARGET_TYPE.YEAR_ON_YEAR_RATE},{text:BI.i18nText("BI-Year_On_Value"),value:BICst.TARGET_TYPE.YEAR_ON_YEAR_VALUE}];
BICst.CAL_TARGET_RANK_TYPE=[{text:BI.i18nText("BI-Rank_In_Asc"),value:BICst.TARGET_TYPE.CAL_VALUE.RANK_TPYE.ASC},{text:BI.i18nText("BI-Rank_In_Des"),value:BICst.TARGET_TYPE.CAL_VALUE.RANK_TPYE.DESC}];BICst.CAL_TARGET_SUM_TYPE=[{text:BI.i18nText("BI-Qiu_Sum"),value:BICst.TARGET_TYPE.CAL_VALUE.SUMMARY_TYPE.SUM},{text:BI.i18nText("BI-Qiu_Avg"),value:BICst.TARGET_TYPE.CAL_VALUE.SUMMARY_TYPE.AVG},{text:BI.i18nText("BI-Qiu_Max"),value:BICst.TARGET_TYPE.CAL_VALUE.SUMMARY_TYPE.MAX},{text:BI.i18nText("BI-Qiu_Min"),value:BICst.TARGET_TYPE.CAL_VALUE.SUMMARY_TYPE.MIN}];
BICst.DATABASE={APACHE_KYLIN:"Apache Kylin",HP_VERTiCA:"HP Vertica",IBM_DB2:"Ibm DB2",INFORMIX:"Informix",SQL_SERVER:"SQL Server",MYSQL:"MySQL",ORACLE:"Oracle",PIVOTAL_GREENPLUM_DATABASE:"Pivotal Greenplum Database",POSTGRESQL:"Postgresql",DERBY:"Derby",KINGBASE:"Kingbase",ELK:BI.i18nText("BI-Basic_Huawei")+"Elk",GBASE_8A:"Gbase 8A",GBASE_8S:"Gbase 8S",GBASE_8T:"Gbase 8T",PRESTO:"Presto",SAP_HANA:"Sap Hana",SAP_SYBASE:"Sap Sybase",TERADATA:"TeraData",APACHE_IMPALA:"Apache Impala",HADOOP_HIVE:"Hadoop Hive",SPARK:"Spark",TRANSWARP_INCEPTOR:"Transwarp Inceptor",FUSIONINSIGHT:BI.i18nText("BI-Basic_Huawei")+"Fusioninsight",APACHE_PHOENIX:"Apache Phoenix",ADS:"Ads",AMAZON_REDSHIFT:"Amazon Redshift",HBASE:"Hbase",OTHERS:BI.i18nText("BI-Basic_Others"),MORE:BI.i18nText("BI-Data_Link_More")};
BICst.DATA_LINK_MANAGE={CODES:[{text:"",value:""},{text:"BIG5",value:"BIG5"},{text:"EUC_JP",value:"EUC_JP"},{text:"EUC_KR",value:"EUC_KR"},{text:"GBK",value:"GBK"},{text:"ISO-8859-1",value:"ISO-8859-1"},{text:"UTF-8",value:"UTF-8"},{text:"UTF-16",value:"UTF-16"},{text:"CP850",value:"CP850"}],DATABASEA_COMBO:[{text:"APACHE KYLIN",value:BICst.DATABASE.APACHE_KYLIN},{text:"DERBY",value:BICst.DATABASE.DERBY},{text:"HP Vertica",value:BICst.DATABASE.HP_VERTiCA},{text:"IBM DB2",value:BICst.DATABASE.IBM_DB2},{text:"INFORMIX",value:BICst.DATABASE.INFORMIX},{text:"SQL Server",value:BICst.DATABASE.SQL_SERVER},{text:"MySQL",value:BICst.DATABASE.MYSQL},{text:"Oracle",value:BICst.DATABASE.ORACLE},{text:"Pivotal Greenplum Database",value:BICst.DATABASE.PIVOTAL_GREENPLUM_DATABASE},{text:"Postgresql",value:BICst.DATABASE.POSTGRESQL},{text:BI.i18nText("BI-Data_Link_More"),value:BICst.DATABASE.MORE},{text:BI.i18nText("BI-Basic_Others"),value:BICst.DATABASE.OTHERS}],DATABASES:[{text:"APACHE KYLIN",value:BICst.DATABASE.APACHE_KYLIN},{text:"HP Vertica",value:BICst.DATABASE.HP_VERTiCA},{text:"IBM DB2",value:BICst.DATABASE.IBM_DB2},{text:"INFORMIX",value:BICst.DATABASE.INFORMIX},{text:"SQL Server",value:BICst.DATABASE.SQL_SERVER},{text:"MySQL",value:BICst.DATABASE.MYSQL},{text:"Oracle",value:BICst.DATABASE.ORACLE},{text:"Pivotal Greenplum Database",value:BICst.DATABASE.PIVOTAL_GREENPLUM_DATABASE},{text:"Postgresql",value:BICst.DATABASE.POSTGRESQL},{text:"DERBY",value:BICst.DATABASE.DERBY},{text:"KINGBASE",value:BICst.DATABASE.KINGBASE},{text:"Gbase 8A",value:BICst.DATABASE.GBASE_8A},{text:"Gbase 8S",value:BICst.DATABASE.GBASE_8S},{text:"Gbase 8T",value:BICst.DATABASE.GBASE_8T},{text:"Presto",value:BICst.DATABASE.PRESTO},{text:"SAP HANA",value:BICst.DATABASE.SAP_HANA},{text:"SAP Sybase",value:BICst.DATABASE.SAP_SYBASE},{text:"TeraData",value:BICst.DATABASE.TERADATA},{text:"APACHE IMPALA",value:BICst.DATABASE.APACHE_IMPALA},{text:"Hadoop Hive",value:BICst.DATABASE.HADOOP_HIVE},{text:"SPARK",value:BICst.DATABASE.SPARK},{text:"TRANSWARP INCEPTOR",value:BICst.DATABASE.TRANSWARP_INCEPTOR},{text:"APACHE Phoenix",value:BICst.DATABASE.APACHE_PHOENIX},{text:"ADS",value:BICst.DATABASE.ADS},{text:"Amazon Redshift",value:BICst.DATABASE.AMAZON_REDSHIFT},{text:"Hbase",value:BICst.DATABASE.HBASE}],URLS:{APACHE_KYLIN:{"org.apache.kylin.jdbc.Driver":"jdbc:kylin://<hostname>:<port>/<kylin_project_name>"},HP_VERTiCA:{"com.vertica.jdbc.Driver":"jdbc:vertica://VerticaHost:port/databaseName"},IBM_DB2:{"com.ibm.db2.jcc.DB2Driver":"jdbc:db2://hostname:port/dbname"},INFORMIX:{"com.informix.jdbc.IfxDriver":"jdbc:informix-sqli://{host}:{port}/{database}:INFORMIXSERVER={server}"},SQL_SERVER:{"com.microsoft.sqlserver.jdbc.SQLServerDriver":"jdbc:sqlserver://localhost:1433;databaseName="},MYSQL:{"com.mysql.jdbc.Driver":"jdbc:mysql://localhost/dbname","org.gjt.mm.mysql.Driver":"jdbc:mysql://localhost/dbname"},ORACLE:{"oracle.jdbc.driver.OracleDriver":"jdbc:oracle:thin:@localhost:1521:databaseName"},PIVOTAL_GREENPLUM_DATABASE:{"org.postgresql.Driver":"jdbc:postgresql://hostname:port/dbname","com.pivotal.jdbc.GreenplumDriver":"jdbc:pivotal:greenplum://hostname:port;DatabaseName="},POSTGRESQL:{"org.postgresql.Driver":"jdbc:postgresql://hostname:port/dbname"},DERBY:{"org.apache.derby.jdbc.ClientDriver":"jdbc:derby://localhost:1527/"},KINGBASE:{"com.kingbase.Driver":"jdbc:kingbase://hostname:port"},ELK:{"org.postgresql.Driver":"jdbc:postgresql://hostname:port/dbname"},GBASE_8A:{"com.gbase.jdbc.Driver":"jdbc:gbase://hostname:port/dbname"},GBASE_8S:{"com.informix.jdbc.IfxDriver":"jdbc:informix-sqli://{host}:{port}/{database}:INFORMIXSERVER={server}"},GBASE_8T:{"com.informix.jdbc.IfxDriver":"jdbc:informix-sqli://{host}:{port}/{database}:INFORMIXSERVER={server}"},PRESTO:{"com.facebook.presto.jdbc.PrestoDriver":"jdbc:presto://host:port/catalog"},SAP_HANA:{"com.sap.db.jdbc.Driver":"jdbc:sap://hostname:port?reconnect=true"},SAP_SYBASE:{"com.sybase.jdbc4.jdbc.SybDriver":"jdbc:sybase:Tds:hostname:2638/databasename"},TERADATA:{"com.ncr.teradata.TeraDriver":"jdbc:teradata://localhost/CLIENT_CHARSET=EUC_CN,TMODE=TERA,CHARSET=ASCII,LOB_SUPPORT"},APACHE_IMPALA:{"com.cloudera.impala.jdbc41.Driver":"jdbc:impala://hostname:port/_impala_builtins"},HADOOP_HIVE:{"org.apache.hive.jdbc.HiveDriver":"jdbc:hive2://hostname:port/databasename"},SPARK:{"org.apache.hive.jdbc.HiveDriver":"jdbc:hive2://hostname:port/databasename"},TRANSWARP_INCEPTOR:{"org.apache.hive.jdbc.HiveDriver":"jdbc:hive2://hostname:port/databasename"},FUSIONINSIGHT:{"org.apache.hive.jdbc.HiveDriver":"jdbc:hive2://10.135.0.110:24002,10.135.0.67:24002,10.135.0.66:24002/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2;sasl.qop=auth-conf;auth=KERBEROS;zk.principal=zookeeper/hadoop;principal=hive/hadoop.hadoop.com@HADOOP.COM;"},APACHE_PHOENIX:{"org.apache.phoenix.jdbc.PhoenixDriver":"jdbc:phoenix:hostname:port/dbname"},ADS:{"Com.mysql.jdbc.Driver":"jdbc:mysql://hostname:port/my_ads_db"},AMAZON_REDSHIFT:{"com.amazon.redshift.jdbc4.Driver":"jdbc:redshift://endpoint:port/database","com.amazon.redshift.jdbc41.Driver":"jdbc:postgresql://endpoint:port/database"},HBASE:{"org.apache.phoenix.jdbc.PhoenixDriver":"jdbc:phoenix:hostname:port/dbname"},OTHERS:{"org.h2.Driver":"jdbc:h2://${ENV_HOME}/../databaseName","com.fr.third.org.hsqldb.jdbcDriver":"jdbc:hsqldb:file:[PATH_TO_DB_FILES]","org.sqlite.JDBC":"jdbc:sqlite:[PATH_TO_DB_FILES]"}},DRIVERS:{APACHE_KYLIN:[{text:"org.apache.kylin.jdbc.Driver",value:"org.apache.kylin.jdbc.Driver"}],HP_VERTiCA:[{text:"com.vertica.jdbc.Driver",value:"com.vertica.jdbc.Driver"}],IBM_DB2:[{text:"com.ibm.db2.jcc.DB2Driver",value:"com.ibm.db2.jcc.DB2Driver"}],INFORMIX:[{text:"com.informix.jdbc.IfxDriver",value:"com.informix.jdbc.IfxDriver"}],SQL_SERVER:[{text:"com.microsoft.sqlserver.jdbc.SQLServerDriver",value:"com.microsoft.sqlserver.jdbc.SQLServerDriver"}],MYSQL:[{text:"com.mysql.jdbc.Driver",value:"com.mysql.jdbc.Driver"},{text:"org.gjt.mm.mysql.Driver",value:"org.gjt.mm.mysql.Driver"}],ORACLE:[{text:"oracle.jdbc.driver.OracleDriver",value:"oracle.jdbc.driver.OracleDriver"}],PIVOTAL_GREENPLUM_DATABASE:[{text:"org.postgresql.Driver",value:"org.postgresql.Driver"},{text:"com.pivotal.jdbc.GreenplumDriver",value:"com.pivotal.jdbc.GreenplumDriver"}],POSTGRESQL:[{text:"org.postgresql.Driver",value:"org.postgresql.Driver"}],DERBY:[{text:"org.apache.derby.jdbc.ClientDriver",value:"org.apache.derby.jdbc.ClientDriver"}],KINGBASE:[{text:"com.kingbase.Driver",value:"com.kingbase.Driver"}],ELK:[{text:"org.postgresql.Driver",value:"org.postgresql.Driver"}],GBASE_8A:[{text:"com.gbase.jdbc.Driver",value:"com.gbase.jdbc.Driver"}],GBASE_8S:[{text:"com.informix.jdbc.IfxDriver",value:"com.informix.jdbc.IfxDriver"}],GBASE_8T:[{text:"com.informix.jdbc.IfxDriver",value:"com.informix.jdbc.IfxDriver"}],PRESTO:[{text:"com.facebook.presto.jdbc.PrestoDriver",value:"com.facebook.presto.jdbc.PrestoDriver"}],SAP_HANA:[{text:"com.sap.db.jdbc.Driver",value:"com.sap.db.jdbc.Driver"}],SAP_SYBASE:[{text:"com.sybase.jdbc4.jdbc.SybDriver",value:"com.sybase.jdbc4.jdbc.SybDriver"}],TERADATA:[{text:"com.ncr.teradata.TeraDriver",value:"com.ncr.teradata.TeraDriver"}],APACHE_IMPALA:[{text:"com.cloudera.impala.jdbc41.Driver",value:"com.cloudera.impala.jdbc41.Driver"}],HADOOP_HIVE:[{text:"org.apache.hive.jdbc.HiveDriver",value:"org.apache.hive.jdbc.HiveDriver"}],SPARK:[{text:"org.apache.hive.jdbc.HiveDriver",value:"org.apache.hive.jdbc.HiveDriver"}],TRANSWARP_INCEPTOR:[{text:"org.apache.hive.jdbc.HiveDriver",value:"org.apache.hive.jdbc.HiveDriver"}],FUSIONINSIGHT:[{text:"org.apache.hive.jdbc.HiveDriver",value:"org.apache.hive.jdbc.HiveDriver"}],APACHE_PHOENIX:[{text:"org.apache.phoenix.jdbc.PhoenixDriver",value:"org.apache.phoenix.jdbc.PhoenixDriver"}],ADS:[{text:"Com.mysql.jdbc.Driver",value:"Com.mysql.jdbc.Driver"}],AMAZON_REDSHIFT:[{text:"com.amazon.redshift.jdbc4.Driver",value:"com.amazon.redshift.jdbc4.Driver"},{text:"com.amazon.redshift.jdbc41.Driver",value:"com.amazon.redshift.jdbc41.Driver"}],HBASE:[{text:"org.apache.phoenix.jdbc.PhoenixDriver",value:"org.apache.phoenix.jdbc.PhoenixDriver"}],OTHERS:[{text:"org.h2.Driver",value:"org.h2.Driver"},{text:"com.fr.third.org.hsqldb.jdbcDriver",value:"com.fr.third.org.hsqldb.jdbcDriver"},{text:"org.sqlite.JDBC",value:"org.sqlite.JDBC"}]}};
BICst.BUBBLE_DISPLAY_RULES=[{text:BI.i18nText("BI-Series_Color_Setting"),value:BICst.DISPLAY_RULES.DIMENSION},{text:BI.i18nText("BI-Value_Fixed_Color"),value:BICst.DISPLAY_RULES.FIXED,warningTitle:BI.i18nText("BI-Empty_Value_or_Style_Mismatch")},{text:BI.i18nText("BI-Value_Gradient_Color"),value:BICst.DISPLAY_RULES.GRADIENT,warningTitle:BI.i18nText("BI-Empty_Value_or_Style_Mismatch")}];BICst.TARGET_STYLE_FORMAT=[{text:BI.i18nText("BI-Basic_Normal"),value:BICst.TARGET_STYLE.FORMAT.NORMAL},{text:"0",value:BICst.TARGET_STYLE.FORMAT.ZERO2POINT},{text:"0.0",value:BICst.TARGET_STYLE.FORMAT.ONE2POINT},{text:"0.00",value:BICst.TARGET_STYLE.FORMAT.TWO2POINT}];
BICst.TARGET_STYLE_AXIS_FORMAT=[{text:BI.i18nText("BI-Basic_Auto"),value:BICst.TARGET_STYLE.AXIS_FORMAT.AUTO},{text:BI.i18nText("BI-Basic_Digit"),value:BICst.TARGET_STYLE.AXIS_FORMAT.DIGIT},{text:BI.i18nText("BI-Basic_Percentage"),value:BICst.TARGET_STYLE.AXIS_FORMAT.PERCENT}];BICst.TARGET_STYLE_LEVEL=[{text:BI.i18nText("BI-Basic_Count"),value:BICst.TARGET_STYLE.NUM_LEVEL.NORMAL},{text:BI.i18nText("BI-Basic_Wan"),value:BICst.TARGET_STYLE.NUM_LEVEL.TEN_THOUSAND},{text:BI.i18nText("BI-Basic_Million"),value:BICst.TARGET_STYLE.NUM_LEVEL.MILLION},{text:BI.i18nText("BI-Basic_Yi"),value:BICst.TARGET_STYLE.NUM_LEVEL.YI}];
BICst.VALUE_AXIS_TARGET_STYLE_LEVEL=[{text:BI.i18nText("BI-Basic_Count"),value:BICst.TARGET_STYLE.NUM_LEVEL.NORMAL},{text:BI.i18nText("BI-Basic_Wan"),value:BICst.TARGET_STYLE.NUM_LEVEL.TEN_THOUSAND},{text:BI.i18nText("BI-Basic_Million"),value:BICst.TARGET_STYLE.NUM_LEVEL.MILLION},{text:BI.i18nText("BI-Basic_Yi"),value:BICst.TARGET_STYLE.NUM_LEVEL.YI}];BICst.TARGET_STYLE_LEVEL_SHORT=[{text:BI.i18nText("BI-Basic_Normal"),value:BICst.TARGET_STYLE.NUM_LEVEL.NORMAL},{text:BI.i18nText("BI-Basic_Wan"),value:BICst.TARGET_STYLE.NUM_LEVEL.TEN_THOUSAND},{text:BI.i18nText("BI-Basic_Million"),value:BICst.TARGET_STYLE.NUM_LEVEL.MILLION},{text:BI.i18nText("BI-Basic_Yi"),value:BICst.TARGET_STYLE.NUM_LEVEL.YI},{text:"%",value:BICst.TARGET_STYLE.NUM_LEVEL.PERCENT}];
BICst.POINTERS=[{text:BI.i18nText("BI-One_pointer"),value:BICst.POINTER.ONE},{text:BI.i18nText("BI-Some_pointers"),value:BICst.POINTER.SOME}];BICst.PIE_TOTAL_ANGLE=[{text:"180°",value:BICst.PIE_ANGLES.HALF},{text:"270°",value:BICst.PIE_ANGLES.THREE_FOURTHS},{text:"360°",value:BICst.PIE_ANGLES.TOTAL},{text:BI.i18nText("BI-Basic_Custom"),value:BICst.PIE_ANGLES.CUSTOM}];BICst.CHART_LEGEND=[{text:BI.i18nText("BI-Basic_Hidden"),value:BICst.CHART_LEGENDS.NOT_SHOW},{text:BI.i18nText("BI-Ju_xia"),value:BICst.CHART_LEGENDS.BOTTOM},{text:BI.i18nText("BI-Ju_Right"),value:BICst.CHART_LEGENDS.RIGHT}];
BICst.PERCENTAGE_SHOW=[{text:BI.i18nText("BI-Basic_Display"),value:BICst.PERCENTAGE.SHOW},{text:BI.i18nText("BI-Basic_Hidden"),value:BICst.PERCENTAGE.NOT_SHOW}];BICst.DATE_GROUP={};BICst.DATE_GROUP[BICst.GROUP.Y]=BI.i18nText("BI-Year_Fen");BICst.DATE_GROUP[BICst.GROUP.S]=BI.i18nText("BI-Multi_Date_Quarter");BICst.DATE_GROUP[BICst.GROUP.M]=BI.i18nText("BI-Month_Fen");BICst.DATE_GROUP[BICst.GROUP.WEEK_COUNT]=BI.i18nText("BI-Week_Count");BICst.DATE_GROUP[BICst.GROUP.W]=BI.i18nText("BI-Week_XingQi");
BICst.DATE_GROUP[BICst.GROUP.D]=BI.i18nText("BI-Date_Day");BICst.DATE_GROUP[BICst.GROUP.HOUR]=BI.i18nText("BI-Hour_Sin");BICst.DATE_GROUP[BICst.GROUP.MINUTE]=BI.i18nText("BI-Basic_Minute");BICst.DATE_GROUP[BICst.GROUP.SECOND]=BI.i18nText("BI-Basic_Seconds");BICst.DATE_GROUP[BICst.GROUP.YS]=BI.i18nText("BI-Year_Quarter");BICst.DATE_GROUP[BICst.GROUP.YM]=BI.i18nText("BI-Year_Month");BICst.DATE_GROUP[BICst.GROUP.YW]=BI.i18nText("BI-Year_Week");BICst.DATE_GROUP[BICst.GROUP.YMD]=BI.i18nText("BI-YMD_Date");
BICst.DATE_GROUP[BICst.GROUP.YMDH]=BI.i18nText("BI-Basic_YMDH");BICst.DATE_GROUP[BICst.GROUP.YMDHM]=BI.i18nText("BI-Basic_YMDHM");BICst.DATE_GROUP[BICst.GROUP.YMDHMS]=BI.i18nText("BI-Detail_Date");BICst.WIDGET_ICON_CLS_MAP={};BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.TABLE]="drag-group-icon";BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.CROSS_TABLE]="drag-cross-icon";BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.COMPLEX_TABLE]="drag-complex-icon";BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.DETAIL]="drag-detail-icon";BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.AXIS]="drag-axis-icon";
BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.ACCUMULATE_AXIS]="drag-axis-accu-icon";BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.PERCENT_ACCUMULATE_AXIS]="drag-axis-percent-accu-icon";BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.COMPARE_AXIS]="drag-axis-compare-icon";BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.FALL_AXIS]="drag-axis-fall-icon";BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.BAR]="drag-bar-icon";BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.ACCUMULATE_BAR]="drag-bar-accu-icon";BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.COMPARE_BAR]="drag-bar-compare-icon";
BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.PIE]="drag-pie-icon";BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.MULTI_PIE]="drag-multi-pie-icon";BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.RECT_TREE]="drag-rect-tree-icon";BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.MAP]="drag-map-china-icon";BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.GIS_MAP]="drag-map-gis-icon";BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.DASHBOARD]="drag-dashboard-icon";BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.DONUT]="drag-donut-icon";BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.DOT]="drag-dot-icon";
BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.WORD_CLOUD]="drag-word-cloud-icon";BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.FORCE_BUBBLE]="drag-bubble-force-icon";BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.RADAR]="drag-radar-icon";BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.ACCUMULATE_RADAR]="drag-radar-accu-icon";BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.LINE]="drag-line-icon";BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.AREA]="drag-area-icon";BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.ACCUMULATE_AREA]="drag-area-accu-icon";BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.PERCENT_ACCUMULATE_AREA]="drag-area-percent-accu-icon";
BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.COMPARE_AREA]="drag-area-compare-icon";BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.RANGE_AREA]="drag-area-range-icon";BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.COMBINE_CHART]="drag-combine-icon";BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.MULTI_AXIS_COMBINE_CHART]="drag-combine-mult-icon";BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.FUNNEL]="drag-funnel-icon";BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.IMAGE]="drag-image-icon";BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.WEB]="drag-web-icon";
BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.CONTENT]="drag-input-icon";BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.HEAT_MAP]="drag-heat-map-icon";BICst.WIDGET_ICON_CLS_MAP[BICst.WIDGET.LINE_MAP]="drag-line-map-icon";BICst.UPDATE_FREQUENCY_EVER_WEEK_LIST=[{text:BI.i18nText("BI-Basic_Simple_Monday"),value:BICst.UPDATE_FREQUENCY.EVER_MONDAY},{text:BI.i18nText("BI-Basic_Simple_Tuesday"),value:BICst.UPDATE_FREQUENCY.EVER_TUESDAY},{text:BI.i18nText("BI-Basic_Simple_Wednesday"),value:BICst.UPDATE_FREQUENCY.EVER_WEDNESDAY},{text:BI.i18nText("BI-Basic_Simple_Thursday"),value:BICst.UPDATE_FREQUENCY.EVER_THURSDAY},{text:BI.i18nText("BI-Basic_Simple_Friday"),value:BICst.UPDATE_FREQUENCY.EVER_FRIDAY},{text:BI.i18nText("BI-Basic_Simple_Saturday"),value:BICst.UPDATE_FREQUENCY.EVER_SATURDAY},{text:BI.i18nText("BI-Basic_Simple_Sunday"),value:BICst.UPDATE_FREQUENCY.EVER_SUNDAY}];
BICst.UPDATE_FREQUENCY_EVER_MONTH_LIST=[{text:BI.i18nText("BI-Ev_Month_One"),value:BICst.UPDATE_FREQUENCY_EVER_MONTH.ONE},{text:BI.i18nText("BI-Ev_Month_Two"),value:BICst.UPDATE_FREQUENCY_EVER_MONTH.TWO},{text:BI.i18nText("BI-Ev_Month_Three"),value:BICst.UPDATE_FREQUENCY_EVER_MONTH.THREE},{text:BI.i18nText("BI-Ev_Month_Four"),value:BICst.UPDATE_FREQUENCY_EVER_MONTH.FOUR},{text:BI.i18nText("BI-Ev_Month_Five"),value:BICst.UPDATE_FREQUENCY_EVER_MONTH.FIVE},{text:BI.i18nText("BI-Ev_Month_Six"),value:BICst.UPDATE_FREQUENCY_EVER_MONTH.SIX},{text:BI.i18nText("BI-Ev_Month_Seven"),value:BICst.UPDATE_FREQUENCY_EVER_MONTH.SEVEN},{text:BI.i18nText("BI-Ev_Month_Eight"),value:BICst.UPDATE_FREQUENCY_EVER_MONTH.EIGHT},{text:BI.i18nText("BI-Ev_Month_Nine"),value:BICst.UPDATE_FREQUENCY_EVER_MONTH.NINE},{text:BI.i18nText("BI-Ev_Month_Ten"),value:BICst.UPDATE_FREQUENCY_EVER_MONTH.Ten},{text:BI.i18nText("BI-Ev_Month_Eleven"),value:BICst.UPDATE_FREQUENCY_EVER_MONTH.ELEVEN},{text:BI.i18nText("BI-Ev_Month_Twelve"),value:BICst.UPDATE_FREQUENCY_EVER_MONTH.TWELVE},{text:BI.i18nText("BI-Ev_Month_Thirteen"),value:BICst.UPDATE_FREQUENCY_EVER_MONTH.THIRTEEN},{text:BI.i18nText("BI-Ev_Month_Fourteen"),value:BICst.UPDATE_FREQUENCY_EVER_MONTH.FOURTEEN},{text:BI.i18nText("BI-Ev_Month_Fifteen"),value:BICst.UPDATE_FREQUENCY_EVER_MONTH.FIFTEEN},{text:BI.i18nText("BI-Ev_Month_Sixteen"),value:BICst.UPDATE_FREQUENCY_EVER_MONTH.SIXTEEN},{text:BI.i18nText("BI-Ev_Month_Seventeen"),value:BICst.UPDATE_FREQUENCY_EVER_MONTH.SEVENTEEN},{text:BI.i18nText("BI-Ev_Month_Eighteen"),value:BICst.UPDATE_FREQUENCY_EVER_MONTH.EIGHTEEN},{text:BI.i18nText("BI-Ev_Month_Nineteen"),value:BICst.UPDATE_FREQUENCY_EVER_MONTH.NINETEEN},{text:BI.i18nText("BI-Ev_Month_Twenty"),value:BICst.UPDATE_FREQUENCY_EVER_MONTH.TWENTY},{text:BI.i18nText("BI-Ev_Month_Twenty_One"),value:BICst.UPDATE_FREQUENCY_EVER_MONTH.TWENTYONE},{text:BI.i18nText("BI-Ev_Month_Twenty_Two"),value:BICst.UPDATE_FREQUENCY_EVER_MONTH.TWENTYTWO},{text:BI.i18nText("BI-Ev_Month_Twenty_Three"),value:BICst.UPDATE_FREQUENCY_EVER_MONTH.TWENTYTHREE},{text:BI.i18nText("BI-Ev_Month_Twenty_Four"),value:BICst.UPDATE_FREQUENCY_EVER_MONTH.TWENTYFOUR},{text:BI.i18nText("BI-Ev_Month_Twenty_Five"),value:BICst.UPDATE_FREQUENCY_EVER_MONTH.TWENTYFIVE},{text:BI.i18nText("BI-Ev_Month_Twenty_Six"),value:BICst.UPDATE_FREQUENCY_EVER_MONTH.TWENTYSIX},{text:BI.i18nText("BI-Ev_Month_Twenty_Seven"),value:BICst.UPDATE_FREQUENCY_EVER_MONTH.TWENTYSEVEN},{text:BI.i18nText("BI-Ev_Month_Twenty_Eight"),value:BICst.UPDATE_FREQUENCY_EVER_MONTH.TWENTYEIGHT},{text:BI.i18nText("BI-Ev_Month_Twenty_Nine"),value:BICst.UPDATE_FREQUENCY_EVER_MONTH.TWENTYNINE},{text:BI.i18nText("BI-Ev_Month_Thirty"),value:BICst.UPDATE_FREQUENCY_EVER_MONTH.THIRTY},{text:BI.i18nText("BI-Ev_Month_Thirty_One"),value:BICst.UPDATE_FREQUENCY_EVER_MONTH.THIRTYONE}];
BICst.UPDATE_FREQUENCY_MONTH_LIST=[{text:BI.i18nText("BI-Basic_January"),value:BICst.UPDATE_FREQUENCY_MONTH.JANUARY},{text:BI.i18nText("BI-Basic_February"),value:BICst.UPDATE_FREQUENCY_MONTH.FEBRUARY},{text:BI.i18nText("BI-Basic_March"),value:BICst.UPDATE_FREQUENCY_MONTH.MARCH},{text:BI.i18nText("BI-Basic_April"),value:BICst.UPDATE_FREQUENCY_MONTH.APRIL},{text:BI.i18nText("BI-Basic_May"),value:BICst.UPDATE_FREQUENCY_MONTH.MAY},{text:BI.i18nText("BI-Basic_June"),value:BICst.UPDATE_FREQUENCY_MONTH.JUNE},{text:BI.i18nText("BI-Basic_July"),value:BICst.UPDATE_FREQUENCY_MONTH.JULY},{text:BI.i18nText("BI-Basic_August"),value:BICst.UPDATE_FREQUENCY_MONTH.AUGUST},{text:BI.i18nText("BI-Basic_September"),value:BICst.UPDATE_FREQUENCY_MONTH.SEPTEMBER},{text:BI.i18nText("BI-Basic_October"),value:BICst.UPDATE_FREQUENCY_MONTH.OCTOBER},{text:BI.i18nText("BI-Basic_November"),value:BICst.UPDATE_FREQUENCY_MONTH.NOVEMBER},{text:BI.i18nText("BI-Basic_December"),value:BICst.UPDATE_FREQUENCY_MONTH.DECEMBER}];
!(function(){BI.Utils={};BI.extend(BI.Utils,{hasLicence:function(){return Data.SharingPool.get("reg","hasLic")},supportBasic:function(){return Data.SharingPool.get("reg","supportBasic")},supportBigData:function(){return Data.SharingPool.get("reg","supportBigData")},supportCalculateTarget:function(){return Data.SharingPool.get("reg","supportCalculateTarget")},supportDatabaseUnion:function(){return Data.SharingPool.get("reg","supportDatabaseUnion")},supportExcelView:function(){return Data.SharingPool.get("reg","supportExcelView")
},supportGeneralControl:function(){return Data.SharingPool.get("reg","supportGeneralControl")},supportIncrementUpdate:function(){return Data.SharingPool.get("reg","supportIncrementUpdate")},supportMobileClient:function(){return Data.SharingPool.get("reg","supportMobileClient")},supportMultiStatisticsWidget:function(){return Data.SharingPool.get("reg","supportMultiStatisticsWidget")},supportOLAPTable:function(){return Data.SharingPool.get("reg","supportOLAPTable")},supportReportShare:function(){return Data.SharingPool.get("reg","supportReportShare")
},supportSimpleControl:function(){return Data.SharingPool.get("reg","supportSimpleControl")},supportDirect:function(){return Data.SharingPool.get("reg","supportDirect")},supportGlobalExport:function(){var f=Data.SharingPool.cat("templateConfig");if(!f.hasExportAuth){return false}return !f.globalExport||!f.globalExport.disabled},supportExportExcel:function(){var f=Data.SharingPool.cat("templateConfig");if(!f.hasExportAuth){return false}return !f.exportExcel||!f.exportExcel.disabled},supportGlobalStyle:function(){var f=Data.SharingPool.cat("templateConfig");
return !f.globalStyle||!f.globalStyle.disabled},getReportAuth:function(){return Data.SharingPool.get("reportAuth")||BICst.REPORT_AUTH.NONE},getDefaultChartConfig:function(){return Data.SharingPool.get("plateConfig")},getDefaultChartColor:function(){var g=BICst.DEFAULT_CHART_SETTING.chartColor;var i=this.getDefaultChartConfig();var h=i.defaultColor;if(i.styleList.length>0){g=i.styleList[0].colors}if(BI.isKey(h)){var f=BI.find(i.styleList,function(j,k){return k.value===h});if(f){g=f.colors}}return g
},getAllGroupedPackagesTreeJSON:function(){var i=Pool.groups,h=Pool.packages;var j=[],g=[];var f=BI.sortBy(i,function(l,k){return k.initTime});BI.each(f,function(k,l){j.push({id:l.id,text:l.name,isParent:true});BI.each(l.children,function(m,n){j.push({id:n.id,text:h[n.id].name,value:n.id,pId:l.id});g.push(n.id)})});BI.each(h,function(m,k){var l=false;BI.any(g,function(o,n){if(n===m){l=true;return false}});if(!l){j.push({id:k.id,text:k.name,value:k.id})}});return j},getCurrentTemplateId:function(){return Data.SharingPool.get("reportId")
},getLayoutType:function(){var f=Data.SharingPool.get("layoutType");return BI.isNull(f)?BICst.DASHBOARD_LAYOUT_GRID:f},getLayoutRatio:function(){return Data.SharingPool.get("layoutRatio")},getWidgetsByTemplateId:function(f,g){if(f.reportId===this.getCurrentTemplateId()){g(Data.SharingPool.cat("widgets"))}else{Data.BufferPool.getWidgetsByTemplateId(f,g)}},getAllUsedTableIdsByTemplateId:function(j,i){var f=this;if(j===this.getCurrentTemplateId()){var g=Data.SharingPool.cat("widgets");var h=[];BI.each(g,function(k){h=BI.concat(f.getAllRelatedTablesByWidgetId(k),h)
});i(BI.uniq(h))}else{Data.BufferPool.getAllUsedTableIdsByTemplateId({reportId:j,createBy:Data.SharingPool.get("createBy")},i)}},getAllTemplates:function(f){Data.Req.reqAllTemplates(function(g){f(g)})},getAllReportsData:function(f){Data.Req.reqAllReportsData(function(g){f(g)})},getGlobalStyle:function(){return Data.SharingPool.get("globalStyle")||{}},getActualGlobalStyle:function(){var g=this;var f=Data.SharingPool.get("globalStyle")||{};var h=g.getDefaultChartConfig();return{theme:f.theme,chartColor:f.chartColor||g.getDefaultChartColor(),chartStyle:f.chartStyle||h.chartStyle,chartFont:f.chartFont||h.chartFont,controlTheme:f.controlTheme||h.controlTheme,mainBackground:f.mainBackground||h.mainBackground,widgetBackground:f.widgetBackground||h.widgetBackground,titleBackground:f.titleBackground||h.titleBackground,titleFont:f.titleFont||h.titleFont}
},getLinkGroup:function(){return Data.SharingPool.get("linkGroup")||[]},getGSMainBackground:function(){var f=this.getGlobalStyle();return f.mainBackground||this.getDefaultChartConfig().mainBackground},getGSWidgetBackground:function(){var f=this.getGlobalStyle();return f.widgetBackground||this.getDefaultChartConfig().widgetBackground},getGSChartFont:function(){var f=this.getGlobalStyle();return BI.extend({},this.getDefaultChartConfig().chartFont,f.chartFont,{"fontFamily":"Microsoft YaHei","fontSize":12})
},getGSTitleFont:function(){var f=this.getGlobalStyle();return BI.extend({},this.getDefaultChartConfig().titleFont,f.titleFont)},getGSNamePos:function(){var f=this.getGSTitleFont()||this.getDefaultChartConfig().titleFont;if(BI.isNotNull(f)){if(f.textAlign==="left"){return BICst.DASHBOARD_WIDGET_NAME_POS_LEFT}if(f.textAlign==="center"){return BICst.DASHBOARD_WIDGET_NAME_POS_CENTER}}return BICst.DASHBOARD_WIDGET_NAME_POS_LEFT},getAllPackageIDs:function(){return BI.keys(Pool.packages)},getCurrentSelectPackageID:function(l){var j=BI.filter(BI.map(this.getAllDimensionIDs(l),function(n,o){return BI.Utils.getTableIDByDimensionID(o)
}),function(o,n){return BI.isNotNull(n)});if(BI.isNotEmptyArray(j)){return BI.Utils.getPackageIDByTableID(j[0])}else{var m=BI.Cache.getItem(BICst.CACHE.PACKAGE_PREFIX+this.getCurrentTemplateId());var h=this.getAllPackageIDs();if(h.contains(m)){return m}else{var i=BI.sortBy(Pool.packages,"position");var f=BI.sortBy(Pool.groups,"initTime");var k=[];var g=[];BI.each(f,function(n,o){BI.each(o.children,function(p,q){g.push(q.id)})});BI.each(i,function(p,n){var o=BI.find(g,function(r,q){return q===n.id
});if(BI.isNull(o)){k.push(n.id)}});return BI.isNotEmptyArray(g)?g[0]:k[0]}}},setCurrentSelectPackageID:function(g){var f=BICst.CACHE.PACKAGE_PREFIX+this.getCurrentTemplateId();BI.Cache.setItem(f,g)},getPackageNameByID:function(f){if(BI.isNotNull(Pool.packages[f])){return Pool.packages[f].name}},getTableIDsOfPackageID:function(g){if(BI.isNotNull(Pool.packages[g])){var f=Pool.packages[g].tables;f=BI.Func.getSortedResult(f,"id");return BI.pluck(f,"id")}},getPackageIDByTableID:function(f){var g;BI.find(Pool.packages,function(h,j){var i=BI.pluck(j.tables,"id");
if(BI.contains(i,f)){g=h;return true}});return g},getTableNameByID:function(g){var f=Pool.translations;return f[g]||g},getTableLastModifyTimeByID:function(g){if(BI.isNotNull(Pool.tables[g])){var f=Pool.tables[g].lastModifyTime;return f||""}},getConnectionNameByTableId:function(g){if(BI.isNotNull(Pool.tables[g])){var f=Pool.tables[g].connectionName;return f||""}return""},getFieldsByTableId:function(f){if(BI.isNotNull(Pool.tables[f])){return Pool.tables[f].fields[0]||[]}return[]},getFieldIDsOfTableID:function(g){if(BI.isNotNull(Pool.tables[g])){var f=Pool.tables[g].fields;
return BI.pluck(f[0].concat(f[1]).concat(f[2]),"id")}},getFieldIDsWithCountFieldIdOfTableID:function(g){if(BI.isNotNull(Pool.tables[g])){var f=Pool.tables[g].fields;return BI.pluck(f[0].concat(f[1]).concat(f[2]).concat(f[3]),"id")}},getStringFieldIDsOfTableID:function(h){var g=this;if(BI.isNotNull(Pool.tables[h])){var f=Pool.tables[h].fields;return BI.filter(BI.pluck(f[0],"id"),function(i,j){return g.getFieldTypeByID(j)===BICst.COLUMN.STRING})}return[]},getNumberFieldIDsOfTableID:function(h){var g=this;
if(BI.isNotNull(Pool.tables[h])){var f=Pool.tables[h].fields;return BI.filter(BI.pluck(f[0],"id"),function(i,j){return g.getFieldTypeByID(j)===BICst.COLUMN.NUMBER})}return[]},getDateFieldIDsOfTableID:function(h){var g=this;if(BI.isNotNull(Pool.tables[h])){var f=Pool.tables[h].fields;return BI.filter(BI.pluck(f[0],"id"),function(i,j){return g.getFieldTypeByID(j)===BICst.COLUMN.DATE})}return[]},getCountFieldIDsOfTableID:function(g){if(BI.isNotNull(Pool.tables[g])){var f=Pool.tables[g].fields;return BI.pluck(f[3],"id")
}return[]},getSortedFieldIdsOfOneTableByTableId:function(h){var k=Pool.translations;var g=this.getFieldIDsOfTableID(h);var i=[];BI.each(g,function(r,q){if(BI.isNotNull(k[q])){i.push(q)}});var o=[];BI.each(g,function(r,q){if(BI.isNull(k[q])){o.push(q)}});var j=[],n=[],l=[],p=[],f=[],m=[];BI.each(i,function(q,r){switch(BI.Utils.getFieldTypeByID(r)){case BICst.COLUMN.NUMBER:j.push(r);break;case BICst.COLUMN.STRING:n.push(r);break;case BICst.COLUMN.DATE:l.push(r);break}});BI.each(o,function(q,r){switch(BI.Utils.getFieldTypeByID(r)){case BICst.COLUMN.NUMBER:p.push(r);
break;case BICst.COLUMN.STRING:f.push(r);break;case BICst.COLUMN.DATE:m.push(r);break}});return j.concat(n).concat(l).concat(p).concat(f).concat(m)},getExcelViewByTableId:function(h){var g=Pool.excelView||{};var f=g[h]||{};if(BI.isNotNull(f.excelFullName)){return f}},getFieldNameByID:function(h){var g=Pool.translations;var i=Pool.fields[h];var j=g[h];if(BI.isNull(j)&&BI.isNotNull(i)){j=i.fieldName;if(i.fieldType===BICst.COLUMN.COUNTER){var f=this.getTableNameByID(i.tableId);if(BI.isNull(f)){f=i.tableId
}j=f+BI.i18nText("BI-Basic_Records")}}return j},getOriginalFieldNameByID:function(f){var g=Pool.fields[f];if(BI.isNotNull(g)){return g.fieldName}},getFieldTypeByID:function(f){if(BI.isNotNull(Pool.fields[f])){return Pool.fields[f].fieldType}},getFieldTypeByDateGroupType:function(f){switch(f){case BICst.GROUP.Y:return BICst.COLUMN.NUMBER;case BICst.GROUP.S:return BICst.COLUMN.NUMBER;case BICst.GROUP.M:return BICst.COLUMN.NUMBER;case BICst.GROUP.W:return BICst.COLUMN.NUMBER;case BICst.GROUP.WEEK_COUNT:return BICst.COLUMN.NUMBER;
case BICst.GROUP.D:return BICst.COLUMN.NUMBER;case BICst.GROUP.HOUR:return BICst.COLUMN.NUMBER;case BICst.GROUP.MINUTE:return BICst.COLUMN.NUMBER;case BICst.GROUP.SECOND:return BICst.COLUMN.NUMBER;case BICst.GROUP.YM:return BICst.COLUMN.DATE;case BICst.GROUP.YS:return BICst.COLUMN.DATE;case BICst.GROUP.YW:return BICst.COLUMN.DATE;case BICst.GROUP.YMDH:return BICst.COLUMN.DATE;case BICst.GROUP.YMDHM:return BICst.COLUMN.DATE;case BICst.GROUP.YMDHMS:return BICst.COLUMN.DATE;case BICst.GROUP.YMD:return BICst.COLUMN.DATE;
default:return BICst.COLUMN.DATE}},getFieldIsUsableByID:function(f){if(BI.isNotNull(Pool.fields[f])){return Pool.fields[f].isUsable}},getTableIdByFieldID:function(f){if(BI.isNotNull(Pool.fields[f])){return Pool.fields[f].tableId}},isFieldExistByID:function(f){return BI.isNotNull(Pool.fields[f])},getAllFieldIDs:function(){return BI.keys(Pool.fields)},getAllWidgetIDs:function(){return BI.keys(Data.SharingPool.cat("widgets"))},getLinkGroupShowWidgetIds:function(){var g=this;var f=BI.Utils.getAllWidgetIDs();
return BI.filter(f,function(h,i){return g.isLinkageWidgetByWidgetId(i)})},getWidgetBoundsByID:function(f){if(BI.isNotNull(Data.SharingPool.cat("widgets",f))){return Data.SharingPool.get("widgets",f,"bounds")||{}}return{}},getWidgetViewByID:function(f){if(BI.isNotNull(Data.SharingPool.cat("widgets",f))){return Data.SharingPool.get("widgets",f,"view")||{}}return{}},getWidgetRegionsByID:function(f){if(BI.isNotNull(Data.SharingPool.cat("widgets",f))){return Data.SharingPool.get("widgets",f,"regions")||{}
}return{}},getWidgetScopeByID:function(f){if(BI.isNotNull(Data.SharingPool.cat("widgets",f))){return Data.SharingPool.get("widgets",f,"scopes")||{}}return{}},getWidgetViewClassificationByID:function(h){var g=this.getWidgetViewByID(h);var f={};BI.each(g,function(i,j){i=BI.parseInt(i);if(BI.Utils.isDimensionRegion1ByRegionType(i)){f[BICst.REGION.DIMENSION1]=f[BICst.REGION.DIMENSION1]||[];f[BICst.REGION.DIMENSION1].push(i+"");return}if(BI.Utils.isDimensionRegion2ByRegionType(i)){f[BICst.REGION.DIMENSION2]=f[BICst.REGION.DIMENSION2]||[];
f[BICst.REGION.DIMENSION2].push(i+"");return}if(BI.Utils.isTargetRegion1ByRegionType(i)){f[BICst.REGION.TARGET1]=f[BICst.REGION.TARGET1]||[];f[BICst.REGION.TARGET1].push(i+"");return}if(BI.Utils.isTargetRegion2ByRegionType(i)){f[BICst.REGION.TARGET2]=f[BICst.REGION.TARGET2]||[];f[BICst.REGION.TARGET2].push(i+"");return}f[BICst.REGION.TARGET3]=f[BICst.REGION.TARGET3]||[];f[BICst.REGION.TARGET3].push(i+"")});return f},getWidgetTypeByID:function(f){if(BI.isNotNull(Data.SharingPool.cat("widgets",f))){return Data.SharingPool.get("widgets",f,"type")
}},getWidgetSubTypeByID:function(g){var f=this.getWidgetTypeByID(g);var h=Data.SharingPool.get("widgets",g,"subType");if(f===BICst.WIDGET.MAP&&BI.isNull(h)){return BI.findKey(MapConst.INNER_MAP_INFO.MAP_LAYER,function(j,i){if(i===0){return true}})}return h},getWidgetNameByID:function(i){var f=this;var g="";var h=Data.SharingPool.cat("widgets",i);if(BI.isNotNull(h)){g=Data.SharingPool.get("widgets",i,"name")}if(BI.Utils.getWidgetTypeByID(i)===BICst.WIDGET.CONTENT){g=Data.SharingPool.get("widgets",i,"content")||""
}return g.replaceAll("\\$\\{.*?\\}",function(k){var l=k.substring(2,k.length-1);if(!f.isWidgetExistByID(l)&&!f.isDimensionExist(l)){return"<!"+BI.i18nText("BI-Element_Is_Deleted")+"!>"}if(f.isWidgetExistByID(l)){return d(k.substring(2,k.length-1))}else{var j=f.getWidgetIDByDimensionID(l);if(f.isControlWidgetByWidgetId(j)){return d(k.substring(2,k.length-1))}else{return e(i,l)}}})},getInitialWidgetNameByID:function(g){var f=Data.SharingPool.cat("widgets",g);if(BI.isNotNull(f)){return Data.SharingPool.get("widgets",g,"name")
}},getWidgetValueByID:function(g){var f=Data.SharingPool.cat("widgets",g);if(BI.isNotNull(f)){return Data.SharingPool.get("widgets",g,"value")}},checkWidgetNameByID:function(g,j){var h=this.getAllWidgetIDs();var f=this,i=true;BI.some(h,function(k,l){if(j!==l&&f.getInitialWidgetNameByID(l)===g){i=false;return true}});return i},isControlWidgetByWidgetId:function(f){var g=this.getWidgetTypeByID(f);return this.isControlWidgetByWidgetType(g)},isControlWidgetByWidgetType:function(f){return f===BICst.WIDGET.STRING||f===BICst.WIDGET.STRING_LIST||f===BICst.WIDGET.NUMBER||f===BICst.WIDGET.SINGLE_SLIDER||f===BICst.WIDGET.INTERVAL_SLIDER||f===BICst.WIDGET.DATE||f===BICst.WIDGET.MONTH||f===BICst.WIDGET.QUARTER||f===BICst.WIDGET.TREE||f===BICst.WIDGET.TREE_LIST||f===BICst.WIDGET.LIST_LABEL||f===BICst.WIDGET.TREE_LABEL||f===BICst.WIDGET.YEAR||f===BICst.WIDGET.YMD||f===BICst.WIDGET.DATE_PANE||f===BICst.WIDGET.GENERAL_QUERY
},isLinkageWidgetByWidgetId:function(g){var h=BI.Utils.getWidgetTypeByID(g);var f=true;if(BI.Utils.isControlWidgetByWidgetType(h)){f=false}if(h===BICst.WIDGET.QUERY||h===BICst.WIDGET.RESET||h===BICst.WIDGET.GENERAL_QUERY){f=false}if(h===BICst.WIDGET.IMAGE||h===BICst.WIDGET.WEB){f=false}return f},isExtendWidgetByWidgetType:function(f){return f===BICst.WIDGET.CONTENT||f===BICst.WIDGET.WEB||f===BICst.WIDGET.IMAGE||f===BICst.WIDGET.DETAIL},isInstantControlWidgetByWidgetId:function(f){var g=this.getWidgetTypeByID(f);
return this.isInstantControlWidgetByWidgetType(g)},isMultiFieldBindWidgetById:function(g){var f=this.getWidgetTypeByID(g);if(this.isSpecialWidgetByWidgetId(g)){return false}if(!this.isControlWidgetByWidgetId(g)){return true}return f===BICst.WIDGET.TREE||f===BICst.WIDGET.NUMBER||f===BICst.WIDGET.INTERVAL_SLIDER||f===BICst.WIDGET.SINGLE_SLIDER||f===BICst.WIDGET.TREE_LIST||f===BICst.WIDGET.TREE_LABEL||f===BICst.WIDGET.DATE_PANE||f===BICst.WIDGET.DATE||f===BICst.WIDGET.YEAR||f===BICst.WIDGET.QUARTER||f===BICst.WIDGET.MONTH||f===BICst.WIDGET.YMD
},isInstantControlWidgetByWidgetType:function(f){return f===BICst.WIDGET.LIST_LABEL||f===BICst.WIDGET.TREE_LABEL||f===BICst.WIDGET.TREE_LIST||f===BICst.WIDGET.STRING_LIST||f===BICst.WIDGET.SINGLE_SLIDER||f===BICst.WIDGET.DATE_PANE||f===BICst.WIDGET.INTERVAL_SLIDER},isSpecialWidgetByWidgetId:function(f){var g=this.getWidgetTypeByID(f);return this.isSpecialWidgetByWidgetType(g)},isSpecialWidgetByWidgetType:function(f){return f===BICst.WIDGET.CONTENT||f===BICst.WIDGET.IMAGE||f===BICst.WIDGET.WEB},isQueryControlExist:function(){var f=this,g=false;
BI.some(this.getAllWidgetIDs(),function(h,j){if(f.getWidgetTypeByID(j)===BICst.WIDGET.QUERY){return g=true}});return g},getControlFilters:function(){return Data.SharingPool.get("controlFilters")},isAutoQuery:function(){var f=this,g=false;if(this.isQueryControlExist()){BI.some(this.getAllWidgetIDs(),function(h,j){if(f.getWidgetTypeByID(j)===BICst.WIDGET.QUERY){g=f.getWSAutoQueryByID(j);return true}})}return g},getWidgetDimensionsByID:function(f){return Data.SharingPool.get("widgets",f,"dimensions")||{}
},getWidgetSortByID:function(f){return Data.SharingPool.get("widgets",f,"sort")||{}},getWidgetSortSequenceByID:function(f){return Data.SharingPool.get("widgets",f,"sortSequence")||[]},isShowWidgetRealDataByID:function(f){return Data.SharingPool.get("widgets",f,"realData")},getWidgetCopyByID:function(q){var p=this;var l=Data.SharingPool.get("widgets",q);if(BI.isNotNull(l)){var k={};k.type=l.type;k.name=BI.Func.createDistinctName(Data.SharingPool.get("widgets"),l.name);k.id=BI.UUID();k.wId=k.id;k.regions=l.regions;
k.scopes=l.scopes;if(BI.isNotNull(l.subType)){k.subType=l.subType}var i={};var f={};var o={};BI.each(l.dimensions,function(r){var s=n(r);f[s.id]=s.dimension});BI.each(l.view,function(s,r){o[s]=[];BI.each(r,function(t,u){o[s].push(i[u])})});k.dimensions=f;k.view=o;var g=l.bounds||{};k.bounds={height:g.height,width:g.width,left:g.left,top:g.top};k.jump=l.jump;k.settings=l.settings;if(BI.isNotNull(l.value)){k.value=l.value}if(BI.has(l,"sort")&&BI.isNotNull(l.sort)&&BI.isNotEmptyObject(l.sort)){var j={};
if(BI.has(l.sort,"sortTarget")){j.sortTarget=n(l.sort.sortTarget).id}k.sort=BI.extend({},l.sort,j)}if(BI.has(l,"sortSequence")&&BI.isNotNull(l.sortSequence)){k.sortSequence=[];BI.each(l.sortSequence,function(r,s){k.sortSequence.push(n(s).id)})}if(BI.has(l,"filterValue")&&BI.isNotNull(l.filterValue)){var m={};BI.each(l.filterValue,function(t,r){var s=n(t).id;m[s]=h(r,t,s)});k.filterValue=m}return k}function h(t,x,s){var v={};var w=t.filterType,y=t.filterValue;v.filterType=t.filterType;if(w===BICst.FILTER_TYPE.AND||w===BICst.FILTER_TYPE.OR){v.filterValue=[];
BI.each(y,function(z,A){v.filterValue.push(h(A,x,s))})}else{BI.extend(v,t);if(BI.has(t,"targetId")){if(t.targetId!==x){var r=n(t.targetId);v.targetId=r.id}else{v.targetId=s}}if(BI.has(t,"formulaIds")){var u=t.formulaIds||[];if(BI.isNotEmptyArray(u)&&BI.isNull(BI.Utils.getFieldTypeByID(u[0]))){BI.each(u,function(B,A){var z=n(A);v.filterValue=v.filterValue.replaceAll(A,z.id);v.formulaIds[B]=z.id})}}}return v}function n(s){var t=i[s]||BI.UUID();var u=BI.deepClone(l.dimensions[s]);if(BI.has(i,s)&&BI.has(f,[i[s]])){return{id:i[s],dimension:f[i[s]]}
}switch(l.dimensions[s].type){case BICst.TARGET_TYPE.STRING:case BICst.TARGET_TYPE.NUMBER:case BICst.TARGET_TYPE.DATE:if(BI.has(l.dimensions[s],"dimensionMap")){u.dimensionMap={};BI.each(l.dimensions[s].dimensionMap,function(y,x){if(p.isDimensionExist(y)){var w=n(y);u.dimensionMap[w.id]=x}else{u.dimensionMap[y]=x}})}if(BI.has(l.dimensions[s],"filterValue")&&BI.isNotNull(l.dimensions[s].filterValue)){u.filterValue=h(l.dimensions[s].filterValue,s,t)}if(BI.has(l.dimensions[s],"sort")){u.sort=BI.deepClone(l.dimensions[s].sort);
if(BI.has(u.sort,"sortTarget")){if(u.sort.sortTarget===s){u.sort.sortTarget=t}else{var r=n(u.sort.sortTarget);u.sort.sortTarget=r.id}}}break;case BICst.TARGET_TYPE.FORMULA:case BICst.TARGET_TYPE.YEAR_ON_YEAR_RATE:case BICst.TARGET_TYPE.MONTH_ON_MONTH_RATE:case BICst.TARGET_TYPE.YEAR_ON_YEAR_VALUE:case BICst.TARGET_TYPE.MONTH_ON_MONTH_VALUE:case BICst.TARGET_TYPE.SUM_OF_ABOVE:case BICst.TARGET_TYPE.SUM_OF_ABOVE_IN_GROUP:case BICst.TARGET_TYPE.SUM_OF_ALL:case BICst.TARGET_TYPE.SUM_OF_ALL_IN_GROUP:case BICst.TARGET_TYPE.RANK:case BICst.TARGET_TYPE.RANK_IN_GROUP:var v=u._src.expression;
BI.each(v.ids,function(y,x){var w=n(x);if(BI.has(v,"formulaValue")){v.formulaValue=v.formulaValue.replaceAll(x,w.id)}v.ids[y]=w.id});break}u.dId=t;i[s]=t;return{id:t,dimension:u}}},getWSTitleDetailSettingByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.widgetNameStyle)?f.widgetNameStyle:{}},getWSWidgetBGByID:function(h){var g=this.getWidgetSettingsByID(h);var f=this.getGSWidgetBackground(h);if(BI.isNull(g.widgetBG)){return f?f:{}}return g.widgetBG},getWSTableFormByID:function(g){var f=this.getWidgetSettingsByID(g);
return BI.isNotNull(f.tableFormGroup)?f.tableFormGroup:BICst.DEFAULT_CHART_SETTING.tableFormGroup},getWSThemeColorByID:function(h){var f=this.getWidgetSettingsByID(h);var g=this.getActualGlobalStyle();switch(BI.Utils.getWidgetTypeByID(h)){case BICst.WIDGET.GIS_MAP:case BICst.WIDGET.LINE_MAP:case BICst.WIDGET.MAP:return result=BI.isNotNull(f.themeColor)?f.themeColor:BI.isNotNull(g.chartColor)?g.chartColor[0]:BICst.DEFAULT_CHART_SETTING.themeColor}return BI.isNotNull(f.themeColor)?f.themeColor:BICst.DEFAULT_CHART_SETTING.themeColor
},getWSTableStyleByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.tableStyleGroup)?f.tableStyleGroup:BICst.DEFAULT_CHART_SETTING.tableStyleGroup},getWSIsCustomTableStyleByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.isCustomTableStyle)?f.isCustomTableStyle:BICst.DEFAULT_CHART_SETTING.isCustomTableStyle},getWSCustomTableStyleByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.customTableStyle)?f.customTableStyle:{}},getWSTableNameStyleByID:function(g){var f=this.getWidgetSettingsByID(g);
if(f.customTableStyle){return BI.isNotNull(f.customTableStyle.tableNameStyle)?f.customTableStyle.tableNameStyle:{}}return{}},getWSTableValueStyleByID:function(g){var f=this.getWidgetSettingsByID(g);if(f.customTableStyle){return BI.isNotNull(f.customTableStyle.tableValueStyle)?f.customTableStyle.tableValueStyle:{}}return{}},getWSShowNumberByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.showNumber)?f.showNumber:BICst.DEFAULT_CHART_SETTING.showNumber},getWSShowRowTotalByID:function(g){var f=this.getWidgetSettingsByID(g);
return BI.isNotNull(f.showRowTotal)?f.showRowTotal:BICst.DEFAULT_CHART_SETTING.showRowTotal},getWSShowColTotalByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.showColTotal)?f.showColTotal:BICst.DEFAULT_CHART_SETTING.showColTotal},getWSOpenRowNodeByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.openRowNode)?f.openRowNode:BICst.DEFAULT_CHART_SETTING.openRowNode},getWSRegionColumnSizeByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.regionColumnSize)?f.regionColumnSize:[]
},getWSOpenColNodeByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.openColNode)?f.openColNode:BICst.DEFAULT_CHART_SETTING.openColNode},getWSMaxRowByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.maxRow)?f.maxRow:BICst.DEFAULT_CHART_SETTING.maxRow},getWSMaxColByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.maxCol)?f.maxCol:BICst.DEFAULT_CHART_SETTING.maxCol},getWSRowHeightByID:function(g){var f=this.getWidgetSettingsByID(g);
return BI.isNotNull(f.rowHeight)?f.rowHeight:BICst.DEFAULT_CHART_SETTING.rowHeight},getWSFreezeDimByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.freezeDim)?f.freezeDim:BICst.DEFAULT_CHART_SETTING.freezeDim},getWSFreezeFirstColumnById:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.freezeFirstColumn)?f.freezeFirstColumn:BICst.DEFAULT_CHART_SETTING.freezeFirstColumn},getWSChartDisplayRulesByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.displayRules)?f.displayRules:BICst.DEFAULT_CHART_SETTING.displayRules
},getWSChartBubbleFixedStyleByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.fixedStyle)?f.fixedStyle:BICst.MAP_STYLE_CONDITIONS},getWSChartBubbleGradientStyleByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.gradientStyle)?f.gradientStyle:BICst.BUBBLE_GRADIENT_COLOR},getWSChartDotStyleByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.dotStyle)&&f.dotStyle!==BICst.DOT_STYLE.LOCATION?f.dotStyle:BICst.DEFAULT_CHART_SETTING.dotStyle
},getWSChartMapDotStyleByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.dotStyle)?f.dotStyle:BICst.DEFAULT_CHART_SETTING.mapDotStyle},getWSChartBubbleStyleByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.bubbleStyle)?f.bubbleStyle:BICst.DEFAULT_CHART_SETTING.bubbleStyle},getWSTransferFilterByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.transferFilter)?f.transferFilter:BICst.DEFAULT_CHART_SETTING.transferFilter},getWSManualSelectLinkageFilterByID:function(g){var f=this.getWidgetSettingsByID(g);
return BI.isNotNull(f.manualSelectLinkageFilter)?f.manualSelectLinkageFilter:BICst.DEFAULT_CHART_SETTING.manualSelectLinkageFilter},getWSChartClickZoomByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.clickZoom)?f.clickZoom:BICst.DEFAULT_CHART_SETTING.clickZoom},getWSShowNameByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.showName)?f.showName:BICst.DEFAULT_CHART_SETTING.showName},getWSNamePosByID:function(h){var f=this.getWidgetSettingsByID(h);var g=this.getGSNamePos();
return f.namePos||g||BICst.DEFAULT_CHART_SETTING.namePos},getWSTurnOnJumpById:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.showTurnOnJump)?f.showTurnOnJump:BICst.DEFAULT_CHART_SETTING.showTurnOnJump},getWSColumnSizeByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.columnSize)?f.columnSize:[]},getWSChartColorByID:function(i){var h=this;var g=this.getGlobalStyle();var f=this.getWidgetSettingsByID(i);return f.chartColor||g.chartColor||h.getDefaultChartColor()||BICst.DEFAULT_CHART_SETTING.chartColor
},getWSChartStyleByID:function(j){var i=this;var g=this.getWidgetSettingsByID(j);var h=this.getGlobalStyle();function f(){var k=i.getDefaultChartConfig();return k.chartStyle}return g.chartStyle||h.chartStyle||f()||BICst.DEFAULT_CHART_SETTING.chartStyle},getWSLineAreaChartTypeByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.lineAreaChartType)?f.lineAreaChartType:BICst.DEFAULT_CHART_SETTING.lineAreaChartType},getWSPieChartTypeByID:function(g){var f=this.getWidgetSettingsByID(g);
return BI.isNotNull(f.pieChartType)?f.pieChartType:BICst.DEFAULT_CHART_SETTING.pieChartType},getWSMultiPieGradienTypeByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.gradientType)?f.gradientType:BICst.DEFAULT_CHART_SETTING.gradientStyle},getWSChartSlantStyleByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.slantStyle)?f.slantStyle:BICst.DEFAULT_CHART_SETTING.slantStyle},getWSRadarChartTypeByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.radarChartType)?f.radarChartType:BICst.DEFAULT_CHART_SETTING.radarChartType
},getWSDashboardChartTypeByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.dashboardChartType)?f.dashboardChartType:BICst.DEFAULT_CHART_SETTING.dashboardChartType},getWSDashboardColorsByID:function(i){var g=this.getWidgetSettingsByID(i);var h=this.getWSDashboardChartTypeByID(i);var f={},j;switch(h){case BICst.CHART_SHAPE.NORMAL:case BICst.CHART_SHAPE.HALF_DASHBOARD:j=BICst.DEFAULT_CHART_SETTING.pointerColor;break;case BICst.CHART_SHAPE.PERCENT_SCALE_SLOT:j=BICst.DEFAULT_CHART_SETTING.slotColor;
break;case BICst.CHART_SHAPE.PERCENT_DASHBOARD:j=BICst.DEFAULT_CHART_SETTING.ringColor;break;case BICst.CHART_SHAPE.VERTICAL_TUBE:case BICst.CHART_SHAPE.HORIZONTAL_TUBE:j=BICst.DEFAULT_CHART_SETTING.thermometerColor}BI.map(BI.keys(j),function(l,k){f[k]=BI.isNotNull(g[k])?g[k]:j[k]});return f},getWSChartTotalAngleByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.totalAngle)?f.totalAngle:BICst.DEFAULT_CHART_SETTING.totalAngle},getWSChartStartAngleByID:function(g){var f=this.getWidgetSettingsByID(g);
return BI.isNotNull(f.startAngle)?f.startAngle:BICst.DEFAULT_CHART_SETTING.startAngle},getWSChartEndAngleByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.endAngle)?f.endAngle:BICst.DEFAULT_CHART_SETTING.endAngle},getWSChartInnerRadiusByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.innerRadius)?f.innerRadius:BICst.DEFAULT_CHART_SETTING.innerRadius},getWSChartRightYNumberLevelByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.rightYNumberLevel)?f.rightYNumberLevel:BICst.DEFAULT_CHART_SETTING.rightYNumberLevel
},getWSChartRightY2NumberLevelByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.rightY2NumberLevel)?f.rightY2NumberLevel:BICst.DEFAULT_CHART_SETTING.rightY2NumberLevel},getWSChartLeftYNumberLevelByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.leftYNumberLevel)?f.leftYNumberLevel:BICst.DEFAULT_CHART_SETTING.leftYNumberLevel},getWSChartDashboardPointerByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.dashboardPointer)?f.dashboardPointer:BICst.POINTER.ONE
},getWSChartStyleRadioByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.styleRadio)?f.styleRadio:BICst.SCALE_SETTING.AUTO},getWSChartFixedStyleRadioByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.fixedStyleRadio)?f.fixedStyleRadio:BICst.SCALE_SETTING.AUTO},getWSChartGradientStyleRadioByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.gradientStyleRadio)?f.gradientStyleRadio:BICst.SCALE_SETTING.AUTO},getWSChartDashboardStylesByID:function(g){var f=this.getWidgetSettingsByID(g);
return BI.isNotNull(f.dashboardStyles)?f.dashboardStyles:BICst.DASHBOARD_STYLE_CONDITIONS},getWSChartMapStylesByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.mapStyles)?f.mapStyles:BICst.INTERVAL_STYLE_CONDITIONS},getWSLeftYAxisUnitByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.leftYUnit)?f.leftYUnit:BICst.DEFAULT_CHART_SETTING.leftYUnit},getWSChartMinScaleByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.minScale)?f.minScale:BICst.DEFAULT_CHART_SETTING.minScale
},getWSChartMaxScaleByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.maxScale)?f.maxScale:BICst.DEFAULT_CHART_SETTING.maxScale},getWSChartShowPercentageByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.showPercentage)?f.showPercentage:BICst.DEFAULT_CHART_SETTING.dashboardShowPercentage},getWSChartRightYUnitByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.rightYUnit)?f.rightYUnit:BICst.DEFAULT_CHART_SETTING.rightYUnit},getWSChartRightYAxis2UnitByID:function(g){var f=this.getWidgetSettingsByID(g);
return BI.isNotNull(f.rightY2Unit)?f.rightY2Unit:BICst.DEFAULT_CHART_SETTING.rightY2Unit},getWSChartLeftYShowTitleByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.leftYShowTitle)?f.leftYShowTitle:BICst.DEFAULT_CHART_SETTING.leftYShowTitle},getWSChartRightYShowTitleByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.rightYShowTitle)?f.rightYShowTitle:BICst.DEFAULT_CHART_SETTING.rightYShowTitle},getWSChartRightY2ShowTitleByID:function(g){var f=this.getWidgetSettingsByID(g);
return BI.isNotNull(f.rightYShowTitle)?f.rightYShowTitle:BICst.DEFAULT_CHART_SETTING.rightYShowTitle},getWSChartLeftYTitleByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.leftYTitle)?f.leftYTitle:BICst.DEFAULT_CHART_SETTING.leftYTitle},getWSChartRightYTitleByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.rightYTitle)?f.rightYTitle:BICst.DEFAULT_CHART_SETTING.rightYTitle},getWSChartRightY2TitleByID:function(g){var f=this.getWidgetSettingsByID(g);
return BI.isNotNull(f.rightY2Title)?f.rightY2Title:BICst.DEFAULT_CHART_SETTING.rightY2Title},getWSChartCatShowTitleByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.catShowTitle)?f.catShowTitle:BICst.DEFAULT_CHART_SETTING.catShowTitle},getWSChartCatTitleByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.catTitle)?f.catTitle:BICst.DEFAULT_CHART_SETTING.catTitle},getWSChartLeftYReverseByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.leftYReverse)?f.leftYReverse:BICst.DEFAULT_CHART_SETTING.leftYReverse
},getWSChartRightYReverseByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.rightYReverse)?f.rightYReverse:BICst.DEFAULT_CHART_SETTING.rightYReverse},getWSChartRightY2ReverseByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.rightY2Reverse)?f.rightY2Reverse:BICst.DEFAULT_CHART_SETTING.rightY2Reverse},getWSChartLegendByID:function(g){var f=this.getWidgetSettingsByID(g);if(BI.isNull(f.legend)){switch(BI.Utils.getWidgetTypeByID(g)){case BICst.WIDGET.WORD_CLOUD:case BICst.WIDGET.FUNNEL:return BICst.CHART_LEGENDS.NOT_SHOW;
default:return BICst.DEFAULT_CHART_SETTING.legend}}return f.legend},getWSChartShowDataLabelByID:function(g){var f=this.getWidgetSettingsByID(g);if(BI.isNull(f.showDataLabel)){switch(BI.Utils.getWidgetTypeByID(g)){case BICst.WIDGET.DASHBOARD:case BICst.WIDGET.FORCE_BUBBLE:return BICst.DEFAULT_CHART_SETTING.dashboardShowDataLabel;default:return BICst.DEFAULT_CHART_SETTING.showDataLabel}}return f.showDataLabel},getWSChartDataLabelSettingByID:function(h){var g=this.getWidgetSettingsByID(h);if(BI.isNotNull(g.dataLabelSetting)){return g.dataLabelSetting
}var f;switch(BI.Utils.getWidgetTypeByID(h)){case BICst.WIDGET.ACCUMULATE_AREA:case BICst.WIDGET.LINE:case BICst.WIDGET.AREA:case BICst.WIDGET.COMPARE_AREA:case BICst.WIDGET.RANGE_AREA:case BICst.WIDGET.ACCUMULATE_RADAR:case BICst.WIDGET.RADAR:case BICst.WIDGET.PERCENT_ACCUMULATE_AREA:f=BICst.DEFAULT_CHART_SETTING.areaDataLabelSetting;break;case BICst.WIDGET.DONUT:case BICst.WIDGET.PIE:f=BICst.DEFAULT_CHART_SETTING.pieDataLabelSetting;break;case BICst.WIDGET.MULTI_PIE:f=BICst.DEFAULT_CHART_SETTING.multiPieDataLabelSetting;
break;case BICst.WIDGET.DASHBOARD:f=BICst.DEFAULT_CHART_SETTING.dashboardDataLabelSetting;break;case BICst.WIDGET.BUBBLE:case BICst.WIDGET.SCATTER:case BICst.WIDGET.DOT:f=BICst.DEFAULT_CHART_SETTING.dotDataLabelSetting;break;case BICst.WIDGET.MAP:case BICst.WIDGET.GIS_MAP:f=BICst.DEFAULT_CHART_SETTING.mapDataLabelSetting;break;case BICst.WIDGET.LINE_MAP:case BICst.WIDGET.HEAT_MAP:f=BICst.DEFAULT_CHART_SETTING.heatMapDataLabelSetting;break;case BICst.WIDGET.FUNNEL:f=BICst.DEFAULT_CHART_SETTING.funnelDataLabelSetting;
break;default:f=BICst.DEFAULT_CHART_SETTING.axisDataLabelSetting;break}return BI.deepClone(f)},getWSChartShowDataTableByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.showDataTable)?f.showDataTable:BICst.DEFAULT_CHART_SETTING.showDataTable},getWSChartBubbleSizeFromByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.bubbleSizeFrom)?f.bubbleSizeFrom:BICst.DEFAULT_CHART_SETTING.bubbleSizeFrom},getWSChartBubbleSizeToByID:function(g){var f=this.getWidgetSettingsByID(g);
return BI.isNotNull(f.bubbleSizeTo)?f.bubbleSizeTo:BICst.DEFAULT_CHART_SETTING.bubbleSizeTo},getWSChartMinFontSizeByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.minFontSize)?f.minFontSize:BICst.DEFAULT_CHART_SETTING.minFontSize},getWSChartMaxFontSizeByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.maxFontSize)?f.maxFontSize:BICst.DEFAULT_CHART_SETTING.maxFontSize},getWSLeftYNumberSeparatorByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.leftYSeparator)?f.leftYSeparator:BICst.DEFAULT_CHART_SETTING.leftYSeparator
},getWSRightYNumberSeparatorByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.rightYSeparator)?f.rightYSeparator:BICst.DEFAULT_CHART_SETTING.rightYSeparator},getWSRightY2NumberSeparatorByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.rightY2Separator)?f.rightY2Separator:BICst.DEFAULT_CHART_SETTING.rightY2Separator},getWSChartLeftYShowLabelByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.leftYShowLabel)?f.leftYShowLabel:BICst.DEFAULT_CHART_SETTING.leftYShowLabel
},getWSChartLeftYLabelStyleByID:function(i){var f=this.getWidgetSettingsByID(i);var g=this.getGSChartFont();var h=f.leftYLabelStyle||{};h.textStyle=BI.extend(g,h.textStyle);h.textDirection=h.textDirection||0;h.format=BI.isNotNull(h.format)?h.format:BICst.DEFAULT_CHART_SETTING.leftYFormat;h.decimalDigits=BI.isNotNull(h.decimalDigits)?h.decimalDigits:BICst.DEFAULT_CHART_SETTING.leftYDecimalDigits;h.numberLevel=BI.isNotNull(h.numberLevel)?h.numberLevel:BICst.DEFAULT_CHART_SETTING.leftYNumberLevel;h.separator=BI.isNotNull(h.separator)?h.separator:BICst.DEFAULT_CHART_SETTING.leftYSeparator;
h.unit=BI.isNotNull(h.unit)?h.unit:BICst.DEFAULT_CHART_SETTING.leftYUnit;return h},getWSChartLeftYLineColorByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.leftYLineColor)?f.leftYLineColor:BICst.DEFAULT_CHART_SETTING.lineColor},getWSRightYShowLabelByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.rightYShowLabel)?f.rightYShowLabel:BICst.DEFAULT_CHART_SETTING.rightYShowLabel},getWSRightYLabelStyleByID:function(i){var f=this.getWidgetSettingsByID(i);
var g=this.getGSChartFont();var h=f.rightYLabelStyle||{};h.textStyle=BI.extend(g,h.textStyle);h.textDirection=h.textDirection||0;h.format=BI.isNotNull(h.format)?h.format:BICst.DEFAULT_CHART_SETTING.rightYFormat;h.decimalDigits=BI.isNotNull(h.decimalDigits)?h.decimalDigits:BICst.DEFAULT_CHART_SETTING.rightYDecimalDigits;h.numberLevel=BI.isNotNull(h.numberLevel)?h.numberLevel:BICst.DEFAULT_CHART_SETTING.rightYNumberLevel;h.separator=BI.isNotNull(h.separator)?h.separator:BICst.DEFAULT_CHART_SETTING.rightYSeparator;
h.unit=BI.isNotNull(h.unit)?h.unit:BICst.DEFAULT_CHART_SETTING.rightYUnit;return h},getWSRightY2ShowLabelByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.right2YShowLabel)?f.right2YShowLabel:BICst.DEFAULT_CHART_SETTING.right2YShowLabel},getWSRightY2LabelStyleByID:function(i){var f=this.getWidgetSettingsByID(i);var g=this.getGSChartFont();var h=f.rightY2LabelStyle||{};h.textStyle=BI.extend(g,h.textStyle);h.textDirection=h.textDirection||0;h.format=BI.isNotNull(h.format)?h.format:BICst.DEFAULT_CHART_SETTING.rightY2Format;
h.decimalDigits=BI.isNotNull(h.decimalDigits)?h.decimalDigits:BICst.DEFAULT_CHART_SETTING.rightY2DecimalDigits;h.numberLevel=BI.isNotNull(h.numberLevel)?h.numberLevel:BICst.DEFAULT_CHART_SETTING.rightY2NumberLevel;h.separator=BI.isNotNull(h.separator)?h.separator:BICst.DEFAULT_CHART_SETTING.rightY2Separator;h.unit=BI.isNotNull(h.unit)?h.unit:BICst.DEFAULT_CHART_SETTING.rightY2Unit;return h},getWSRightY2LineColorByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.rightY2LineColor)?f.rightY2LineColor:BICst.DEFAULT_CHART_SETTING.lineColor
},getWSChartCatShowLabelByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.catShowLabel)?f.catShowLabel:BICst.DEFAULT_CHART_SETTING.catShowLabel},getWSChartCatLabelStyleByID:function(i){var f=this.getWidgetSettingsByID(i);var g=this.getGSChartFont();var h=f.catLabelStyle||{};h.textStyle=BI.extend(g,h.textStyle);h.textDirection=h.textDirection||0;return h},getWSChartLegendStyleByID:function(i){var f=this.getWidgetSettingsByID(i);var g=this.getGSChartFont();var h=f.legendStyle||{};
h=BI.extend(g,h);return h},getWSChartDataSheetStyleByID:function(h){var f=this.getWidgetSettingsByID(h);var g=this.getGSChartFont();var i=f.dataSheetStyle||{};i=BI.extend(g,i);return i},getWSChartLeftYTitleStyleByID:function(h){var f=this.getWidgetSettingsByID(h);var g=this.getGSChartFont();var i=f.leftYTitleStyle||{};i=BI.extend(g,i);return i},getWSChartRightYTitleStyleByID:function(h){var f=this.getWidgetSettingsByID(h);var g=this.getGSChartFont();var i=f.rightYTitleStyle||{};i=BI.extend(g,i);return i
},getWSChartRightY2TitleStyleByID:function(h){var f=this.getWidgetSettingsByID(h);var g=this.getGSChartFont();var i=f.rightY2TitleStyle||{};i=BI.extend(g,i);return i},getWSChartCatTitleStyleByID:function(h){var f=this.getWidgetSettingsByID(h);var g=this.getGSChartFont();var i=f.catTitleStyle||{};i=BI.extend(g,i);return i},getWSChartHShowGridLineByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.hShowGridLine)?f.hShowGridLine:BICst.DEFAULT_CHART_SETTING.hShowGridLine},getWSChartVShowGridLineByID:function(g){var f=this.getWidgetSettingsByID(g);
return BI.isNotNull(f.vShowGridLine)?f.vShowGridLine:BICst.DEFAULT_CHART_SETTING.vShowGridLine},getWSChartHGridLineColorByID:function(g){var f=this.getWidgetSettingsByID(g);return f.hGridLineColor||""},getWSChartVGridLineColorByID:function(g){var f=this.getWidgetSettingsByID(g);return f.vGridLineColor||""},getWSChartToolTipStyleByID:function(i){var g=this.getWidgetSettingsByID(i);if(BI.isNotNull(g.tooltipStyle)){return g.tooltipStyle}var h=BICst.WIDGET,j=BICst.DEFAULT_CHART_SETTING;var f={};switch(BI.Utils.getWidgetTypeByID(i)){case h.PIE:f=j.pieChartTooltipStyle;
break;case h.MULTI_PIE:f=j.multiPieChartTooltipStyle;break;case h.DONUT:f=j.donutChartTooltipStyle;break;case h.DASHBOARD:f=j.gaugeChartTooltipStyle;break;case h.DOT:f=j.dotChartTooltipStyle;break;case h.MAP:case h.GIS_MAP:f=j.mapChartTooltipStyle;break;case h.HEAT_MAP:case h.LINE_MAP:f=j.heatMapChartTooltipStyle;break;case h.FUNNEL:f=j.funnelChartTooltipStyle;break;case h.RECT_TREE:f=j.rectTreeChartTooltipStyle;break;case h.WORD_CLOUD:f=j.wordCloudChartTooltipStyle;break;case h.FORCE_BUBBLE:f=j.forceBubbleChartTooltipStyle;
break;default:f=j.axisChartTooltipStyle;break}return BI.deepClone(f)},getWSLinkageSelectionByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.linkageSelection)?f.linkageSelection:BICst.DEFAULT_CHART_SETTING.linkageSelection},getWSMinimalistByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.miniMode)?f.miniMode:BICst.DEFAULT_CHART_SETTING.miniMode},getWSChartBigDataModeByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.bigDataMode)?f.bigDataMode:BICst.DEFAULT_CHART_SETTING.bigDataMode
},getWSChartRightYShowCustomScaleByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.rightYShowCustomScale)?f.rightYShowCustomScale:BICst.DEFAULT_CHART_SETTING.rightYShowCustomScale},getWSChartRightYCustomScaleByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.rightYCustomScale)?f.rightYCustomScale:BICst.DEFAULT_CHART_SETTING.customScale},getWSChartLeftYShowCustomScaleByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.leftYShowCustomScale)?f.leftYShowCustomScale:BICst.DEFAULT_CHART_SETTING.leftYShowCustomScale
},getWSChartLeftYCustomScaleByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.leftYCustomScale)?f.leftYCustomScale:BICst.DEFAULT_CHART_SETTING.customScale},getWSChartRightY2CustomScaleByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.rightY2CustomScale)?f.rightY2CustomScale:BICst.DEFAULT_CHART_SETTING.customScale},getWSChartRightY2ShowCustomScaleByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.rightY2ShowCustomScale)?f.rightY2ShowCustomScale:BICst.DEFAULT_CHART_SETTING.rightY2ShowCustomScale
},getWSChartShowZoomByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.showZoom)?f.showZoom:BICst.DEFAULT_CHART_SETTING.showZoom},getWSShowBackgroundByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.isShowBackgroundLayer)?f.isShowBackgroundLayer:BICst.DEFAULT_CHART_SETTING.isShowBackgroundLayer},getWSChartMapBackgroundLayerInfoByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.backgroundLayerInfo)?f.backgroundLayerInfo:BICst.DEFAULT_CHART_SETTING.backgroundLayerInfo
},getWSChartLineMapBackgroundLayerInfoByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.backgroundLayerInfo)?f.backgroundLayerInfo:BICst.DEFAULT_CHART_SETTING.lineMapBackgroundLayerInfo},getWSNullContinuityByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.nullContinuity)?f.nullContinuity:BICst.DEFAULT_CHART_SETTING.nullContinuity},getWSLineMapLineWidthByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.lineWidth)?f.lineWidth:BICst.DEFAULT_CHART_SETTING.lineWidth
},getWSEffectByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.effect)?f.effect:BICst.DEFAULT_CHART_SETTING.effect},getWSHeatMapRadiusWidthByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.lineWidth)?f.lineWidth:BICst.DEFAULT_CHART_SETTING.heatMapRadius},getWSHeatMapOpacityWidthByID:function(g){var f=this.getWidgetSettingsByID(g);return(BI.isNotNull(f.maxOpacity)&&BI.isNotNull(f.minOpacity))?{min:f.minOpacity,max:f.maxOpacity}:BICst.DEFAULT_CHART_SETTING.heatMapOpacity
},getWSHeatMapBlurWidthByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.blur)?f.blur:BICst.DEFAULT_CHART_SETTING.heatMapBlur},getWSAutoQueryByID:function(g){var f=this.getWidgetSettingsByID(g);return BI.isNotNull(f.autoQuery)?f.autoQuery:true},getWidgetSettingsByID:function(f){return Data.SharingPool.get("widgets",f,"settings")||{}},getWidgetInitTimeByID:function(f){return Data.SharingPool.get("widgets",f,"initTime")||Date.getTime()},getJumpByID:function(f){return Data.SharingPool.get("widgets",f,"jump")||[]
},getClickedByID:function(f){return Data.SharingPool.get("widgets",f,"clicked")||{}},getDrillSequenceByID:function(f){return Data.SharingPool.get("widgets",f,"drillSequence")||[]},getDrillByID:function(i){var f=this;var g=this.getClickedByID(i);var h={};BI.each(g,function(k,j){if(f.isDimensionExist(k)&&f.isDimensionByDimensionID(k)){h[k]=j}});return h},getDrillList:function(g){var f=BI.Utils.getDrillByID(g);var h={};BI.each(f,function(i,j){h[i]=[];BI.each(j,function(k,l){h[i].push(l.dId)})});return h
},getLinkageList:function(j,i){var g=this;i=i||[];var l=this.getLinkageValuesByID(j);var k=[];BI.each(l,function(m){var n=g.getWidgetIDByDimensionID(m);if(!BI.contains(i,n)){BI.each(g.getLinkageList(n,BI.concat(i,[j])),function(o,p){k.push(BI.concat([n],p))})}});var f=[];var h=0;BI.each(k,function(n,m){if(n===0){f=[m];h=m.length}else{if(h<m.length){f=[m];h=m.length}if(h===m.length){f.push(m)}}});return BI.isEmptyArray(f)?[f]:f},getLinkageValuesByID:function(i){var f=this;var g=this.getClickedByID(i);
var h={};BI.each(g,function(k,j){if(f.isDimensionExist(k)&&!f.isDimensionByDimensionID(k)){h[k]=j}});return h},getDrillDownDIdsByWidgetId:function(i){var j=BI.Utils.getAllDimDimensionIDs(i);var h=BI.Utils.getAllUsableDimDimensionIDs(i);var f=[];if(j.length>h.length){var g=this.getDrillByID(i);var k=[];BI.each(g,function(l,m){BI.each(m,function(n,o){k.push(o.dId)})});BI.each(j,function(l,m){if(!h.contains(m)&&!k.contains(m)){f.push(m)}})}return f},getDrillUpDimensionIdByDimensionId:function(k){var i=BI.Utils.getWidgetIDByDimensionID(k);
var j=BI.Utils.getAllDimDimensionIDs(i);var h=BI.Utils.getAllUsableDimDimensionIDs(i);var f=null;if(j.length>h.length){var g=BI.Utils.getDrillByID(i);BI.any(g,function(l,m){if(m.length>0&&(k===l||m[m.length-1].dId===k)){if(m.length>1){f=m[m.length-2].dId}else{f=l}return true}})}return f},getClickedValue4Group:function(p,q){var o=this.getDimensionGroupByID(q);var j=this.getFieldTypeByDimensionID(q);var m=p;if(BI.isNotNull(o)){if(j===BICst.COLUMN.STRING){var f=o.details,i=o.ungroup2Other,n=o.ungroup2OtherName;
if(i===BICst.CUSTOM_GROUP.UNGROUP2OTHER.SELECTED&&n===p){m=BICst.UNGROUP_TO_OTHER}BI.some(f,function(r,s){if(s.value===p){m=s.id;return true}})}else{if(j===BICst.COLUMN.NUMBER){var g=o.groupValue,k=o.type;if(k===BICst.GROUP.CUSTOM_NUMBER_GROUP){var h=g.groupNodes,l=g.useOther;if(l===p){m=BICst.UNGROUP_TO_OTHER}BI.some(h,function(r,s){if(s.groupName===p){m=s.id;return true}})}}}}return m},getWidgetFilterValueByID:function(f){if(this.isWidgetExistByID(f)){return Data.SharingPool.get("widgets",f,"filterValue")||{}
}return{}},getAllDimensionIDs:function(f){if(!f){return BI.keys(Data.SharingPool.cat("dimensions"))}if(this.isWidgetExistByID(f)){return BI.keys(Data.SharingPool.cat("widgets",f,"dimensions"))}return[]},getAllUsedFieldIds:function(){var g=this.getAllDimensionIDs();var f=[];BI.each(g,function(h,j){f.push(BI.Utils.getFieldIDByDimensionID(j))});return f},isWidgetExistByID:function(f){return this.getAllWidgetIDs().contains(f)},isAllFieldsExistByWidgetID:function(h){var f=this;var g=this.getAllDimensionIDs(h);
return !BI.some(g,function(j,k){return i(k)});function i(m){var l=BI.Utils.getDimensionTypeByID(m);if(l===BICst.TARGET_TYPE.STRING||l===BICst.TARGET_TYPE.NUMBER||l===BICst.TARGET_TYPE.DATE||l===BICst.TARGET_TYPE.COUNTER){var j=BI.Utils.getFieldIDByDimensionID(m);if(BI.isNull(Pool.fields[j])||Pool.fields[j].isUsable===false){return true}}else{var n=BI.Utils.getExpressionByDimensionID(m);var k=n.ids;return BI.some(k,function(p,o){var q=o;var r=BI.Utils.getFieldIDByDimensionID(q);if(BI.isNotNull(f.getDimensionTypeByID(q))){i(q)
}else{if(BI.isNull(Pool.fields[r])){return false}}})}}},isNoAuthFieldExistByWidgetID:function(h){var f=this;var g=this.getAllDimensionIDs(h);return BI.some(g,function(j,k){return i(k)});function i(m){var l=BI.Utils.getDimensionTypeByID(m);if(l===BICst.TARGET_TYPE.STRING||l===BICst.TARGET_TYPE.NUMBER||l===BICst.TARGET_TYPE.DATE||l===BICst.TARGET_TYPE.COUNTER){var j=BI.Utils.getFieldIDByDimensionID(m);if(BI.isNotNull(Pool.noAuthFields[j])){return true}}else{var n=BI.Utils.getExpressionByDimensionID(m);
var k=n.ids;return BI.some(k,function(p,o){var q=o;var r=BI.Utils.getFieldIDByDimensionID(q);if(BI.isNotNull(f.getDimensionTypeByID(q))){return i(q)}else{if(BI.isNotNull(Pool.noAuthFields[r])){return true}}})}}},getAllDimDimensionIDs:function(h){var f=[];var g=Data.SharingPool.get("widgets",h,"view");BI.each(g,function(j,k){if(BI.Utils.isDimensionRegionByRegionType(j)){f=f.concat(k)}});return f},getAllTargetDimensionIDs:function(h){var f=[];var g=Data.SharingPool.get("widgets",h,"view");BI.each(g,function(k,j){if(BI.Utils.isTargetRegionByRegionType(k)){f=f.concat(j)
}});return f},getAllBaseDimensionIDs:function(j){var h=this;var g=[];var i=this.getAllDimensionIDs(j);var f=[BICst.TARGET_TYPE.STRING,BICst.TARGET_TYPE.NUMBER,BICst.TARGET_TYPE.DATE,BICst.TARGET_TYPE.COUNTER];BI.each(i,function(k,m){var l=h.getDimensionTypeByID(m);if(f.contains(l)){g.push(m)}});return g},getAllUsableDimensionIDs:function(h){var f=this,i=[],g=[];if(!h){i=BI.keys(Data.SharingPool.get("dimensions"))}else{i=BI.keys(Data.SharingPool.get("widgets",h,"dimensions"))}BI.each(i,function(j,k){f.isDimensionUsable(k)&&(g.push(k))
});return g},getAllUsableDimDimensionIDs:function(h){var f=this,g=[];var i=this.getAllDimDimensionIDs(h);BI.each(i,function(j,k){f.isDimensionUsable(k)&&(g.push(k))});return g},getAllUsableTargetDimensionIDs:function(h){var f=this,g=[];var i=this.getAllTargetDimensionIDs(h);BI.each(i,function(j,k){f.isDimensionUsable(k)&&(g.push(k))});return g},getImagesByWidgetID:function(g){var f=this.getWidgetSettingsByID(g);return f.images||[]},isImageNotExists:function(g,i){var h=this.getWidgetIDByDimensionID(g);
var f=this.getImagesByWidgetID(h);return f.indexOf(i)===-1&&!/^default/.test(i)},getDatalabelByWidgetID:function(g){var f=this.getWidgetSettingsByID(g);return f.dataLabel||{}},getWidgetIDByDimensionID:function(i){var f=this;if(!this._dimension2WidgetMap){this._dimension2WidgetMap={}}if(BI.isNotNull(this._dimension2WidgetMap[i])){return this._dimension2WidgetMap[i]}var g=this.getAllWidgetIDs();var h=BI.find(g,function(j,k){var l=f.getAllDimensionIDs(k);return BI.find(l,function(m,n){return i===n})
});this._dimension2WidgetMap[i]=h;return h},getDimensionNameByID:function(f){if(BI.isNotNull(Data.SharingPool.cat("dimensions",f))){return Data.SharingPool.get("dimensions",f,"name")}},getDimensionNameWithLevel:function(j){var h=this.getDimensionNameByID(j);var i=this.getDimensionSettingsByID(j);var f="";BI.any(BICst.TARGET_STYLE_LEVEL,function(l,k){if(i.formatStyle===BICst.TARGET_STYLE.AXIS_FORMAT.PERCENT){f="%";return true}else{if(k.value===i.numLevel&&i.numLevel!==BICst.TARGET_STYLE.NUM_LEVEL.NORMAL){f=k.text;
return true}}});var g=f+(i.unit||"");if(BI.isNotEmptyString(g)){h=h+"("+g+")"}return h},isDimensionUsable:function(f){if(BI.isNotNull(Data.SharingPool.cat("dimensions",f))){return Data.SharingPool.get("dimensions",f,"used")}},isDimensionExist:function(f){return this.getAllDimensionIDs().contains(f)},getDimensionSortByID:function(f){if(BI.isNotNull(Data.SharingPool.cat("dimensions",f))){return Data.SharingPool.get("dimensions",f,"sort")||{}}return{}},getDimensionSrcByID:function(f){if(BI.isNotNull(Data.SharingPool.cat("dimensions",f))){return Data.SharingPool.get("dimensions",f,"_src")||{}
}return{}},getDimensionGroupByID:function(f){if(BI.isNotNull(Data.SharingPool.cat("dimensions",f))){return Data.SharingPool.get("dimensions",f,"group")||{}}return{}},getDimensionTypeByID:function(f){if(BI.isNotNull(Data.SharingPool.cat("dimensions",f))){return Data.SharingPool.get("dimensions",f,"type")}},getDimensionFilterValueByID:function(f){if(BI.isNotNull(Data.SharingPool.cat("dimensions",f))){return Data.SharingPool.get("dimensions",f,"filterValue")||{}}return{}},getDimensionSettingsByID:function(g){if(BI.isNotNull(Data.SharingPool.cat("dimensions",g))){var f=Data.SharingPool.get("dimensions",g,"settings")||{formatStyle:BICst.TARGET_STYLE.AXIS_FORMAT.AUTO,formatDecimal:BICst.TARGET_STYLE.FORMAT.TWO2POINT,numLevel:BICst.TARGET_STYLE.NUM_LEVEL.NORMAL,unit:"",iconStyle:BICst.TARGET_STYLE.ICON_STYLE.NONE,mark:0,conditions:[],numSeparators:BICst.TARGET_STYLE.NUM_SEPARATORS,dateFormat:{type:BICst.DATE_FORMAT_SPLIT},showMissTime:false};
if(!BI.has(f,"formatDecimal")){f.formatDecimal=BICst.TARGET_STYLE.FORMAT.NORMAL}return f}return{}},getDimensionHyperLinkByID:function(f){if(BI.isNotNull(Data.SharingPool.cat("dimensions",f))){return Data.SharingPool.get("dimensions",f,"hyperlink")||{}}return{}},getFieldTypeByDimensionID:function(g){if(BI.isNotNull(Data.SharingPool.cat("dimensions",g))){var f=this.getFieldIDByDimensionID(g);if(BI.isKey(f)){return this.getFieldTypeByID(f)}return BICst.COLUMN.NUMBER}},getDimensionStyleOfChartByID:function(f){if(BI.isNotNull(Data.SharingPool.cat("dimensions",f))){return Data.SharingPool.get("dimensions",f,"style_of_chart")
}},getDimensionCordonByID:function(f){if(BI.isNotNull(Data.SharingPool.cat("dimensions",f))){return Data.SharingPool.get("dimensions",f,"cordon")}},getDimensionPositionByID:function(f){if(BI.isNotNull(Data.SharingPool.cat("dimensions",f))){return Data.SharingPool.get("dimensions",f,"position")}},getFieldIDByDimensionID:function(f){if(BI.isNotNull(Data.SharingPool.cat("dimensions",f))){return Data.SharingPool.get("dimensions",f,"_src","fieldId")}},getExpressionByDimensionID:function(f){if(BI.isNotNull(Data.SharingPool.cat("dimensions",f))){return Data.SharingPool.get("dimensions",f,"_src","expression")
}},getExpressionValuesByDimensionID:function(f){var g=this.getExpressionByDimensionID(f);if(BI.isNotNull(g)){return g.ids||[]}return[]},getTableIDByDimensionID:function(f){if(BI.isNotNull(Data.SharingPool.cat("dimensions",f))){return BI.Utils.getTableIdByFieldID(BI.Utils.getFieldIDByDimensionID(f))}},getDimensionMapByDimensionID:function(f){if(BI.isNotNull(Data.SharingPool.cat("dimensions",f))){return Data.SharingPool.get("dimensions",f,"dimensionMap")||{}}return{}},getDatalabelByID:function(f){if(BI.isNotNull(Data.SharingPool.cat("dimensions",f))){return Data.SharingPool.get("dimensions",f,"dataLabel")||{}
}return{}},getDataimageByID:function(f){if(BI.isNotNull(Data.SharingPool.cat("dimensions",f))){return Data.SharingPool.get("dimensions",f,"dataImage")||{}}return{}},getSeriesAccumulationByDimensionID:function(f){if(BI.isNotNull(Data.SharingPool.cat("dimensions",f))){return Data.SharingPool.get("dimensions",f,"seriesAccumulation")||{}}return{}},getSeriesAccumulationByWidgetID:function(h){var g=BI.Utils.getAllUsableDimDimensionIDs(h);var f={};BI.any(g,function(i,j){if(BI.Utils.isDimensionRegion2ByRegionType(BI.Utils.getRegionTypeByDimensionID(j))){f=BI.Utils.getSeriesAccumulationByDimensionID(j)
}});return f},isDimensionByDimensionID:function(h){var i=this.getWidgetIDByDimensionID(h);var f=this.getWidgetViewByID(i);var g=null;BI.some(f,function(k,j){if(j.contains(h)){g=k;return true}});return BI.isNull(g)?false:BI.Utils.isDimensionRegionByRegionType(g)},isDimensionRegion1AreaNameByRegionType:function(f){return BI.parseInt(f)==BI.parseInt(BICst.REGION.DIMENSION1)},isDimensionRegion1LngByRegionType:function(f){return BI.parseInt(f)==BI.parseInt(BICst.REGION.DIMENSION1)+1},isDimensionRegion1LatByRegionType:function(f){return BI.parseInt(f)==BI.parseInt(BICst.REGION.DIMENSION1)+2
},isDimensionRegion2AreaNameByRegionType:function(f){return BI.parseInt(f)==BI.parseInt(BICst.REGION.DIMENSION2)},isDimensionRegion2LngByRegionType:function(f){return BI.parseInt(f)==BI.parseInt(BICst.REGION.DIMENSION2)+1},isDimensionRegion2LatByRegionType:function(f){return BI.parseInt(f)==BI.parseInt(BICst.REGION.DIMENSION2)+2},isDimensionRegionByRegionType:function(f){return BI.parseInt(f)<BI.parseInt(BICst.REGION.TARGET1)},isDimensionRegion1ByRegionType:function(f){return BI.parseInt(f)>=BI.parseInt(BICst.REGION.DIMENSION1)&&BI.parseInt(f)<BI.parseInt(BICst.REGION.DIMENSION2)
},isDimensionRegion2ByRegionType:function(f){return BI.parseInt(f)>=BI.parseInt(BICst.REGION.DIMENSION2)&&BI.parseInt(f)<BI.parseInt(BICst.REGION.TARGET1)},isTargetByDimensionID:function(j){var k=this.getWidgetIDByDimensionID(j);var g=this.getWidgetViewByID(k);var h=this.getDimensionTypeByID(j);var f=[BICst.TARGET_TYPE.STRING,BICst.TARGET_TYPE.NUMBER,BICst.TARGET_TYPE.DATE,BICst.TARGET_TYPE.COUNTER,BICst.TARGET_TYPE.FORMULA,BICst.TARGET_TYPE.MONTH_ON_MONTH_RATE,BICst.TARGET_TYPE.MONTH_ON_MONTH_VALUE,BICst.TARGET_TYPE.RANK,BICst.TARGET_TYPE.RANK_IN_GROUP,BICst.TARGET_TYPE.SUM_OF_ABOVE,BICst.TARGET_TYPE.SUM_OF_ABOVE_IN_GROUP,BICst.TARGET_TYPE.SUM_OF_ALL,BICst.TARGET_TYPE.SUM_OF_ALL_IN_GROUP,BICst.TARGET_TYPE.YEAR_ON_YEAR_RATE,BICst.TARGET_TYPE.YEAR_ON_YEAR_VALUE];
var i=0;BI.some(g,function(m,l){if(l.contains(j)){i=m;return true}});return BI.Utils.isTargetRegionByRegionType(i)&&f.contains(h)},isTargetRegionByRegionType:function(f){return BI.parseInt(f)>=BI.parseInt(BICst.REGION.TARGET1)},isTargetRegion1ByRegionType:function(f){return BI.parseInt(f)>=BI.parseInt(BICst.REGION.TARGET1)&&BI.parseInt(f)<BI.parseInt(BICst.REGION.TARGET2)},isTargetRegion2ByRegionType:function(f){return BI.parseInt(f)>=BI.parseInt(BICst.REGION.TARGET2)&&BI.parseInt(f)<BI.parseInt(BICst.REGION.TARGET3)
},isTargetRegion3ByRegionType:function(f){return BI.parseInt(f)>=BI.parseInt(BICst.REGION.TARGET3)},isDimensionType:function(f){return f===BICst.TARGET_TYPE.STRING||f===BICst.TARGET_TYPE.DATE||f===BICst.TARGET_TYPE.NUMBER},isTargetType:function(f){return f===BICst.TARGET_TYPE.NUMBER||this.isCounterType(f)||this.isCalculateTargetType(f)},isCounterType:function(f){return f===BICst.TARGET_TYPE.COUNTER},isCalculateTargetType:function(g){var f=[BICst.TARGET_TYPE.FORMULA,BICst.TARGET_TYPE.MONTH_ON_MONTH_RATE,BICst.TARGET_TYPE.MONTH_ON_MONTH_VALUE,BICst.TARGET_TYPE.RANK,BICst.TARGET_TYPE.RANK_IN_GROUP,BICst.TARGET_TYPE.SUM_OF_ABOVE,BICst.TARGET_TYPE.SUM_OF_ABOVE_IN_GROUP,BICst.TARGET_TYPE.SUM_OF_ALL,BICst.TARGET_TYPE.SUM_OF_ALL_IN_GROUP,BICst.TARGET_TYPE.YEAR_ON_YEAR_RATE,BICst.TARGET_TYPE.YEAR_ON_YEAR_VALUE];
return f.contains(g)},isCalculateTargetByDimensionID:function(g){var f=this.getDimensionTypeByID(g);return this.isCalculateTargetType(f)},isCounterTargetByDimensionID:function(j){var k=this.getWidgetIDByDimensionID(j);var g=this.getWidgetViewByID(k);var h=this.getDimensionTypeByID(j);var f=[BICst.TARGET_TYPE.COUNTER];var i=0;BI.some(g,function(m,l){if(l.contains(j)){i=m;return true}});return BI.Utils.isTargetRegionByRegionType(i)&&f.contains(h)},isSrcUsedBySrcID:function(g){var f=BI.find(this.getAllDimensionIDs(),function(h,j){var k=Data.SharingPool.get("dimensions",j,"_src");
return k.id===g});return BI.isNotNull(f)},getTargetRelationByDimensionID:function(i,f){var h=BI.Utils.getDimensionMapByDimensionID(i);var g;if(BI.isNull(f)){g=BI.firstObject(h).targetRelation}else{g=h[f].targetRelation}return g},getDimensionTypeByFieldID:function(g){var f=BI.Utils.getFieldTypeByID(g);switch(f){case BICst.COLUMN.STRING:return BICst.TARGET_TYPE.STRING;case BICst.COLUMN.COUNTER:return BICst.TARGET_TYPE.COUNTER;case BICst.COLUMN.NUMBER:return BICst.TARGET_TYPE.NUMBER;case BICst.COLUMN.DATE:return BICst.TARGET_TYPE.DATE;
default:return BICst.TARGET_TYPE.NUMBER}},getRegionDimensionIdsByDimensionID:function(h){var i=BI.Utils.getWidgetIDByDimensionID(h);var g=BI.Utils.getWidgetViewByID(i);var f=BI.findKey(g,function(j,k){if(BI.contains(k,h)){return true}});return g[f]},getRegionTypeByDimensionID:function(g){var h=BI.Utils.getWidgetIDByDimensionID(g);var f=BI.Utils.getWidgetViewByID(h);return BI.findKey(f,function(i,j){if(BI.contains(j,g)){return true}})},getDimensionUsedByOtherDimensionsByDimensionID:function(i){var g=this;
var j=this.getWidgetIDByDimensionID(i);var h=[],f=[];switch(this.getWidgetTypeByID(j)){case BICst.WIDGET.DETAIL:h=this.getAllDimensionIDs(j);BI.each(h,function(k,m){var l=g.getExpressionValuesByDimensionID(m);if(l.contains(i)){f.push(m)}});return f;default:if(this.isDimensionByDimensionID(i)){return[]}h=this.getAllTargetDimensionIDs(j);BI.each(h,function(k,m){var l=g.getExpressionValuesByDimensionID(m);if(l.contains(i)){f.push(m)}});return f}},getAllUsedTargetById:function(h){var g=this;var f=[];
if(this.isCalculateTargetByDimensionID(h)){var i=BI.Utils.getExpressionByDimensionID(h);BI.each(i.ids,function(k,j){f=BI.concat(f,g.getAllUsedTargetById(j))})}else{if(!BI.Utils.isDimensionByDimensionID(h)){f.push(h)}}return f},isDimensionValidByDimensionID:function(j){var h=this.getDimensionMapByDimensionID(j);var i=this.getAllTargetDimensionIDs(this.getWidgetIDByDimensionID(j));var g=BI.find(i,function(k,l){return !BI.Utils.isCalculateTargetByDimensionID(l)&&!f(l)});return BI.isNull(g);function f(n){var l=true;
if(BI.has(h,n)){var k=h[n].targetRelation;BI.any(k,function(s,q){var p=BI.Utils.getFirstRelationPrimaryIdFromRelations(q);var o=BI.Utils.getLastRelationForeignIdFromRelations(q);var r=BI.Utils.getPathsFromFieldAToFieldB(p,o);if(!BI.deepContains(r,q)){if(r.length===1){}else{l=false;return true}}})}else{var m=BI.Utils.getPathsFromFieldAToFieldB(BI.Utils.getFieldIDByDimensionID(j),BI.Utils.getFieldIDByDimensionID(n));l=m.length===1}return l}},getFirstRelationPrimaryIdFromRelations:function(h){var g=BI.first(h);
var f="";if(BI.isNotNull(g)){f=g.primaryKey.fieldId}return f},getLastRelationForeignIdFromRelations:function(h){var f;var g=BI.last(h);BI.isNotNull(g)&&(f=g.foreignKey.fieldId);return f},getPrimaryIdFromRelation:function(g){var f;BI.isNotNull(g.primaryKey)&&(f=g.primaryKey.fieldId);return f},getForeignIdFromRelation:function(g){var f;BI.isNotNull(g.foreignKey)&&(f=g.foreignKey.fieldId);return f},getPrimaryRelationTablesByTableID:function(g){var f=[];BI.each(Pool.foreignRelations[g],function(i,h){if(h.length>0){f.push(i)
}});return BI.uniq(f)},getForeignRelationTablesByTableID:function(g){var f=[];BI.each(Pool.relations[g],function(i,h){if(h.length>0){f.push(i)}});return BI.uniq(f)},getPathsFromTableAToTableB:function(i,h){var g=Pool.relations;if(BI.isNull(i)||BI.isNull(h)){return[]}if(BI.isNull(g[i])){return[]}if(BI.isNull(g[i][h])){return[]}return f();function f(){var j=[];return BI.filter(g[i][h],function(k,n){var m=[];var l=BI.any(n,function(s,r){var q=BI.Utils.getTableIdByFieldID(BI.Utils.getPrimaryIdFromRelation(r));
var p=BI.Utils.getTableIdByFieldID(BI.Utils.getForeignIdFromRelation(r));var o=BI.find(j,function(u,t){if(t[0]===p&&t[1]===q){return true}});m.push([q,p]);return BI.isNotNull(o)});if(l===false){j=BI.concat(j,m)}return l===false})}},getPathsFromFieldAToFieldB:function(m,l){var f=this;if(BI.isNull(m)||BI.isNull(l)){return[]}var k=BI.Utils.getTableIdByFieldID(m);var j=BI.Utils.getTableIdByFieldID(l);var i=this.getPathsFromTableAToTableB(k,j);if(k===j){return[[{primaryKey:{fieldId:m,tableId:f.getTableIdByFieldID(m)},foreignKey:{fieldId:l,tableId:f.getTableIdByFieldID(l)}}]]
}return i;function h(p,o,n){return BI.find(n,function(q,r){return BI.find(r,function(u,t){var s=f.getForeignIdFromRelation(t);return s===p||s===o})})}function g(q,o,p){var n=BI.find(q,function(r,s){return BI.find(s,function(v,u){var t=f.getForeignIdFromRelation(u);return t===o||t===p})});return BI.isNull(n)}},getCommonPrimaryTablesByTableIDs:function(g){var f=this;var h=[];var i={};BI.each(g,function(j,k){i[k]=f.getPrimaryRelationTablesByTableID(k);i[k].splice(0,0,k)});BI.each(i,function(l,k){var j=BI.deepClone(i);
k.push(l);BI.each(k,function(n,o){var m=true;BI.findKey(j,function(q,p){if(!BI.contains(p,o)){m=false;return true}});if(m===true){(!BI.contains(h,o))&&h.push(o)}})});return h},getCommonForeignTablesByTableIDs:function(h){var g=this;var i=[];var f={};BI.each(h,function(j,k){f[k]=g.getForeignRelationTablesByTableID(k);f[k].splice(0,0,k)});BI.each(f,function(l,j){var k=BI.deepClone(f);j.push(l);BI.each(j,function(n,o){var m=true;BI.findKey(k,function(q,p){if(!BI.contains(p,o)){m=false;return true}});
if(m===true){(!BI.contains(i,o))&&i.push(o)}})});return i},isTableInRelativeTables:function(h,i){var g=this;var f=BI.Utils.getCommonForeignTablesByTableIDs(h);return BI.some(f,function(j,l){if(l===i){return true}var k=g.getPrimaryRelationTablesByTableID(l);if(k.contains(i)){return true}})},isLinkageWidgetsByDimensionId:function(j,h){var g=this;var f=g.getAllTablesByWidgetId(h);var i=g.getTableIDByDimensionID(j);return g.isTableInLinkTables(f,i)},isTableInLinkTables:function(i,k){var g=this;var h=BI.some(i,function(l,m){var n=g.getPathsFromTableAToTableB(m,k);
if(n>1){return true}});if(h){return false}var j=BI.concat(g.getForeignRelationTablesByTableID(k),k);var f=BI.some(i,function(l,m){return BI.contains(j,m)});return f},getWidgetIdsBelongOneLinkGroup:function(i){var h=BI.Utils.getLinkGroup();var f=BI.Utils.getLinkGroupShowWidgetIds();if(BI.isEmptyArray(h)){return f.remove(i)}else{var g=-1;BI.some(h,function(j,k){if(BI.contains(k,i)){g=j;return true}f=BI.difference(f,k)});return g===-1?f.remove(i):h[g].remove(i)}},getLinkedWidgets:function(h,i){var f=this;
var g=f.getWidgetIdsBelongOneLinkGroup(i);return BI.filter(g,function(j,l){var k=f.getWidgetTypeByID(l);if(k===BICst.WIDGET.CONTENT){return true}return f.isLinkageWidgetsByDimensionId(h,l)})},getContentWidgets:function(){return BI.filter(this.getAllWidgetIDs(),function(f,g){return BI.Utils.getWidgetTypeByID(g)===BICst.WIDGET.CONTENT})},getRelativePrimaryAndForeignTableIDs:function(i){var h=this;var g=[];var f=this.getCommonForeignTablesByTableIDs(i);g=g.concat(f);BI.each(f,function(j,l){var k=h.getPrimaryRelationTablesByTableID(l);
g=g.concat(k)});return g},getAllPrimaryKeyByTableIds:function(h){var g=this;var f=Pool.relations;return BI.flatten(BI.map(h,function(k,l){if(BI.isNull(l)){return[]}if(BI.isNull(f[l])){return[]}var j=f[l];return BI.map(j,function(i,m){return BI.map(m,function(o,n){return g.getFirstRelationPrimaryIdFromRelations(n)})})}))},getPreviewTableDataByTableId:function(j,l){var h=this;var f=this.getSortedFieldIdsOfOneTableByTableId(j);var i={},g={10000:[]};BI.each(f,function(o,m){var r=BI.UUID();var n={},q={};
n[j]={targetRelation:[]};if(h.getFieldTypeByID(m)===BICst.COLUMN.DATE){q.type=BICst.GROUP.YMDHMS}var p=BICst.TARGET_TYPE.STRING;switch(h.getFieldTypeByID(m)){case BICst.COLUMN.DATE:p=BICst.TARGET_TYPE.DATE;break;case BICst.COLUMN.NUMBER:p=BICst.TARGET_TYPE.NUMBER}i[r]={name:r,_src:{fieldId:m,tableId:j},type:p,used:true,dimensionMap:n,group:q};g[10000].push(r)});var k={type:BICst.WIDGET.DETAIL,bounds:{height:0,width:0,left:0,top:0},wId:BI.UUID(),name:"__StatisticWidget__"+BI.UUID(),page:0,dimensions:i,view:g};
Data.Req.reqWidgetSettingByData({widget:k},function(m){l(m.data)})},getNoGroupedDataByDimensionID:function(j,k){var i=Data.SharingPool.get("dimensions",j);i.group={type:BICst.GROUP.ID_GROUP};i.filterValue={};i.used=true;var h={};h[j]=i;var g={};g[BICst.REGION.DIMENSION1]=[j];var f=this.getAllTargetDimensionIDs(this.getWidgetIDByDimensionID(j));BI.each(f,function(l,m){h[m]=Data.SharingPool.get("dimensions",m);h[m].filterValue={};if(!BI.has(g,BICst.REGION.TARGET1)){g[BICst.REGION.TARGET1]=[]}g[BICst.REGION.TARGET1].push(m)
});this.getWidgetDataByWidgetInfo(h,g,function(l){k(BI.pluck(l.data.c,"n"))},{page:BICst.TABLE_PAGE_OPERATOR.ALL_PAGE})},getDataByDimensionID:function(j,k){var h=this.getWidgetIDByDimensionID(j);var i=Data.SharingPool.get("dimensions",j);i.filterValue={};i.used=true;var g=Data.SharingPool.get("widgets",h);g.type=BICst.WIDGET.TABLE;g.wId=h;g.page=-1;g.realData=true;g.dimensions={};g.dimensions[j]=i;g.view={};g.view[BICst.REGION.DIMENSION1]=[j];var f=this.getAllTargetDimensionIDs(this.getWidgetIDByDimensionID(j));
BI.each(f,function(l,m){g.dimensions[m]=Data.SharingPool.get("dimensions",m);g.dimensions[m].filterValue={};if(!BI.has(g.view,BICst.REGION.TARGET1)){g.view[BICst.REGION.TARGET1]=[]}g.view[BICst.REGION.TARGET1].push(m)});Data.Req.reqWidgetSettingByData({widget:g},function(l){k(BI.pluck(l.data.c,"n"))})},getWidgetDataByDimensionInfo:function(i,g){var f="__StatisticWidget__"+BI.UUID();var h={type:BICst.WIDGET.STRING,bounds:{height:0,width:0,left:0,top:0},name:f,wId:BI.UUID(),dimensions:{"1234567":BI.extend({name:"__Dimension__",_src:i,type:BICst.TARGET_TYPE.STRING},g)},view:{10000:["1234567"]}};
var g={};return{setDimensionType:function(j){h.dimensions["1234567"].type=j},setSrc:function(j){h.dimensions["1234567"]._src=j},setFilterValue:function(j){h.dimensions["1234567"].filterValue=j},setSort:function(j){h.dimensions["1234567"].sort=j},setOptions:function(j){g=j},first:function(j){var k=BI.deepClone(h);k.page=BICst.TABLE_PAGE_OPERATOR.REFRESH;Data.Req.reqWidgetSettingByData({widget:BI.extend(k,{textOptions:g})},function(l){j(l)})},prev:function(j){var k=BI.deepClone(h);k.page=BICst.TABLE_PAGE_OPERATOR.ROW_PRE;
Data.Req.reqWidgetSettingByData({widget:BI.extend(k,{textOptions:g})},function(l){j(l)})},next:function(j){var k=BI.deepClone(h);k.page=BICst.TABLE_PAGE_OPERATOR.ROW_NEXT;Data.Req.reqWidgetSettingByData({widget:BI.extend(k,{textOptions:g})},function(l){j(l)})},all:function(j){var k=BI.deepClone(h);k.page=BICst.TABLE_PAGE_OPERATOR.ALL_PAGE;Data.Req.reqWidgetSettingByData({widget:BI.extend(k,{textOptions:g})},function(l){j(l)})}}},getWidgetDataByWidgetInfo:function(i,f,k,h){var g=this;h||(h={});var j={bounds:{left:0,top:0,width:0,height:0},wId:BI.UUID(),name:"__StatisticWidget__"+BI.UUID(),dimensions:i,filter:{filterType:BICst.FILTER_TYPE.AND,filterValue:g.getControlCalculations(h.id)},type:BICst.WIDGET.TABLE,view:f};
Data.Req.reqWidgetSettingByData({widget:BI.extend(j,h)},function(l){k(l)})},getControlCalculations:function(g){var i=this,m=[];var f=this.getAllWidgetIDs();BI.each(f,function(p,u){if(!i.isControlWidgetByWidgetId(u)){return}if(u===g){return}var s=i.getWidgetValueByID(u);if(BI.isNotNull(s)){var o=i.getAllDimensionIDs(u);BI.each(o,function(A,D){var E=s,x="";if(BI.isNull(E)||BI.isEmptyString(s)||BI.isEmptyObject(s)||!h(i.getWidgetTypeByID(u),s)){return}var w=null;switch(i.getWidgetTypeByID(u)){case BICst.WIDGET.STRING:case BICst.WIDGET.STRING_LIST:case BICst.WIDGET.LIST_LABEL:x=BICst.TARGET_FILTER_STRING.BELONG_VALUE;
w={filterType:x,filterValue:E,_src:{fieldId:i.getFieldIDByDimensionID(D)}};break;case BICst.WIDGET.SINGLE_SLIDER:case BICst.WIDGET.INTERVAL_SLIDER:case BICst.WIDGET.NUMBER:x=BICst.TARGET_FILTER_NUMBER.BELONG_VALUE;w={filterType:x,filterValue:E,_src:{fieldId:i.getFieldIDByDimensionID(D)}};break;case BICst.WIDGET.DATE:x=BICst.FILTER_DATE.BELONG_DATE_RANGE;var v=E.start,z=E.end;E={};if(BI.isNotNull(v)){v=b(v);E.start=v}if(BI.isNotNull(z)){z=b(z);E.end=z}w={filterType:x,filterValue:E,_src:{fieldId:i.getFieldIDByDimensionID(D)}};
break;case BICst.WIDGET.MONTH:x=BICst.FILTER_DATE.EQUAL_TO;var C=E.year,B=E.month;if(BI.isNumeric(C)){m.push({filterType:BICst.FILTER_DATE.EQUAL_TO,filterValue:{group:BICst.GROUP.Y,values:C},_src:{fieldId:i.getFieldIDByDimensionID(D)}})}if(!BI.isNumeric(B)){return}E={group:BICst.GROUP.M,values:B+1};w={filterType:x,filterValue:E,_src:{fieldId:i.getFieldIDByDimensionID(D)}};break;case BICst.WIDGET.QUARTER:x=BICst.FILTER_DATE.EQUAL_TO;var y=E.quarter,C=E.year;if(BI.isNumeric(C)){m.push({filterType:BICst.FILTER_DATE.EQUAL_TO,filterValue:{group:BICst.GROUP.Y,values:C},_src:{fieldId:i.getFieldIDByDimensionID(D)}})
}if(!BI.isNumeric(y)){return}E={group:BICst.GROUP.S,values:y};w={filterType:x,filterValue:E,_src:{fieldId:i.getFieldIDByDimensionID(D)}};break;case BICst.WIDGET.YEAR:x=BICst.FILTER_DATE.EQUAL_TO;E={group:BICst.GROUP.Y,values:E};w={filterType:x,filterValue:E,_src:{fieldId:i.getFieldIDByDimensionID(D)}};break;case BICst.WIDGET.YMD:case BICst.WIDGET.DATE_PANE:x=BICst.FILTER_DATE.EQUAL_TO;E={group:BICst.GROUP.YMD,values:b(E)};w={filterType:x,filterValue:E,_src:{fieldId:i.getFieldIDByDimensionID(D)}};
break}BI.isNotNull(w)&&m.push(w)});if(i.getWidgetTypeByID(u)===BICst.WIDGET.TREE||i.getWidgetTypeByID(u)===BICst.WIDGET.TREE_LIST){var r=i.getWidgetViewByID(u)[BICst.REGION.DIMENSION1];var n=[];l(n,s,0,r);q={filterType:BICst.FILTER_TYPE.OR,filterValue:n};m.push(q)}if(i.getWidgetTypeByID(u)===BICst.WIDGET.TREE_LABEL){var r=i.getWidgetViewByID(u)[BICst.REGION.DIMENSION1];var t=[];k(t,s,r);q={filterType:BICst.FILTER_TYPE.OR,filterValue:t};m.push(q)}if(i.getWidgetTypeByID(u)===BICst.WIDGET.GENERAL_QUERY&&s.length===1){var q=s[0];
if(BI.isNotNull(a(q))){m.push(q)}}}});return m;function l(n,q,r,o,p){BI.each(q,function(t,v){var s={filterType:BICst.TARGET_FILTER_STRING.BELONG_VALUE,filterValue:{type:BI.Selection.Multi,value:[t]},_src:i.getDimensionSrcByID(o[r])};if(BI.isEmptyObject(v)){var u={filterType:BICst.FILTER_TYPE.AND,filterValue:[]};u.filterValue.push(s);if(BI.isNotNull(p)){u.filterValue=u.filterValue.concat(p)}n.push(u)}else{p||(p=[]);l(n,v,r+1,o,p.concat(s))}})}function k(n,p,o){p=j(p);BI.each(p,function(r,q){var s={filterType:BICst.FILTER_TYPE.AND,filterValue:[]};
BI.each(q,function(t,u){if(u===BICst.LIST_LABEL_TYPE.ALL){return}s.filterValue.push({filterType:BICst.TARGET_FILTER_STRING.BELONG_VALUE,filterValue:{type:BI.Selection.Multi,value:[u]},_src:i.getDimensionSrcByID(o[t])})});n.push(s)})}function j(n){if(!BI.isArray(n)){n=[]}return n.reduce(function(p,o){return p.map(function(q){return o.map(function(r){return q.concat(r)})}).reduce(function(r,q){return r.concat(q)},[])},[[]])}function h(n,o){switch(n){case BICst.WIDGET.NUMBER:return !(BI.isEmptyString(o.min)&&BI.isEmptyString(o.max));
default:return true}}},getWidgetCalculationByID:function(p,r){var t=this;r=r||{};var f=Data.SharingPool.get("widgets",p);f.globalStyle=Data.SharingPool.get("globalStyle");f.wId=p;var k=[];function n(H,D){var E=BI.Utils.getDimensionGroupByID(H);var A=E.details;var B={};BI.each(A,function(J,K){B[K.id]=[];BI.each(K.content,function(L,M){B[K.id].push(M.value)})});var I=BI.keys(B),C=E.ungroup2OtherName;if(E.ungroup2Other===BICst.CUSTOM_GROUP.UNGROUP2OTHER.SELECTED){I.push(BICst.UNGROUP_TO_OTHER)}var F=D[0];
if(I.contains(F)){if(F===BICst.UNGROUP_TO_OTHER){var G=[];BI.each(B,function(K,J){K!==F&&(G=G.concat(J))});return{filterType:BICst.TARGET_FILTER_STRING.NOT_BELONG_VALUE,filterValue:{type:BI.Selection.Multi,value:G},_src:{fieldId:BI.Utils.getFieldIDByDimensionID(H)}}}return{filterType:BICst.TARGET_FILTER_STRING.BELONG_VALUE,filterValue:{type:BI.Selection.Multi,value:B[F]},_src:{fieldId:BI.Utils.getFieldIDByDimensionID(H)}}}return{filterType:BICst.TARGET_FILTER_STRING.BELONG_VALUE,filterValue:{type:BI.Selection.Multi,value:D},_src:{fieldId:BI.Utils.getFieldIDByDimensionID(H)}}
}function z(L,J){var H=J[0];var I=BI.Utils.getDimensionGroupByID(L);var A=I.groupValue,E=I.type;var B={};if((BI.isNull(A)&&BI.isNull(E))||E===BICst.GROUP.AUTO_GROUP){return}if(E===BICst.GROUP.ID_GROUP){if(BI.isNull(H)||BI.isEmptyString(H)){return{filterType:BICst.TARGET_FILTER_NUMBER.IS_NULL,filterValue:{},_src:{fieldId:BI.Utils.getFieldIDByDimensionID(L)}}}else{return{filterType:BICst.TARGET_FILTER_NUMBER.BELONG_VALUE,filterValue:{min:BI.parseFloat(H),max:BI.parseFloat(H),closemin:true,closemax:true},_src:{fieldId:BI.Utils.getFieldIDByDimensionID(L)}}
}}var C=A.groupNodes,F=A.useOther;var D,G;BI.each(C,function(M,N){M===0&&(D=N.min);M===C.length-1&&(G=N.max);B[N.id]={min:N.min,max:N.max,closemin:N.closemin,closemax:N.closemax}});if(BI.isNotNull(B[H])){return{filterType:BICst.TARGET_FILTER_NUMBER.BELONG_VALUE,filterValue:B[H],_src:{fieldId:BI.Utils.getFieldIDByDimensionID(L)}}}else{if(H===BICst.UNGROUP_TO_OTHER){var K=[];BI.each(B,function(N,M){K.push({filterType:BICst.TARGET_FILTER_NUMBER.NOT_BELONG_VALUE,filterValue:M,_src:{fieldId:BI.Utils.getFieldIDByDimensionID(L)}})
});return{filterType:BICst.FILTER_TYPE.AND,filterValue:K}}else{if(BI.isNumeric(H)){return{filterType:BICst.TARGET_FILTER_NUMBER.BELONG_VALUE,filterValue:{min:BI.parseFloat(H),max:BI.parseFloat(H),closemin:true,closemax:true},_src:{fieldId:BI.Utils.getFieldIDByDimensionID(L)}}}else{if(BI.isNull(H)||BI.isEmptyString(H)){return{filterType:BICst.TARGET_FILTER_NUMBER.IS_NULL,filterValue:{},_src:{fieldId:BI.Utils.getFieldIDByDimensionID(L)}}}}}}}function o(B){var E=B.dId;var D=t.getDimensionTypeByID(E);
switch(D){case BICst.TARGET_TYPE.STRING:return n(E,B.value);case BICst.TARGET_TYPE.NUMBER:return z(E,B.value);case BICst.TARGET_TYPE.DATE:var C=t.getDimensionGroupByID(E);var A=C.type;return{filterType:BICst.FILTER_DATE.EQUAL_TO,filterValue:{values:B.value[0],group:A},_src:{fieldId:BI.Utils.getFieldIDByDimensionID(B.dId)}}}}var g=this.getDrillByID(p);if(BI.isNotNull(g)&&f.type!==BICst.WIDGET.MAP){BI.each(g,function(A,B){if(B.length===0){return}BI.isNotNull(f.dimensions[A])&&(f.dimensions[A].used=false);
BI.each(B,function(F,D){if(BI.isNotNull(f.dimensions[D.dId])){f.dimensions[D.dId].used=(F===B.length-1);var E=t.getRegionTypeByDimensionID(A);var C=t.getRegionTypeByDimensionID(D.dId);var G=f.view[E].indexOf(A);BI.remove(f.view[C],D.dId);f.view[E].splice(G,0,D.dId)}BI.each(B[F].values,function(I,H){var J=o(H);if(BI.isNotNull(J)){k.push(J)}})})})}k=k.concat(this.isQueryControlExist()&&!this.isControlWidgetByWidgetId(p)?Data.SharingPool.get("controlFilters"):this.getControlCalculations(p));var q=this.getLinkageValuesByID(p);
BI.each(q,function(B,D){var C=BI.Utils.getWSTransferFilterByID(BI.Utils.getWidgetIDByDimensionID(B));if(C===true){var A=BI.Utils.getDimensionFilterValueByID(B);if(BI.isNotNull(A)){a(A);if(BI.isNotNull(A)&&BI.isNotEmptyObject(A)){k.push(A)}}}});f.linkedWidget={};var i=r.linkedWidgetIds||[];i.push(f.wId);var u=t.getLinkageList(f.wId,i)[0];var v=BI.isNotNull(u)?u[0]:null;if(BI.isNotNull(v)){f.linkedWidget=t.getWidgetCalculationByID(v,{linkedWidgetIds:i});f.linkedWidget.globalFilter=Data.SharingPool.get("filter")
}var l=f.dimensions;BI.each(l,function(C,B){var D=B.filterValue||{};var A=B.group||{};a(D,A.type)});var w=f.filterValue;BI.each(w,function(B,A){a(A)});var y=this.getAllDimDimensionIDs(p);BI.each(y,function(A,E){var B=t.getDimensionMapByDimensionID(E);var D=true;if(f.type===BICst.WIDGET.DETAIL||f.type===BICst.WIDGET.TREE||f.type===BICst.WIDGET.TREE_LIST||f.type===BICst.WIDGET.TREE_LABEL){BI.each(B,function(I,J){var G=J.targetRelation;var H=t.getFirstRelationPrimaryIdFromRelations(G);var F=t.getLastRelationForeignIdFromRelations(G);
var K=t.getPathsFromFieldAToFieldB(H,F);if(!BI.deepContains(K,G)){if(K.length>=1){f.dimensions[E].dimensionMap[I].targetRelation=K[0]}}})}else{var C=t.getAllTargetDimensionIDs(p);BI.any(C,function(F,J){if(!t.isCalculateTargetByDimensionID(J)){if(!BI.has(B,J)){var G=BI.Utils.getFieldIDByDimensionID(E);var I=BI.Utils.getPathsFromFieldAToFieldB(G,BI.Utils.getFieldIDByDimensionID(J));if(I.length===1){f.dimensions[E].dimensionMap[J]={_src:{fieldId:G},targetRelation:I}}else{D=false;return true}}else{var H=B[J].targetRelation;
BI.any(H,function(O,M){var L=t.getFirstRelationPrimaryIdFromRelations(M);var K=t.getLastRelationForeignIdFromRelations(M);var N=t.getPathsFromFieldAToFieldB(L,K);if(!BI.deepContains(N,M)){if(N.length===1){f.dimensions[E].dimensionMap[J].targetRelation.length=O;f.dimensions[E].dimensionMap[J].targetRelation.push(N[0])}else{D=false;return true}}})}}})}if(D===false){f.dimensions[E].used=false}});f.filter={filterType:BICst.FILTER_TYPE.AND,filterValue:k};f.realData=true;if(!BI.Utils.isControlWidgetByWidgetId(p)&&(BI.Utils.getWidgetTypeByID(p)!==BICst.WIDGET.DETAIL)){var j=BI.Utils.getAllDimDimensionIDs(p);
var m=f.clicked,h=[];BI.each(m,function(B,A){if(BI.Utils.isDimensionByDimensionID(B)){h.push(B);BI.each(A,function(D,C){h.push(C.dId)})}});BI.each(j,function(B,A){if(!(BI.Utils.isDimensionUsable(A)||h.contains(A))){delete f.dimensions[A];BI.some(f.view,function(D,C){if(C.contains(A)){BI.remove(C,A);return true}})}})}return f;function x(C,D){var B=BI.UUID();var A=BI.deepClone(C);if(BI.has(C,"filterValue")&&BI.isNotNull(C.filterValue)){A.filterValue=s(C.filterValue,B)}if(BI.has(C,"sort")){A.sort=BI.deepClone(C.sort);
if(BI.has(A.sort,"sortTarget")){if(A.sort.sortTarget===D){A.sort.sortTarget=B}}}return{id:B,dimension:A}}function s(C,B){var A=this;var D={};var E=C.filterType,F=C.filterValue;D.filterType=C.filterType;if(E===BICst.FILTER_TYPE.AND||E===BICst.FILTER_TYPE.OR){D.filterValue=[];BI.each(F,function(G,H){D.filterValue.push(A._checkFilter(H,B))})}else{BI.extend(D,C);if(BI.has(C,"targetId")){D.targetId=B}}return D}},getWidgetDataByID:(function(){var f={};return function(k,j,h,g){h||(h={});var i=BI.UUID();
if(!BI.Utils.isControlWidgetByWidgetId(k)){i=k}f[i]=j;Data.Req.reqWidgetSettingByData({widget:BI.extend(this.getWidgetCalculationByID(k),h,{globalFilter:Data.SharingPool.get("filter")})},function(l){if(f[i]===j){j.success(l);delete f[i]}else{j.error&&j.error(l)}},function(){j.done&&j.done()},{sync:g&&g.sync})}})(),broadcastAllWidgets2Refresh:function(h,i){var g=this;var f=this.getAllWidgetIDs();if(h===true||this.isQueryControlExist()===false){BI.each(f,function(j,k){if(!g.isControlWidgetByWidgetId(k)||g.isInstantControlWidgetByWidgetId(k)||BI.Utils.isSpecialWidgetByWidgetId(k)){if(BI.isNull(i)||i!==k){BI.Broadcasts.send(BICst.BROADCAST.REFRESH_PREFIX+k)
}}})}},broadcastAllContentWidgets2Refresh:function(g,h){var f=this.getAllWidgetIDs();BI.each(f,function(j,k){if(BI.Utils.isSpecialWidgetByWidgetId(k)){if(BI.isNull(h)||h!==k){BI.Broadcasts.send(BICst.BROADCAST.REFRESH_PREFIX+k)}}})},broadcastAllWidgets2Refresh4Linkage:function(h,g,f){BI.each(BI.isArray(h)?h:[h],function(i,k){var j=BI.Utils.getLinkageValuesByID(BI.Utils.getWidgetIDByDimensionID(g));BI.remove(j,function(l){return BI.Utils.getWidgetIDByDimensionID(l)===k});if(BI.isNotNull(f)&&f.length>0){j[g]=f
}BI.Broadcasts.send(BICst.BROADCAST.LINKAGE_PREFIX+k,g,j)})},getExportData4WidgetByWid:function(g){var f=BI.Utils.getWidgetCalculationByID(g);f=BI.extend(f,{wId:BI.UUID(),name:BI.Utils.getWidgetNameByID(g),globalFilter:Data.SharingPool.get("filter")});return{sessionID:Data.SharingPool.get("sessionID"),widget:f,reportName:Data.SharingPool.get("reportName"),filterValue:BI.Utils.getFilterValue4ExportByWid(g)}},doJumpByTemplateId:function(j,g){g=g||{};var f=BI.servletURL+"?op=fr_bi&cmd=";var i="_blank";
if(g.openPosition===BICst.JUMP_POSITION.CURRENT_WINDOW){i="_self"}if(g.openPosition===BICst.JUMP_POSITION.DIALOG){i=g.name}var h={};if(BI.isNotNull(g.clicked)){h.clicked=g.clicked}if(BI.isNotNull(g.linkedWidget)){h.linkedWidget=g.linkedWidget;h.linkedWidget.globalFilter=Data.SharingPool.get("filter")}BI.Func.doActionByForm(f+"bi_init",BI.extend(h,{show:"_bi_show_",id:j,createBy:Data.SharingPool.get("createBy"),sourceTemplateName:Data.SharingPool.get("reportName")}),{target:i})},doJumpByUrl:function(h,g){g=g||{};
var k="_blank";if(g.openPosition===BICst.JUMP_POSITION.CURRENT_WINDOW){k="_self"}if(g.openPosition===BICst.JUMP_POSITION.DIALOG){k=g.name}h=h||"";var f=BI.map(h.match(/\$\{.*?\}/g),function(l,m){return m.substring(2,m.length-1)});Data.Req.reqJumpFieldInfo({fieldIds:f,clicked:g.clicked,linkedWidget:BI.extend(g.linkedWidget,{globalFilter:Data.SharingPool.get("filter")})},i);function i(m){var l=j(h,m);BI.Func.doActionByForm(BI.Func.formatAddress(l.prefix),BI.extend(l.params,{paramEncode:true}),{target:k,method:"get",notEncode:true})
}function j(n,m){n=n||"";var o=n.split(/\?/);var p=(o[0]||"").replace(/\s+/g,"");p=p.replaceAll("\\$\\{.*?\\}",function(t){var u=t.substring(2,t.length-1);if(BI.has(m,u)){return m[u]}});var r=o[1]||"";var l=BI.isEmptyString(r)?[]:r.split("&");var s={};BI.each(l,function(w,y){var x=y.split("=");var v=x[0];var z=x[1];if(BI.isNull(z.match(/\$\{.*?\}/))){s[v]=z}else{if(v.length>0){var u=z.substring(2,z.length-1);if(BI.has(m,u)){var t=m[u];s[v]=t}}}});var q=p.split(/\?/);if(BI.size(s)===0&&q.length===2){p=q[0];
r=q[1];l=BI.isEmptyString(r)?[]:r.split("&");s={};BI.each(l,function(t,v){var u=v.split("=");s[u[0]]=u[1]})}return{prefix:p,params:s}}},isJumpEnabledByDimensionId:function(h){var i=this.getWidgetIDByDimensionID(h);if(BI.Utils.getWSTurnOnJumpById(i)===false){return false}var f=this.getFieldIDByDimensionID(h);var g=this.getDimensionMapByDimensionID(h);return BI.isNull(BI.find(g,function(k,j){return j.targetRelation.length>1||f!==j._src.fieldId}))},getAllTablesByWidgetId:function(j,h){var f=this;var i=this.getAllTargetDimensionIDs(j);
if(BI.isEmptyArray(i)){i=this.getAllDimDimensionIDs(j)}var g=[];BI.each(i,function(m,l){var k=f.getTableIDByDimensionID(l);k&&(g.indexOf(k)<0)&&g.push(k)});return g},getAllRelatedTablesByWidgetId:function(h){var g=this.getAllTablesByWidgetId(h)||[];var f=BI.clone(g);BI.each(g,function(j,l){var i=BI.Utils.getPrimaryRelationTablesByTableID(l)||[];var k=BI.Utils.getForeignRelationTablesByTableID(l)||[];f=BI.union(i,k,f)});return f},isTableUsableByWidgetID:function(i,k){var g=this;var j=this.getAllDimensionIDs(k);
var f=[];BI.each(j,function(m,n){var l=g.getDimensionTypeByID(n);switch(l){case BICst.TARGET_TYPE.DATE:case BICst.TARGET_TYPE.STRING:case BICst.TARGET_TYPE.NUMBER:f.push(n)}});if(f.length<1){return true}var h=[];BI.each(f,function(m,l){h.push(g.getTableIDByDimensionID(l))});return this.isTableInRelativeTables(h,i)},});function b(f){if(f.type===BICst.DATE_TYPE.MULTI_DATE_PARAM){return h(f.value)}else{return g(f)}function h(n){var l=n.widgetInfo,p=n.offset;if(BI.isNull(l)||BI.isNull(p)){return}var k;
var o=l.wId,m=l.startOrEnd;if(BI.isNotNull(o)&&BI.isNotNull(m)){var j=BI.Utils.getWidgetValueByID(o);if(BI.isNull(j)||BI.isEmptyObject(j)){return}if(m===BI.MultiDateParamPane.start&&BI.isNotNull(j.start)){k=g(j.start)}if(m===BI.MultiDateParamPane.end&&BI.isNotNull(j.end)){k=g(j.end)}}else{if(BI.isNull(l.wId)||BI.isNull(BI.Utils.getWidgetValueByID(l.wId))){return}k=g(BI.Utils.getWidgetValueByID(l.wId))}if(BI.isNotNull(k)){return g(p,Date.getDate(k))}}function g(r,p){var o=r.type,q=r.value;var m=BI.isNull(p)?Date.getDate():p;
var k=m.getFullYear(),n=m.getMonth(),j=m.getDate();m=Date.getDate(m.getFullYear(),m.getMonth(),m.getDate());if(BI.isNull(o)&&i(r)){return Date.getTime(r.year,r.month,r.day)}var l;switch(o){case BICst.DATE_TYPE.MULTI_DATE_YEAR_PREV:return Date.getTime(k-1*q,n,j);case BICst.DATE_TYPE.MULTI_DATE_YEAR_AFTER:return Date.getTime(k+1*q,n,j);case BICst.DATE_TYPE.MULTI_DATE_YEAR_BEGIN:return Date.getTime(k,0,1);case BICst.DATE_TYPE.MULTI_DATE_YEAR_END:return Date.getTime(k,11,31);case BICst.DATE_TYPE.MULTI_DATE_MONTH_PREV:l=m.getBeforeMultiMonth(q);
return Date.getTime(l.getFullYear(),l.getMonth(),l.getDate(),l.getHours(),l.getMinutes(),l.getSeconds());case BICst.DATE_TYPE.MULTI_DATE_MONTH_AFTER:l=m.getAfterMultiMonth(q);return Date.getTime(l.getFullYear(),l.getMonth(),l.getDate(),l.getHours(),l.getMinutes(),l.getSeconds());case BICst.DATE_TYPE.MULTI_DATE_MONTH_BEGIN:l=Date.getDate(k,n,1);return Date.getTime(l.getFullYear(),l.getMonth(),l.getDate(),l.getHours(),l.getMinutes(),l.getSeconds());case BICst.DATE_TYPE.MULTI_DATE_MONTH_END:l=Date.getDate(k,n,(m.getLastDateOfMonth()).getDate());
return Date.getTime(l.getFullYear(),l.getMonth(),l.getDate(),l.getHours(),l.getMinutes(),l.getSeconds());case BICst.DATE_TYPE.MULTI_DATE_QUARTER_PREV:l=m.getBeforeMulQuarter(q);return Date.getTime(l.getFullYear(),l.getMonth(),l.getDate(),l.getHours(),l.getMinutes(),l.getSeconds());case BICst.DATE_TYPE.MULTI_DATE_QUARTER_AFTER:l=m.getAfterMulQuarter(q);return Date.getTime(l.getFullYear(),l.getMonth(),l.getDate(),l.getHours(),l.getMinutes(),l.getSeconds());case BICst.DATE_TYPE.MULTI_DATE_QUARTER_BEGIN:l=m.getQuarterStartDate();
return Date.getTime(l.getFullYear(),l.getMonth(),l.getDate(),l.getHours(),l.getMinutes(),l.getSeconds());case BICst.DATE_TYPE.MULTI_DATE_QUARTER_END:l=m.getQuarterEndDate();return Date.getTime(l.getFullYear(),l.getMonth(),l.getDate(),l.getHours(),l.getMinutes(),l.getSeconds());case BICst.DATE_TYPE.MULTI_DATE_WEEK_PREV:l=m.getOffsetDate(-7*q);return Date.getTime(l.getFullYear(),l.getMonth(),l.getDate(),l.getHours(),l.getMinutes(),l.getSeconds());case BICst.DATE_TYPE.MULTI_DATE_WEEK_AFTER:l=m.getOffsetDate(7*q);
return Date.getTime(l.getFullYear(),l.getMonth(),l.getDate(),l.getHours(),l.getMinutes(),l.getSeconds());case BICst.DATE_TYPE.MULTI_DATE_DAY_PREV:l=m.getOffsetDate(-1*q);return Date.getTime(l.getFullYear(),l.getMonth(),l.getDate(),l.getHours(),l.getMinutes(),l.getSeconds());case BICst.DATE_TYPE.MULTI_DATE_DAY_AFTER:l=m.getOffsetDate(1*q);return Date.getTime(l.getFullYear(),l.getMonth(),l.getDate(),l.getHours(),l.getMinutes(),l.getSeconds());case BICst.DATE_TYPE.MULTI_DATE_DAY_TODAY:return Date.getTime(m.getFullYear(),m.getMonth(),m.getDate(),m.getHours(),m.getMinutes(),m.getSeconds());
case BICst.DATE_TYPE.MULTI_DATE_CALENDAR:return Date.getTime(q.year,q.month,q.day)}}function i(j){return BI.isNotNull(j.year)&&BI.isNotNull(j.month)&&BI.isNotNull(j.day)}}function a(m,t){var k=m.filterType,w=m.filterValue;if(k===BICst.FILTER_TYPE.AND||k===BICst.FILTER_TYPE.OR){BI.each(w,function(s,y){a(y,t)})}if(BI.isNull(w)){return}if(k===BICst.FILTER_DATE.BELONG_DATE_RANGE||k===BICst.FILTER_DATE.NOT_BELONG_DATE_RANGE){var j=w.start,g=w.end;if(BI.isNotNull(j)){w.start=b(j)}if(BI.isNotNull(g)){var h=b(g);
if(BI.isNotNull(h)){var f=Date.getDate(h).getOffsetDate(1);w.end=Date.getTime(f.getFullYear(),f.getMonth(),f.getDate(),f.getHours(),f.getMinutes(),f.getSeconds())-1}else{delete w.end}}}if(k===BICst.FILTER_DATE.BELONG_WIDGET_VALUE||k===BICst.FILTER_DATE.NOT_BELONG_WIDGET_VALUE){var l=w.wId,u=(w.filterValue||{}).type;var p=BI.Utils.getWidgetValueByID(l);if(!BI.Utils.isWidgetExistByID(l)||BI.isNull(p)){return}switch(u){case BICst.DATE_TYPE.SAME_PERIOD:if(BI.isNotNull(p.start)){w.start=b(p.start)}if(BI.isNotNull(p.end)){var h=b(p.end);
if(BI.isNotNull(h)){var f=Date.getDate(h).getOffsetDate(1);w.end=Date.getTime(f.getFullYear(),f.getMonth(),f.getDate(),f.getHours(),f.getMinutes(),f.getSeconds())-1}else{delete w.end}}break;case BICst.DATE_TYPE.LAST_SAME_PERIOD:if(BI.isNotNull(p.start)&&BI.isNotNull(p.end)){var n=b(p.start);var v=b(p.end);if(BI.isNotNull(n)&&BI.isNotNull(v)){var f=Date.getDate(2*n-v).getOffsetDate(-1);w.start=Date.getTime(f.getFullYear(),f.getMonth(),f.getDate(),f.getHours(),f.getMinutes(),f.getSeconds())}else{delete w.start
}if(BI.isNotNull(n)){w.end=Date.getTime(n)-1}else{delete w.end}}else{if(BI.isNotNull(p.start)){var n=b(p.start);delete w.start;if(BI.isNotNull(n)){w.end=n-1}else{delete w.end}}else{if(BI.isNotNull(p.end)){w.start=w.end=0}}}break;case BICst.DATE_TYPE.YEAR_QUARTER:case BICst.DATE_TYPE.YEAR_MONTH:case BICst.DATE_TYPE.YEAR_WEEK:case BICst.DATE_TYPE.YEAR_DAY:case BICst.DATE_TYPE.MONTH_WEEK:case BICst.DATE_TYPE.MONTH_DAY:case BICst.DATE_TYPE.YEAR:var x=q(l);if(!i(l)){w.filterValue.type=BICst.DATE_TYPE.YEAR
}if(BI.isNotNull(x)){var r=o(x,w.filterValue);w.start=r.start;if(BI.isNotNull(r.end)){var f=Date.getDate(r.end).getOffsetDate(1);w.end=Date.getTime(f.getFullYear(),f.getMonth(),f.getDate(),f.getHours(),f.getMinutes(),f.getSeconds())-1}}break}}if(k===BICst.FILTER_DATE.EARLY_THAN){var x=q(w.wId);if(BI.isNotNull(x)){var r=o(x,w.filterValue);if(BI.isNotNull(r.start)){w.end=r.start-1}}}if(k===BICst.FILTER_DATE.LATER_THAN){var x=q(w.wId);if(BI.isNotNull(x)){var r=o(x,w.filterValue);if(BI.isNotNull(r.start)){w.start=r.start
}}}if(k===BICst.FILTER_DATE.EQUAL_TO||k===BICst.FILTER_DATE.NOT_EQUAL_TO){if(BI.isNull(w)){w={}}else{w.values=b(w);w.group=BICst.GROUP.YMD}}if(k===BICst.DIMENSION_FILTER_DATE.CONTAIN||k===BICst.DIMENSION_FILTER_DATE.NOT_CONTAIN||k===BICst.DIMENSION_FILTER_DATE.BEGIN_WITH||k===BICst.DIMENSION_FILTER_DATE.END_WITH){BI.isNotNull(t)&&(m.group=t)}return m;function o(z,G){var C=G.type,G=G.value;var B=G.foffset===0?-1:1;var I=G.soffset===0?-1:1;var s,A;s=A=z;var H=Date.getDate((z.getFullYear()+B*G.fvalue),z.getMonth(),1).getMonthDays();
var E=z.getDate();if(E>H){E=H}var D=Date.getDate((z.getFullYear()+B*G.fvalue),z.getMonth(),E);switch(C){case BICst.DATE_TYPE.YEAR:s=Date.getDate((z.getFullYear()+B*G.fvalue),0,1);A=Date.getDate(s.getFullYear(),11,31);break;case BICst.DATE_TYPE.YEAR_QUARTER:D=D.getOffsetMonth(I*G.svalue*3);s=D.getQuarterStartDate();A=D.getQuarterEndDate();break;case BICst.DATE_TYPE.YEAR_MONTH:D=D.getOffsetMonth(I*G.svalue);s=Date.getDate(D.getFullYear(),D.getMonth(),1);A=Date.getDate(D.getFullYear(),D.getMonth(),(D.getLastDateOfMonth()).getDate());
break;case BICst.DATE_TYPE.YEAR_WEEK:var y=D.getOffsetDate(I*7*G.svalue);s=y.getWeekStartDate();A=s.getWeekEndDate();break;case BICst.DATE_TYPE.YEAR_DAY:s=D.getOffsetDate(I*G.svalue);A=s;break;case BICst.DATE_TYPE.MONTH_WEEK:var F=z.getOffsetMonth(B*G.fvalue);var y=F.getOffsetDate(I*7*G.svalue);s=y.getWeekStartDate();A=s.getWeekEndDate();break;case BICst.DATE_TYPE.MONTH_DAY:var F=z.getOffsetMonth(B*G.fvalue);s=F.getOffsetDate(I*G.svalue);A=s;break}return{start:Date.getTime(s.getFullYear(),s.getMonth(),s.getDate(),s.getHours(),s.getMinutes(),s.getSeconds()),end:Date.getTime(A.getFullYear(),A.getMonth(),A.getDate(),A.getHours(),A.getMinutes(),A.getSeconds())}
}function i(z){var A=BI.Utils.getWidgetTypeByID(z);var y=BI.Utils.getWidgetValueByID(z);var s=true;switch(A){case BICst.WIDGET.MONTH:if(!BI.isNumeric(y.month)){s=false}break;case BICst.WIDGET.QUARTER:if(!BI.isNumeric(y.quarter)){s=false}break}return s}function q(B){if(!BI.Utils.isWidgetExistByID(B)){return null}var C=BI.Utils.getWidgetTypeByID(B);var A=BI.Utils.getWidgetValueByID(B);var z=null;switch(C){case BICst.WIDGET.YEAR:if(BI.isNumeric(A)){z=Date.getDate(A,0,1)}break;case BICst.WIDGET.MONTH:if(BI.isNotNull(A)&&BI.isNumeric(A.year)){z=Date.getDate(A.year,BI.isNumeric(A.month)?A.month:0,1)
}break;case BICst.WIDGET.QUARTER:if(BI.isNotNull(A)&&BI.isNumeric(A.year)){var y=A.quarter;z=Date.getDate(A.year,BI.isNumeric(y)?(y*3-1):0,1)}break;case BICst.WIDGET.YMD:case BICst.WIDGET.DATE_PANE:if(BI.isNotNull(A)){var s=b(A);if(BI.isNotNull(s)){z=Date.getDate(s);z=Date.getDate(z.getFullYear(),z.getMonth(),z.getDate())}}break}return z}}function d(t){var f,r;if(BI.Utils.isWidgetExistByID(t)){r=t}else{r=BI.Utils.getWidgetIDByDimensionID(t);f=t}var v=BI.Utils.getWidgetValueByID(r);var k=BI.Utils.getWidgetTypeByID(r);
var p="";var z=c(t);if(BI.isNull(v)||BI.isEmptyObject(v)||BI.isEmptyArray(v)){return BI.i18nText("BI-Basic_All")}switch(k){case BICst.WIDGET.STRING:case BICst.WIDGET.STRING_LIST:case BICst.WIDGET.LIST_LABEL:if(BI.isNull(v.value)||v.value.length===0){return BI.i18nText("BI-Basic_All")}var m=v.type===BI.Selection.Multi?"value":"assist";return j(v[m]);case BICst.WIDGET.SINGLE_SLIDER:case BICst.WIDGET.INTERVAL_SLIDER:return y(v);case BICst.WIDGET.NUMBER:return i(v);case BICst.WIDGET.DATE:return l(v);
case BICst.WIDGET.MONTH:var n=v.year,x=v.month;if(BI.isNumeric(n)&&BI.isNumeric(x)){p=n+"-"+(x+1)}else{if(BI.isNumeric(n)){p=n}else{if(BI.isNumeric(x)){p=(x+1)}else{p=BI.i18nText("BI-Basic_All")}}}return p;case BICst.WIDGET.QUARTER:var n=v.year,q=v.quarter;if(BI.isNumeric(n)&&BI.isNumeric(q)){p=n+"-"+q}else{if(BI.isNumeric(n)){p=n}else{if(BI.isNumeric(q)){p=q}else{p=BI.i18nText("BI-Basic_All")}}}return p;case BICst.WIDGET.YEAR:if(BI.isNumeric(v)){p=v}else{p=BI.i18nText("BI-Basic_All")}return p;case BICst.WIDGET.YMD:case BICst.WIDGET.DATE_PANE:if(BI.isNotNull(v)){var u=b(v);
p=BI.isNotNull(u)?Date.getDate(u).print("%Y-%X-%d"):""}else{p=BI.i18nText("BI-Basic_All")}return p;case BICst.WIDGET.TREE:case BICst.WIDGET.TREE_LIST:var h=BI.Utils.getRegionDimensionIdsByDimensionID(f);var g=h.indexOf(f);var o=s(v,0,g);return j(o);case BICst.WIDGET.TREE_LABEL:var h=BI.Utils.getRegionDimensionIdsByDimensionID(f);var g=h.indexOf(f);var w=v[g];if(w.indexOf(BICst.LIST_LABEL_TYPE.ALL)!==-1){p=BI.i18nText("BI-Basic_All")}else{p=j(w)}return p;default:return v}function s(A,B,E){var D=[];
var C=BI.Func.getSortedResult(BI.map(BI.keys(A),function(F,G){return{value:G}}));BI.each(BI.pluck(C,"value"),function(F,H){if(E===B||(E>B&&BI.isEmptyObject(A[H]))){D.push(H);return}if(E>B){var G=s(A[H],B+1,E);D=BI.concat(D,G)}});return D}function j(B){var A="";switch(B.length){case 0:break;case 1:A=B[0];break;case 2:A=B.join("&");break;case 3:A=B.join(",");break;default:A=B.slice(0,3).join(",")+BI.i18nText("BI-Filter_And_Other_More");break}return A}function y(D){var C="";var B=D.min,A=D.max;if(BI.isNotNull(B)&&BI.isNotNull(A)){if(BI.isEqual(B,A)){C=B
}else{C=B+"~"+A}}return C}function i(D){var C="";var B=D.min,A=D.max;if(BI.isNotNull(B)&&BI.isNotEmptyString(B)&&BI.isNotNull(A)&&BI.isNotEmptyString(A)){if(BI.isEqual(B,A)){C=B}else{C=B+"~"+A}}else{if(BI.isNotNull(B)&&BI.isNotEmptyString(B)){C=B+"~"+BI.i18nText("BI-Basic_Positive_Endless")}else{if(BI.isNotNull(A)&&BI.isNotEmptyString(A)){C="-"+BI.i18nText("BI-Basic_Endless")+"~"+A}else{C=BI.i18nText("BI-Basic_All")}}}return C}function l(H){var G=H.start,B=H.end;var C="",E="";var F="";if(BI.isNotNull(G)){if(BI.isNotNull(G.year)&&BI.isNotNull(G.month)&&BI.isNotNull(G.day)){C=G.year+"-"+(G.month+1)+"-"+G.day
}else{var D=b(G);if(BI.isNotNull(D)){var A=Date.getDate(D);C=A.getFullYear()+"-"+(A.getMonth()+1)+"-"+A.getDate()}else{C=""}}}if(BI.isNotNull(B)){if(BI.isNotNull(B.year)&&BI.isNotNull(B.month)&&BI.isNotNull(B.day)){E=B.year+"-"+(B.month+1)+"-"+B.day}else{var D=b(B);if(BI.isNotNull(D)){var A=Date.getDate(D);E=A.getFullYear()+"-"+(A.getMonth()+1)+"-"+A.getDate()}else{E=""}}}if(BI.isNotEmptyString(C)&&BI.isNotEmptyString(E)){F=BI.isEqual(C,E)?C:(C+BI.i18nText("BI-Basic_To")+E)}else{if(BI.isNotEmptyString(C)){F=C+BI.i18nText("BI-Hou_Last")
}else{if(BI.isNotEmptyString(E)){F=E+BI.i18nText("BI-Qian_First")}else{F=BI.i18nText("BI-Basic_All")}}}return F}}function c(f){if(BI.Utils.isWidgetExistByID(f)){return BI.Utils.getInitialWidgetNameByID(f)}else{return BI.Utils.getDimensionNameByID(f)}}function e(h,g){var i=BI.Utils.getLinkageValuesByID(h);var f=BI.i18nText("BI-Basic_All");BI.find(i,function(k,j){return BI.find(j,function(l,m){if(m.dId===g){var n=BI.Utils.getDimensionGroupByID(m.dId);f=BI.Func.formatValueByGroup(m.value[0],n.type);
return true}})});return f}})();
BI.extend(BI.Utils,{chartType:function(a){switch(a){case BICst.WIDGET.MAP:case BICst.WIDGET.GIS_MAP:case BICst.WIDGET.PIE:case BICst.WIDGET.DONUT:case BICst.WIDGET.FORCE_BUBBLE:case BICst.WIDGET.MULTI_PIE:case BICst.WIDGET.RECT_TREE:case BICst.WIDGET.FUNNEL:case BICst.WIDGET.LINE_MAP:case BICst.WIDGET.HEAT_MAP:case BICst.WIDGET.WORD_CLOUD:case BICst.WIDGET.DOT:case BICst.WIDGET.AXIS:case BICst.WIDGET.ACCUMULATE_AXIS:case BICst.WIDGET.PERCENT_ACCUMULATE_AXIS:case BICst.WIDGET.COMPARE_AXIS:case BICst.WIDGET.FALL_AXIS:case BICst.WIDGET.LINE:case BICst.WIDGET.AREA:case BICst.WIDGET.ACCUMULATE_AREA:case BICst.WIDGET.COMPARE_AREA:case BICst.WIDGET.RANGE_AREA:case BICst.WIDGET.PERCENT_ACCUMULATE_AREA:case BICst.WIDGET.BAR:case BICst.WIDGET.ACCUMULATE_BAR:case BICst.WIDGET.COMPARE_BAR:case BICst.WIDGET.COMBINE_CHART:case BICst.WIDGET.MULTI_AXIS_COMBINE_CHART:case BICst.WIDGET.DASHBOARD:case BICst.WIDGET.RADAR:case BICst.WIDGET.ACCUMULATE_RADAR:return true;
default:return false}},barChartType:function(a){return a===BICst.WIDGET.BAR||a===BICst.WIDGET.ACCUMULATE_BAR||a===BICst.WIDGET.COMPARE_BAR},tableChartType:function(a){return a===BICst.WIDGET.TABLE||a===BICst.WIDGET.CROSS_TABLE||a===BICst.WIDGET.COMPLEX_TABLE},dotChartType:function(a){return a===BICst.WIDGET.DOT},axisChartType:function(a){switch(a){case BICst.WIDGET.AXIS:case BICst.WIDGET.ACCUMULATE_AXIS:case BICst.WIDGET.PERCENT_ACCUMULATE_AXIS:case BICst.WIDGET.COMPARE_AXIS:case BICst.WIDGET.FALL_AXIS:case BICst.WIDGET.LINE:case BICst.WIDGET.AREA:case BICst.WIDGET.ACCUMULATE_AREA:case BICst.WIDGET.COMPARE_AREA:case BICst.WIDGET.RANGE_AREA:case BICst.WIDGET.PERCENT_ACCUMULATE_AREA:case BICst.WIDGET.MULTI_AXIS_COMBINE_CHART:case BICst.WIDGET.COMBINE_CHART:case BICst.WIDGET.BAR:case BICst.WIDGET.ACCUMULATE_BAR:case BICst.WIDGET.COMPARE_BAR:case BICst.WIDGET.DOT:return true;
default:return false}},percentChartType:function(a){return a===BICst.WIDGET.PERCENT_ACCUMULATE_AXIS||a===BICst.WIDGET.PERCENT_ACCUMULATE_AREA},toastBigDataModeChartType:function(a){switch(a){case BICst.WIDGET.BUBBLE:case BICst.WIDGET.SCATTER:case BICst.WIDGET.DOT:case BICst.WIDGET.GIS_MAP:case BICst.WIDGET.LINE_MAP:return true;default:return false}},radioTargetChartType:function(a){return a===BICst.WIDGET.FORCE_BUBBLE||a===BICst.WIDGET.FALL_AXIS||a===BICst.WIDGET.COMPARE_AXIS||a===BICst.WIDGET.COMPARE_BAR||a===BICst.WIDGET.RANGE_AREA||a===BICst.WIDGET.COMPARE_AREA||a===BICst.WIDGET.MULTI_AXIS_COMBINE_CHART||a===BICst.WIDGET.DOT||a===BICst.WIDGET.MULTI_PIE||a===BICst.WIDGET.RECT_TREE||a===BICst.WIDGET.FUNNEL||a===BICst.WIDGET.WORD_CLOUD||a===BICst.WIDGET.HEAT_MAP||a===BICst.WIDGET.LINE_MAP
},checkDimensionChartType:function(a,b){switch(a){case BICst.WIDGET.MAP:case BICst.WIDGET.MULTI_PIE:return true;case BICst.WIDGET.DOT:if(BI.Utils.isDimensionRegion2ByRegionType(BI.Utils.getRegionTypeByDimensionID(b))){return false}else{return true}default:return false}},createChartRegionName:function(a){var b={};switch(a){case BICst.WIDGET.AXIS:case BICst.WIDGET.ACCUMULATE_AXIS:case BICst.WIDGET.LINE:case BICst.WIDGET.AREA:case BICst.WIDGET.ACCUMULATE_AREA:case BICst.WIDGET.COMBINE_CHART:b[BICst.REGION.DIMENSION1]=BI.i18nText("BI-Basic_Category");
b[BICst.REGION.DIMENSION2]=BI.i18nText("BI-Basic_Series");b[BICst.REGION.TARGET1]=BI.i18nText("BI-Left_Value_Axis");b[BICst.REGION.TARGET2]=BI.i18nText("BI-Right_Value_Axis");break;case BICst.WIDGET.PERCENT_ACCUMULATE_AXIS:case BICst.WIDGET.ACCUMULATE_BAR:b[BICst.REGION.DIMENSION1]=BI.i18nText("BI-Basic_Category");b[BICst.REGION.DIMENSION2]=BI.i18nText("BI-Basic_Series");b[BICst.REGION.TARGET1]=BI.i18nText("BI-Left_Value_Axis");break;case BICst.WIDGET.RECT_TREE:b[BICst.REGION.DIMENSION1]=BI.i18nText("BI-Basic_Category");
b[BICst.REGION.DIMENSION2]=BI.i18nText("BI-Basic_Series");b[BICst.REGION.TARGET1]=BI.i18nText("BI-Basic_Target");break;case BICst.WIDGET.BAR:case BICst.WIDGET.PERCENT_ACCUMULATE_AREA:b[BICst.REGION.DIMENSION1]=BI.i18nText("BI-Basic_Category");b[BICst.REGION.DIMENSION2]=BI.i18nText("BI-Basic_Series");b[BICst.REGION.TARGET1]=BI.i18nText("BI-Value_Axis");break;case BICst.WIDGET.COMPARE_AXIS:case BICst.WIDGET.COMPARE_AREA:b[BICst.REGION.DIMENSION1]=BI.i18nText("BI-Basic_Category");b[BICst.REGION.TARGET1]=BI.i18nText("BI-Positive_Value_Axis");
b[BICst.REGION.TARGET2]=BI.i18nText("BI-Negative_Value_Axis");break;case BICst.WIDGET.FALL_AXIS:b[BICst.REGION.DIMENSION1]=BI.i18nText("BI-Basic_Category");b[BICst.REGION.TARGET1]=BI.i18nText("BI-Value_Axis");break;case BICst.WIDGET.RANGE_AREA:b[BICst.REGION.DIMENSION1]=BI.i18nText("BI-Basic_Category");b[BICst.REGION.TARGET1]=BI.i18nText("BI-Low_Value_Axis");b[BICst.REGION.TARGET2]=BI.i18nText("BI-High_Value_Axis");break;case BICst.WIDGET.COMPARE_BAR:b[BICst.REGION.DIMENSION1]=BI.i18nText("BI-Basic_Category");
b[BICst.REGION.TARGET1]=BI.i18nText("BI-Value_Axis_One");b[BICst.REGION.TARGET2]=BI.i18nText("BI-Value_Axis_Two");break;case BICst.WIDGET.MULTI_AXIS_COMBINE_CHART:b[BICst.REGION.DIMENSION1]=BI.i18nText("BI-Basic_Category");b[BICst.REGION.TARGET1]=BI.i18nText("BI-Left_Value_Axis");b[BICst.REGION.TARGET2]=BI.i18nText("BI-Right_Value_Axis_One");b[BICst.REGION.TARGET3]=BI.i18nText("BI-Right_Value_Axis_Two");break;case BICst.WIDGET.DONUT:case BICst.WIDGET.RADAR:case BICst.WIDGET.ACCUMULATE_RADAR:b[BICst.REGION.DIMENSION1]=BI.i18nText("BI-Basic_Category");
b[BICst.REGION.DIMENSION2]=BI.i18nText("BI-Basic_Series");b[BICst.REGION.TARGET1]=BI.i18nText("BI-Basic_Target");break;case BICst.WIDGET.PIE:case BICst.WIDGET.MULTI_PIE:case BICst.WIDGET.DASHBOARD:case BICst.WIDGET.FORCE_BUBBLE:case BICst.WIDGET.FUNNEL:b[BICst.REGION.DIMENSION1]=BI.i18nText("BI-Basic_Category");b[BICst.REGION.TARGET1]=BI.i18nText("BI-Basic_Target");break;case BICst.WIDGET.MAP:b[BICst.REGION.DIMENSION1]=BI.i18nText("BI-Region_Name");b[BICst.REGION.TARGET1]=BI.i18nText("BI-Basic_Target");
b[BICst.REGION.TARGET2]=BI.i18nText("BI-Region_Suspension_Target");break;case BICst.WIDGET.GIS_MAP:b[BICst.REGION.DIMENSION1]=BI.i18nText("BI-Basic_Point");b[BICst.REGION.TARGET1]=BI.i18nText("BI-Basic_Target");break;case BICst.WIDGET.HEAT_MAP:b[BICst.REGION.DIMENSION1]=BI.i18nText("BI-Area_Name");b[BICst.REGION.TARGET1]=BI.i18nText("BI-Region_Target");break;case BICst.WIDGET.LINE_MAP:b[BICst.REGION.DIMENSION1]=BI.i18nText("BI-From_Point");b[BICst.REGION.DIMENSION2]=BI.i18nText("BI-To_Point");b[BICst.REGION.TARGET1]=BI.i18nText("BI-Basic_Target");
break;case BICst.WIDGET.DOT:b[BICst.REGION.DIMENSION1]=BI.i18nText("BI-Basic_Category");b[BICst.REGION.DIMENSION2]=BI.i18nText("BI-Basic_Series");b[BICst.REGION.TARGET1]=BI.i18nText("BI-Y_Value");b[BICst.REGION.TARGET2]=BI.i18nText("BI-X_Value");b[BICst.REGION.TARGET3]=BI.i18nText("BI-Basic_Value");break;default:b[BICst.REGION.DIMENSION1]=BI.i18nText("BI-Basic_Category");b[BICst.REGION.TARGET1]=BI.i18nText("BI-Basic_Target");break}return b},createChartRegionType:function(b){var a={};switch(b){case BICst.WIDGET.FALL_AXIS:case BICst.WIDGET.PIE:case BICst.WIDGET.MULTI_PIE:case BICst.WIDGET.DASHBOARD:case BICst.WIDGET.FORCE_BUBBLE:case BICst.WIDGET.FUNNEL:case BICst.WIDGET.GIS_MAP:case BICst.WIDGET.HEAT_MAP:a[BICst.REGION.DIMENSION1]=BICst.REGION_TYPE.REGION_DIMENSION;
a[BICst.REGION.TARGET1]=BICst.REGION_TYPE.REGION_TARGET;break;case BICst.WIDGET.BAR:case BICst.WIDGET.PERCENT_ACCUMULATE_AXIS:case BICst.WIDGET.PERCENT_ACCUMULATE_AREA:case BICst.WIDGET.ACCUMULATE_BAR:case BICst.WIDGET.RECT_TREE:case BICst.WIDGET.DONUT:case BICst.WIDGET.RADAR:case BICst.WIDGET.ACCUMULATE_RADAR:case BICst.WIDGET.LINE_MAP:a[BICst.REGION.DIMENSION1]=BICst.REGION_TYPE.REGION_DIMENSION;a[BICst.REGION.DIMENSION2]=BICst.REGION_TYPE.REGION_DIMENSION;a[BICst.REGION.TARGET1]=BICst.REGION_TYPE.REGION_TARGET;
break;case BICst.WIDGET.AXIS:case BICst.WIDGET.ACCUMULATE_AXIS:case BICst.WIDGET.LINE:case BICst.WIDGET.AREA:case BICst.WIDGET.ACCUMULATE_AREA:a[BICst.REGION.DIMENSION1]=BICst.REGION_TYPE.REGION_DIMENSION;a[BICst.REGION.DIMENSION2]=BICst.REGION_TYPE.REGION_DIMENSION;a[BICst.REGION.TARGET1]=BICst.REGION_TYPE.REGION_TARGET;a[BICst.REGION.TARGET2]=BICst.REGION_TYPE.REGION_TARGET;break;case BICst.WIDGET.COMBINE_CHART:a[BICst.REGION.DIMENSION1]=BICst.REGION_TYPE.REGION_DIMENSION;a[BICst.REGION.DIMENSION2]=BICst.REGION_TYPE.REGION_DIMENSION;
a[BICst.REGION.TARGET1]=BICst.REGION_TYPE.REGION_WRAPPER_TARGET_SETTING;a[BICst.REGION.TARGET2]=BICst.REGION_TYPE.REGION_WRAPPER_TARGET_SETTING;break;case BICst.WIDGET.COMPARE_AXIS:case BICst.WIDGET.COMPARE_AREA:case BICst.WIDGET.COMPARE_BAR:case BICst.WIDGET.RANGE_AREA:case BICst.WIDGET.MAP:a[BICst.REGION.DIMENSION1]=BICst.REGION_TYPE.REGION_DIMENSION;a[BICst.REGION.TARGET1]=BICst.REGION_TYPE.REGION_TARGET;a[BICst.REGION.TARGET2]=BICst.REGION_TYPE.REGION_TARGET;break;case BICst.WIDGET.MULTI_AXIS_COMBINE_CHART:a[BICst.REGION.DIMENSION1]=BICst.REGION_TYPE.REGION_DIMENSION;
a[BICst.REGION.TARGET1]=BICst.REGION_TYPE.REGION_TARGET_SETTING;a[BICst.REGION.TARGET2]=BICst.REGION_TYPE.REGION_TARGET_SETTING;a[BICst.REGION.TARGET3]=BICst.REGION_TYPE.REGION_TARGET_SETTING;break;case BICst.WIDGET.DOT:a[BICst.REGION.DIMENSION1]=BICst.REGION_TYPE.REGION_DIMENSION;a[BICst.REGION.DIMENSION2]=BICst.REGION_TYPE.REGION_DIMENSION;a[BICst.REGION.TARGET1]=BICst.REGION_TYPE.REGION_TARGET;a[BICst.REGION.TARGET2]=BICst.REGION_TYPE.REGION_TARGET;a[BICst.REGION.TARGET3]=BICst.REGION_TYPE.REGION_TARGET_SETTING;
break;default:a[BICst.REGION.DIMENSION1]=BICst.REGION_TYPE.REGION_DIMENSION;a[BICst.REGION.TARGET1]=BICst.REGION_TYPE.REGION_TARGET;break}return a},doChartDimensionAndTargetChange:function(a){a=a||{};switch(a.wType){case BICst.WIDGET.MAP:if(a.usableT.length>1){a.doTargetChangeForCommon(a.dims,a.view);a.doTargetChangeForMap(a.dims,a.preDims,a.view)}break;case BICst.WIDGET.MULTI_PIE:if(a.usableT.length>1){a.doTargetChangeForSingleChart(a.dims,a.preDims,BI.Utils.isTargetRegion1ByRegionType)}break;case BICst.WIDGET.AXIS:case BICst.WIDGET.ACCUMULATE_AXIS:case BICst.WIDGET.PERCENT_ACCUMULATE_AXIS:case BICst.WIDGET.BAR:case BICst.WIDGET.ACCUMULATE_BAR:case BICst.WIDGET.LINE:case BICst.WIDGET.AREA:case BICst.WIDGET.ACCUMULATE_AREA:case BICst.WIDGET.PERCENT_ACCUMULATE_AREA:case BICst.WIDGET.COMBINE_CHART:case BICst.WIDGET.DONUT:case BICst.WIDGET.RADAR:case BICst.WIDGET.ACCUMULATE_RADAR:a.doDimensionChangeForCommon(a.dims,a.preDims,BI.Utils.isDimensionRegion1ByRegionType);
a.doDimensionChangeForCommon(a.dims,a.preDims,BI.Utils.isDimensionRegion2ByRegionType);if(a.usableT.length>1){a.doTargetChangeForCommon(a.dims,a.view)}break;case BICst.WIDGET.PIE:case BICst.WIDGET.DASHBOARD:a.doDimensionChangeForCommon(a.dims,a.preDims,BI.Utils.isDimensionRegion1ByRegionType);a.doDimensionChangeForCommon(a.dims,a.preDims,BI.Utils.isDimensionRegion2ByRegionType);if(a.usableT.length>1){a.doTargetChangeForCommon(a.dims,a.view);a.doTargetChangeForPieAndDashBoard(a.dims,a.view)}break;
case BICst.WIDGET.GIS_MAP:a.doDimensionChangeForCommon(a.dims,a.preDims,BI.Utils.isDimensionRegion1AreaNameByRegionType);a.doDimensionChangeForCommon(a.dims,a.preDims,BI.Utils.isDimensionRegion1LngByRegionType);a.doDimensionChangeForCommon(a.dims,a.preDims,BI.Utils.isDimensionRegion1LatByRegionType);break;case BICst.WIDGET.HEAT_MAP:a.doDimensionChangeForCommon(a.dims,a.preDims,BI.Utils.isDimensionRegion1AreaNameByRegionType);a.doDimensionChangeForCommon(a.dims,a.preDims,BI.Utils.isDimensionRegion1LngByRegionType);
a.doDimensionChangeForCommon(a.dims,a.preDims,BI.Utils.isDimensionRegion1LatByRegionType);if(a.usableT.length>1){a.doTargetChangeForSingleChart(a.dims,a.preDims,BI.Utils.isTargetRegion1ByRegionType)}break;case BICst.WIDGET.LINE_MAP:a.doDimensionChangeForCommon(a.dims,a.preDims,BI.Utils.isDimensionRegion1AreaNameByRegionType);a.doDimensionChangeForCommon(a.dims,a.preDims,BI.Utils.isDimensionRegion1LngByRegionType);a.doDimensionChangeForCommon(a.dims,a.preDims,BI.Utils.isDimensionRegion1LatByRegionType);
a.doDimensionChangeForCommon(a.dims,a.preDims,BI.Utils.isDimensionRegion2AreaNameByRegionType);a.doDimensionChangeForCommon(a.dims,a.preDims,BI.Utils.isDimensionRegion2LngByRegionType);a.doDimensionChangeForCommon(a.dims,a.preDims,BI.Utils.isDimensionRegion2LatByRegionType);if(a.usableT.length>1){a.doTargetChangeForSingleChart(a.dims,a.preDims,BI.Utils.isTargetRegion1ByRegionType)}break;case BICst.WIDGET.FUNNEL:case BICst.WIDGET.RECT_TREE:case BICst.WIDGET.FORCE_BUBBLE:case BICst.WIDGET.RANGE_AREA:case BICst.WIDGET.FALL_AXIS:case BICst.WIDGET.COMPARE_AREA:case BICst.WIDGET.COMPARE_AXIS:case BICst.WIDGET.COMPARE_BAR:case BICst.WIDGET.WORD_CLOUD:a.doDimensionChangeForCommon(a.dims,a.preDims,BI.Utils.isDimensionRegion1ByRegionType);
a.doDimensionChangeForCommon(a.dims,a.preDims,BI.Utils.isDimensionRegion2ByRegionType);if(a.usableT.length>1){a.doTargetChangeForSingleChart(a.dims,a.preDims,BI.Utils.isTargetRegion1ByRegionType);a.doTargetChangeForSingleChart(a.dims,a.preDims,BI.Utils.isTargetRegion2ByRegionType)}break;case BICst.WIDGET.MULTI_AXIS_COMBINE_CHART:a.doDimensionChangeForCommon(a.dims,a.preDims,BI.Utils.isDimensionRegion1ByRegionType);if(a.usableT.length>1){a.doTargetChangeForSingleChart(a.dims,a.preDims,BI.Utils.isTargetRegion1ByRegionType);
a.doTargetChangeForSingleChart(a.dims,a.preDims,BI.Utils.isTargetRegion2ByRegionType);a.doTargetChangeForSingleChart(a.dims,a.preDims,BI.Utils.isTargetRegion3ByRegionType)}break;case BICst.WIDGET.DOT:a.doDimensionChangeForCommon(a.dims,a.preDims,BI.Utils.isDimensionRegion2ByRegionType);if(a.usableT.length>1){a.doTargetChangeForSingleChart(a.dims,a.preDims,BI.Utils.isTargetRegion1ByRegionType);a.doTargetChangeForSingleChart(a.dims,a.preDims,BI.Utils.isTargetRegion2ByRegionType);a.doTargetChangeForSingleChart(a.dims,a.preDims,BI.Utils.isTargetRegion3ByRegionType)
}break}},mapTypeChartType:function(a){return a===BICst.WIDGET.MAP||a===BICst.WIDGET.GIS_MAP||a===BICst.WIDGET.HEAT_MAP||a===BICst.WIDGET.LINE_MAP},refreshButtonVisible:function(a){switch(a){case BICst.WIDGET.ACCUMULATE_AXIS:case BICst.WIDGET.ACCUMULATE_AREA:case BICst.WIDGET.AXIS:case BICst.WIDGET.LINE:case BICst.WIDGET.AREA:case BICst.WIDGET.PERCENT_ACCUMULATE_AXIS:case BICst.WIDGET.PERCENT_ACCUMULATE_AREA:case BICst.WIDGET.COMPARE_AXIS:case BICst.WIDGET.COMPARE_AREA:case BICst.WIDGET.FALL_AXIS:case BICst.WIDGET.RANGE_AREA:case BICst.WIDGET.BAR:case BICst.WIDGET.ACCUMULATE_BAR:case BICst.WIDGET.COMPARE_BAR:case BICst.WIDGET.COMBINE_CHART:case BICst.WIDGET.MULTI_AXIS_COMBINE_CHART:case BICst.WIDGET.FORCE_BUBBLE:case BICst.WIDGET.DOT:case BICst.WIDGET.MAP:case BICst.WIDGET.WORD_CLOUD:case BICst.WIDGET.LINE_MAP:case BICst.WIDGET.HEAT_MAP:case BICst.WIDGET.GIS_MAP:return true;
default:return false}},getNormalMarkerItems:function(){return[{value:BICst.DOT_STYLE.SQUARE,iconCls:"dot-chart-square-style-font"},{value:BICst.DOT_STYLE.TRIANGLE,iconCls:"dot-chart-triangle-style-font"},{value:BICst.DOT_STYLE.CIRCLE,iconCls:"dot-chart-cricle-style-font"},{value:BICst.DOT_STYLE.DIAMOND,iconCls:"dot-chart-diamond-style-font"},{value:BICst.DOT_STYLE.HOLLOW_SQUARE,iconCls:"dot-chart-hollow-square-style-font"},{value:BICst.DOT_STYLE.HOLLOW_TRIANGLE,iconCls:"dot-chart-hollow-triangle-style-font"},{value:BICst.DOT_STYLE.HOLLOW_CIRCLE,iconCls:"dot-chart-hollow-circle-style-font"},{value:BICst.DOT_STYLE.HOLLOW_DIAMON,iconCls:"dot-chart-hollow-diamond-style-font"}]
},getGisMapMarkerItems:function(){return[{value:BICst.DOT_STYLE.LOCATION,iconCls:"dot-chart-location-style-font"},{value:BICst.DOT_STYLE.SQUARE,iconCls:"dot-chart-square-style-font"},{value:BICst.DOT_STYLE.TRIANGLE,iconCls:"dot-chart-triangle-style-font"},{value:BICst.DOT_STYLE.CIRCLE,iconCls:"dot-chart-cricle-style-font"},{value:BICst.DOT_STYLE.DIAMOND,iconCls:"dot-chart-diamond-style-font"},{value:BICst.DOT_STYLE.HOLLOW_SQUARE,iconCls:"dot-chart-hollow-square-style-font"},{value:BICst.DOT_STYLE.HOLLOW_TRIANGLE,iconCls:"dot-chart-hollow-triangle-style-font"},{value:BICst.DOT_STYLE.HOLLOW_CIRCLE,iconCls:"dot-chart-hollow-circle-style-font"},{value:BICst.DOT_STYLE.HOLLOW_DIAMON,iconCls:"dot-chart-hollow-diamond-style-font"}]
}});
BI.extend(BI.Utils,{parseComplexDate:function(b){function a(g){var f=g.wId,e=g.startOrEnd;if(BI.isNotNull(f)&&BI.isNotNull(e)){var d=BI.Utils.getWidgetValueByID(f);if(e===BI.MultiDateParamPane.start&&BI.isNotNull(d.start)){return c(d.start)}else{return c(d.end)}}else{return c(BI.Utils.getWidgetValueByID())}}function c(l){var i=l.type,j=l.value;var f=Date.getDate();var e=f.getFullYear(),h=f.getMonth(),d=f.getDate();if(BI.isNull(i)&&BI.isNotNull(l.year)){return Date.getDate(l.year,l.month,l.day)}switch(i){case BICst.DATE_TYPE.MULTI_DATE_YEAR_PREV:return Date.getDate(e-1*j,h,d);
case BICst.DATE_TYPE.MULTI_DATE_YEAR_AFTER:return Date.getDate(e+1*j,h,d);case BICst.DATE_TYPE.MULTI_DATE_YEAR_BEGIN:return Date.getDate(e,0,1);case BICst.DATE_TYPE.MULTI_DATE_YEAR_END:return Date.getDate(e,11,31);case BICst.DATE_TYPE.MULTI_DATE_MONTH_PREV:return Date.getDate().getBeforeMultiMonth(j);case BICst.DATE_TYPE.MULTI_DATE_MONTH_AFTER:return Date.getDate().getAfterMultiMonth(j);case BICst.DATE_TYPE.MULTI_DATE_MONTH_BEGIN:return Date.getDate(e,h,1);case BICst.DATE_TYPE.MULTI_DATE_MONTH_END:return Date.getDate(e,h,(f.getLastDateOfMonth()).getDate());
case BICst.DATE_TYPE.MULTI_DATE_QUARTER_PREV:return Date.getDate().getBeforeMulQuarter(j);case BICst.DATE_TYPE.MULTI_DATE_QUARTER_AFTER:return Date.getDate().getAfterMulQuarter(j);case BICst.DATE_TYPE.MULTI_DATE_QUARTER_BEGIN:return Date.getDate().getQuarterStartDate();case BICst.DATE_TYPE.MULTI_DATE_QUARTER_END:return Date.getDate().getQuarterEndDate();case BICst.DATE_TYPE.MULTI_DATE_WEEK_PREV:return f.getOffsetDate(-7*j);case BICst.DATE_TYPE.MULTI_DATE_WEEK_AFTER:return f.getOffsetDate(7*j);case BICst.DATE_TYPE.MULTI_DATE_DAY_PREV:return f.getOffsetDate(-1*j);
case BICst.DATE_TYPE.MULTI_DATE_DAY_AFTER:return f.getOffsetDate(1*j);case BICst.DATE_TYPE.MULTI_DATE_DAY_TODAY:return f;case BICst.DATE_TYPE.MULTI_DATE_PARAM:var m=j.wId,g=j.startOrEnd;if(BI.isNotNull(m)&&BI.isNotNull(g)){var k=BI.Utils.getWidgetValueByID(m);if(g===BI.MultiDateParamPane.start&&BI.isNotNull(k.start)){return Date.getDate(k.start.year,k.start.month,k.start.day)}else{return Date.getDate(k.end.year,k.end.month,k.end.day)}}else{if(BI.isNotNull(j.year)&&BI.isNotNull(j.month)&&BI.isNotNull(j.day)){return Date.getDate(j.year,j.month,j.day)
}}break;case BICst.DATE_TYPE.MULTI_DATE_CALENDAR:return Date.getDate(j.year,j.month,j.day)}}if(b.type===BICst.DATE_TYPE.MULTI_DATE_PARAM){return a(b)}else{return c(b)}},getNumberRangeText:function(f){var e="";var b=f.closemin,d=f.closemax,c=f.min,a=f.max;if(BI.isNotNull(c)&&BI.isNotEmptyString(c)&&BI.isNotNull(a)&&BI.isNotEmptyString(a)){e=c+(b?"<=":"<")+BI.i18nText("BI-Basic_Value")+(d?"<=":"<")+a}else{if(BI.isNotNull(c)&&BI.isNotEmptyString(c)){e=c+(b?"<=":"<")+BI.i18nText("BI-Basic_Value")}else{if(BI.isNotNull(a)&&BI.isNotEmptyString(a)){e=BI.i18nText("BI-Basic_Value")+(d?"<=":"<")+a
}}}return e},getDataRangeText4Param:function(a,m){var f=BI.i18nText("BI-Basic_Unrestricted"),i=BI.i18nText("BI-Basic_Unrestricted");if(a===BICst.FILTER_DATE.BELONG_WIDGET_VALUE||a===BICst.FILTER_DATE.NOT_BELONG_WIDGET_VALUE){var c=m.wId,k=(m.filterValue||{}).type;var d=BI.Utils.getWidgetValueByID(c);if(!BI.Utils.isWidgetExistByID(c)||BI.isNull(d)){return}switch(k){case BICst.DATE_TYPE.SAME_PERIOD:if(BI.isNotNull(d.start)){f=this.parseComplexDate(d.start).print("%Y/%X/%d")}if(BI.isNotNull(d.end)){i=this.parseComplexDate(d.end).print("%Y/%X/%d")
}break;case BICst.DATE_TYPE.LAST_SAME_PERIOD:if(BI.isNotNull(d.start)&&BI.isNotNull(d.end)){var p=this.parseComplexDate(d.start);var l=this.parseComplexDate(d.end);if(BI.isNotNull(p)&&BI.isNotNull(l)){var h=Date.getTime(p.getFullYear(),p.getMonth(),p.getDate(),p.getHours(),p.getMinutes(),p.getSeconds());f=Date.getDate(2*h-l).getOffsetDate(-1).print("%Y/%X/%d")}if(BI.isNotNull(p)){i=p.getOffsetDate(-1).print("%Y/%X/%d")}}else{if(BI.isNotNull(d.start)){var p=this.parseComplexDate(d.start);if(BI.isNotNull(p)){i=p.getOffsetDate(-1)
}}}break;case BICst.DATE_TYPE.YEAR_QUARTER:case BICst.DATE_TYPE.YEAR_MONTH:case BICst.DATE_TYPE.YEAR_WEEK:case BICst.DATE_TYPE.YEAR_DAY:case BICst.DATE_TYPE.MONTH_WEEK:case BICst.DATE_TYPE.MONTH_DAY:case BICst.DATE_TYPE.YEAR:var g=b(c);if(!n(c)){f=g.getFullYear()+BI.i18nText("BI-Basic_Year")}if(BI.isNotNull(g)){var o=j(g,m.filterValue);f=o.start.print("%Y/%X/%d");if(BI.isNotNull(o.end)){i=o.end.print("%Y/%X/%d")}}break}return f+"-"+i}if(a===BICst.FILTER_DATE.EARLY_THAN){var g=b(m.wId);if(BI.isNotNull(g)){var o=j(g,m.filterValue);
if(BI.isNotNull(o.start)){i=o.start.getOffsetDate(-1).print("%Y/%X/%d")}}}if(a===BICst.FILTER_DATE.LATER_THAN){var g=b(m.wId);if(BI.isNotNull(g)){var o=j(g,m.filterValue);if(BI.isNotNull(o.start)){f=o.start.print("%Y/%X/%d")}}}return f+"-"+i;function j(r,y){var u=y.type,y=y.value;var t=y.foffset===0?-1:1;var A=y.soffset===0?-1:1;var e,s;e=s=r;var z=Date.getDate((r.getFullYear()+t*y.fvalue),r.getMonth(),1).getMonthDays();var w=r.getDate();if(w>z){w=z}var v=Date.getDate((r.getFullYear()+t*y.fvalue),r.getMonth(),w);
switch(u){case BICst.DATE_TYPE.YEAR:e=Date.getDate((r.getFullYear()+t*y.fvalue),0,1);s=Date.getDate(e.getFullYear(),11,31);break;case BICst.DATE_TYPE.YEAR_QUARTER:v=v.getOffsetMonth(A*y.svalue*3);e=v.getQuarterStartDate();s=v.getQuarterEndDate();break;case BICst.DATE_TYPE.YEAR_MONTH:v=v.getOffsetMonth(A*y.svalue);e=Date.getDate(v.getFullYear(),v.getMonth(),1);s=Date.getDate(v.getFullYear(),v.getMonth(),(v.getLastDateOfMonth()).getDate());break;case BICst.DATE_TYPE.YEAR_WEEK:var q=v.getOffsetDate(A*7*y.svalue);
e=q.getWeekStartDate();s=e.getWeekEndDate();break;case BICst.DATE_TYPE.YEAR_DAY:e=v.getOffsetDate(A*y.svalue);s=e;break;case BICst.DATE_TYPE.MONTH_WEEK:var x=r.getOffsetMonth(t*y.fvalue);var q=x.getOffsetDate(A*7*y.svalue);e=q.getWeekStartDate();s=e.getWeekEndDate();break;case BICst.DATE_TYPE.MONTH_DAY:var x=r.getOffsetMonth(t*y.fvalue);e=x.getOffsetDate(A*y.svalue);s=e;break}return{start:e,end:s}}function n(r){var s=BI.Utils.getWidgetTypeByID(r);var q=BI.Utils.getWidgetValueByID(r);var e=true;switch(s){case BICst.WIDGET.MONTH:if(!BI.isNumeric(q.month)){e=false
}break;case BICst.WIDGET.QUARTER:if(!BI.isNumeric(q.quarter)){e=false}break}return e}function b(s){if(!BI.Utils.isWidgetExistByID(s)){return null}var t=BI.Utils.getWidgetTypeByID(s);var r=BI.Utils.getWidgetValueByID(s);var q=null;switch(t){case BICst.WIDGET.YEAR:if(BI.isNumeric(r)){q=Date.getDate(r,0,1)}break;case BICst.WIDGET.MONTH:if(BI.isNotNull(r)&&BI.isNumeric(r.year)){q=Date.getDate(r.year,BI.isNumeric(r.month)?r.month:0,1)}break;case BICst.WIDGET.QUARTER:if(BI.isNotNull(r)&&BI.isNumeric(r.year)){var e=r.quarter;
q=Date.getDate(r.year,BI.isNumeric(e)?(e*3-1):0,1)}break;case BICst.WIDGET.YMD:case BICst.WIDGET.DATE_PANE:if(BI.isNotNull(r)){q=BI.Utils.parseComplexDate(r)}break}return q}},getDateRangeText:function(f){var e=f.start,a=f.end;var b="",d="";if(BI.isNotNull(e)){if(BI.isNotNull(e.year)&&BI.isNotNull(e.month)&&BI.isNotNull(e.day)){b=e.year+"/"+(e.month+1)+"/"+e.day}else{var c=BI.Utils.parseComplexDate(e);b=BI.isNotNull(c)?(c.getFullYear()+"/"+(c.getMonth()+1)+"/"+c.getDate()):""}}if(BI.isNotNull(a)){if(BI.isNotNull(a.year)&&BI.isNotNull(a.month)&&BI.isNotNull(a.day)){d=a.year+"/"+(a.month+1)+"/"+a.day
}else{var c=BI.Utils.parseComplexDate(a);d=BI.isNotNull(c)?(c.getFullYear()+"/"+(c.getMonth()+1)+"/"+c.getDate()):""}}return b+"-"+d},getDateText:function(d){var c=d||{};var a="";if(BI.isNotNull(c.year)&&BI.isNotNull(c.month)&&BI.isNotNull(c.day)){a=c.year+"/"+(c.month+1)+"/"+c.day}else{var b=BI.Utils.parseComplexDate(c);a=BI.isNotNull(b)?(b.getFullYear()+"/"+(b.getMonth()+1)+"/"+b.getDate()):""}return a},getControlWidgetValueTextByID:function(l){var i=BI.Utils.getWidgetValueByID(l);var a=BI.Utils.getWidgetTypeByID(l);
var k="";if(BI.isNull(i)){return k}switch(a){case BICst.WIDGET.STRING:case BICst.WIDGET.STRING_LIST:case BICst.WIDGET.LIST_LABEL:if(BI.isNull(i.value)||i.value.length===0){return k}if(i.type===BI.Selection.Multi){k=BI.i18nText("BI-Basic_In")+" "+i.value}else{if(i.type===BI.Selection.All){k=BI.i18nText("BI-Not_In")+" "+i.value}}return k;case BICst.WIDGET.SINGLE_SLIDER:case BICst.WIDGET.INTERVAL_SLIDER:return j(i);case BICst.WIDGET.NUMBER:return BI.Utils.getNumberRangeText(i);case BICst.WIDGET.DATE:return BI.Utils.getDateRangeText(i);
case BICst.WIDGET.MONTH:var f=i.year,e=i.month;if(BI.isNumeric(f)&&BI.isNumeric(e)){k=f+"/"+(e+1)}else{if(BI.isNumeric(f)){k=f}else{if(BI.isNumeric(e)){k=e+1}}}return k;case BICst.WIDGET.QUARTER:var f=i.year,b=i.quarter;if(BI.isNumeric(f)&&BI.isNumeric(b)){k=f+" "+BI.i18nText("BI-Basic_Di")+b+BI.i18nText("BI-Basic_Quarter")}else{if(BI.isNumeric(f)){k=f}else{if(BI.isNumeric(b)){k=BI.i18nText("BI-Basic_Di")+b+BI.i18nText("BI-Basic_Quarter")}}}return k;case BICst.WIDGET.YEAR:return i;case BICst.WIDGET.YMD:case BICst.WIDGET.DATE_PANE:if(BI.isNotNull(i)){var c=BI.Utils.parseComplexDate(i);
k=BI.isNotNull(c)?(c.getFullYear()+"/"+(c.getMonth()+1)+"/"+c.getDate()):""}return k;case BICst.WIDGET.TREE:case BICst.WIDGET.TREE_LIST:function h(m){var p="";var n=0,o=BI.size(m);BI.each(m,function(q,r){n++;var s=h(r);p+=q+(s===""?"":(":"+s))+(n===o?"":",")});return p}BI.each(i,function(m,n){var o=h(n);k+=m+(o===""?"":(":"+o))+"; "});if(k!==""){k=BI.i18nText("BI-Basic_In")+" "+k}return k;case BICst.WIDGET.TREE_LABEL:var d=BI.filter(i,function(n,m){return m.indexOf(BICst.LIST_LABEL_TYPE.ALL)<0});
if(d.length===0){return k}d=g(d);BI.each(d,function(n,m){BI.each(m,function(o,p){k+=p+(o===0?m.length>1?":":"":o===m.length-1?"":",")});k+=";"});if(k!==""){k=BI.i18nText("BI-Basic_In")+" "+k}return k;default:return i}function j(p){var o="";var n=p.min,m=p.max;if(BI.isNotNull(n)&&BI.isNotNull(m)){o=n+"<="+BI.i18nText("BI-Basic_Value")+"<="+m}return o}function g(m){if(!BI.isArray(m)){m=[]}return m.reduce(function(o,n){return o.map(function(p){return n.map(function(q){return p.concat(q)})}).reduce(function(q,p){return q.concat(p)
},[])},[[]])}},parseClicked4Group:function(l,k){var j=BI.Utils.getDimensionGroupByID(l);var e=BI.Utils.getFieldTypeByDimensionID(l);var h=k;if(BI.isNotNull(j)){if(e===BICst.COLUMN.STRING){var a=j.details,d=j.ungroup2Other,i=j.ungroup2OtherName;if(d===BICst.CUSTOM_GROUP.UNGROUP2OTHER.SELECTED&&k===BICst.UNGROUP_TO_OTHER){h=i}BI.some(a,function(m,n){if(n.id===k){h=n.value;return true}})}else{if(e===BICst.COLUMN.NUMBER){var b=j.groupValue,f=j.type;if(f===BICst.GROUP.CUSTOM_NUMBER_GROUP){var c=b.groupNodes,g=b.useOther;
if(k===BICst.UNGROUP_TO_OTHER){h=g}BI.some(c,function(m,n){if(n.id===k){h=n.groupName;return true}})}}}}return h},formatDate:function(b){if(BI.isNull(b)||!BI.isNumeric(b)){return b||""}var a=Date.getDate(BI.parseInt(b));return a.print("%Y/%X/%d")},getFilterValue4ExportByWid:function(b){var i=[];o(i);f(b,i);a(b,i);d(b,i);var g=h(b);var c;if(i.length>1){c={filterType:BICst.FILTER_TYPE.AND,children:i}}else{c=i[0]?i[0]:{}}if(g!==""){c.drillFilter=BI.i18nText("BI-Drill")+g}function o(q){var p=BI.Utils.getAllWidgetIDs();
BI.each(p,function(r,v){if(BI.Utils.isControlWidgetByWidgetId(v)){if(BI.Utils.getWidgetTypeByID(v)===BICst.WIDGET.GENERAL_QUERY){var u=BI.Utils.getWidgetValueByID(v);var t=k(u[0]);if(BI.isNotNull(t)){q.push(t)}}else{var w=BI.Utils.getControlWidgetValueTextByID(v);var s=BI.Utils.getWidgetNameByID(v);if(BI.isNotNull(w)&&w!==""){q.push({text:s+" "+w})}}}})}function k(q){if(BI.isNull(q)){return}if(q.filterType===BICst.FILTER_TYPE.AND||q.filterType===BICst.FILTER_TYPE.OR){var p=[];BI.each(q.filterValue,function(r,s){var t=k(s);
if(BI.isNotNull(t)){p.push(k(s))}});return{filterType:q.filterType,children:p}}else{if(BI.isNotNull(q._src)){return e(q)}}}function e(s,w){var u,t,A,y,q;u=s._src&&s._src.fieldId;if(!u){return{text:w}}t=BI.Utils.getTableIdByFieldID(u);y=BI.Utils.getTableNameByID(t);A=BI.Utils.getFieldNameByID(u);var x,r;switch(s.filterType){case BICst.TARGET_FILTER_NUMBER.EQUAL_TO:r=BI.i18nText("BI-Basic_Equal");x=s.filterValue;break;case BICst.TARGET_FILTER_NUMBER.NOT_EQUAL_TO:r=BI.i18nText("BI-Not_Equal_To");x=s.filterValue;
break;case BICst.TARGET_FILTER_NUMBER.BELONG_VALUE:r=BI.i18nText("BI-Basic_In");x=BI.Utils.getNumberRangeText(s.filterValue);break;case BICst.TARGET_FILTER_NUMBER.NOT_BELONG_VALUE:r=BI.i18nText("BI-Not_In");x=BI.Utils.getNumberRangeText(s.filterValue);break;case BICst.TARGET_FILTER_NUMBER.IS_NULL:r=BI.i18nText("BI-Is_Null");break;case BICst.TARGET_FILTER_NUMBER.NOT_NULL:r=BI.i18nText("BI-Not_Null");break;case BICst.TARGET_FILTER_STRING.BELONG_VALUE:var z=s.filterValue;var p=z.type;r=p===BI.Selection.All?BI.i18nText("BI-Not_In"):BI.i18nText("BI-Basic_In");
x=z.value;break;case BICst.TARGET_FILTER_STRING.NOT_BELONG_VALUE:var z=s.filterValue;var p=z.type;r=p===BI.Selection.All?BI.i18nText("BI-Basic_In"):BI.i18nText("BI-Not_In");x=z.value;break;case BICst.TARGET_FILTER_STRING.CONTAIN:r=BI.i18nText("BI-Basic_Contain");x=s.filterValue;break;case BICst.TARGET_FILTER_STRING.NOT_CONTAIN:r=BI.i18nText("BI-Not_Contain");x=s.filterValue;break;case BICst.TARGET_FILTER_STRING.IS_NULL:r=BI.i18nText("BI-Is_Null");break;case BICst.TARGET_FILTER_STRING.NOT_NULL:r=BI.i18nText("BI-Not_Null");
break;case BICst.TARGET_FILTER_STRING.BEGIN_WITH:r=BI.i18nText("BI-Begin_With");x=s.filterValue;break;case BICst.TARGET_FILTER_STRING.END_WITH:r=BI.i18nText("BI-End_With");x=s.filterValue;break;case BICst.TARGET_FILTER_STRING.NOT_BEGIN_WITH:r=BI.i18nText("BI-Not_Begin_With");x=s.filterValue;break;case BICst.TARGET_FILTER_STRING.NOT_END_WITH:r=BI.i18nText("BI-Not_End_With");x=s.filterValue;break;case BICst.FILTER_DATE.BELONG_DATE_RANGE:r=BI.i18nText("BI-Basic_In");x=BI.Utils.getDateRangeText(s.filterValue);
break;case BICst.FILTER_DATE.NOT_BELONG_DATE_RANGE:r=BI.i18nText("BI-Not_In");x=BI.Utils.getDateRangeText(s.filterValue);break;case BICst.FILTER_DATE.BELONG_WIDGET_VALUE:break;case BICst.FILTER_DATE.NOT_BELONG_WIDGET_VALUE:break;case BICst.FILTER_DATE.EQUAL_TO:r=BI.i18nText("BI-Basic_Equal");x=BI.Utils.getDateText(s.filterValue);break;case BICst.FILTER_DATE.NOT_EQUAL_TO:r=BI.i18nText("BI-Not_Equal_To");x=BI.Utils.getDateText(s.filterValue);break;case BICst.FILTER_DATE.IS_NULL:r=BI.i18nText("BI-Is_Null");
break;case BICst.FILTER_DATE.NOT_NULL:r=BI.i18nText("BI-Not_Null");break;case BICst.FILTER_DATE.EARLY_THAN:r=BI.i18nText("BI-Sooner_Than");break;case BICst.FILTER_DATE.LATER_THAN:r=BI.i18nText("BI-Later_Than");break;case BICst.FILTER_DATE.CONTAINS:r=BI.i18nText("BI-Basic_Contain");break}return{text:y+"."+A+" "+r+" "+(x?x:"")}}function f(q,p){var r=BI.Utils.getLinkageValuesByID(q);BI.each(r,function(t,s){if(BI.isEmptyObject(s[0])){return}p.push({text:l(s,t)})})}function l(q,t){var s=BI.Utils.getWidgetIDByDimensionID(t);
var p=BI.Utils.getWidgetNameByID(s);var r="";BI.each(q,function(v,w){var x=w.dId,u;u=BI.Utils.parseClicked4Group(x,w.value[0]);if(BI.Utils.getFieldTypeByDimensionID(x)===BICst.COLUMN.DATE&&BI.Utils.getDimensionGroupByID(x).type===BICst.GROUP.YMD){u=BI.Utils.formatDate(u)}r=r+" "+BI.Utils.getDimensionNameByID(x)+"="+u});return p+" "+r}function a(r,p){var q=BI.Utils.getWidgetFilterValueByID(r);BI.each(q,function(t,s){p.push(n(s,t))})}function n(r,p){if(r.filterType===BICst.FILTER_TYPE.AND||r.filterType===BICst.FILTER_TYPE.OR){var q=[];
BI.each(r.filterValue,function(s,t){q.push(n(t,p))});return{filterType:r.filterType,children:q}}else{return e(r,BI.Utils.getFieldNameByID(p))}}function d(s,q){var p=BI.Utils.getWidgetTypeByID(s);var r=BI.Utils.getAllDimDimensionIDs(s);BI.each(r,function(w,v){if(BI.Utils.isDimensionUsable(v)){var t=BI.Utils.getDimensionFilterValueByID(v);var u=BI.Utils.getFieldIDByDimensionID(v);if(BI.isNotEmptyObject(t)&&p!==BICst.WIDGET.DETAIL){q.push(j(t,u))}}})}function j(r,p){if(r.filterType===BICst.FILTER_TYPE.AND||r.filterType===BICst.FILTER_TYPE.OR){var q=[];
BI.each(r.filterValue,function(s,t){q.push(j(t,p))});return{filterType:r.filterType,children:q}}else{return m(r,BI.Utils.getFieldNameByID(p))}}function m(s,q){var u,t;var x=s.targetId;switch(s.filterType){case BICst.FILTER_TYPE.FORMULA:t=BI.i18nText("BI-Basic_Fulfil");u=s.filterValue;BI.each(s.formulaIds,function(y,A){var v=BI.Utils.getDimensionNameByID(A);var z=new RegExp("\\${"+A+"}","g");u=u.replace(z,v)});break;case BICst.DIMENSION_FILTER_NUMBER.BELONG_VALUE:t=BI.i18nText("BI-Basic_In");u=BI.Utils.getNumberRangeText(s.filterValue);
break;case BICst.DIMENSION_FILTER_NUMBER.NOT_BELONG_VALUE:t=BI.i18nText("BI-Not_In");u=BI.Utils.getNumberRangeText(s.filterValue);break;case BICst.DIMENSION_FILTER_NUMBER.MORE_THAN_AVG:t=BI.i18nText("BI-Above_Average");break;case BICst.DIMENSION_FILTER_NUMBER.LESS_THAN_AVG:t=BI.i18nText("BI-Below_Average");break;case BICst.DIMENSION_FILTER_NUMBER.IS_NULL:t=BI.i18nText("BI-Is_Null");break;case BICst.DIMENSION_FILTER_NUMBER.NOT_NULL:t=BI.i18nText("BI-Not_Null");break;case BICst.DIMENSION_FILTER_NUMBER.TOP_N:t=BI.i18nText("BI-Top_N");
u=s.filterValue;break;case BICst.DIMENSION_FILTER_NUMBER.BOTTOM_N:t=BI.i18nText("BI-Last_N");u=s.filterValue;break;case BICst.DIMENSION_FILTER_STRING.BELONG_VALUE:var p=s.filterValue;var w=p.type;t=w===BI.Selection.All?BI.i18nText("BI-Not_In"):BI.i18nText("BI-Basic_In");u=p.value;break;case BICst.DIMENSION_FILTER_STRING.NOT_BELONG_VALUE:var p=s.filterValue;var w=p.type;t=w===BI.Selection.All?BI.i18nText("BI-Basic_In"):BI.i18nText("BI-Not_In");u=p.value;break;case BICst.DIMENSION_FILTER_STRING.CONTAIN:t=BI.i18nText("BI-Basic_Contain");
u=s.filterValue;break;case BICst.DIMENSION_FILTER_STRING.NOT_CONTAIN:t=BI.i18nText("BI-Not_Contain");u=s.filterValue;break;case BICst.DIMENSION_FILTER_STRING.IS_NULL:t=BI.i18nText("BI-Is_Null");break;case BICst.DIMENSION_FILTER_STRING.NOT_NULL:t=BI.i18nText("BI-Not_Null");break;case BICst.DIMENSION_FILTER_STRING.BEGIN_WITH:t=BI.i18nText("BI-Begin_With");u=s.filterValue;break;case BICst.DIMENSION_FILTER_STRING.END_WITH:t=BI.i18nText("BI-End_With");u=s.filterValue;break;case BICst.DIMENSION_FILTER_STRING.TOP_N:t=BI.i18nText("BI-Top_N");
u=s.filterValue;break;case BICst.DIMENSION_FILTER_STRING.BOTTOM_N:t=BI.i18nText("BI-Last_N");u=s.filterValue;break;case BICst.DIMENSION_FILTER_STRING.NOT_BEGIN_WITH:t=BI.i18nText("BI-Not_Begin_With");u=s.filterValue;break;case BICst.DIMENSION_FILTER_STRING.NOT_END_WITH:t=BI.i18nText("BI-Not_End_With");u=s.filterValue;break;case BICst.DIMENSION_FILTER_DATE.BELONG_VALUE:t=BI.i18nText("BI-Basic_In");s.filterValue=s.filterValue||{};u=BI.Utils.getDimensionDateText(s.filterValue.value,x);break;case BICst.DIMENSION_FILTER_DATE.NOT_BELONG_VALUE:t=BI.i18nText("BI-Not_In");
s.filterValue=s.filterValue||{};u=BI.Utils.getDimensionDateText(s.filterValue.value,x);break;case BICst.DIMENSION_FILTER_DATE.IS_NULL:t=BI.i18nText("BI-Is_Null");break;case BICst.DIMENSION_FILTER_DATE.NOT_NULL:t=BI.i18nText("BI-Not_Null");break;case BICst.DIMENSION_FILTER_DATE.CONTAIN:t=BI.i18nText("BI-Basic_Contain");break;case BICst.DIMENSION_FILTER_DATE.NOT_CONTAIN:t=BI.i18nText("BI-Not_Contain");break;case BICst.DIMENSION_FILTER_DATE.TOP_N:t=BI.i18nText("BI-Top_N");u=s.filterValue;break;case BICst.DIMENSION_FILTER_DATE.BOTTOM_N:t=BI.i18nText("BI-Last_N");
u=s.filterValue;break;case BICst.DIMENSION_FILTER_DATE.BEGIN_WITH:t=BI.i18nText("BI-Begin_With");u=s.filterValue;break;case BICst.DIMENSION_FILTER_DATE.END_WITH:t=BI.i18nText("BI-End_With");u=s.filterValue;break}var r=x?(BI.Utils.getDimensionNameByID(x)||BI.Utils.getFieldNameByID(x)):q;return{text:r+" "+(t?t:"")+" "+(u?u:"")}}function h(r){var p=BI.Utils.getDrillByID(r);var q="";BI.each(p,function(t,s){BI.each(s,function(u,v){BI.each(v.values,function(w,x){q=q+" "+BI.Utils.getDimensionNameByID(x.dId)+"="+BI.Utils.parseValue4DrillFilter(x.dId,x.value[0])
})})});return q}return c},getDimensionDateText:function(a,b){return BI.map(a,function(c,d){return BI.Func.formatValueByGroup(d,BI.Utils.getDimensionGroupByID(b).type)})},parseValue4DrillFilter:function(c,b){function a(p,o){var n=BI.Utils.getDimensionGroupByID(p);var i=BI.Utils.getFieldTypeByDimensionID(p);var l=o;if(BI.isNotNull(n)){if(i===BICst.COLUMN.STRING){var e=n.details,h=n.ungroup2Other,m=n.ungroup2OtherName;if(h===BICst.CUSTOM_GROUP.UNGROUP2OTHER.SELECTED&&o===BICst.UNGROUP_TO_OTHER){l=m}BI.some(e,function(q,r){if(r.id===o){l=r.value;
return true}})}else{if(i===BICst.COLUMN.NUMBER){var f=n.groupValue,j=n.type;if(j===BICst.GROUP.CUSTOM_NUMBER_GROUP){var g=f.groupNodes,k=f.useOther;if(o===BICst.UNGROUP_TO_OTHER){l=k}BI.some(g,function(q,r){if(r.id===o){l=r.groupName;return true}})}}}}return l}var d=a(c,b);if(BI.Utils.getFieldTypeByDimensionID(c)===BICst.COLUMN.DATE&&BI.Utils.getDimensionGroupByID(c).type===BICst.GROUP.YMD){d=BI.Utils.formatDate(d)}return d}});
BI.CustomGroupGroup2Other=BI.inherit(BI.Widget,{_constant:{selected:1},_defaultConfig:function(){return BI.extend(BI.CustomGroupGroup2Other.superclass._defaultConfig.apply(this,arguments),{baseCls:"custom-group-bottom"})},_init:function(){var a=this,b=this.options;BI.CustomGroupGroup2Other.superclass._init.apply(this,arguments);this.checkbox=BI.createWidget({type:"bi.checkbox"});this.label=BI.createWidget({type:"bi.label",value:BI.i18nText("BI-Ungrouped_Value_To")});this.editor=BI.createWidget({type:"bi.editor",cls:"custom-group-editor bi-border",value:BI.i18nText("BI-Basic_Others"),validationChecker:b.validationChecker,width:88,height:28,disabled:true});
this.checkbox.on(BI.Checkbox.EVENT_CHANGE,function(){if(a.checkbox.isSelected()){a.editor.setEnable(true)}else{a.editor.setEnable(false)}});this.editor.on(BI.Editor.EVENT_CHANGE,function(){a.fireEvent(BI.CustomGroupGroup2Other.EVENT_CHANGE)});BI.createWidget({element:this,type:"bi.vertical_adapt",rgap:5,items:[a.checkbox,a.label,a.editor]})},populate:function(b,c,a){if(b===BICst.CUSTOM_GROUP.UNGROUP2OTHER.SELECTED){this.checkbox.setSelected(true);this.editor.setValue(c);this.editor.setEnable(true)
}else{this.checkbox.setSelected(false);if(BI.contains(a,BI.i18nText("BI-Basic_Others"))){this.editor.setValue(BI.i18nText("BI-Basic_Others-One"))}this.editor.setEnable(false)}},isSelected:function(){return this.checkbox.isSelected()},getValue:function(){return this.editor.getValue()},setValue:function(a){this.editor.setValue(a)}});BI.CustomGroupGroup2Other.EVENT_CHANGE="EVENT_CHANGE";BI.shortcut("bi.custom_group_group2other",BI.CustomGroupGroup2Other);
BI.CustomGroup=BI.inherit(BI.Widget,{_constant:{OTHER_GROUP_EN:"other"},_defaultConfig:function(){return BI.extend(BI.CustomGroup.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-custom-group",did:""})},_init:function(){BI.CustomGroup.superclass._init.apply(this,arguments);var a=this;this.chosenPane=BI.createWidget({type:"bi.custom_group_field_pane",title:BI.i18nText("BI-Click_Cancel_Selection"),nodeType:"bi.arrow_group_node",height:350});this.combo=BI.createWidget({type:"bi.custom_group_combo",popup:a.chosenPane});
this.move2group=BI.createWidget({type:"bi.move2group_combo",items:a.groupedItems,disabled:true});this.copy2group=BI.createWidget({type:"bi.copy2group_combo",items:a.groupedItems,disabled:true});this.removeFieldButton=BI.createWidget({type:"bi.button",text:BI.i18nText("BI-Shift_Out_Group"),level:"warning",tipType:"warning",disabled:true,height:30});this.fieldPane=BI.createWidget({type:"bi.custom_group_all_fields_pane",enableCheckGroup:true,height:270,unGroupedItems:a.unGroupedItems,validationChecker:function(c){var b=a.bottom.getValue();
return b!==c}});this.groupButtons=BI.createWidget({type:"bi.right",hgap:5,items:[a.removeFieldButton,a.copy2group,a.move2group]});this.buttons=BI.createWidget({type:"bi.center_adapt",items:[a.combo,a.groupButtons]});this.searchPane=BI.createWidget({type:"bi.custom_group_searcher_pane",cls:"bi-custom-group-searchpane bi-card",nodeType:"bi.arrow_group_node",enableCheckGroup:true});this.search=BI.createWidget({type:"bi.custom_group_search",adapter:a.fieldPane,popup:a.searchPane,onSearch:function(e,j){var b=a.fieldPane.getGroupedFieldMap();
var i=a.fieldPane.getUngroupedFieldMap();var g=BI.Func.getSearchResult(b,e.keyword);b=BI.concat(g.matched,g.finded);g=BI.Func.getSearchResult(i,e.keyword);i=BI.concat(g.matched,g.finded);var c=a.fieldPane.createItemFromGroupedFieldMap(b);var d=a.fieldPane.createItemFromUngroupedFieldMap(i);var k=BI.union(d,c);var h=[];var f=a.fieldPane.getSelectedFieldMap();BI.each(f,function(m,l){h.push(m)});j(k,e.keyword,h)}});this.bottom=BI.createWidget({type:"bi.custom_group_group2other",validationChecker:function(c){var b=BI.findKey(a.fieldPane.getGroupMap(),function(d,e){return e===c
});if(BI.isNotNull(b)){return false}else{return true}}});this.top=BI.createWidget({type:"bi.vertical",cls:"bi-custom-group-top",vgap:10,items:[a.buttons,a.search]});BI.createWidget({type:"bi.vertical",height:390,element:a,items:[a.top,a.fieldPane,a.bottom]});this.fieldPane.on(BI.CustomGroupAllFieldsPane.EVENT_CHANGE,function(){a._checkChosenNum()});this.searchPane.on(BI.CustomGroupSearcherPane.EVENT_TOOLBAR_VALUE_CHANGE,function(b,c){if(b===true){BI.each(c,function(e,d){a.fieldPane.setFieldSelectedTrue(e)
})}else{BI.each(c,function(e,d){a.fieldPane.setFieldSelectedFalse(e)})}a._checkChosenNum()});this.searchPane.on(BI.CustomGroupSearcherPane.EVENT_CHANGE,function(b){if(b.isSelected()===true){a.fieldPane.setFieldSelectedTrue(b.options.id)}else{a.fieldPane.setFieldSelectedFalse(b.options.id)}a._checkChosenNum()});this.chosenPane.on(BI.CustomGroupFieldPane.EVENT_CHANGE,function(b){a.fieldPane.setFieldSelectedFalse(b.options.id);a.chosenPane.deleteFieldWidget(b.options.id);a._checkChosenNum()});this.combo.on(BI.CustomGroupCombo.EVENT_BEFORE_POPUPVIEW,function(){a.search.stopSearch();
var e=a.fieldPane.getGroupedSelectedFieldMap();var d=a.fieldPane.getUnGroupedSelectedFieldMap();var c=a.fieldPane.createItemFromGroupedFieldMap(e);var b=a.fieldPane.createItemFromUngroupedFieldMap(d);var f=BI.union(b,c);a.chosenPane.populate(BI.map(f,function(g,h){h.title=BI.i18nText("BI-Click_To_Cancel_Selected_Value");return h}));a._checkChosenNum()});this.move2group.on(BI.Move2GroupCombo.EVENT_CONFIRM,function(){var b=a.move2group.getValue();a._move2groupHandle(b)});this.move2group.on(BI.Move2GroupCombo.EVENT_CLICK_NEW_BUTTON,function(){var k=a.move2group.getTargetValue();
var g=a.fieldPane.getUnGroupedSelectedFieldMap();var h=a.fieldPane.getUngroupedFieldMap();var d=a.fieldPane.getGroupMap();var e={};var j={};var i="";var b=false;BI.each(g,function(m,l){delete h[m]});BI.each(h,function(m,l){j[l]=m});BI.each(d,function(m,l){e[l]=m});e[k]=BI.UUID();BI.find(e,function(m,l){if(BI.isNotNull(j[m])){b=true;i=m;return true}});var c=a.bottom.getValue();var f=false;if(c===k||k===a._constant.OTHER_GROUP_EN){b=true;i=k;f=true}if(!b){a.fieldPane.addGroupWidget(k);a._move2groupHandle(k);
a._scrollToBottom()}else{if(f===true){BI.Msg.alert(BI.i18nText("BI-Failure_Toast"),'"'+i+'"'+BI.i18nText("BI-Failute_Fieldname_Othername_Duplicate"))}else{BI.Msg.alert(BI.i18nText("BI-Failure_Toast"),'"'+i+'"'+BI.i18nText("BI-Failure_Fieldname_Duplicate"))}}});this.move2group.on(BI.Move2GroupCombo.EVENT_BEFORE_POPUPVIEW,function(){var c=a.fieldPane.getGroupMap();var b=a.fieldPane.createItemFromGroupedFieldMap(c);BI.each(b,function(e,d){d.title=d.value;d.text=d.value});a.move2group.populate(b)});this.copy2group.on(BI.Copy2GroupCombo.EVENT_CONFIRM,function(){var c=a.copy2group.getValue();
a.search.stopSearch();var b=a.fieldPane.getSelectedFieldMap();BI.each(c,function(d,e){BI.each(b,function(g,f){a.fieldPane.addFieldWidget(g,f,e);a.fieldPane.setFieldSelectedFalse(g)})});a._checkChosenNum()});this.copy2group.on(BI.Copy2GroupCombo.EVENT_CLICK_BUTTON,function(){var k=a.copy2group.getTargetValue();var g=a.fieldPane.getUngroupedFieldMap();var c=a.fieldPane.getGroupMap();var e={};var i={};var b=false;var h="";BI.each(g,function(m,l){i[l]=m});BI.each(c,function(m,l){e[l]=m});e[k]=BI.UUID();
BI.find(e,function(m,l){if(BI.isNotNull(i[m])){b=true;h=m;return true}});var d=a.bottom.getValue();var f=false;if(d===k||k===a._constant.OTHER_GROUP_EN){h=k;b=true;f=true}if(!b){a.fieldPane.addGroupWidget(k);var c=a.fieldPane.getGroupMap();var j=a.fieldPane.createItemFromGroupedFieldMap(c);BI.each(j,function(m,l){l.title=l.value;l.text=l.value});a.copy2group.populate(j);a.copy2group.setValue(k);a._scrollToBottom();this.scrollToBottom()}else{if(f===true){BI.Msg.alert(BI.i18nText("BI-Failure_Toast"),'"'+h+'"'+BI.i18nText("BI-Failute_Fieldname_Othername_Duplicate"))
}else{BI.Msg.alert(BI.i18nText("BI-Failure_Toast"),'"'+h+'"'+BI.i18nText("BI-Failure_Fieldname_Duplicate"))}}});this.copy2group.on(BI.Copy2GroupCombo.EVENT_BEFORE_POPUPVIEW,function(){var c=a.fieldPane.getGroupMap();var b=a.fieldPane.createItemFromGroupedFieldMap(c);BI.each(b,function(e,d){d.title=d.value;d.text=d.value});a.copy2group.populate(b)});this.removeFieldButton.on(BI.Button.EVENT_CHANGE,function(){var g=a.fieldPane.getGroupedSelectedFieldMap();var h=a.fieldPane.getUngroupedFieldMap();var c=a.fieldPane.getGroupOfFieldMap();
var e=a.fieldPane.getGroupMap();var i={};var f={};var d={};var b=false;BI.each(h,function(l,k){i[k]=l});BI.each(e,function(l,k){f[k]=l});BI.each(g,function(k,n){var m=a._getGroupID(k);var l=a._getFieldID(k);delete c[l][m];if(BI.size(c[l])===0){i[n]=BI.UUID()}});BI.each(f,function(l,k){if(BI.isNotNull(i[l])){d[l]="duplicateField";b=true}});if(!b){a.search.stopSearch();BI.each(g,function(k,l){a.fieldPane.deleteFieldWidget(k)});a._checkChosenNum()}else{var j="";BI.each(d,function(l,k){if(BI.isNotEmptyString(j)){j=j+"、"+'"'+l+'"'
}else{j=j+'"'+l+'"'}});BI.Msg.alert(BI.i18nText("BI-Failure_Toast"),j+BI.i18nText("BI-Failure_Groupname_Duplicate"))}})},_getGroupID:function(b){var a=b.split("_");return a[0]},_getFieldID:function(b){var a=b.split("_");return a[1]},_checkChosenNum:function(){var c=this;var a=c.fieldPane.getSelectedFieldMap();var d=BI.size(a);c.combo.setTriggerValue(BI.i18nText("BI-Have_Selected")+d+BI.i18nText("BI-Basic_Item"));c.combo.doRedMark(d);if(d>0){c.move2group.setEnable(true);c.move2group.setTitle("");var b=c.fieldPane.getUnGroupedSelectedFieldMap();
if(BI.size(b)>0){c.copy2group.setEnable(false);c.copy2group.setTitle(BI.i18nText("BI-Ungrouped_Can_Move"));c.removeFieldButton.setEnable(false);c.removeFieldButton.setTitle(BI.i18nText("BI-Ungrouped_Can_Move"))}else{c.copy2group.setEnable(true);c.copy2group.setTitle("");c.removeFieldButton.setEnable(true);c.removeFieldButton.setTitle("")}}else{c.move2group.setEnable(false);c.move2group.setTitle(BI.i18nText("BI-Select_Null"));c.copy2group.setEnable(false);c.copy2group.setTitle(BI.i18nText("BI-Select_Null"));
c.removeFieldButton.setEnable(false);c.removeFieldButton.setTitle("")}},_move2groupHandle:function(e){var a=this;a.search.stopSearch();var d=a.fieldPane.getUnGroupedSelectedFieldMap();BI.each(d,function(g,f){a.fieldPane.addFieldWidget(g,f,e);a.fieldPane.deleteFieldWidget(g)});var c=a.fieldPane.getGroupedSelectedFieldMap();var b=a.fieldPane.getGroupMap();BI.each(c,function(h,g){a.fieldPane.addFieldWidget(h,g,e);var f=a._getGroupID(h);if(e!=b[f]){a.fieldPane.deleteFieldWidget(h)}});a._checkChosenNum()
},_scrollToBottom:function(){var a=this;BI.delay(function(){a.fieldPane.element.scrollTop(BI.MAX)},30)},populate:function(a,c,d){var b=this,f=this.options;var e=f.dId;this.fieldPane.loading();b.bottom.populate(c,d,BI.pluck(a,"value"));BI.Utils.getNoGroupedDataByDimensionID(e,function(i){b.fieldPane.loaded();if(false){if(!BI.Maskers.has(b.getName())){b._tooManyFieldsPane=BI.createWidget({type:"bi.center_adapt",cls:"bi-custom-group-disable-mask bi-card",items:[{type:"bi.label",cls:"mask-label",value:BI.i18nText("BI-Unsupport_Too_Many_Fields"),textHeight:30}],element:BI.Maskers.make(b.getName(),b)})
}BI.Maskers.show(b.getName())}else{var g={};g.value=BI.i18nText("BI-Ungrouped_China");g.content=[];var j={};var h={};BI.each(i,function(k,l){h[l]=l});BI.each(a,function(l,k){BI.remove(k.content,function(n,m){if(BI.isNull(h[m.value])){return true}else{j[m.value]=m.value}})});BI.each(i,function(l,m){if(!BI.isNotNull(j[m])){var k={};k.value=m;g.content.push(k)}});b.fieldPane.populate([g],a);b._checkChosenNum()}})},getValue:function(){var a=this;var c={};var b={};b.details=[];var d=a.bottom.getValue();
c.details=a.fieldPane.createItemFromGroupMap();BI.each(c.details,function(e,f){b.details.push(f.value)});c.ungroup=BI.pluck(a.fieldPane.createUngroupedItemFromGroupMap(),"content")[0]||[];if(a.bottom.isSelected()){c.ungroup2Other=BICst.CUSTOM_GROUP.UNGROUP2OTHER.SELECTED;c.ungroup2OtherName=d;b.details.push(d)}else{c.ungroup2Other=BICst.CUSTOM_GROUP.UNGROUP2OTHER.NOTSELECTED;c.ungroup2OtherName=""}return c}});BI.shortcut("bi.custom_group",BI.CustomGroup);
BI.CustomGroupCombo=BI.inherit(BI.Single,{_defaultConfig:function(){return BI.extend(BI.CustomGroupCombo.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-custom-group-combo",items:[]})},_init:function(){var a=this,b=this.options;BI.CustomGroupCombo.superclass._init.apply(this,arguments);this.triggerButton=BI.createWidget({type:"bi.button",value:BI.i18nText("BI-Have_Selected")+0+BI.i18nText("BI-Basic_Item"),level:"ignore",readonly:false,height:30});this.combo=BI.createWidget({type:"bi.combo",isNeedAdjustHeight:false,isNeedAdjustWidth:false,element:this,el:a.triggerButton,popup:{width:580,maxHeight:350,el:b.popup}});
a.combo.on(BI.Combo.EVENT_BEFORE_POPUPVIEW,function(){a.fireEvent(BI.CustomGroupCombo.EVENT_BEFORE_POPUPVIEW)});a.combo.on(BI.Combo.EVENT_AFTER_HIDEVIEW,function(){a.fireEvent(BI.CustomGroupCombo.EVENT_HIDEVIEW)})},populate:function(a){this.popup.empty();this.combo.populate(a)},doRedMark:function(){this.triggerButton.doRedMark.apply(this.triggerButton,arguments)},setTriggerValue:function(a){this.triggerButton.setValue(a)},getValue:function(){return this.combo.getValue()}});BI.CustomGroupCombo.EVENT_BEFORE_POPUPVIEW="EVENT_BEFORE_POPUPVIEW";
BI.CustomGroupCombo.EVENT_CHANGE="EVENT_CHANGE";BI.CustomGroupCombo.EVENT_HIDEVIEW="EVENT_HIDEVIEW";BI.shortcut("bi.custom_group_combo",BI.CustomGroupCombo);
BI.CustomGroupSearch=BI.inherit(BI.Widget,{_defaultConfig:function(){return BI.extend(BI.CustomGroupSearch.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-custom-group-search"})},_init:function(){var a=this,b=this.options;BI.CustomGroupSearch.superclass._init.apply(this,arguments);this.searchEditor=BI.createWidget({type:"bi.search_editor",cls:"bi-custom-group-search-editor",width:445});this.searcher=BI.createWidget({type:"bi.searcher",el:a.searchEditor,onSearch:b.onSearch,adapter:b.adapter,popup:{type:"bi.custom_group_searcher_view",searcher:b.popup,tipText:BI.i18nText("BI-No_Select")},isAutoSearch:false,isAutoSync:false});
this.toolbar=BI.createWidget({type:"bi.multi_select_bar",text:BI.i18nText("BI-Select_All_Search_Results"),height:30,width:110,disabled:true});BI.createWidget({type:"bi.left_right_vertical_adapt",element:this,items:{left:[a.searcher],right:[a.toolbar]}})},stopSearch:function(){this.searcher.stopSearch()},setValue:function(a){this.searchEditor.setValue(a)},getValue:function(){return this.searchEditor.getValue()}});BI.shortcut("bi.custom_group_search",BI.CustomGroupSearch);
BI.ArrowNodeDelete=BI.inherit(BI.NodeButton,{_defaultConfig:function(){return BI.extend(BI.ArrowNodeDelete.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-arrow-group-node bi-border-bottom bi-list-item",id:"",pId:"",open:false,height:25,hoverClass:"search-close-h-font"})},_init:function(){var a=this,b=this.options;BI.ArrowNodeDelete.superclass._init.apply(this,arguments);this.checkbox=BI.createWidget({iconWidth:13,iconHeight:13,type:"bi.arrow_tree_group_node_checkbox"});this.editor=BI.createWidget({type:"bi.editor",textAlign:"left",whiteSpace:"nowrap",textHeight:b.height,height:b.height,hgap:b.hgap,validationChecker:b.validationChecker,quitChecker:function(){return true
},value:b.value,py:b.py});this.deletebutton=BI.createWidget({type:"bi.icon_button",stopPropagation:true});this.checkbox.on(BI.Controller.EVENT_CHANGE,function(c){if(c===BI.Events.CLICK){a.setSelected(a.isSelected())}a.fireEvent(BI.Controller.EVENT_CHANGE,arguments)});this.editor.on(BI.Editor.EVENT_CONFIRM,function(){var c=this.getValue();if(a.preValue!==c){a.preValue=c;a.fireEvent(BI.ArrowNodeDelete.EVENT_CONFIRM)}});this.deletebutton.on(BI.IconButton.EVENT_CHANGE,function(){a.fireEvent(BI.ArrowNodeDelete.EVENT_CLICK_DELETE)
});BI.createWidget({type:"bi.htape",element:this,items:[{width:23,el:this.checkbox},{el:this.editor},{el:this.deletebutton,width:25}]});this.element.hover(function(){a.deletebutton.element.addClass(b.hoverClass)},function(){a.deletebutton.element.removeClass(b.hoverClass)})},doRedMark:function(){this.text.doRedMark.apply(this.text,arguments)},unRedMark:function(){this.text.unRedMark.apply(this.text,arguments)},doClick:function(){BI.ArrowNodeDelete.superclass.doClick.apply(this,arguments);this.checkbox.setSelected(this.isOpened())
},setOpened:function(a){BI.ArrowNodeDelete.superclass.setOpened.apply(this,arguments);this.checkbox.setSelected(a)},setValue:function(a){this.preValue=a;return this.editor.setValue(a)},getValue:function(){return this.editor.getValue()}});BI.ArrowNodeDelete.EVENT_CLICK_DELETE="EVENT_CLICK_DELETE";BI.ArrowNodeDelete.EVENT_CONFIRM="EVENT_CONFIRM";BI.shortcut("bi.arrow_group_node_delete",BI.ArrowNodeDelete);

BI.CustomgroupGroupExpander=BI.inherit(BI.Widget,{_defaultConfig:function(){return BI.extend(BI.CustomgroupGroupExpander.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-custom-group-expander",id:"",item:{},title:"",nodeType:"bi.arrow_group_node_delete"})},_init:function(){this.fieldWidgetMap={};var a=this,b=this.options;BI.CustomgroupGroupExpander.superclass._init.apply(this,arguments);var d=this._createFieldButtons(b.item);this.popup=BI.createWidget({type:"bi.left",items:d});this.node=BI.createWidget({type:b.nodeType,validationChecker:function(e){return b.validationChecker(e,a.attr("id"))
},cls:"bi-custom-group-group-name bi-border-bottom",hoverClass:"search-close-h-font",height:40,open:true,value:b.item.value});var c=BI.createWidget({type:"bi.expander",element:this,id:b.item.id,isDefaultInit:true,el:a.node,popup:this.popup});this.node.on(BI.ArrowNodeDelete.EVENT_CLICK_DELETE,function(){a.fireEvent(BI.CustomgroupGroupExpander.EVENT_CLICK_DELETE)});this.node.on(BI.ArrowNodeDelete.EVENT_CONFIRM,function(){a.fireEvent(BI.CustomgroupGroupExpander.EVENT_NODE_VALUE_CONFIRM)});a.checkFieldEmpty()
},_createFieldButtons:function(b){var a=this,d=[],c=this.options;if(BI.isNotNull(b.content)&&BI.isNotEmptyArray(b.content)){BI.each(b.content,function(h,e){if(d.length<100){var g=BI.find(a.fieldWidgetMap,function(i,j){if(e.id===i){return true}});if(!g){var f=BI.createWidget({type:"bi.custom_group_field_button",valueLeft:e.value,id:e.id,title:c.title,cls:"item-custom-group bi-list-item-active",textHeight:25,hgap:10,});a.fieldWidgetMap[e.id]=f;f.on(BI.CustomGroupFieldButton.EVENT_CHANGE,function(i,j){a.fireEvent(BI.CustomgroupGroupExpander.EVENT_CHANGE,j)
});d.push(f)}}})}return d},addFieldWidget:function(c){var a=this;var b=a._createFieldButtons(c);a.popup.addItems(b);a.checkFieldEmpty()},deleteFieldWidget:function(c){var a=this;if(BI.isNotNull(a.fieldWidgetMap[c])){var b=a.fieldWidgetMap[c];b.destroy();delete a.fieldWidgetMap[c];a.checkFieldEmpty()}},populate:function(b){var a=this;var c=a._createFieldButtons(b);a.node.setValue(b.value);a.popup.empty();a.popup.populate(c);a.checkFieldEmpty()},getNodeValue:function(){return this.node.getValue()},setFieldSelectedTrue:function(b){var a=this;
BI.each(b,function(d,c){if(BI.isNotNull(a.fieldWidgetMap[c])){a.fieldWidgetMap[c].setSelected(true)}})},setFieldSelectedFalse:function(b){var a=this;BI.each(b,function(d,c){if(BI.isNotNull(a.fieldWidgetMap[c])){a.fieldWidgetMap[c].setSelected(false)}})},checkFieldEmpty:function(){var a=this;if(BI.size(a.fieldWidgetMap)===0){a.emptyButton=BI.createWidget({type:"bi.text_button",value:BI.i18nText("BI-Basic_Null"),cls:"item-custom-group bi-list-item-active",hgap:10,height:25,disabled:true});a.popup.populate([a.emptyButton])
}else{if(BI.isNotNull(a.emptyButton)){a.emptyButton.destroy()}}},doRedMark:function(c,a){var b=this;if(BI.isNotNull(b.fieldWidgetMap[a])){b.fieldWidgetMap[a].doRedMark(c)}},doHighLight:function(a){var b=this;if(BI.isNotNull(b.fieldWidgetMap[a])){this.fieldWidgetMap[a].doHighLight()}},unHighLight:function(a){var b=this;if(BI.isNotNull(b.fieldWidgetMap[a])){this.fieldWidgetMap[a].unHighLight()}},setFieldRightValue:function(c,a){var b=this;if(BI.isNotNull(b.fieldWidgetMap[a])){this.fieldWidgetMap[a].setValueRight(c)
}}});BI.CustomgroupGroupExpander.EVENT_CHANGE="EVENT_CHANGE";BI.CustomgroupGroupExpander.EVENT_CLICK_DELETE="EVENT_CLICK_DELETE";BI.CustomgroupGroupExpander.EVENT_NODE_VALUE_CONFIRM="EVENT_NODE_VALUE_CONFIRM";BI.shortcut("bi.custom_group_group_expander",BI.CustomgroupGroupExpander);
BI.CustomGroupFieldButton=BI.inherit(BI.BasicButton,{_defaultConfig:function(){var a=BI.CustomGroupFieldButton.superclass._defaultConfig.apply(this,arguments);return BI.extend(a,{baseCls:(a.baseCls||"")+" bi-text-button"+" bi-custom-group-field-button",height:24,textAlign:"center",whiteSpace:"nowrap",textWidth:null,textHeight:null,hgap:0,valueRight:"",py:""})},_init:function(){BI.CustomGroupFieldButton.superclass._init.apply(this,arguments);var a=this,b=this.options;this.textLeft=BI.createWidget({type:"bi.label",cls:"button-label",textAlign:b.textAlign,whiteSpace:b.whiteSpace,textHeight:b.textHeight,height:b.height,lgap:b.hgap,text:b.textLeft,value:b.valueLeft,py:b.py});
this.textRight=BI.createWidget({type:"bi.label",cls:"button-label",textAlign:b.textAlign,whiteSpace:b.whiteSpace,textHeight:b.textHeight,height:b.height,rgap:b.hgap,text:b.textRight,value:b.valueRight});this.setTitle(b.title||this.getValue());BI.createWidget({type:"bi.left",element:this,items:[a.textLeft,a.textRight]})},doClick:function(){BI.CustomGroupFieldButton.superclass.doClick.apply(this,arguments);if(this.isValid()){this.fireEvent(BI.CustomGroupFieldButton.EVENT_CHANGE,this.getValue(),this)
}},doRedMark:function(){this.textLeft.doRedMark.apply(this.textLeft,arguments)},unRedMark:function(){this.textLeft.unRedMark.apply(this.textLeft,arguments)},doHighLight:function(){this.textLeft.doHighLight.apply(this.textLeft,arguments)},unHighLight:function(){this.textLeft.unHighLight.apply(this.textLeft,arguments)},setValueLeft:function(a){BI.CustomGroupFieldButton.superclass.setValue.apply(this,arguments);if(!this.isReadOnly()){a=BI.isArray(a)?a.join(","):a;this.textLeft.setValue(a);this.setTitle(this.getValue())
}},setValueRight:function(a){BI.CustomGroupFieldButton.superclass.setValue.apply(this,arguments);if(!this.isReadOnly()){a=BI.isArray(a)?a.join(","):a;this.textRight.setValue(a);this.setTitle(this.getValue())}},getValueLeft:function(){return this.textLeft.getValue()},getValueRight:function(){return this.textRight.getValue()},getValue:function(){return this.getValueLeft()+this.getValueRight()}});BI.CustomGroupFieldButton.EVENT_CHANGE="EVENT_CHANGE";BI.shortcut("bi.custom_group_field_button",BI.CustomGroupFieldButton);
BI.CustomGroupFieldPane=BI.inherit(BI.Widget,{_defaultConfig:function(){return BI.extend(BI.CustomGroupFieldPane.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-custom-group-field-pane",nodeType:"bi.arrow_group_node_delete",title:"",enableCheckGroup:false})},_init:function(){var b=this,d=this.options;BI.CustomGroupFieldPane.superclass._init.apply(this,arguments);this.groupMap={};this.fieldMap={};this.fieldReserveMap={};this.groupWidgetMap={};this.chosenFieldMap={};this.fieldInGroupMap={};
this.groupOfFieldMap={};this._initFields(d.items);var a=b.createItemFromFieldMap(b.fieldMap);var c=[];BI.each(a,function(e,f){c.push(b.createGroupWidget(f))});this.fieldPane=BI.createWidget({type:"bi.vertical",element:this,items:c});BI.each(b.fieldMap,function(e,f){b.checkDuplicate(e)})},_initFields:function(b){var a=this;BI.each(b,function(d,e){var c;if(!BI.isNotNull(e.id)){c=BI.UUID();e.id=c}c=e.id;a.groupMap[c]=e.value;a.fieldInGroupMap[c]={};BI.each(e.content,function(h,g){var f=BI.isNotNull(g.id)?g.id:a.fieldReserveMap[g.value];
if(!BI.isNotNull(f)){f=a._createGroupFieldID(c,BI.UUID())}else{f=a._createGroupFieldID(c,a._getFieldID(f))}a.fieldMap[f]=g.value;a.fieldReserveMap[g.value]=f;a.fieldInGroupMap[c][f]=g.value;if(!a.groupOfFieldMap[a._getFieldID(f)]){a.groupOfFieldMap[a._getFieldID(f)]={}}a.groupOfFieldMap[a._getFieldID(f)][c]=a.groupMap[c]})})},_getGroupID:function(b){var a=b.split("_");return a[0]},_getFieldID:function(b){var a=b.split("_");return a[1]},_createGroupFieldID:function(b,a){return b+"_"+a},createItemFromEmptyGroupMap:function(){var b=this,a=[];
BI.each(b.fieldInGroupMap,function(e,c){if(BI.size(c)===0){var d={};d.id=e;d.value=b.groupMap[e];d.content=[];a.push(d)}});return a},createItemFromFieldMap:function(c){var b=this,a=[];BI.each(c,function(d,i){var g=b._getGroupID(d);var h=BI.find(a,function(l,k){if(k.id===g){var j={};j.id=d;j.value=i;k.content.push(j);return true}});if(!h){var f={};f.id=g;f.value=b.groupMap[g];f.content=[];var e={};e.id=d;e.value=i;f.content.push(e);a.push(f)}});return a},createItemFromGroupMap:function(){var b=this,a=[];
BI.each(b.groupMap,function(d,e){var c={};c.value=e;c.content=[];BI.each(b.fieldInGroupMap[d],function(f,h){var g={};g.value=h;c.content.push(g);c.id=d});a.push(c)});return a},createGroupWidget:function(c){var b=this,d=this.options;var a=BI.createWidget({type:"bi.custom_group_group_expander",nodeType:d.nodeType,validationChecker:d.validationChecker,title:d.title,id:c.id});a.populate(c);this.groupWidgetMap[c.id]=a;a.on(BI.CustomgroupGroupExpander.EVENT_CHANGE,function(e){var f=e.attr("id");if(e.isSelected()===true){b.chosenFieldMap[f]=b.fieldMap[f]
}else{delete b.chosenFieldMap[f]}b.fireEvent(BI.CustomGroupFieldPane.EVENT_CHANGE,e)});a.on(BI.CustomgroupGroupExpander.EVENT_CLICK_DELETE,function(){var e=a.attr("id");BI.Msg.confirm("",BI.i18nText("BI-Is_Dissolve_Group")+":"+a.getNodeValue()+"?",function(f){if(f===true){b.deleteGroupWidget(e)}})});a.on(BI.CustomgroupGroupExpander.EVENT_NODE_VALUE_CONFIRM,function(){b.groupMap[a.attr("id")]=a.getNodeValue();var e=b.createItemFromGroupMap()});return a},empty:function(){this.groupMap={};this.fieldMap={};
this.groupWidgetMap={};this.chosenFieldMap={};this.fieldInGroupMap={};this.groupOfFieldMap={};this.fieldPane.empty()},populate:function(d){var c=this;this.empty();this._initFields(d);var g="";BI.find(d,function(h,i){if(BI.has(i,"title")){g=i.title;return true}});var f=c.createItemFromFieldMap(c.fieldMap);if(BI.isNotEmptyString(g)){BI.each(f,function(h,i){BI.each(i.content,function(k,j){j.title=g})})}var b=c.createItemFromEmptyGroupMap();var a=BI.union(f,b);var e=[];BI.each(a,function(h,j){e.push(c.createGroupWidget(j))
});this.fieldPane.populate(e);BI.each(c.fieldMap,function(h,i){c.checkDuplicate(h)})},setFieldSelectedTrue:function(a){var b=this;var c=b._getGroupID(a);if(BI.isNotNull(b.groupWidgetMap[c])){b.groupWidgetMap[c].setFieldSelectedTrue([a]);b.chosenFieldMap[a]=b.fieldMap[a]}},setFieldSelectedFalse:function(a){var b=this;var c=b._getGroupID(a);if(BI.isNotNull(b.groupWidgetMap[c])){b.groupWidgetMap[c].setFieldSelectedFalse([a]);delete b.chosenFieldMap[a]}},deleteGroupWidget:function(b){var a=this;BI.each(a.fieldInGroupMap[b],function(d,e){delete a.groupOfFieldMap[a._getFieldID(d)][b];
var c=a._createGroupFieldID(b,a._getFieldID(d));a.deleteFieldWidget(c)});this.groupWidgetMap[b].destroy();delete a.groupMap[b];delete a.groupWidgetMap[b];delete a.fieldInGroupMap[b]},addGroupWidget:function(f){var b=this;var d=BI.find(b.groupMap,function(h,g){if(f===g){return true}});if(!d){var c=BI.UUID();var a={};a.value=f;a.id=c;b.groupMap[c]=f;b.fieldInGroupMap[c]={};var e=b.createGroupWidget(a);b.fieldPane.addItem(e)}},addFieldWidget:function(e,f,g){var h=this;var d={};var b=BI.findKey(h.groupMap,function(k,j){return j===g
});if(BI.isNotNull(b)){d.id=b;d.value=g;d.content=[];if(h._getGroupID(e)!=b){var c={};var i=h._createGroupFieldID(b,h._getFieldID(e));if(!BI.isNotNull(h.groupOfFieldMap[h._getFieldID(e)])){h.fieldMap[i]=f;h.fieldReserveMap[f]=i;h.groupOfFieldMap[h._getFieldID(e)]={}}c.id=i;c.value=f;d.content.push(c);h.fieldInGroupMap[b][i]=f;h.groupOfFieldMap[h._getFieldID(i)][b]=g;h.fieldMap[i]=f;h.fieldReserveMap[f]=i}var a=h.groupWidgetMap[b];a.addFieldWidget(d)}h.checkDuplicate(e)},deleteFieldWidget:function(a){var b=this;
var c=b._getGroupID(a);var d=b._getFieldID(a);if(BI.isNotNull(b.groupWidgetMap[c])){b.groupWidgetMap[c].deleteFieldWidget(a);delete b.fieldInGroupMap[c][a];delete b.groupOfFieldMap[b._getFieldID(a)][c];delete b.chosenFieldMap[a];b.checkDuplicate(a);if(BI.size(b.groupOfFieldMap[d])===0){b.fireEvent(BI.CustomGroupFieldPane.EVENT_EMPTY_GROUP,a,b.fieldMap[a])}var e=b.fieldMap[a];delete b.fieldReserveMap[e];delete b.fieldMap[a]}},doRedMark:function(c,a){var b=this;var d=this._getGroupID(a);if(BI.isNotNull(b.groupWidgetMap[d])){b.groupWidgetMap[d].doRedMark(c,a)
}},doHighLight:function(a){var b=this;var c=this._getGroupID(a);if(BI.isNotNull(b.groupWidgetMap[c])){b.groupWidgetMap[c].doHighLight(a)}},setFieldRightValue:function(d,a){var b=this;var c=this._getGroupID(a);if(BI.isNotNull(b.groupWidgetMap[c])){b.groupWidgetMap[c].setFieldRightValue(d,a)}},getSelectedFieldMap:function(){return this.chosenFieldMap},getFieldMap:function(){return this.fieldMap},getGroupMap:function(){return this.groupMap},checkSelectedAll:function(){var a=this;if(BI.size(a.chosenFieldMap)===0){return"none"
}else{if(BI.size(a.chosenFieldMap)===BI.size(a.fieldMap)){return"all"}else{return"half"}}},checkDuplicate:function(b){var d=this,g=this.options;if(g.enableCheckGroup===true){var a=d._getFieldID(b);var f=d.groupOfFieldMap[a];if(BI.size(f)>1){var c="";BI.each(f,function(h,i){if(BI.isEmptyString(c)){c=i}else{c=c+"、"+i}});BI.each(f,function(h,j){var i=d._createGroupFieldID(h,a);d.groupWidgetMap[h].setFieldRightValue("("+c+")",i);d.groupWidgetMap[h].doHighLight(i)})}else{var e=d._getFieldID(b);BI.each(f,function(i,j){var h=d._createGroupFieldID(i,e);
d.groupWidgetMap[i].setFieldRightValue("",h);d.groupWidgetMap[i].unHighLight(h)})}}},setGroupName:function(a,d){var b=this;var c=BI.findKey(b.groupMap,function(e,f){return f===d});b.groupMap[c]=a},getGroupOfFieldMap:function(){return this.groupOfFieldMap}});BI.CustomGroupFieldPane.EVENT_CHANGE="EVENT_CHANGE";BI.CustomGroupFieldPane.EVENT_EMPTY_GROUP="EVENT_EMPTY_GROUP";BI.shortcut("bi.custom_group_field_pane",BI.CustomGroupFieldPane);
BI.CustomGroupAllFieldsPane=BI.inherit(BI.Pane,{_defaultConfig:function(){return BI.extend(BI.CustomGroupAllFieldsPane.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-custom-group-all-fields-pane",enableCheckGroup:false,unGroupedItems:[],groupedItems:[]})},_init:function(){var a=this,b=this.options;BI.CustomGroupAllFieldsPane.superclass._init.apply(this,arguments);this.ungroupedPane=BI.createWidget({type:"bi.custom_group_field_pane",items:b.unGroupedItems,nodeType:"bi.arrow_group_node"});
this.groupedPane=BI.createWidget({type:"bi.custom_group_field_pane",items:b.groupedItems,enableCheckGroup:b.enableCheckGroup,validationChecker:function(d,h){var e=b.validationChecker(d);var f=a.groupedPane.getGroupMap();var g=a.ungroupedPane.getFieldMap();var c=BI.findKey(f,function(i,j){return j===d&&h!=i});c=c||BI.findKey(g,function(i,j){return j===d});if(BI.isNotNull(c)||!e){return false}else{return true}},nodeType:b.nodeType});this.ungroupedPane.on(BI.CustomGroupFieldPane.EVENT_CHANGE,function(c){a.fireEvent(BI.CustomGroupAllFieldsPane.EVENT_CHANGE,c)
});this.groupedPane.on(BI.CustomGroupFieldPane.EVENT_CHANGE,function(c){a.fireEvent(BI.CustomGroupAllFieldsPane.EVENT_CHANGE,c)});this.groupedPane.on(BI.CustomGroupFieldPane.EVENT_EMPTY_GROUP,function(c,d){a.ungroupedPane.addFieldWidget(c,d,BI.i18nText("BI-Ungrouped_China"))});BI.createWidget({type:"bi.vertical",element:this,items:[a.ungroupedPane,a.groupedPane]})},_getGroupID:function(b){var a=b.split("_");return a[0]},_getFieldID:function(b){var a=b.split("_");return a[1]},createItemFromEmptyGroupMap:function(){return this.groupedPane.createItemFromEmptyGroupMap()
},createItemFromGroupMap:function(){return this.groupedPane.createItemFromGroupMap()},createUngroupedItemFromGroupMap:function(){return this.ungroupedPane.createItemFromGroupMap()},createItemFromUngroupedFieldMap:function(b){var a=this.ungroupedPane.createItemFromFieldMap(b);return a},createItemFromGroupedFieldMap:function(b){var a=this.groupedPane.createItemFromFieldMap(b);return a},createGroupWidget:function(a){this.groupedPane.createGroupWidget(a)},empty:function(){this.ungroupedPane.empty();this.groupedPane.empty()
},populate:function(b,a){this.ungroupedPane.populate(b);this.groupedPane.populate(a)},setFieldSelectedTrue:function(a){this.ungroupedPane.setFieldSelectedTrue(a);this.groupedPane.setFieldSelectedTrue(a)},setFieldSelectedFalse:function(a){this.ungroupedPane.setFieldSelectedFalse(a);this.groupedPane.setFieldSelectedFalse(a)},deleteGroupWidget:function(a){this.groupedPane.deleteGroupWidget(a)},addGroupWidget:function(a){this.groupedPane.addGroupWidget(a)},addFieldWidget:function(a,c,b){this.groupedPane.addFieldWidget(a,c,b)
},deleteFieldWidget:function(a){var b=this;this.ungroupedPane.deleteFieldWidget(a);this.groupedPane.deleteFieldWidget(a);var c=b._getFieldID(a)},doRedMark:function(b,a){this.groupedPane.doRedMark(b,a);this.ungroupedPane.doRedMark(b,a)},doHighLight:function(a){this.groupedPane.doHighLight(a)},setFieldRightValue:function(b,a){this.groupedPane.setFieldRightValue(b,a)},getSelectedFieldMap:function(){var c=this;var b=BI.deepClone(c.ungroupedPane.getSelectedFieldMap());var a=BI.deepClone(c.groupedPane.getSelectedFieldMap());
BI.each(a,function(e,d){b[e]=a[e]});return b},getGroupedSelectedFieldMap:function(){var a=this;var b=BI.deepClone(a.groupedPane.getSelectedFieldMap());return b},getUnGroupedSelectedFieldMap:function(){var a=this;var b=BI.deepClone(a.ungroupedPane.getSelectedFieldMap());return b},getGroupedFieldMap:function(){return this.groupedPane.getFieldMap()},getUngroupedFieldMap:function(){return this.ungroupedPane.getFieldMap()},getAllFieldMap:function(){var a=this;var c=BI.deepClone(a.groupedPane.getFieldMap());
var b=BI.deepClone(a.ungroupedPane.getFieldMap());BI.each(c,function(e,d){b[e]=c[e]});return b},getGroupMap:function(){return this.groupedPane.getGroupMap()},getGroupOfFieldMap:function(){var a=this;return BI.deepClone(a.groupedPane.getGroupOfFieldMap())}});BI.CustomGroupAllFieldsPane.EVENT_CHANGE="EVENT_CHANGE";BI.shortcut("bi.custom_group_all_fields_pane",BI.CustomGroupAllFieldsPane);
BI.CustomGroupSearcherPane=BI.inherit(BI.Widget,{_defaultConfig:function(){return BI.extend(BI.CustomGroupSearcherPane.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-custom-group-field-pane",nodeType:"bi.arrow_group_node_delete",title:"",enableCheckGroup:false})},_init:function(){var a=this,b=this.options;BI.CustomGroupSearcherPane.superclass._init.apply(this,arguments);this.fieldPane=BI.createWidget({type:"bi.custom_group_field_pane",nodeType:"bi.arrow_group_node",enableCheckGroup:true});
this.toolbar=BI.createWidget({type:"bi.multi_select_bar",cls:"bi-custom-group-searcher-toolbar bi-card",text:BI.i18nText("BI-Select_All_Search_Results"),height:30,width:110});this.toolbar.on(BI.MultiSelectBar.EVENT_CHANGE,function(){var d=a.fieldPane.getFieldMap();var c=a.toolbar.isSelected();if(c===true){BI.each(d,function(f,e){a.fieldPane.setFieldSelectedTrue(f)})}else{BI.each(d,function(f,e){a.fieldPane.setFieldSelectedFalse(f)})}a.fireEvent(BI.CustomGroupSearcherPane.EVENT_TOOLBAR_VALUE_CHANGE,c,d)
});this.fieldPane.on(BI.CustomGroupFieldPane.EVENT_CHANGE,function(c){switch(a.fieldPane.checkSelectedAll()){case"none":a.toolbar.setSelected(false);break;case"half":a.toolbar.setHalfSelected(true);break;case"all":a.toolbar.setSelected(true)}a.fireEvent(BI.CustomGroupSearcherPane.EVENT_CHANGE,c)});BI.createWidget({type:"bi.absolute",element:this,items:[{el:a.toolbar,height:30,width:110,top:-40,right:5},{el:a.fieldPane,top:0,bottom:0,left:0,right:0}]})},populate:function(c,d,b){var a=this;a.fieldPane.populate(c);
var e=a.fieldPane.getFieldMap();BI.each(d,function(f,g){if(BI.isNotNull(e[g])){a.fieldPane.setFieldSelectedTrue(g)}});BI.each(e,function(g,f){a.fieldPane.doRedMark(b,g)});if(BI.size(e)>0){a.toolbar.setEnable(true)}else{a.toolbar.setEnable(false)}switch(a.fieldPane.checkSelectedAll()){case"none":a.toolbar.setSelected(false);break;case"half":a.toolbar.setHalfSelected(true);break;case"all":a.toolbar.setSelected(true)}},empty:function(){this.fieldPane.empty()}});BI.CustomGroupSearcherPane.EVENT_CHANGE="EVENT_CHANGE";
BI.CustomGroupSearcherPane.EVENT_TOOLBAR_VALUE_CHANGE="EVENT_TOOLBAR_VALUE_CHANGE";BI.shortcut("bi.custom_group_searcher_pane",BI.CustomGroupSearcherPane);
BI.CustomGroupSearcherView=BI.inherit(BI.Pane,{_defaultConfig:function(){var a=BI.CustomGroupSearcherView.superclass._defaultConfig.apply(this,arguments);return BI.extend(a,{baseCls:(a.baseCls||"")+" bi-custom-group-searcher-view bi-card",})},_init:function(){var a=this,b=this.options;BI.CustomGroupSearcherView.superclass._init.apply(this,arguments);this.searcher=b.searcher;this.searcher.on(BI.Controller.EVENT_CHANGE,function(d,e,c){a.fireEvent(BI.Controller.EVENT_CHANGE,arguments);if(d===BI.Events.CLICK){a.fireEvent(BI.CustomGroupSearcherView.EVENT_CHANGE,e,c)
}});BI.createWidget({type:"bi.absolute",element:this,items:[{el:this.searcher,top:0,bottom:0,right:0,left:0}]})},_assertTip:function(){var a=this.options;if(!this._tipText){this._tipText=BI.createWidget({type:"bi.label",cls:"bi-tips",text:a.tipText,height:25});BI.createWidget({type:"bi.absolute",element:this,items:[{el:this._tipText,top:0,bottom:0,left:0,right:0}]})}},setTipVisible:function(a){if(a===true){this._assertTip();this._tipText.setVisible(true)}else{this._tipText&&this._tipText.setVisible(false)
}},populate:function(a,c,d){var b=this;a||(a=[]);this.setTipVisible(a.length===0);this.searcher.populate(a,d,c)},empty:function(){this.searcher.empty()}});BI.CustomGroupSearcherView.EVENT_CHANGE="EVENT_CHANGE";BI.shortcut("bi.custom_group_searcher_view",BI.CustomGroupSearcherView);
BI.GlobalExport=BI.inherit(BI.Widget,{_const:{HEIGHT:30,TRIGGER_WIDTH:80,EDIT_PANE_LEFT:140,PANE_TOP:30,PANE_WIDTH:1366,PANE_HEIGHT:768},_defaultConfig:function(){return BI.extend(BI.GlobalExport.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-global-export"})},_init:function(){BI.GlobalExport.superclass._init.apply(this,arguments);var a=this;var c=BI.createWidget({type:"bi.icon_text_icon_item",iconCls1:"toolbar-global-export",iconCls2:"pull-down-font",text:BI.i18nText("BI-Basic_Export"),readonly:true,height:this._const.HEIGHT,width:this._const.TRIGGER_WIDTH});
var b=BI.createWidget({type:"bi.static_combo",el:c,element:this,textAlign:"center",items:[{text:BI.i18nText("BI-Excel_Export"),value:BICst.EXPORT.EXCEL},{text:BI.i18nText("BI-PDF_Export"),value:BICst.EXPORT.PDF}],chooseType:BI.ButtonGroup.CHOOSE_TYPE_NONE});b.on(BI.StaticCombo.EVENT_CHANGE,function(d){BI.$defaultImport({op:"emb",type:"js",path:"export.js"});switch(d){case BICst.EXPORT.EXCEL:a._export("bi_excel_global_export",{widgets:a._getWidgets4ExcelExport()});break;case BICst.EXPORT.PDF:a._export("bi_pdf_global_export",{});
break}})},_export:function(d,f){if(BI.isIE9Below()){this._exportRequest(d,f,"");return}var m=this,i=$(".bi-drag-icon-group").length>0;var g=$(".arrangement-container");g.parent().scrollTop(0).scrollLeft(0);var a=this._getStyle().bodyStyle.background;var k=0,b=0;BI.each(BI.Utils.getAllWidgetIDs(),function(n,p){var o=BI.Utils.getWidgetBoundsByID(p);k=Math.max(k,o.top+o.height,m._const.PANE_HEIGHT);b=Math.max(b,o.left+o.width,m._const.PANE_WIDTH)});g.height(k);g.width(b);var c=document.createElement("canvas");
if(!document.createElement("canvas").getContext){c=window.G_vmlCanvasManager.initElement(c)}var j=i?this._const.EDIT_PANE_LEFT:0;var h=this._const.PANE_TOP;c.width=b+j;c.height=k+h;var l=c.getContext("2d");if(a.indexOf("url")>-1){var e=new Image;e.onload=function(){l.fillStyle=l.createPattern(this,"repeat");l.fillRect(0,0,c.width,c.height);m._html2canvas(g,c,d,f,h,j)};e.onerror=function(){m._html2canvas(g,c,d,f,h,j)};e.src=a.replace(/url\(['"]{0,}|['"]{0,}\)$/ig,"")}else{l.fillStyle=a;l.fillRect(j,h,b,k);
this._html2canvas(g,c,d,f,h,j)}},_html2canvas:function(g,b,f,e,d,c){var a=this;html2canvas(g,{useCORS:true,logging:false,canvas:b,cropTop:d,cropLeft:c,iframeTimeout:1500}).then(function(h){g.height("");g.width("");var i=h.toDataURL();a._exportRequest(f,e,i)})},_exportRequest:function(b,a,c){BI.Func.doActionByForm(BI.servletURL+"?op=fr_bi_dezi&cmd="+b,BI.extend(a,{base64:c.replaceAll("data:image/png;base64,",""),reportName:Data.SharingPool.get("reportName"),sessionID:Data.SharingPool.get("sessionID")}))
},_getWidgets4ExcelExport:function(){var a=BI.deepClone(Data.SharingPool.get("widgets"));BI.each(BI.keys(a),function(b,c){var d=BI.Utils.getWidgetCalculationByID(c);a[c]=BI.extend(d,{wId:BI.UUID(),name:BI.Utils.getWidgetNameByID(c),globalFilter:Data.SharingPool.get("filter")})});return a},_getStyle:function(){var g=BI.Utils.getActualGlobalStyle();g||(g={});var f=BI.Utils.getDefaultChartConfig();var i=this._getBackgroundValue(g,"mainBackground");var h;var d=i,j;if(BI.DOM.isHexColor(i)){j=h=BI.DOM.getContrastColor(i)
}else{if(i===""){d=this._getBackgroundValue(f,"mainBackground");if(BI.DOM.isHexColor(d)){j=BI.DOM.getContrastColor(d)}else{if(g.theme===BICst.THEME_DARK){d="#191B2B";j=BI.DOM.getContrastColor(d)}else{d="#eff1f4";j=BI.DOM.getContrastColor(d)}}}else{if(i==="transparent"){if(g.theme===BICst.THEME_DARK){d="#191B2B";j=BI.DOM.getContrastColor(d)}else{d="#eff1f4";j=BI.DOM.getContrastColor(d)}}}}var e=this._getBackgroundValue(g,"widgetBackground");var k=this._getBackgroundValue(g,"titleBackground");var b={};
BI.each(g.titleFont,function(o,n){if(n){b[BI.hyphenate(o)]=n}});var a=g.controlTheme||f.controlTheme;var c=BI.DOM.hex2rgb(a);var m=BI.DOM.rgb2json(c);m.a=0.05;var l={background:d,color:j};return{bodyStyle:l}},_getBackgroundValue:function(a,b){if(!a[b]){return""}switch(a[b].type){case BICst.BACKGROUND_TYPE.COLOR:return a[b].value;case BICst.BACKGROUND_TYPE.IMAGE:if(a[b]["value"]){return"url("+BI.Func.getCompleteImageUrl(a[b]["value"])+")"}return"transparent"}return""},_isColor:function(a){return a===""||BI.DOM.isColor(a)||a==="transparent"
}});BI.shortcut("bi.global_export",BI.GlobalExport);
BI.ChartSettingSelectColorCombo=BI.inherit(BI.Widget,{_defaultConfig:function(){return BI.extend(BI.ChartSettingSelectColorCombo.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-chart-setting-select-color-combo",width:130})},_init:function(){BI.ChartSettingSelectColorCombo.superclass._init.apply(this,arguments);var a=this,b=this.options;this.combo=BI.createWidget({type:"bi.combo",element:this,adjustLength:1,el:{type:"bi.chart_setting_select_color_trigger",height:24},popup:{el:{type:"bi.chart_setting_select_color_popup"},stopPropagation:false,minWidth:145}});
this.combo.on(BI.Combo.EVENT_CHANGE,function(){a.setValue(this.getValue()[0]);a.combo.hideView();a.fireEvent(BI.ChartSettingSelectColorCombo.EVENT_CHANGE)})},populate:function(b){var c=b||BI.Utils.getDefaultChartConfig();var a=[];if(c.styleList.length>0){BI.each(c.styleList,function(e,d){a.push({header:d.value,text:d.colors.slice(0,5),value:d.colors})})}else{a=BICst.CHART_COLORS}this.combo.populate(a)},setValue:function(a){a=BI.isArray(a)?a:[a];this.combo.setValue(a)},getValue:function(){return this.combo.getValue()
}});BI.ChartSettingSelectColorCombo.EVENT_CHANGE="ChartSettingSelectColorCombo.EVENT_CHANGE";BI.shortcut("bi.chart_setting_select_color_combo",BI.ChartSettingSelectColorCombo);
BI.ChartSettingWrapSelectColorItem=BI.inherit(BI.Single,{_defaultConfig:function(){var a=BI.ChartSettingWrapSelectColorItem.superclass._defaultConfig.apply(this,arguments);return BI.extend(a,{baseCls:(a.baseCls||"")+" bi-chart-setting-wrap-select-color-item",text:"",header:"",value:[],height:50,width:130})},_init:function(){BI.ChartSettingWrapSelectColorItem.superclass._init.apply(this,arguments);var a=this,b=this.options;this.item=BI.createWidget({type:"bi.chart_setting_select_color_item",value:b.value,text:b.text,});
BI.createWidget({type:"bi.vtape",hgap:2,element:this,items:[{type:"bi.label",textAlign:"left",text:b.header,lgap:3},{el:this.item,height:28}]});this.item.on(BI.Controller.EVENT_CHANGE,function(){a.fireEvent(BI.Controller.EVENT_CHANGE,arguments)})},setSelected:function(a){this.item.setSelected(a)},isSelected:function(){return this.item.isSelected()},doRedMark:function(){},unRedMark:function(){}});BI.ChartSettingWrapSelectColorItem.EVENT_CHANGE="EVENT_CHANGE";BI.shortcut("bi.chart_setting_wrap_select_color_item",BI.ChartSettingWrapSelectColorItem);
BI.ChartSettingSelectColorItem=BI.inherit(BI.BasicButton,{_defaultConfig:function(){var a=BI.ChartSettingSelectColorItem.superclass._defaultConfig.apply(this,arguments);return BI.extend(a,{baseCls:(a.baseCls||"")+" bi-chart-setting-select-color-item bi-border bi-select-item-effect",value:[],text:[],once:true,height:50,width:130})},_init:function(){BI.ChartSettingSelectColorItem.superclass._init.apply(this,arguments);var a=this,c=this.options;var b=BI.map(c.text,function(d,f){var e=BI.createWidget({type:"bi.layout"});
e.element.css("background-color",f);return e});this.colorContainer=BI.createWidget({type:"bi.button_group",items:b,layouts:[{type:"bi.center",hgap:0.5,vgap:2}]});BI.createWidget({type:"bi.absolute",element:this,items:[{el:this.colorContainer,left:1,right:2,top:0,bottom:0}]})},doClick:function(){BI.ChartSettingSelectColorItem.superclass.doClick.apply(this,arguments);if(this.isValid()){this.fireEvent(BI.ChartSettingSelectColorItem.EVENT_CHANGE,this.getValue(),this)}},doRedMark:function(){},unRedMark:function(){}});
BI.ChartSettingSelectColorItem.EVENT_CHANGE="EVENT_CHANGE";BI.shortcut("bi.chart_setting_select_color_item",BI.ChartSettingSelectColorItem);
BI.ChartSettingSelectColorPopup=BI.inherit(BI.Widget,{_defaultConfig:function(){return BI.extend(BI.ChartSettingSelectColorPopup.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-chart-setting-select-color-popup",height:145})},_init:function(){BI.ChartSettingSelectColorPopup.superclass._init.apply(this,arguments);var a=this,b=this.options;this.popup=BI.createWidget({type:"bi.button_group",element:this,layouts:[{type:"bi.vertical"}]});this.popup.on(BI.Controller.EVENT_CHANGE,function(c,d,e){a.setValue(d);
a.fireEvent(BI.Controller.EVENT_CHANGE,arguments)})},populate:function(a){this.popup.populate(BI.createItems(a,{type:"bi.chart_setting_wrap_select_color_item"}))},setValue:function(a){BI.each(this.popup.getAllButtons(),function(b,c){if(BI.isEqual(a,c.getValue())){c.setSelected&&c.setSelected(true)}else{c.setSelected&&c.setSelected(false)}})},getValue:function(){return this.popup.getValue()}});BI.ChartSettingSelectColorPopup.EVENT_CHANGE="ChartSettingSelectColorPopup.EVENT_CHANGE";BI.shortcut("bi.chart_setting_select_color_popup",BI.ChartSettingSelectColorPopup);
BI.ChartSettingSelectColorTrigger=BI.inherit(BI.Trigger,{_defaultConfig:function(){var a=BI.ChartSettingSelectColorTrigger.superclass._defaultConfig.apply(this,arguments);return BI.extend(a,{baseCls:(a.baseCls||"")+" bi-chart-setting-select-color-trigger bi-border",height:28,items:[]})},_init:function(){BI.ChartSettingSelectColorTrigger.superclass._init.apply(this,arguments);var a=this,c=this.options;var b=BI.map(c.text,function(d,f){var e=BI.createWidget({type:"bi.layout"});e.element.css("background-color",f);
return e});this.down=BI.createWidget({type:"bi.icon_button",disableSelected:true,cls:"icon-combo-down-icon trigger-triangle-font",width:15,height:10});this.down.setVisible(false);this.element.hover(function(){a.down.setVisible(true)},function(){a.down.setVisible(false)});this.colorContainer=BI.createWidget({type:"bi.button_group",items:b,layouts:[{type:"bi.center",hgap:0.5,vgap:2}]});BI.createWidget({type:"bi.absolute",element:this,items:[{el:this.colorContainer,left:1,right:2,top:0,bottom:0},{el:this.down,right:4,bottom:5}]})
},populate:function(a){this.options.items=a},setValue:function(b){BI.ChartSettingSelectColorTrigger.superclass.setValue.apply(this,arguments);this.value=b;var a=[];BI.each(this.options.items,function(c,d){if(BI.isEqual(d.value,b)){a=BI.map(d.text,function(e,g){var f=BI.createWidget({type:"bi.layout"});f.element.css("background-color",g);return f})}});this.colorContainer.populate(a)},getValue:function(){return this.value}});BI.ChartSettingSelectColorTrigger.EVENT_CHANGE="ChartSettingSelectColorTrigger.EVENT_CHANGE";
BI.shortcut("bi.chart_setting_select_color_trigger",BI.ChartSettingSelectColorTrigger);
BI.GlobalStyle=BI.inherit(BI.Widget,{_defaultConfig:function(){return BI.extend(BI.GlobalStyle.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-global-style"})},_init:function(){BI.GlobalStyle.superclass._init.apply(this,arguments);var b=this;this.manager=new BI.StyleSetManager;var a=BI.createWidget({type:"bi.icon_text_item",cls:"toolbar-global-style-font",element:this,height:30,text:BI.i18nText("BI-Global_Style"),width:90});a.on(BI.Button.EVENT_CHANGE,function(){b._createGlobalStylePane()
})},_createGlobalStylePane:function(){var b=this;var a={};if(BI.isNull(this.globalStyleSetting)){var c=BI.Layers.create(BICst.GLOBAL_STYLE_LAYER);this.globalStyleSetting=BI.createWidget({type:"bi.global_style_setting"});this.globalStyleSetting.populate();BI.Layers.show(BICst.GLOBAL_STYLE_LAYER);a=BI.Utils.getGlobalStyle();this.globalStyleSetting.on(BI.GlobalStyleSetting.EVENT_CANCEL,function(){BI.Layers.hide(BICst.GLOBAL_STYLE_LAYER);b.fireEvent(BI.GlobalStyle.EVENT_SET,a);b.populate()});this.globalStyleSetting.on(BI.GlobalStyleSetting.EVENT_CHANGE,function(){var d=b.getValue();
b.fireEvent(BI.GlobalStyle.EVENT_SET,d);b.populate()});this.globalStyleSetting.on(BI.GlobalStyleSetting.EVENT_SAVE,function(){BI.Layers.hide(BICst.GLOBAL_STYLE_LAYER);var d=this.getValue();a=d;b.fireEvent(BI.GlobalStyle.EVENT_SET,d)});BI.createWidget({type:"bi.absolute",element:c,items:[{el:this.globalStyleSetting,top:40,left:140,bottom:10}]})}else{BI.Layers.show(BICst.GLOBAL_STYLE_LAYER);this.globalStyleSetting.populate()}},getValue:function(){return this.globalStyleSetting.getValue()},populate:function(){var a=BI.Utils.getActualGlobalStyle();
this.manager.setThemeStyle(a);this.manager.setGlobalStyle(a)}});BI.GlobalStyle.EVENT_SET="EVENT_SET";BI.GlobalStyle.EVENT_CHART_CHANGE="EVENT_CHART";BI.shortcut("bi.global_style",BI.GlobalStyle);
BI.GlobalStyleSetting=BI.inherit(BI.Widget,{_const:{BUTTON_WIDTH:40,BUTTON_HEIGHT:30,ICON_WIDTH:24,ICON_HEIGHT:24,HEIGHT:30},_defaultConfig:function(){return BI.extend(BI.GlobalStyleSetting.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-global-style-setting bi-card",width:420})},_init:function(){BI.GlobalStyleSetting.superclass._init.apply(this,arguments);var a=this;this.data={};var c=BI.createWidget({type:"bi.button",level:"ignore",text:BI.i18nText("BI-Basic_Cancel"),height:this._const.HEIGHT,width:90});
c.on(BI.Button.EVENT_CHANGE,function(){a.fireEvent(BI.GlobalStyleSetting.EVENT_CANCEL)});var b=BI.createWidget({type:"bi.button",text:BI.i18nText("BI-Basic_Sure"),height:this._const.HEIGHT,width:90});b.on(BI.Button.EVENT_CHANGE,function(){a.fireEvent(BI.GlobalStyleSetting.EVENT_SAVE)});this.predictionStyle=BI.createWidget({type:"bi.global_style_index_prediction_style"});this.predictionStyle.on(BI.GlobalStyleIndexPredictionStyle.EVENT_CHANGE,function(){a.data.predictionStyle=this.getValue();a._setValue(this.getSelectedStyle());
a.fireEvent(BI.GlobalStyleSetting.EVENT_CHANGE)});this.predictionStyle.on(BI.GlobalStyleIndexPredictionStyle.EVENT_DELETE,function(){a.data.predictionStyle=this.getValue();a._checkPredictionBtn();a.fireEvent(BI.GlobalStyleSetting.EVENT_CHANGE)});this._initCenter();var d=BI.createWidget({type:"bi.label",text:BI.i18nText("BI-Global_Style"),height:40,lgap:20,textAlign:"left",cls:"global-style-title"});BI.createWidget({type:"bi.vtape",element:this,items:[{el:d,height:40},{el:this.predictionStyle,height:190},{el:this.centerItems},{el:{type:"bi.left_right_vertical_adapt",items:{left:[c],right:[b]},llgap:20,rrgap:20,height:60},height:60}]});
this.element.draggable({handle:d.element,axis:"x",stop:function(e,f){if(f.position.left<0){a.element.css("left",0)}else{if(f.position.left>$("body").width()-a.element.width()){a.element.css("left",$("body").width()-a.element.width()+"px")}}}})},_initCenter:function(){var i=this;this.data.theme=BICst.THEME_DEFAULT;this.savePredictionBtn=BI.createWidget({type:"bi.text_button",text:BI.i18nText("BI-Save_As_Prediction_Style"),warningTitle:BI.i18nText("BI-Number_Limit"),textAlign:"right",height:this._const.HEIGHT,width:100});
this.savePredictionBtn.on(BI.TextButton.EVENT_CHANGE,function(){i._savePrediction()});var j=BI.createWidget({type:"bi.right",cls:"global-style-item-save",items:[this.savePredictionBtn,{type:"bi.layout",height:this._const.HEIGHT}]});this.mainBackground=BI.createWidget({type:"bi.global_style_index_background"});this.mainBackground.on(BI.GlobalStyleIndexBackground.EVENT_CHANGE,function(){i.data.mainBackground=this.getValue();i.fireEvent(BI.GlobalStyleSetting.EVENT_CHANGE)});var h=BI.createWidget({type:"bi.left",cls:"global-style-wrapper-bottom bi-border-bottom",items:[{type:"bi.label",cls:"global-style-item-label",text:BI.i18nText("BI-Background_Colour")+":",textAlign:"left",height:this._const.HEIGHT,width:95},i.mainBackground],vgap:10});
this.widgetBackground=BI.createWidget({type:"bi.global_style_index_background"});this.widgetBackground.on(BI.GlobalStyleIndexBackground.EVENT_CHANGE,function(){i.data.widgetBackground=this.getValue();i.fireEvent(BI.GlobalStyleSetting.EVENT_CHANGE)});var e=this._createComboWrapper(BI.i18nText("BI-Widget_Background_Colour"),this.widgetBackground);this.titleColour=BI.createWidget({type:"bi.global_style_index_background"});this.titleColour.on(BI.GlobalStyleIndexBackground.EVENT_CHANGE,function(){i.data.titleBackground=this.getValue();
i.fireEvent(BI.GlobalStyleSetting.EVENT_CHANGE)});var a=this._createComboWrapper(BI.i18nText("BI-Title_Colour"),this.titleColour);this.titleWordStyle=BI.createWidget({type:"bi.global_style_index_title_tool_bar",cls:"global-style-border bi-border"});this.titleWordStyle.on(BI.GlobalStyleIndexTitleToolBar.EVENT_CHANGE,function(){i.data.titleFont=this.getValue();i.fireEvent(BI.GlobalStyleSetting.EVENT_CHANGE)});var c=this._createWrapper(BI.i18nText("BI-Title_Word_Style"),this.titleWordStyle);this.chartStyle=BI.createWidget({type:"bi.button_group",items:BI.createItems(BICst.AXIS_STYLE_GROUP,{type:"bi.icon_button",extraCls:"global-style-chart-style-font bi-list-item-active bi-list-item-border",width:this._const.BUTTON_WIDTH,height:this._const.BUTTON_HEIGHT,iconWidth:this._const.ICON_WIDTH,iconHeight:this._const.ICON_HEIGHT}),layouts:[{type:"bi.vertical_adapt",height:this._const.HEIGHT}]});
this.chartStyle.on(BI.ButtonGroup.EVENT_CHANGE,function(){i.data.chartStyle=this.getValue()[0];i.fireEvent(BI.GlobalStyleSetting.EVENT_CHANGE)});var d=this._createWrapper(BI.i18nText("BI-Chart_Style"),this.chartStyle);this.chartColour=BI.createWidget({type:"bi.chart_setting_select_color_combo",height:this._const.HEIGHT});this.chartColour.on(BI.ChartSettingSelectColorCombo.EVENT_CHANGE,function(){i.data.chartColor=this.getValue()[0];i.fireEvent(BI.GlobalStyleSetting.EVENT_CHANGE)});this.chartColour.populate();
var f=this._createWrapper(BI.i18nText("BI-Chart_Colour"),this.chartColour);this.chartWordStyle=BI.createWidget({type:"bi.global_style_index_chart_tool_bar",cls:"global-style-border bi-border"});this.chartWordStyle.on(BI.GlobalStyleIndexChartToolBar.EVENT_CHANGE,function(){i.data.chartFont=this.getValue();i.fireEvent(BI.GlobalStyleSetting.EVENT_CHANGE)});var g=BI.createWidget({type:"bi.left",cls:"global-style-wrapper-bottom bi-border-bottom",items:[{type:"bi.label",cls:"global-style-item-label",text:BI.i18nText("BI-Chart_Word_Style")+":",textAlign:"left",height:this._const.HEIGHT,width:100},this.chartWordStyle],vgap:10});
this.controlTheme=BI.createWidget({type:"bi.color_chooser",height:this._const.HEIGHT,width:160});this.controlTheme.on(BI.ColorChooser.EVENT_CHANGE,function(){i.data.controlTheme=this.getValue();i.fireEvent(BI.GlobalStyleSetting.EVENT_CHANGE)});var b=BI.createWidget({type:"bi.left",cls:"global-style-wrapper-bottom bi-border-bottom",items:[{type:"bi.label",cls:"global-style-item-label",text:BI.i18nText("BI-Control_Theme")+":",textAlign:"left",height:this._const.HEIGHT,width:100},this.controlTheme],vgap:10});
this.centerItems=BI.createWidget({type:"bi.vertical",items:[j,h,e,a,c,d,f,g,b],hgap:20})},_createComboWrapper:function(a,b){return{type:"bi.left",items:[{type:"bi.label",cls:"global-style-item-label",text:a+":",textAlign:"left",height:this._const.HEIGHT,width:95},b],vgap:10}},_createWrapper:function(a,b){return{type:"bi.left",items:[{type:"bi.label",cls:"global-style-item-label",text:a+":",textAlign:"left",height:this._const.HEIGHT,width:100},b],vgap:10}},_savePrediction:function(){var a=this.getValue();
delete a.predictionStyle;if(this.predictionStyle.addStyle(a)){this._checkPredictionBtn();this.data.predictionStyle=this.predictionStyle.getValue();this.fireEvent(BI.GlobalStyleSetting.EVENT_CHANGE)}},_checkPredictionBtn:function(){this.savePredictionBtn.setEnable(this.predictionStyle.canAddMoreStyles())},_setValue:function(a){var b=BI.Utils.getDefaultChartConfig();this.theme=a.theme||BICst.THEME_DEFAULT;this.data.theme=a.theme||BICst.THEME_DEFAULT;this.mainBackground.setValue(a.mainBackground||b.mainBackground);
this.data.mainBackground=a.mainBackground;this.widgetBackground.setValue(a.widgetBackground||b.widgetBackground);this.data.widgetBackground=a.widgetBackground;this.titleColour.setValue(a.titleBackground||b.titleBackground);this.data.titleBackground=a.titleBackground;this.titleWordStyle.setValue(a.titleFont||b.titleFont);this.data.titleFont=a.titleFont;this.chartStyle.setValue(a.chartStyle||a.chartStyle||1);this.data.chartStyle=a.chartStyle;this.chartColour.setValue(a.chartColor||BI.Utils.getDefaultChartColor());
this.data.chartColor=a.chartColor;this.chartWordStyle.setValue(a.chartFont||b.chartFont);this.data.chartFont=a.chartFont;this.controlTheme.setValue(a.controlTheme||b.controlTheme);this.data.controlTheme=a.controlTheme},getValue:function(){return BI.deepClone(this.data)},populate:function(){var a=BI.Utils.getGlobalStyle();this.data=a;this.predictionStyle.populate();this._checkPredictionBtn();this._setValue(a)}});BI.GlobalStyleSetting.EVENT_CHANGE="EVENT_CHANGE";BI.GlobalStyleSetting.EVENT_CANCEL="EVENT_CANCEL";
BI.GlobalStyleSetting.EVENT_SAVE="EVENT_SAVE";BI.shortcut("bi.global_style_setting",BI.GlobalStyleSetting);
BI.GlobalStyleIndexBackground=BI.inherit(BI.Widget,{_constant:{},_defaultConfig:function(){return BI.extend(BI.GlobalStyleIndexBackground.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-global-style-indexcombo"})},_init:function(){BI.GlobalStyleIndexBackground.superclass._init.apply(this,arguments);var a=this,b=this.options||{};this.data={};this.combo=BI.createWidget({type:"bi.text_value_combo",width:120,height:b.height||30,text:BI.i18nText("BI-Basic_Colors"),items:[{text:BI.i18nText("BI-Basic_Colors"),value:BICst.BACKGROUND_TYPE.COLOR},{text:BI.i18nText("BI-Basic_Pictures"),value:BICst.BACKGROUND_TYPE.IMAGE}]});
this.combo.on(BI.TextValueCombo.EVENT_CHANGE,function(){a.tab.setSelect(this.getValue()[0]);a.data.type=this.getValue()[0];a.data.value=a.tab.getValue();a.fireEvent(BI.GlobalStyleIndexBackground.EVENT_CHANGE)});this.tab=BI.createWidget({type:"bi.tab",cardCreator:function(d){switch(d){case BICst.BACKGROUND_TYPE.COLOR:var c=BI.createWidget({type:"bi.color_chooser",height:b.height||30,width:b.height||30});c.on(BI.ColorChooser.EVENT_CHANGE,function(){a.data.type=a.combo.getValue()[0];a.data.value=a.tab.getValue();
a.fireEvent(BI.GlobalStyleIndexBackground.EVENT_CHANGE)});return c;case BICst.BACKGROUND_TYPE.IMAGE:var e=BI.createWidget({type:"bi.upload_image_preview"});e.on(BI.UploadImagePreview.EVENT_CHANGE,function(){a.data.type=a.combo.getValue()[0];a.data.value=a.tab.getValue();a.fireEvent(BI.GlobalStyleIndexBackground.EVENT_CHANGE)});return e}}});BI.createWidget({type:"bi.left",width:150,cls:"bi-global-style-indexcombo",element:this,items:[this.combo,this.tab],hgap:5})},getValue:function(){return this.data
},setValue:function(a){a||(a={});this.data=a;this.combo.setValue(a.type||BICst.BACKGROUND_TYPE.COLOR);this.tab.setSelect(a.type||BICst.BACKGROUND_TYPE.COLOR);this.tab.setValue(a.value||"")}});BI.GlobalStyleIndexBackground.EVENT_CHANGE="EVENT_CHANGE";BI.shortcut("bi.global_style_index_background",BI.GlobalStyleIndexBackground);
BI.GlobalStyleIndexTitleToolBar=BI.inherit(BI.Widget,{_defaultConfig:function(){return BI.extend(BI.GlobalStyleIndexTitleToolBar.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-global-style-title-toolbar bi-card"})},_init:function(){BI.GlobalStyleIndexTitleToolBar.superclass._init.apply(this,arguments);var a=this;this.data={};this.bold=BI.createWidget({type:"bi.icon_button",title:BI.i18nText("BI-Basic_Bold"),height:20,width:20,cls:"text-toolbar-button bi-list-item-active text-bold-font"});
this.bold.on(BI.IconButton.EVENT_CHANGE,function(){a.data.fontWeight=a.bold.isSelected()?"bold":"normal";a.fireEvent(BI.GlobalStyleIndexTitleToolBar.EVENT_CHANGE)});this.italic=BI.createWidget({type:"bi.icon_button",title:BI.i18nText("BI-Basic_Italic"),height:20,width:20,cls:"text-toolbar-button bi-list-item-active text-italic-font"});this.italic.on(BI.IconButton.EVENT_CHANGE,function(){a.data.fontStyle=a.italic.isSelected()?"italic":"normal";a.fireEvent(BI.GlobalStyleIndexTitleToolBar.EVENT_CHANGE)
});this.alignChooser=BI.createWidget({type:"bi.global_style_index_align_chooser",cls:"text-toolbar-button"});this.alignChooser.on(BI.GlobalStyleIndexAlignChooser.EVENT_CHANGE,function(){a.data.textAlign=a.alignChooser.getValue();a.fireEvent(BI.GlobalStyleIndexTitleToolBar.EVENT_CHANGE)});this.colorchooser=BI.createWidget({type:"bi.color_chooser",el:{type:"bi.text_toolbar_color_chooser_trigger",title:BI.i18nText("BI-Font_Colour"),cls:"text-toolbar-button"}});this.colorchooser.on(BI.ColorChooser.EVENT_CHANGE,function(){a.data.color=a.colorchooser.getValue();
a.fireEvent(BI.GlobalStyleIndexTitleToolBar.EVENT_CHANGE)});BI.createWidget({type:"bi.left",element:this,items:[this.bold,this.italic,this.alignChooser,this.colorchooser],hgap:3,vgap:3})},getValue:function(){return this.data},setValue:function(a){a||(a={});this.data=a;this.bold.setSelected(a["fontWeight"]==="bold");this.italic.setSelected(a["fontStyle"]==="italic");this.alignChooser.setValue(a["textAlign"]||"left");this.colorchooser.setValue(a["color"]||"")}});BI.GlobalStyleIndexTitleToolBar.EVENT_CHANGE="EVENT_CHANGE";
BI.shortcut("bi.global_style_index_title_tool_bar",BI.GlobalStyleIndexTitleToolBar);
BI.GlobalStyleIndexChartToolBar=BI.inherit(BI.Widget,{_defaultConfig:function(){return BI.extend(BI.GlobalStyleIndexChartToolBar.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-global-style-title-toolbar bi-card"})},_init:function(){BI.GlobalStyleIndexChartToolBar.superclass._init.apply(this,arguments);var a=this;this.data={};this.bold=BI.createWidget({type:"bi.icon_button",title:BI.i18nText("BI-Basic_Bold"),height:20,width:20,cls:"text-toolbar-button bi-list-item-active text-bold-font"});
this.bold.on(BI.IconButton.EVENT_CHANGE,function(){a.data.fontWeight=a.bold.isSelected()?"bold":"normal";a.fireEvent(BI.GlobalStyleIndexChartToolBar.EVENT_CHANGE)});this.italic=BI.createWidget({type:"bi.icon_button",title:BI.i18nText("BI-Basic_Italic"),height:20,width:20,cls:"text-toolbar-button bi-list-item-active text-italic-font"});this.italic.on(BI.IconButton.EVENT_CHANGE,function(){a.data.fontStyle=a.italic.isSelected()?"italic":"normal";a.fireEvent(BI.GlobalStyleIndexChartToolBar.EVENT_CHANGE)
});this.colorchooser=BI.createWidget({type:"bi.color_chooser",el:{type:"bi.text_toolbar_color_chooser_trigger",title:BI.i18nText("BI-Font_Colour"),cls:"text-toolbar-button"}});this.colorchooser.on(BI.ColorChooser.EVENT_CHANGE,function(){a.data.color=a.colorchooser.getValue();a.fireEvent(BI.GlobalStyleIndexChartToolBar.EVENT_CHANGE)});BI.createWidget({type:"bi.left",element:this,items:[this.bold,this.italic,this.colorchooser],hgap:3,vgap:3})},getValue:function(){return this.data},setValue:function(a){a||(a={});
this.data=a;this.bold.setSelected(a["fontWeight"]==="bold");this.italic.setSelected(a["fontStyle"]==="italic");this.colorchooser.setValue(a["color"]||"")}});BI.GlobalStyleIndexChartToolBar.EVENT_CHANGE="EVENT_CHANGE";BI.shortcut("bi.global_style_index_chart_tool_bar",BI.GlobalStyleIndexChartToolBar);
BI.GlobalStyleIndexAlignChooser=BI.inherit(BI.Widget,{_defaultConfig:function(){return BI.extend(BI.GlobalStyleIndexAlignChooser.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-global-style-index-align-chooser",width:40,height:20})},_init:function(){BI.GlobalStyleIndexAlignChooser.superclass._init.apply(this,arguments);var a=this,b=this.options;this.button_group=BI.createWidget({type:"bi.button_group",element:this,items:BI.createItems([{cls:"align-chooser-button bi-list-item-active text-align-left-font",title:BI.i18nText("BI-Position_Left"),selected:true,value:"left"},{cls:"align-chooser-button text-align-center-font bi-list-item-active",title:BI.i18nText("BI-Position_Center"),value:"center"}],{type:"bi.icon_button",height:b.height}),layouts:[{type:"bi.center"}]});
this.button_group.on(BI.Controller.EVENT_CHANGE,function(){a.fireEvent(BI.Controller.EVENT_CHANGE,arguments)});this.button_group.on(BI.ButtonGroup.EVENT_CHANGE,function(){a.fireEvent(BI.GlobalStyleIndexAlignChooser.EVENT_CHANGE,arguments)})},setValue:function(a){this.button_group.setValue(a)},getValue:function(){return this.button_group.getValue()[0]}});BI.GlobalStyleIndexAlignChooser.EVENT_CHANGE="BI.GlobalStyleIndexAlignChooser.EVENT_CHANGE";BI.shortcut("bi.global_style_index_align_chooser",BI.GlobalStyleIndexAlignChooser);
BI.GlobalStyleIndexPredictionStyle=BI.inherit(BI.Widget,{_const:{pageCount:6},_defaultConfig:function(){return BI.extend(BI.GlobalStyleIndexPredictionStyle.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-global-style-index-prediction-style bi-background"})},_init:function(){BI.GlobalStyleIndexPredictionStyle.superclass._init.apply(this,arguments);var c=this.options,b=this;this.allCustomStyles=[];this.currentPage=1;this.leftButton=BI.createWidget({type:"bi.icon_button",cls:"page-left-font",height:26,width:14});
this.leftButton.on(BI.IconButton.EVENT_CHANGE,function(){b._setPage(b.currentPage-1);b._populate(b.allCustomStyles)});this.rightButton=BI.createWidget({type:"bi.icon_button",cls:"page-right-font",height:26,width:14});this.rightButton.on(BI.IconButton.EVENT_CHANGE,function(){b._setPage(b.currentPage+1);b._populate(b.allCustomStyles)});this.pagination=BI.createWidget({type:"bi.global_style_pagination"});this.pagination.on(BI.GlobalStylePagination.EVENT_CHANGE,function(){b._setPage(this.getValue());
b._populate(b.allCustomStyles)});this.centerButtonGroup=BI.createWidget({type:"bi.button_group",items:[],layouts:[{type:"bi.left",lgap:5,rgap:5,tgap:5,bgap:5}]});this.centerButtonGroup.on(BI.ButtonGroup.EVENT_CHANGE,function(d){b.fireEvent(BI.GlobalStyleIndexPredictionStyle.EVENT_CHANGE)});var a=BI.createWidget({type:"bi.htape",items:[{el:{type:"bi.center_adapt",items:[this.leftButton]},width:29},{el:this.centerButtonGroup},{el:{type:"bi.center_adapt",items:[this.rightButton]},width:29}]});BI.createWidget({type:"bi.vtape",element:this,items:[{el:{type:"bi.layout"},height:9},{el:a},{el:this.pagination,height:20}]})
},_createUserCustomStyleButton:function(c){var a=this;var b=BI.createWidget({type:"bi.global_style_user_custom_button",cls:"button-shadow",text:c.name,value:c.style,cannotDelete:c.cannotDelete});b.on(BI.GlobalStyleUserCustomButton.EVENT_DELETE,function(){a._removeStyle(this.getValue());a.fireEvent(BI.GlobalStyleIndexPredictionStyle.EVENT_DELETE)});return b},canAddMoreStyles:function(){return this.allCustomStyles.length<5},addStyle:function(a){if(this.canAddMoreStyles()&&!BI.deepContains(this.allCustomStyles,a)&&!BI.deepContains(BICst.GLOBAL_PREDICTION_STYLE,a)){if((this.allCustomStyles.length+BI.size(BICst.GLOBAL_PREDICTION_STYLE))%this._const.pageCount===0){this.currentPage++
}this.allCustomStyles.push(a);this._populate(this.allCustomStyles);return true}return false},_removeStyle:function(a){if(BI.deepRemove(this.allCustomStyles,a)){if((this.allCustomStyles.length+BI.size(BICst.GLOBAL_PREDICTION_STYLE))%this._const.pageCount===0){this.currentPage--;if(this.currentPage<1){this.currentPage=1}}this._populate(this.allCustomStyles)}},getSelectedStyle:function(){return this.centerButtonGroup.getValue()[0]},getValue:function(){return this.allCustomStyles},_setPage:function(a){this.currentPage=a
},populate:function(){this._setPage(1);var a=BI.Utils.getGlobalStyle();this.allCustomStyles=a.predictionStyle||[];this._populate(this.allCustomStyles)},_populate:function(b){var a=this;var c=[];BI.each(BICst.GLOBAL_PREDICTION_STYLE,function(d,e){c.push({name:BI.i18nText("BI-Prediction_Style")+(c.length+1),style:e,cannotDelete:true})});c=c.concat(BI.map(b||[],function(d,e){return{name:BI.i18nText("BI-Custom_Style")+(d+1),style:e}}));this.centerButtonGroup.populate(BI.map(c.slice((this.currentPage-1)*this._const.pageCount,this.currentPage*this._const.pageCount),function(d,e){return a._createUserCustomStyleButton(e)
}));this.leftButton.setEnable(this.currentPage>1);this.rightButton.setEnable(c.length>this.currentPage*this._const.pageCount);this.pagination.populate(this.allCustomStyles);this.pagination.setValue(this.currentPage)}});BI.GlobalStyleIndexPredictionStyle.EVENT_DELETE="BI.GlobalStyleIndexPredictionStyle.EVENT_DELETE";BI.GlobalStyleIndexPredictionStyle.EVENT_CHANGE="BI.GlobalStyleIndexPredictionStyle.EVENT_CHANGE";BI.shortcut("bi.global_style_index_prediction_style",BI.GlobalStyleIndexPredictionStyle);
BI.GlobalStyleUserCustomButton=BI.inherit(BI.BasicButton,{_defaultConfig:function(){var a=BI.GlobalStyleUserCustomButton.superclass._defaultConfig.apply(this,arguments);return BI.extend(a,{baseCls:a.baseCls+" bi-global-style-user-custom-button",text:"",selected:false,once:false,value:null,cannotDelete:false})},_init:function(){BI.GlobalStyleUserCustomButton.superclass._init.apply(this,arguments);var b=this.options;var a=this;this.button=BI.createWidget({type:"bi.global_style_style_button",title:b.text,value:b.value});
this.deleteCombo=BI.createWidget({type:"bi.bubble_combo",el:{type:"bi.icon_button",cls:"close-red-font"},popup:{type:"bi.bubble_bar_popup_view",buttons:[{value:BI.i18nText(BI.i18nText("BI-Basic_Sure")),handler:function(){a.deleteCombo.hideView();a.fireEvent(BI.GlobalStyleUserCustomButton.EVENT_DELETE)}},{value:BI.i18nText("BI-Basic_Cancel"),level:"ignore",handler:function(){a.deleteCombo.hideView()}}],el:{type:"bi.vertical_adapt",items:[{type:"bi.label",text:BI.i18nText("BI-Confirm_To_Delete_Style"),cls:"package-delete-label",textAlign:"left",width:300}],width:300,height:100,hgap:20},maxHeight:140,minWidth:340},invisible:true,stopPropagation:true});
this.widget=BI.createWidget({type:"bi.absolute",element:this,items:[{el:this.button},{el:this.deleteCombo}],height:70,width:110,rgap:0,tgap:0});this.deleteCombo.setVisible(false);if(!this.options.cannotDelete){this.widget.element.hover(function(){a.deleteCombo.setVisible(true)},function(){a.deleteCombo.setVisible(false)})}},getValue:function(){return BI.deepClone(this.button.getValue())},setValue:function(a){this.button.setValue(a)},doClick:function(){BI.GlobalStyleUserCustomButton.superclass.doClick.apply(this,arguments);
if(this.isValid()){this.fireEvent(BI.GlobalStyleUserCustomButton.EVENT_CHANGE)}}});BI.GlobalStyleUserCustomButton.EVENT_CHANGE="BI.GlobalStyleUserCustomButton.EVENT_CHANGE";BI.GlobalStyleUserCustomButton.EVENT_DELETE="BI.GlobalStyleUserCustomButton.EVENT_DELETE";BI.shortcut("bi.global_style_user_custom_button",BI.GlobalStyleUserCustomButton);
BI.GlobalStyleStyleButton=BI.inherit(BI.Single,{_defaultConfig:function(){var a=BI.GlobalStyleStyleButton.superclass._defaultConfig.apply(this,arguments);return BI.extend(a,{baseCls:(a.baseCls||""),value:{}})},_init:function(){BI.GlobalStyleStyleButton.superclass._init.apply(this,arguments);var f=this.options;var n=this._createLayout(70,110);var b=this._createLayout(50,90);var l=this._createLayout(10,90);var a=this._createLayout(6,40);var j=this._createLayout(6,70);var d=this._createLayout(6,50);
var r={type:1,value:"#EFF1F4"};var c={type:1,value:"#ffffff"};var q={type:1,value:"#ffffff"};if(f.value.theme===BICst.THEME_DARK){r={type:1,value:"#191B2B"};c={type:1,value:"#242640"};q={type:1,value:"#242640"}}var h=f.value.mainBackground||r;var e=f.value.widgetBackground||c;var p=f.value.titleBackground||q;var m=f.value.chartColor||BI.Utils.getDefaultChartColor();var i=(h.type===1&&BI.isNotEmptyString(h.value))?h.value:r.value;var g=(e.type===1&&BI.isNotEmptyString(e.value))?e.value:c.value;var k=(p.type===1&&BI.isNotEmptyString(p.value))?p.value:q.value;
n.element.css("background-color",i);b.element.css("background-color",g);l.element.css("background-color",k);a.element.css("background-color",m[0]);j.element.css("background-color",m[1]);d.element.css("background-color",m[2]);BI.createWidget({type:"bi.absolute",element:this,items:[this._createItem(n,0,0),this._createItem(b,10,10),this._createItem(l,10,10),this._createItem(a,27,20),this._createItem(j,37,20),this._createItem(d,47,20)],height:70,width:110})},_createItem:function(a,c,b){return{el:a,top:c,left:b}
},_createLayout:function(a,b){return BI.createWidget({type:"bi.layout",height:a,width:b})}});BI.GlobalStyleStyleButton.EVENT_CHANGE="BI.GlobalStyleStyleButton.EVENT_CHANGE";BI.shortcut("bi.global_style_style_button",BI.GlobalStyleStyleButton);
BI.GlobalStylePaginationIcon=BI.inherit(BI.BasicButton,{_defaultConfig:function(){return BI.extend(BI.GlobalStylePaginationIcon.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-global-style-pagination-icon",forceSelected:true,width:20,height:20})},_init:function(){BI.GlobalStylePaginationIcon.superclass._init.apply(this,arguments);var a=this;this.icon=BI.createWidget({type:"bi.icon_button",cls:"page-pagination-font",element:this})},doClick:function(){BI.GlobalStylePaginationIcon.superclass.doClick.apply(this,arguments);
if(this.isValid()){this.fireEvent(BI.GlobalStylePaginationIcon.EVENT_CHANGE)}}});BI.GlobalStylePaginationIcon.EVENT_CHANGE="BI.GlobalStylePaginationIcon.EVENT_CHANGE";BI.shortcut("bi.global_style_pagination_icon",BI.GlobalStylePaginationIcon);
BI.GlobalStylePagination=BI.inherit(BI.Widget,{_const:{pageCount:6},_defaultConfig:function(){return BI.extend(BI.GlobalStylePagination.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-global-style-pagination"})},_init:function(){BI.GlobalStylePagination.superclass._init.apply(this,arguments);var a=this;this.button_group=BI.createWidget({type:"bi.button_group",element:this,items:[],layouts:[{type:"bi.float_center_adapt",items:[{type:"bi.horizontal"}]}]});this.button_group.on(BI.ButtonGroup.EVENT_CHANGE,function(){a.fireEvent(BI.GlobalStylePagination.EVENT_CHANGE)
})},getValue:function(){return this.button_group.getValue()[0]},setValue:function(a){this.button_group.setValue(a)},populate:function(d){var c=[];var a=Math.floor((d.length+BI.size(BICst.GLOBAL_PREDICTION_STYLE)-1)/this._const.pageCount);for(var b=0;b<a+1;b++){c.push({type:"bi.global_style_pagination_icon",value:b+1})}this.button_group.populate(c)}});BI.GlobalStylePagination.EVENT_CHANGE="BI.GlobalStylePagination.EVENT_CHANGE";BI.shortcut("bi.global_style_pagination",BI.GlobalStylePagination);
BI.UploadImagePreview=BI.inherit(BI.Widget,{_defaultConfig:function(){return BI.extend(BI.UploadImagePreview.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-upload-image-preview"})},_init:function(){BI.UploadImagePreview.superclass._init.apply(this,arguments);var a=this;this.tab=BI.createWidget({type:"bi.tab",element:this,cardCreator:function(b){switch(b){case BI.UploadImagePreview.TO_UPLOAD:var c=BI.createWidget({type:"bi.multifile_editor",title:BI.i18nText("BI-Upload_Image"),accept:"*.jpg;*.png;*.gif;*.bmp;*.jpeg;",maxSize:1024*1024*100,width:30,height:30});
a._bindUploadEvents(c);return BI.createWidget({type:"bi.absolute",items:[{el:{type:"bi.icon_button",cls:"upload-image-button img-global-style-upload-font",width:30,height:30}},{el:c,top:0},{el:{type:"bi.label",text:".jpg/.png/.gif/.bmp",cls:"support-files bi-tips",height:25},top:10,left:40}],width:30,height:30});case BI.UploadImagePreview.UPLOADED:a.previewArea=BI.createWidget({type:"bi.layout",cls:"preview-area",width:30,height:30});var e=BI.createWidget({type:"bi.multifile_editor",accept:"*.jpg;*.png;*.gif;*.bmp;*.jpeg;",maxSize:1024*1024*100,width:30,height:30});
a._bindUploadEvents(e);var d=BI.createWidget({type:"bi.text_button",text:BI.i18nText("BI-Basic_Delete"),cls:"remove-button",height:25});d.on(BI.TextButton.EVENT_CHANGE,function(){a._removeFile()});return BI.createWidget({type:"bi.absolute",items:[{el:a.previewArea,top:0,left:0},{el:{type:"bi.label",text:BI.i18nText("BI-Basic_Modify"),height:25,cls:"modify-button"},top:-5,left:40},{el:e,top:-5,left:40},{el:d,top:-5,left:120},{el:{type:"bi.label",text:".jpg/.png/.gif/.bmp",cls:"support-files bi-tips",height:25},top:10,left:40}]})
}}});this.tab.setSelect(BI.UploadImagePreview.TO_UPLOAD)},_bindUploadEvents:function(b){var a=this;b.on(BI.MultifileEditor.EVENT_CHANGE,function(){this.upload()});b.on(BI.MultifileEditor.EVENT_UPLOADED,function(){var d=this.getValue();var c=d[d.length-1];a.attachId=c.attach_id;BI.requestAsync("fr_bi_base","save_upload_image",{attach_id:a.attachId},function(){a.tab.setSelect(BI.UploadImagePreview.UPLOADED);a.imageId=a.attachId;a.previewArea.element.css({background:"url("+BI.Func.getCompleteImageUrl(a.imageId)+")",backgroundSize:"100% 100%"});
a.fireEvent(BI.UploadImagePreview.EVENT_CHANGE)})})},_removeFile:function(){this.imageId="";this.tab.setSelect(BI.UploadImagePreview.TO_UPLOAD);this.fireEvent(BI.UploadImagePreview.EVENT_CHANGE)},getValue:function(){return this.imageId},setValue:function(a){if(BI.isNotNull(a)&&(a!=="")){this.imageId=a;this.tab.setSelect(BI.UploadImagePreview.UPLOADED);this.previewArea.element.css({background:"url("+BI.Func.getCompleteImageUrl(a)+")",backgroundSize:"100% 100%"})}else{this.tab.setSelect(BI.UploadImagePreview.TO_UPLOAD)
}}});BI.extend(BI.UploadImagePreview,{TO_UPLOAD:1,UPLOADED:2});BI.UploadImagePreview.EVENT_CHANGE="BI.UploadImagePreview.EVENT_CHANGE";BI.shortcut("bi.upload_image_preview",BI.UploadImagePreview);
BI.StyleSetManager=BI.inherit(BI.OB,{constant:{GLOBAL_STYLE:"__global_style__"},_init:function(){BI.StyleSetManager.superclass._init.apply(this,arguments)},_isColor:function(a){return a===""||BI.DOM.isColor(a)||a==="transparent"},_getBackgroundValue:function(a,b){if(!a[b]){return""}switch(a[b].type){case BICst.BACKGROUND_TYPE.COLOR:return a[b].value;case BICst.BACKGROUND_TYPE.IMAGE:if(a[b]["value"]){return"url("+BI.Func.getCompleteImageUrl(a[b]["value"])+")"}return"transparent"}return""},setStyle:function(c,b){var a="";
BI.each(b,function(d,e){a+=d+"{";BI.each(e,function(f,g){a+=f+":"+g+";"});a+="} "});BI.StyleLoaders.removeStyle(c).loadStyle(c,a)},setThemeStyle:function(a){a=a||{};$("html").removeClass(BICst.THEME_DEFAULT).removeClass(BICst.THEME_DARK);switch(a.theme){case BICst.THEME_DARK:$("html").addClass(BICst.THEME_DARK);break;default:$("html").addClass(BICst.THEME_DEFAULT);break}},setGlobalStyle:function(f){f||(f={});var i=BI.Utils.getDefaultChartConfig();var c=this._getBackgroundValue(f,"mainBackground");
var k;var b=c,j;if(BI.DOM.isHexColor(c)){j=k=BI.DOM.getContrastColor(c)}else{if(c===""){b=this._getBackgroundValue(i,"mainBackground");if(BI.DOM.isHexColor(b)){j=BI.DOM.getContrastColor(b)}else{if(f.theme===BICst.THEME_DARK){b="#191B2B";j=BI.DOM.getContrastColor(b)}else{b="#eff1f4";j=BI.DOM.getContrastColor(b)}}}else{if(c==="transparent"){if(f.theme===BICst.THEME_DARK){b="#191B2B";j=BI.DOM.getContrastColor(b)}else{b="#eff1f4";j=BI.DOM.getContrastColor(b)}}}}var q=this._getBackgroundValue(f,"widgetBackground");
var t;var m=q,d;if(BI.DOM.isHexColor(q)){d=t=BI.DOM.getContrastColor(q)}else{if(q===""){m=this._getBackgroundValue(i,"widgetBackground");if(BI.DOM.isHexColor(m)){d=BI.DOM.getContrastColor(m)}else{if(m===""){if(f.theme===BICst.THEME_DARK){m="#242640";d=BI.DOM.getContrastColor(m)}else{m="#ffffff";d=BI.DOM.getContrastColor(m)}}else{if(m==="transparent"){m=this._isColor(b)?b:"transparent";d=j}}}}else{if(q==="transparent"){m=this._isColor(b)?b:"transparent";d=j}}}var o=this._getBackgroundValue(f,"titleBackground");
var n;var s=o,h;if(BI.DOM.isHexColor(o)){h=n=BI.DOM.getContrastColor(o)}else{if(o===""){s=this._getBackgroundValue(i,"titleBackground");if(BI.DOM.isHexColor(s)){h=BI.DOM.getContrastColor(s)}else{if(s===""){if(f.theme===BICst.THEME_DARK){s="#242640";h=BI.DOM.getContrastColor(s)}else{s="#ffffff";h=BI.DOM.getContrastColor(s)}}else{if(s==="transparent"){s=this._isColor(m)?m:"transparent";h=d}}}}}var l={};BI.each(f.titleFont,function(w,u){if(u){l[BI.hyphenate(w)]=u}});var a=f.controlTheme||i.controlTheme;
var e=BI.DOM.hex2rgb(a);var r=BI.DOM.rgb2json(e);r.a=0.05;var g=BI.DOM.json2rgba(r);var p=BI.extend({"#body":{"background":b,"color":j},"#body .bi-dashboard-widget":{"background":m,"color":d},"#body .bi-dashboard-widget .bi-card":{"background":BI.DOM.isColor(m)?m:"","color":d},"#body .bi-dashboard-widget .bi-background":{"background":BI.DOM.isColor(b)?b:"","color":j},"#body .bi-dashboard-widget .dashboard-widget-title":BI.extend({"background":s,"color":h},l),},this._fixedBackgroundColor("#body .bi-dashboard-widget",m==="transparent"?(f.theme===BICst.THEME_DARK?"#000000":"#ffffff"):m),this._fixedBackgroundColor("#body .bi-dashboard-widget .bi-background",b==="transparent"?(f.theme===BICst.THEME_DARK?"#000000":"#ffffff"):b),{"#body .bi-control-widget .bi-list-item:hover":{"background-color":g},"#body .bi-control-widget .bi-list-item-effect:hover":{"background-color":g},"#body .bi-control-widget .bi-list-item-active:hover":{"background-color":g},"#body .bi-control-widget .bi-list-item-effect:active":{"background-color":g},"#body .bi-control-widget .bi-list-item-effect.active":{"color":a},"#body .bi-control-widget .bi-list-item-active:active":{"color":a},"#body .bi-control-widget .bi-list-item-active.active":{"color":a},"#body .bi-control-widget .bi-list-item-select:hover":{"color":a,"background-color":g},"#body .bi-control-widget .bi-list-item-select:active":{"background-color":a,"color":BI.DOM.getContrastColor(a)},"#body .bi-control-widget .bi-border":{"border-color":a},"#body .bi-control-widget .bi-border-left":{"border-color":a},"#body .bi-control-widget .bi-border-right":{"border-color":a},"#body .bi-control-widget .bi-border-top":{"border-color":a},"#body .bi-control-widget .bi-border-bottom":{"border-color":a},"#body .bi-control-widget .bi-high-light":{"color":a},"#body .bi-control-widget .bi-high-light-background":{"background-color":a,"color":BI.DOM.getContrastColor(a)},"#body .bi-control-widget .bi-high-light-border":{"border-color":a},"#body .bi-control-widget .bi-button.button-common":{"border-color":a,"background-color":a,"color":BI.DOM.getContrastColor(a)},"#body .bi-control-widget .bi-button.button-common .b-font:before":{"color":BI.DOM.getContrastColor(a)},"#body .bi-control-widget .bi-button.button-common.clear,#body .bi-control-widget .bi-button.button-common.clear .b-font:before":{"color":a},});
this.setStyle(this.constant.GLOBAL_STYLE,p)},_fixedBackgroundColor:function(g,j){var b={};var k=BI.DOM.getContrastColor(j);var d,i,a,e,f;var c=BI.DOM.isDarkColor(j);if(c===true){d="#525466";i="rgba(204, 204, 204, 0.05)";e="rgba(204,204,204,0.7)";a="rgba(204, 204, 204, 0.3)";f="#666666"}else{d="#d4dadd";i="rgba(102, 102, 102, 0.05)";e="rgba(102,102,102,0.7)";a="rgba(102, 102, 102, 0.3)";f="#cccccc"}b[g+" .bi-input"]={"color":k};b[g+" .bi-textarea"]={"color":k};b[g+" .bi-border"]={"border-color":d};
b[g+" .bi-border-left"]={"border-color":d};b[g+" .bi-border-right"]={"border-color":d};b[g+" .bi-border-top"]={"border-color":d};b[g+" .bi-border-bottom"]={"border-color":d};b[g+" .scrollbar-layout-main"]={"background-color":i};b[g+" .scrollbar-layout-main-horizontal"]={"background-color":i};b[g+" .public-scrollbar-face:after"]={"background-color":a};b[g+" div::-webkit-scrollbar"]={"background-color":i};b[g+" div::-webkit-scrollbar-thumb"]={"background-color":a};b[g+" div::-webkit-scrollbar-thumb:hover"]={"background-color":e};
b[g+" .public-scrollbar-main:hover .public-scrollbar-face:after"]={"background-color":e};b[g+" .public-scrollbar-main-active .public-scrollbar-face:after"]={"background-color":e};b[g+" .public-scrollbar-face-active:after"]={"background-color":e};b[g+" .base-disabled"]={"color":f+"!important"};b[g+" .base-disabled .bi-input"]={"color":f+"!important"};b[g+" .base-disabled .bi-textarea"]={"color":f+"!important"};b[g+" .base-disabled .b-font:before"]={"color":f+"!important"};var h={"background-color":c?"rgba(255,255,255,.05)":"rgba(26,26,26,.05)","color":c?"#ffffff":"#1a1a1a"};
b[g+" .bi-list-item:hover"]=h;b[g+" .bi-list-item-effect:hover"]=h;b[g+" .bi-list-item-active:hover"]=h;b[g+" .bi-list-item-select:hover"]=h;return b}});
BI.TargetFilterPopup=BI.inherit(BI.BarPopoverSection,{_defaultConfig:function(){return BI.extend(BI.TargetFilterPopup.superclass._defaultConfig.apply(this,arguments),{extraCls:"bi-target-filter"})},_init:function(){BI.TargetFilterPopup.superclass._init.apply(this,arguments)},rebuildNorth:function(c){var b=this.options;var a=BI.Utils.getDimensionNameByID(b.dId);BI.createWidget({type:"bi.label",element:c,text:BI.i18nText("BI-Sen_Add_Filter_wei",a),height:50,textAlign:"left",lgap:10});return true},rebuildCenter:function(a){var b=this.options;
this.targetFilterPane=BI.createWidget({type:"bi.target_filter",element:a,dId:b.dId});return true},populate:function(){this.targetFilterPane.populate()},end:function(){this.fireEvent(BI.TargetFilterPopup.EVENT_CHANGE,this.targetFilterPane.getValue()[0])}});BI.TargetFilterPopup.EVENT_CHANGE="EVENT_CHANGE";BI.shortcut("bi.target_filter_popup",BI.TargetFilterPopup);
BI.DimensionFilterPopup=BI.inherit(BI.BarPopoverSection,{_defaultConfig:function(){return BI.extend(BI.DimensionFilterPopup.superclass._defaultConfig.apply(this,arguments),{width:600,height:500})},_init:function(){BI.DimensionFilterPopup.superclass._init.apply(this,arguments)},rebuildNorth:function(c){var b=this.options;var a=BI.Utils.getDimensionNameByID(b.dId);BI.createWidget({type:"bi.label",element:c,text:BI.i18nText("BI-Sen_Add_Filter_wei",a),height:50,textAlign:"left",lgap:10});return true},rebuildCenter:function(a){var b=this.options;
this.dimensionFilterPane=BI.createWidget({type:"bi.dimension_filter",element:a,dId:b.dId});return true},populate:function(){this.dimensionFilterPane.populate()},end:function(){this.fireEvent(BI.DimensionFilterPopup.EVENT_CHANGE,this.dimensionFilterPane.getValue()[0])}});BI.DimensionFilterPopup.EVENT_CHANGE="EVENT_CHANGE";BI.shortcut("bi.dimension_filter_popup",BI.DimensionFilterPopup);
BI.TargetSummaryFilterPopup=BI.inherit(BI.BarPopoverSection,{_defaultConfig:function(){return BI.extend(BI.TargetSummaryFilterPopup.superclass._defaultConfig.apply(this,arguments),{extraCls:"bi-target-summary-filter"})},_init:function(){BI.TargetSummaryFilterPopup.superclass._init.apply(this,arguments)},rebuildNorth:function(c){var b=this.options;var a=BI.Utils.getDimensionNameByID(b.dId);BI.createWidget({type:"bi.label",element:c,text:BI.i18nText("BI-Sen_Add_Filter_wei",a),height:50,textAlign:"left",lgap:10});
return true},rebuildCenter:function(a){var b=this.options;this.targetFilterPane=BI.createWidget({type:"bi.target_summary_filter",element:a,dId:b.dId});return true},populate:function(){this.targetFilterPane.populate()},end:function(){this.fireEvent(BI.TargetSummaryFilterPopup.EVENT_CHANGE,this.targetFilterPane.getValue()[0])}});BI.TargetSummaryFilterPopup.EVENT_CHANGE="EVENT_CHANGE";BI.shortcut("bi.target_summary_filter_popup",BI.TargetSummaryFilterPopup);
BI.DetailTableFilterPopup=BI.inherit(BI.BarPopoverSection,{_defaultConfig:function(){return BI.extend(BI.DetailTableFilterPopup.superclass._defaultConfig.apply(this,arguments),{extraCls:"bi-detail-table-filter"})},_init:function(){BI.DetailTableFilterPopup.superclass._init.apply(this,arguments)},rebuildNorth:function(c){var b=this.options;var a=BI.Utils.getDimensionNameByID(b.dId);BI.createWidget({type:"bi.label",element:c,text:BI.i18nText("BI-Sen_Add_Filter_wei",a),height:50,textAlign:"left",lgap:10});
return true},rebuildCenter:function(a){var b=this.options;this.targetFilterPane=BI.createWidget({type:"bi.detail_table_filter",element:a,dId:b.dId});return true},populate:function(){this.targetFilterPane.populate()},end:function(){this.fireEvent(BI.DetailTableFilterPopup.EVENT_CHANGE,this.targetFilterPane.getValue()[0])}});BI.DetailTableFilterPopup.EVENT_CHANGE="EVENT_CHANGE";BI.shortcut("bi.detail_table_filter_popup",BI.DetailTableFilterPopup);
BI.AuthorityFilterPopup=BI.inherit(BI.BarPopoverSection,{_defaultConfig:function(){return BI.extend(BI.AuthorityFilterPopup.superclass._defaultConfig.apply(this,arguments),{extraCls:"bi-authority-filter"})},_init:function(){BI.AuthorityFilterPopup.superclass._init.apply(this,arguments)},rebuildNorth:function(b){var a=this.options;BI.createWidget({type:"bi.label",element:b,text:BI.i18nText("BI-Sen_Add_Filter_wei",a.name),height:50,textAlign:"left",lgap:10});return true},rebuildCenter:function(a){this.targetFilterPane=BI.createWidget({type:"bi.authority_filter",element:a});
return true},populate:function(a){this.targetFilterPane.populate(a)},end:function(){this.fireEvent(BI.AuthorityFilterPopup.EVENT_CHANGE,this.targetFilterPane.getValue())}});BI.AuthorityFilterPopup.EVENT_CHANGE="EVENT_CHANGE";BI.shortcut("bi.authority_filter_popup",BI.AuthorityFilterPopup);
BI.TargetStringFieldFilterItem=BI.inherit(BI.AbstractFilterItem,{_constant:{LEFT_ITEMS_H_GAP:5,CONTAINER_HEIGHT:40,BUTTON_HEIGHT:30,COMBO_WIDTH:130,FIELD_NAME_BUTTON_WIDTH:110,TEXT_BUTTON_H_GAP:10,INPUT_WIDTH:238,WIDGET_WIDTH:240},_defaultConfig:function(){return BI.extend(BI.TargetStringFieldFilterItem.superclass._defaultConfig.apply(this,arguments),{extraCls:"bi-analysis-target-string-field-item",afterValueChange:BI.emptyFn})},_init:function(){BI.TargetStringFieldFilterItem.superclass._init.apply(this,arguments);
var a=this,c=this.options;var b=this._buildConditions();this.deleteButton=BI.createWidget({type:"bi.icon_button",cls:"close-h-font"});this.deleteButton.on(BI.Controller.EVENT_CHANGE,function(){a.fireEvent(BI.Controller.EVENT_CHANGE,BI.Events.DESTROY,c.id,a)});BI.createWidget({type:"bi.vertical",element:this,items:[{type:"bi.left_right_vertical_adapt",height:this._constant.CONTAINER_HEIGHT,items:{left:[b[0],b[1],b[2]],right:[this.deleteButton]},lhgap:this._constant.LEFT_ITEMS_H_GAP,rhgap:this._constant.LEFT_ITEMS_H_GAP}],scrolly:false})
},populate:function(b,a,c){this.filterType.setValue(c.filterType);this._refreshFilterWidget(c.filterType,c.filterValue)},_buildConditions:function(){var a=this,b=this.options;if(BI.isNull(b._src)){return[]}this.fieldId=b._src.fieldId;var c=BI.Utils.getTableNameByID(BI.Utils.getTableIdByFieldID(this.fieldId))+"."+BI.Utils.getFieldNameByID(this.fieldId);this.fieldButton=BI.createWidget({type:"bi.text_button",text:c,title:c,width:this._constant.FIELD_NAME_BUTTON_WIDTH,height:this._constant.BUTTON_HEIGHT,textAlign:"left",hgap:this._constant.TEXT_BUTTON_H_GAP});
this.fieldButton.on(BI.Controller.EVENT_CHANGE,function(){arguments[2]=a;a.fireEvent(BI.Controller.EVENT_CHANGE,arguments)});this.filterWidgetContainer=BI.createWidget({type:"bi.left"});this.id=b.id;this.filterType=BI.createWidget({type:"bi.text_value_down_list_combo",width:this._constant.COMBO_WIDTH,height:this._constant.BUTTON_HEIGHT,items:BICst.TARGET_FILTER_STRING_COMBO});this.filterType.setValue(b.filterType);this.filterType.on(BI.TextValueDownListCombo.EVENT_CHANGE,function(){a._refreshFilterWidget(a.filterType.getValue()[0]);
a._setNodeData({filterType:this.getValue()[0]});b.afterValueChange.apply(a,arguments)});this._refreshFilterWidget(b.filterType,b.filterValue);return[this.fieldButton,this.filterType,this.filterWidgetContainer]},_refreshFilterWidget:function(b,a){switch(b){case BICst.TARGET_FILTER_STRING.BELONG_VALUE:case BICst.TARGET_FILTER_STRING.NOT_BELONG_VALUE:this._createTargetStringBelongCombo(a);break;case BICst.TARGET_FILTER_STRING.CONTAIN:case BICst.TARGET_FILTER_STRING.NOT_CONTAIN:this._createStringInput(a);
break;case BICst.TARGET_FILTER_STRING.IS_NULL:case BICst.TARGET_FILTER_STRING.NOT_NULL:this.filterWidget=BI.createWidget();break;case BICst.TARGET_FILTER_STRING.BEGIN_WITH:case BICst.TARGET_FILTER_STRING.END_WITH:this._createStringInput(a);break}this.filterWidgetContainer.empty();this.filterWidgetContainer.addItem(this.filterWidget)},_createTargetStringBelongCombo:function(a){var b=this,c=this.options;this.filterWidget=BI.createWidget({type:"bi.select_field_data_combo",fieldId:this.fieldId,width:this._constant.WIDGET_WIDTH,height:this._constant.BUTTON_HEIGHT});
this.filterWidget.on(BI.SelectFieldDataCombo.EVENT_CONFIRM,function(){b._setNodeData({filterValue:this.getValue()});c.afterValueChange.apply(b,arguments)});BI.isNotNull(a)&&this.filterWidget.setValue(a);return this.filterWidget},_createStringInput:function(a){var b=this,c=this.options;this.filterWidget=BI.createWidget({type:"bi.sign_editor",cls:"condition-operator-input bi-border",allowBlank:true,height:this._constant.BUTTON_HEIGHT-2,width:this._constant.INPUT_WIDTH});this.filterWidget.on(BI.SignEditor.EVENT_CONFIRM,function(){b._setNodeData({filterValue:this.getValue()});
c.afterValueChange.apply(b,arguments)});BI.isNotNull(a)&&this.filterWidget.setValue(a);return this.filterWidget},_setNodeData:function(a){var b=this.options;b.node.set("data",BI.extend(b.node.get("data"),a))},getValue:function(){return{_src:this.options._src,filterType:this.filterType.getValue()[0],filterValue:this.filterWidget.getValue()}}});BI.shortcut("bi.target_string_field_filter_item",BI.TargetStringFieldFilterItem);
BI.TargetNumberFieldFilterItem=BI.inherit(BI.AbstractFilterItem,{_constant:{LEFT_ITEMS_H_GAP:5,CONTAINER_HEIGHT:40,BUTTON_HEIGHT:30,COMBO_WIDTH:130,FIELD_NAME_BUTTON_WIDTH:110,TEXT_BUTTON_H_GAP:10,INPUT_WIDTH:238,WIDGET_WIDTH:240},_defaultConfig:function(){return BI.extend(BI.TargetNumberFieldFilterItem.superclass._defaultConfig.apply(this,arguments),{extraCls:"bi-analysis-target-number-field-item",afterValueChange:BI.emptyFn})},_init:function(){BI.TargetNumberFieldFilterItem.superclass._init.apply(this,arguments);
var a=this,c=this.options;var b=this._buildConditions();this.deleteButton=BI.createWidget({type:"bi.icon_button",cls:"close-h-font"});this.deleteButton.on(BI.Controller.EVENT_CHANGE,function(){a.fireEvent(BI.Controller.EVENT_CHANGE,BI.Events.DESTROY,c.id,a)});BI.createWidget({type:"bi.vertical",element:this,items:[{el:{type:"bi.left_right_vertical_adapt",height:this._constant.CONTAINER_HEIGHT,items:{left:[b[0],b[1],b[2]],right:[this.deleteButton]},lhgap:this._constant.LEFT_ITEMS_H_GAP,rhgap:this._constant.LEFT_ITEMS_H_GAP}}],scrolly:false})
},populate:function(b,a,c){this.filterType.setValue(c.filterType);this._refreshFilterWidget(c.filterType,c.filterValue)},_buildConditions:function(){var a=this,b=this.options;if(BI.isNull(b._src)){return[]}this.fieldId=b._src.fieldId;var c=BI.Utils.getTableNameByID(BI.Utils.getTableIdByFieldID(this.fieldId))+"."+BI.Utils.getFieldNameByID(this.fieldId);this.fieldButton=BI.createWidget({type:"bi.text_button",text:c,title:c,width:this._constant.FIELD_NAME_BUTTON_WIDTH,height:this._constant.BUTTON_HEIGHT,textAlign:"left",hgap:this._constant.TEXT_BUTTON_H_GAP});
this.fieldButton.on(BI.Controller.EVENT_CHANGE,function(){arguments[2]=a;a.fireEvent(BI.Controller.EVENT_CHANGE,arguments)});this.filterWidgetContainer=BI.createWidget({type:"bi.left"});this.id=b.id;this.filterType=BI.createWidget({type:"bi.text_value_down_list_combo",width:this._constant.COMBO_WIDTH,height:this._constant.BUTTON_HEIGHT,items:BICst.TARGET_FILTER_NUMBER_COMBO});this.filterType.setValue(b.filterType);this.filterType.on(BI.TextValueDownListCombo.EVENT_CHANGE,function(){a._refreshFilterWidget(a.filterType.getValue()[0]);
a._setNodeData({filterType:a.filterType.getValue()[0]});b.afterValueChange.apply(a,arguments)});this._refreshFilterWidget(b.filterType,this.options.filterValue);return[this.fieldButton,this.filterType,this.filterWidgetContainer]},_refreshFilterWidget:function(b,a){switch(b){case BICst.TARGET_FILTER_NUMBER.EQUAL_TO:case BICst.TARGET_FILTER_NUMBER.NOT_EQUAL_TO:this._createNumberInput(a);break;case BICst.TARGET_FILTER_NUMBER.BELONG_VALUE:case BICst.TARGET_FILTER_NUMBER.NOT_BELONG_VALUE:this._createNumberIntervalFilter(a);
break;case BICst.TARGET_FILTER_NUMBER.BELONG_USER:case BICst.TARGET_FILTER_NUMBER.NOT_BELONG_USER:this._createNumberIntervalFilter(a);break;case BICst.TARGET_FILTER_NUMBER.IS_NULL:case BICst.TARGET_FILTER_NUMBER.NOT_NULL:this.filterWidget=BI.createWidget();break}this.filterWidgetContainer.empty();this.filterWidgetContainer.addItem(this.filterWidget)},_createNumberIntervalFilter:function(a){var b=this,c=this.options;this.filterWidget=BI.createWidget({type:"bi.number_interval",width:this._constant.INPUT_WIDTH+2,height:this._constant.BUTTON_HEIGHT});
BI.isNotNull(a)&&this.filterWidget.setValue(a);this.filterWidget.on(BI.NumberInterval.EVENT_CHANGE,function(){b._setNodeData({filterValue:this.getValue()});c.afterValueChange.apply(b,arguments)});return this.filterWidget},_createNumberInput:function(a){var b=this,c=this.options;this.filterWidget=BI.createWidget({type:"bi.text_editor",validationChecker:function(){if(!BI.isNumeric(b.filterWidget.getValue())){return false}},errorText:BI.i18nText("BI-Numerical_Interval_Input_Data"),allowBlank:true,height:this._constant.BUTTON_HEIGHT,width:this._constant.INPUT_WIDTH+2});
this.filterWidget.on(BI.TextEditor.EVENT_CONFIRM,function(){b._setNodeData({filterValue:this.getValue()});c.afterValueChange.apply(b,arguments)});BI.isNotNull(a)&&this.filterWidget.setValue(a);return BI.createWidget({type:"bi.vertical_adapt",items:[{type:"bi.label",text:"N="},this.filterWidget]})},_setNodeData:function(a){var b=this.options;b.node.set("data",BI.extend(b.node.get("data"),a))},getValue:function(){return{_src:this.options._src,filterType:this.filterType.getValue()[0],filterValue:this.filterWidget.getValue()}
}});BI.shortcut("bi.target_number_field_filter_item",BI.TargetNumberFieldFilterItem);
BI.TargetDateFieldFilterItem=BI.inherit(BI.AbstractFilterItem,{_constant:{LEFT_ITEMS_H_GAP:5,CONTAINER_HEIGHT:40,BUTTON_HEIGHT:30,COMBO_WIDTH:130,FIELD_NAME_BUTTON_WIDTH:110,TEXT_BUTTON_H_GAP:10,INPUT_WIDTH:238,WIDGET_WIDTH:240},_defaultConfig:function(){return BI.extend(BI.TargetDateFieldFilterItem.superclass._defaultConfig.apply(this,arguments),{extraCls:"bi-analysis-date-field-item",afterValueChange:BI.emptyFn})},_init:function(){BI.TargetDateFieldFilterItem.superclass._init.apply(this,arguments);
var a=this,c=this.options;var b=this._buildConditions();this.deleteButton=BI.createWidget({type:"bi.icon_button",cls:"close-h-font"});this.deleteButton.on(BI.Controller.EVENT_CHANGE,function(){a.fireEvent(BI.Controller.EVENT_CHANGE,BI.Events.DESTROY,c.id,a)});BI.createWidget({type:"bi.vertical",element:this,items:[{el:{type:"bi.left_right_vertical_adapt",height:this._constant.CONTAINER_HEIGHT,items:{left:[b[0],b[1],b[2]],right:[this.deleteButton]},lhgap:this._constant.LEFT_ITEMS_H_GAP,rhgap:this._constant.LEFT_ITEMS_H_GAP}}],scrolly:false})
},populate:function(b,a,c){this.filterType.setValue(c.filterType);this._refreshFilterWidget(c.filterType,c.filterValue)},_buildConditions:function(){var a=this,b=this.options;if(BI.isNull(b._src)){return[]}var c=BI.Utils.getTableNameByID(BI.Utils.getTableIdByFieldID(b._src.fieldId))+"."+BI.Utils.getFieldNameByID(b._src.fieldId);this.fieldButton=BI.createWidget({type:"bi.text_button",text:c,title:c,width:this._constant.FIELD_NAME_BUTTON_WIDTH,height:this._constant.BUTTON_HEIGHT,textAlign:"left",hgap:this._constant.TEXT_BUTTON_H_GAP});
this.fieldButton.on(BI.Controller.EVENT_CHANGE,function(){arguments[2]=a;a.fireEvent(BI.Controller.EVENT_CHANGE,arguments)});this.filterWidgetContainer=BI.createWidget({type:"bi.left"});this.id=b.id;this.filterType=BI.createWidget({type:"bi.text_value_down_list_combo",width:this._constant.COMBO_WIDTH,height:this._constant.BUTTON_HEIGHT,items:BICst.FILTER_DATE_COMBO});this.filterType.setValue(b.filterType);this.filterType.on(BI.TextValueDownListCombo.EVENT_CHANGE,function(){a._refreshFilterWidget(a.filterType.getValue()[0]);
a._setNodeData({filterType:this.getValue()[0]});b.afterValueChange.apply(a,arguments)});this._refreshFilterWidget(b.filterType,b.filterValue);return[this.fieldButton,this.filterType,this.filterWidgetContainer]},_refreshFilterWidget:function(a,b){switch(a){case BICst.FILTER_DATE.BELONG_DATE_RANGE:case BICst.FILTER_DATE.NOT_BELONG_DATE_RANGE:this._createTimeRange(b);break;case BICst.FILTER_DATE.BELONG_WIDGET_VALUE:case BICst.FILTER_DATE.NOT_BELONG_WIDGET_VALUE:this._createWidgetTab([BICst.WIDGET.DATE,BICst.WIDGET.YEAR,BICst.WIDGET.QUARTER,BICst.WIDGET.MONTH,BICst.WIDGET.YMD,BICst.WIDGET.DATE_PANE],b,false);
break;case BICst.FILTER_DATE.LATER_THAN:case BICst.FILTER_DATE.EARLY_THAN:this._createWidgetTab([BICst.WIDGET.YMD,BICst.WIDGET.DATE_PANE],b,true);break;case BICst.FILTER_DATE.EQUAL_TO:case BICst.FILTER_DATE.NOT_EQUAL_TO:this._createDate(b);break;case BICst.FILTER_DATE.IS_NULL:case BICst.FILTER_DATE.NOT_NULL:this.filterWidget=BI.createWidget();break}this.filterWidgetContainer.empty();this.filterWidgetContainer.addItem(this.filterWidget)},_createWidgetTab:function(c,d,a){var b=this,e=this.options;this.filterWidget=BI.createWidget({type:"bi.target_date_tab",dateWidgetType:c,isTimePoint:a});
this.filterWidget.on(BI.Tab.EVENT_CHANGE,function(){b._setNodeData({filterValue:this.getValue()});e.afterValueChange.apply(b,arguments)});this.filterWidget.on(BI.TargetDateTab.EVENT_SHOW_CARD_VALUE_CHANGE,function(){b._setNodeData({filterValue:this.getValue()});e.afterValueChange.apply(b,arguments)});if(BI.isNotNull(d)){this.filterWidget.setValue(d)}},_createTimeRange:function(b){var a=this,c=this.options;this.filterWidget=BI.createWidget({type:"bi.custom_param_time_interval",width:this._constant.INPUT_WIDTH+2,height:this._constant.TIME_INTERVAL_HEIGHT});
this.filterWidget.on(BI.CustomParamTimeInterval.EVENT_CHANGE,function(){a._setNodeData({filterValue:this.getValue()});c.afterValueChange.apply(a,arguments)});if(BI.isNotNull(b)){this.filterWidget.setValue(b)}},_createDate:function(b){var a=this,c=this.options;this.filterWidget=BI.createWidget({type:"bi.multidate_param_combo",width:this._constant.INPUT_WIDTH+2});this.filterWidget.on(BI.MultiDateParamCombo.EVENT_CONFIRM,function(){a._setNodeData({filterValue:this.getValue()});c.afterValueChange.apply(a,arguments)
});if(BI.isNotNull(b)){this.filterWidget.setValue(b)}},_setNodeData:function(a){var b=this.options;b.node.set("data",BI.extend(b.node.get("data"),a))},getValue:function(){return{_src:this.options._src,filterType:this.filterType.getValue()[0],filterValue:this.filterWidget.getValue()}}});BI.shortcut("bi.date_field_filter_item",BI.TargetDateFieldFilterItem);
BI.TargetDateTab=BI.inherit(BI.Widget,{constants:{defaultShowWidget:0,comboHeight:30,comboWidth:100},_defaultConfig:function(){return BI.extend(BI.TargetDateTab.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-target-date-tab",dateWidgetType:[],isTimePoint:true})},_init:function(){BI.TargetDateTab.superclass._init.apply(this,arguments);var b=this,f=this.options;var c=f.dateWidgetType;var a=BI.filter(BI.Utils.getAllWidgetIDs(),function(h,g){return BI.contains(c,BI.Utils.getWidgetTypeByID(g))
});var d=BI.map(a,function(h,g){return{text:BI.Utils.getWidgetNameByID(g),value:g}});d=BI.Func.getSortedResult(d);var e=BI.createWidget({type:"bi.text_value_combo",width:this.constants.comboWidth,height:this.constants.comboHeight,items:d});this.tab=BI.createWidget({type:"bi.tab",width:this.constants.comboWidth,height:this.constants.comboHeight,direction:"custom",tab:e,cardCreator:BI.bind(this._cardCreator,this)});this.tab.on(BI.Controller.EVENT_CHANGE,function(){b.fireEvent(BI.Controller.EVENT_CHANGE,arguments)
});this.tab.on(BI.Tab.EVENT_CHANGE,function(){b.fireEvent(BI.TargetDateTab.EVENT_CHANGE)});this.tab.setSelect(0);BI.createWidget({type:"bi.left",element:this,items:[e,{type:"bi.label",text:BI.i18nText("BI-Basic_De"),textAlign:"center",height:30,lgap:5,rgap:5},this.tab]})},_cardCreator:function(b){var a=this,d=this.options;var c=BI.Utils.getAllWidgetIDs();if(!BI.contains(c,b)){return BI.createWidget({type:"bi.text_value_combo",height:this.constants.comboHeight,items:[]})}switch(BI.Utils.getWidgetTypeByID(b)){case BICst.WIDGET.YEAR:this.yearCombo=BI.createWidget({type:"bi.year_param_combo"});
this.yearCombo.on(BI.YearParamCombo.EVENT_CONFIRM,function(){a.fireEvent(BI.TargetDateTab.EVENT_SHOW_CARD_VALUE_CHANGE)});return this.yearCombo;case BICst.WIDGET.MONTH:this.monthCombo=BI.createWidget({type:"bi.year_month_param_combo"});this.monthCombo.on(BI.YearParamCombo.EVENT_CONFIRM,function(){a.fireEvent(BI.TargetDateTab.EVENT_SHOW_CARD_VALUE_CHANGE)});return this.monthCombo;case BICst.WIDGET.QUARTER:this.qurterCombo=BI.createWidget({type:"bi.year_season_param_combo"});this.qurterCombo.on(BI.YearSeasonParamCombo.EVENT_CONFIRM,function(){a.fireEvent(BI.TargetDateTab.EVENT_SHOW_CARD_VALUE_CHANGE)
});return this.qurterCombo;case BICst.WIDGET.YMD:case BICst.WIDGET.DATE_PANE:if(d.isTimePoint===true){this.dateCombo=BI.createWidget({type:"bi.date_param_combo"});this.dateCombo.on(BI.DateParamCombo.EVENT_CONFIRM,function(){a.fireEvent(BI.TargetDateTab.EVENT_SHOW_CARD_VALUE_CHANGE)})}else{this.dateCombo=BI.createWidget({type:"bi.date_interval_param_combo"});this.dateCombo.on(BI.DateIntervalParamCombo.EVENT_CONFIRM,function(){a.fireEvent(BI.TargetDateTab.EVENT_SHOW_CARD_VALUE_CHANGE)})}return this.dateCombo;
case BICst.WIDGET.DATE:this.dateRangeCombo=BI.createWidget({type:"bi.range_value_combo",height:this.constants.comboHeight});this.dateRangeCombo.on(BI.RangeValueCombo.EVENT_CHANGE,function(){a.fireEvent(BI.TargetDateTab.EVENT_SHOW_CARD_VALUE_CHANGE)});return this.dateRangeCombo}},setValue:function(a){this.tab.setSelect(a.wId);this.tab.setValue(a.filterValue)},getValue:function(){return{wId:this.tab.getSelect(),filterValue:this.tab.getValue()}}});BI.TargetDateTab.EVENT_CHANGE="EVENT_CHANGE";BI.TargetDateTab.EVENT_SHOW_CARD_VALUE_CHANGE="EVENT_SHOW_CARD_VALUE_CHANGE";
BI.shortcut("bi.target_date_tab",BI.TargetDateTab);
BI.TargetNoTypeFieldFilterItem=BI.inherit(BI.AbstractFilterItem,{_constant:{LEFT_ITEMS_H_GAP:5,CONTAINER_HEIGHT:40,CONDITION_TYPE_COMBO_ADJUST:2,BUTTON_HEIGHT:30,TEXT_BUTTON_H_GAP:10,ADD_FIELD_POPUP_WIDTH:230,HEIGHT_MAX:10000,MAX_HEIGHT:500},_defaultConfig:function(){return BI.extend(BI.TargetNoTypeFieldFilterItem.superclass._defaultConfig.apply(this,arguments),{extraCls:"bi-target-no-type-field-item",afterValueChange:BI.emptyFn})},_init:function(){BI.TargetNoTypeFieldFilterItem.superclass._init.apply(this,arguments);
var a=this,c=this.options;var b=this._buildConditionsNoType();this.deleteButton=BI.createWidget({type:"bi.icon_button",cls:"close-h-font"});this.deleteButton.on(BI.Controller.EVENT_CHANGE,function(){a.fireEvent(BI.Controller.EVENT_CHANGE,BI.Events.DESTROY,c.id,a)});this.itemContainer=BI.createWidget({type:"bi.left_right_vertical_adapt",cls:"item-no-type",height:this._constant.CONTAINER_HEIGHT,items:{left:[b],right:[this.deleteButton]},lhgap:this._constant.LEFT_ITEMS_H_GAP,rhgap:this._constant.LEFT_ITEMS_H_GAP});
BI.createWidget({type:"bi.vertical",element:this,items:[this.itemContainer],scrolly:false})},populate:function(){if(BI.isNotNull(this.typeSelectedItem)){this.typeSelectedItem.populate.apply(this.typeSelectedItem,arguments)}},_buildConditionsNoType:function(){var b=this,c=this.options;var a=BI.createWidget({type:"bi.target_filter_select_field",height:this._constant.MAX_HEIGHT,fieldId:c.fieldId});this.addCondition=BI.createWidget({type:"bi.combo",isNeedAdjustHeight:true,adjustLength:this._constant.CONDITION_TYPE_COMBO_ADJUST,el:{type:"bi.button",level:"common",height:this._constant.BUTTON_HEIGHT,text:BI.i18nText("BI-Please_Select_Field")},popup:{el:a,minWidth:228,maxHeight:this._constant.MAX_HEIGHT}});
a.on(BI.TargetFilterSelectField.EVENT_CLICK_ITEM,function(d){b._onTypeSelected(d)});return this.addCondition},_onTypeSelected:function(c){var a=BI.Utils.getFieldTypeByID(c.fieldId||c);var b=this,e=this.options;var d=BI.TargetFilterItemFactory.createFilterItemByFieldType(a);this.itemContainer.destroy();this.itemContainer=null;this.typeSelectedItem=BI.createWidget(d,{element:this,_src:BI.isObject(c)?c:{fieldId:c},id:this.options.id,node:e.node,afterValueChange:e.afterValueChange});this.typeSelectedItem.on(BI.Controller.EVENT_CHANGE,function(){b.fireEvent(BI.Controller.EVENT_CHANGE,arguments)
});e.node.set("data",BI.extend(e.node.get("data"),{value:d.filterType,filterType:d.filterType,_src:BI.isObject(c)?c:{fieldId:c}}))},getValue:function(){if(BI.isNotNull(this.typeSelectedItem)){return this.typeSelectedItem.getValue()}return{filterType:BICst.FILTER_TYPE.EMPTY_CONDITION}}});BI.shortcut("bi.target_no_type_field_filter_item",BI.TargetNoTypeFieldFilterItem);
BI.TargetFilterItemFactory={createFilterItemByFieldType:function(a){var c,b;switch(a){case BICst.COLUMN.STRING:c=BICst.TARGET_FILTER_STRING.BELONG_VALUE;b="bi.target_string_field_filter_item";break;case BICst.COLUMN.NUMBER:case BICst.COLUMN.COUNTER:c=BICst.TARGET_FILTER_NUMBER.BELONG_VALUE;b="bi.target_number_field_filter_item";break;case BICst.COLUMN.DATE:c=BICst.FILTER_DATE.BELONG_DATE_RANGE;b="bi.date_field_filter_item";break;default:b="bi.target_no_type_field_filter_item";break}return{type:b,filterType:c}
},createFilterItemByFilterType:function(b){var a="";switch(b){case BICst.TARGET_FILTER_STRING.BELONG_VALUE:case BICst.TARGET_FILTER_STRING.NOT_BELONG_VALUE:case BICst.TARGET_FILTER_STRING.CONTAIN:case BICst.TARGET_FILTER_STRING.NOT_CONTAIN:case BICst.TARGET_FILTER_STRING.IS_NULL:case BICst.TARGET_FILTER_STRING.NOT_NULL:case BICst.TARGET_FILTER_STRING.BEGIN_WITH:case BICst.TARGET_FILTER_STRING.END_WITH:case BICst.TARGET_FILTER_STRING.NOT_BEGIN_WITH:case BICst.TARGET_FILTER_STRING.NOT_END_WITH:a="bi.target_string_field_filter_item";
break;case BICst.TARGET_FILTER_NUMBER.EQUAL_TO:case BICst.TARGET_FILTER_NUMBER.NOT_EQUAL_TO:case BICst.TARGET_FILTER_NUMBER.BELONG_VALUE:case BICst.TARGET_FILTER_NUMBER.NOT_BELONG_VALUE:case BICst.TARGET_FILTER_NUMBER.BELONG_USER:case BICst.TARGET_FILTER_NUMBER.NOT_BELONG_USER:case BICst.TARGET_FILTER_NUMBER.IS_NULL:case BICst.TARGET_FILTER_NUMBER.NOT_NULL:case BICst.TARGET_FILTER_NUMBER.LARGE_THAN_CAL_LINE:case BICst.TARGET_FILTER_NUMBER.LARGE_OR_EQUAL_CAL_LINE:case BICst.TARGET_FILTER_NUMBER.SMALL_THAN_CAL_LINE:case BICst.TARGET_FILTER_NUMBER.SMALL_OR_EQUAL_CAL_LINE:case BICst.TARGET_FILTER_NUMBER.TOP_N:case BICst.TARGET_FILTER_NUMBER.BOTTOM_N:a="bi.target_number_field_filter_item";
break;case BICst.FILTER_DATE.BELONG_DATE_RANGE:case BICst.FILTER_DATE.NOT_BELONG_DATE_RANGE:case BICst.FILTER_DATE.BELONG_WIDGET_VALUE:case BICst.FILTER_DATE.NOT_BELONG_WIDGET_VALUE:case BICst.FILTER_DATE.LATER_THAN:case BICst.FILTER_DATE.EARLY_THAN:case BICst.FILTER_DATE.EQUAL_TO:case BICst.FILTER_DATE.NOT_EQUAL_TO:case BICst.FILTER_DATE.IS_NULL:case BICst.FILTER_DATE.NOT_NULL:a="bi.date_field_filter_item";break;case BICst.FILTER_TYPE.AND:case BICst.FILTER_TYPE.OR:a="bi.filter_expander";break;case BICst.FILTER_TYPE.FORMULA:a="bi.target_formula_filter_item";
break;case BICst.FILTER_TYPE.EMPTY_FORMULA:a="bi.target_formula_empty_filter_item";break;case BICst.FILTER_TYPE.EMPTY_CONDITION:a="bi.target_no_type_field_filter_item";break;default:a="bi.target_no_type_field_filter_item";break}return{type:a}}};
BI.DimensionFilterItemFactory={createFilterItemByDimensionType:function(a){var c,b;switch(a){case BICst.TARGET_TYPE.STRING:c=BICst.DIMENSION_FILTER_STRING.BELONG_VALUE;b="bi.dimension_string_field_filter_item";break;case BICst.TARGET_TYPE.COUNTER:case BICst.TARGET_TYPE.NUMBER:case BICst.TARGET_TYPE.FORMULA:case BICst.TARGET_TYPE.YEAR_ON_YEAR_RATE:case BICst.TARGET_TYPE.MONTH_ON_MONTH_RATE:case BICst.TARGET_TYPE.YEAR_ON_YEAR_VALUE:case BICst.TARGET_TYPE.MONTH_ON_MONTH_VALUE:case BICst.TARGET_TYPE.SUM_OF_ABOVE:case BICst.TARGET_TYPE.SUM_OF_ABOVE_IN_GROUP:case BICst.TARGET_TYPE.SUM_OF_ALL:case BICst.TARGET_TYPE.SUM_OF_ALL_IN_GROUP:case BICst.TARGET_TYPE.RANK:case BICst.TARGET_TYPE.RANK_IN_GROUP:c=BICst.DIMENSION_FILTER_NUMBER.BELONG_VALUE;
b="bi.dimension_number_field_filter_item";break;case BICst.TARGET_TYPE.DATE:c=BICst.DIMENSION_FILTER_DATE.BELONG_VALUE;b="bi.dimension_date_field_filter_item";break;default:b="bi.dimension_no_type_field_filter_item";break}return{type:b,filterType:c}},createFilterItemByFilterType:function(b){var a="";switch(b){case BICst.DIMENSION_FILTER_STRING.BELONG_VALUE:case BICst.DIMENSION_FILTER_STRING.NOT_BELONG_VALUE:case BICst.DIMENSION_FILTER_STRING.CONTAIN:case BICst.DIMENSION_FILTER_STRING.NOT_CONTAIN:case BICst.DIMENSION_FILTER_STRING.IS_NULL:case BICst.DIMENSION_FILTER_STRING.NOT_NULL:case BICst.DIMENSION_FILTER_STRING.BEGIN_WITH:case BICst.DIMENSION_FILTER_STRING.END_WITH:case BICst.DIMENSION_FILTER_STRING.TOP_N:case BICst.DIMENSION_FILTER_STRING.BOTTOM_N:a="bi.dimension_string_field_filter_item";
break;case BICst.DIMENSION_FILTER_DATE.BELONG_VALUE:case BICst.DIMENSION_FILTER_DATE.NOT_BELONG_VALUE:case BICst.DIMENSION_FILTER_DATE.CONTAIN:case BICst.DIMENSION_FILTER_DATE.NOT_CONTAIN:case BICst.DIMENSION_FILTER_DATE.IS_NULL:case BICst.DIMENSION_FILTER_DATE.NOT_NULL:case BICst.DIMENSION_FILTER_DATE.BEGIN_WITH:case BICst.DIMENSION_FILTER_DATE.END_WITH:case BICst.DIMENSION_FILTER_DATE.TOP_N:case BICst.DIMENSION_FILTER_DATE.BOTTOM_N:a="bi.dimension_date_field_filter_item";break;case BICst.DIMENSION_FILTER_NUMBER.BELONG_VALUE:case BICst.DIMENSION_FILTER_NUMBER.NOT_BELONG_VALUE:case BICst.DIMENSION_FILTER_NUMBER.BELONG_USER:case BICst.DIMENSION_FILTER_NUMBER.NOT_BELONG_USER:case BICst.DIMENSION_FILTER_NUMBER.IS_NULL:case BICst.DIMENSION_FILTER_NUMBER.NOT_NULL:case BICst.DIMENSION_FILTER_NUMBER.MORE_THAN_AVG:case BICst.DIMENSION_FILTER_NUMBER.LESS_THAN_AVG:case BICst.DIMENSION_FILTER_NUMBER.TOP_N:case BICst.DIMENSION_FILTER_NUMBER.BOTTOM_N:a="bi.dimension_number_field_filter_item";
break;case BICst.FILTER_DATE.BELONG_DATE_RANGE:case BICst.FILTER_DATE.NOT_BELONG_DATE_RANGE:case BICst.FILTER_DATE.LATER_THAN:case BICst.FILTER_DATE.EARLY_THAN:case BICst.FILTER_DATE.EQUAL_TO:case BICst.FILTER_DATE.NOT_EQUAL_TO:case BICst.FILTER_DATE.IS_NULL:case BICst.FILTER_DATE.NOT_NULL:a="bi.dimension_string_field_filter_item";break;case BICst.FILTER_TYPE.AND:case BICst.FILTER_TYPE.OR:a="bi.filter_expander";break;case BICst.FILTER_TYPE.FORMULA:a="bi.dimension_formula_filter_item";break;case BICst.FILTER_TYPE.EMPTY_FORMULA:a="bi.dimension_formula_empty_filter_item";
break;case BICst.FILTER_TYPE.EMPTY_CONDITION:a="bi.dimension_no_type_field_filter_item";break;default:a="bi.dimension_no_type_field_filter_item";break}return{type:a}}};
BI.DimensionStringFieldFilterItem=BI.inherit(BI.AbstractFilterItem,{_constant:{LEFT_ITEMS_H_GAP:5,CONTAINER_HEIGHT:40,BUTTON_HEIGHT:30,COMBO_WIDTH:130,FIELD_NAME_BUTTON_WIDTH:110,TEXT_BUTTON_H_GAP:10,INPUT_WIDTH:238,N_INPUT_WIDTH:138,DATA_TYPE_ERROR:"number-error",WIDGET_WIDTH:240},_defaultConfig:function(){return BI.extend(BI.DimensionStringFieldFilterItem.superclass._defaultConfig.apply(this,arguments),{extraCls:"bi-dimension-string-field-item",afterValueChange:BI.emptyFn})},_init:function(){BI.DimensionStringFieldFilterItem.superclass._init.apply(this,arguments);
var a=this,c=this.options;var b=this._buildConditions();this.deleteButton=BI.createWidget({type:"bi.icon_button",cls:"close-h-font"});this.deleteButton.on(BI.Controller.EVENT_CHANGE,function(){a.fireEvent(BI.Controller.EVENT_CHANGE,BI.Events.DESTROY,c.id,a)});BI.createWidget({type:"bi.vertical",element:this,scrolly:false,items:[{el:{type:"bi.left_right_vertical_adapt",height:this._constant.CONTAINER_HEIGHT,items:{left:[b[0],b[1],b[2]],right:[this.deleteButton]},lhgap:this._constant.LEFT_ITEMS_H_GAP,rhgap:this._constant.LEFT_ITEMS_H_GAP}}],})
},populate:function(b,a,c){this.filterType.setValue(c.filterType);this._refreshFilterWidget(c.filterType,c.filterValue)},_buildConditions:function(){var a=this,b=this.options;if(BI.isNull(b.dId)){return[]}var c=BI.Utils.getDimensionNameByID(b.dId);this.fieldButton=BI.createWidget({type:"bi.text_button",text:c,title:c,width:this._constant.FIELD_NAME_BUTTON_WIDTH,height:this._constant.BUTTON_HEIGHT,textAlign:"left",hgap:this._constant.TEXT_BUTTON_H_GAP});this.fieldButton.on(BI.Controller.EVENT_CHANGE,function(){arguments[2]=a;
a.fireEvent(BI.Controller.EVENT_CHANGE,arguments)});this.filterWidgetContainer=BI.createWidget({type:"bi.left"});this.id=b.id;this.filterType=BI.createWidget({type:"bi.text_value_down_list_combo",width:this._constant.COMBO_WIDTH,height:this._constant.BUTTON_HEIGHT,items:BICst.DIMENSION_FILTER_STRING_COMBO});this.filterType.setValue(b.filterType);this.filterType.on(BI.TextValueDownListCombo.EVENT_CHANGE,function(){a._refreshFilterWidget(a.filterType.getValue()[0]);a._setNodeData({filterType:this.getValue()[0]});
b.afterValueChange.apply(a,arguments)});this._refreshFilterWidget(b.filterType,b.filterValue);return[this.fieldButton,this.filterType,this.filterWidgetContainer]},_refreshFilterWidget:function(c,a){var b=BI.createWidget();switch(c){case BICst.DIMENSION_FILTER_STRING.BELONG_VALUE:case BICst.DIMENSION_FILTER_STRING.NOT_BELONG_VALUE:b=this._createStringBelongCombo(a);break;case BICst.DIMENSION_FILTER_STRING.CONTAIN:case BICst.DIMENSION_FILTER_STRING.NOT_CONTAIN:b=this._createStringInput(a);break;case BICst.DIMENSION_FILTER_STRING.IS_NULL:case BICst.DIMENSION_FILTER_STRING.NOT_NULL:b=this.filterWidget=BI.createWidget();
break;case BICst.DIMENSION_FILTER_STRING.BEGIN_WITH:case BICst.DIMENSION_FILTER_STRING.END_WITH:b=this._createStringInput(a);break;case BICst.DIMENSION_FILTER_STRING.TOP_N:case BICst.DIMENSION_FILTER_STRING.BOTTOM_N:b=this._createNInput(a);break}this.filterWidgetContainer.empty();this.filterWidgetContainer.addItem(b)},_createStringBelongCombo:function(a){var c=this.options,b=this;this.filterWidget=BI.createWidget({type:"bi.select_dimension_data_combo",dId:c.dId,width:this._constant.WIDGET_WIDTH,height:this._constant.BUTTON_HEIGHT});
this.filterWidget.on(BI.SelectDimensionDataCombo.EVENT_CONFIRM,function(){b._setNodeData({filterValue:this.getValue()});c.afterValueChange.apply(b,arguments)});BI.isNotNull(a)&&this.filterWidget.setValue(a);return this.filterWidget},_createStringInput:function(a){var b=this,c=this.options;this.filterWidget=BI.createWidget({type:"bi.sign_editor",cls:"condition-operator-input bi-border",allowBlank:true,height:this._constant.BUTTON_HEIGHT-2,width:this._constant.INPUT_WIDTH-2});this.filterWidget.on(BI.SignEditor.EVENT_CONFIRM,function(){b._setNodeData({filterValue:this.getValue()});
c.afterValueChange.apply(b,arguments)});BI.isNotNull(a)&&this.filterWidget.setValue(a);return this.filterWidget},_createNInput:function(a){var b=this,d=this.options;this.filterWidget=BI.createWidget({type:"bi.text_editor",validationChecker:function(e){return BI.isPositiveInteger(e)},errorText:BI.i18nText("BI-Please_Input_Positive_Integer"),allowBlank:true,height:this._constant.BUTTON_HEIGHT,width:this._constant.N_INPUT_WIDTH+2});this.filterWidget.on(BI.TextEditor.EVENT_CONFIRM,function(){b._setNodeData({filterValue:this.getValue()});
d.afterValueChange.apply(b,arguments)});var c=BI.createWidget({type:"bi.vertical_adapt",items:[{type:"bi.label",text:"N="},this.filterWidget]});BI.isNumeric(a)&&this.filterWidget.setValue(a);return c},_setNodeData:function(a){var b=this.options;b.node.set("data",BI.extend(b.node.get("data"),a))},getValue:function(){return{targetId:this.options.dId,filterType:this.filterType.getValue()[0],filterValue:this.filterWidget.getValue()}}});BI.shortcut("bi.dimension_string_field_filter_item",BI.DimensionStringFieldFilterItem);
BI.DimensionDateFieldFilterItem=BI.inherit(BI.AbstractFilterItem,{_constant:{LEFT_ITEMS_H_GAP:5,CONTAINER_HEIGHT:40,BUTTON_HEIGHT:30,COMBO_WIDTH:130,FIELD_NAME_BUTTON_WIDTH:110,TEXT_BUTTON_H_GAP:10,INPUT_WIDTH:138,DATA_TYPE_ERROR:"number-error",WIDGET_WIDTH:240},_defaultConfig:function(){return BI.extend(BI.DimensionDateFieldFilterItem.superclass._defaultConfig.apply(this,arguments),{extraCls:"bi-dimension-string-field-item",afterValueChange:BI.emptyFn})},_init:function(){BI.DimensionDateFieldFilterItem.superclass._init.apply(this,arguments);
var a=this,c=this.options;var b=this._buildConditions();this.deleteButton=BI.createWidget({type:"bi.icon_button",cls:"close-h-font"});this.deleteButton.on(BI.Controller.EVENT_CHANGE,function(){a.fireEvent(BI.Controller.EVENT_CHANGE,BI.Events.DESTROY,c.id,a)});BI.createWidget({type:"bi.vertical",element:this,scrolly:false,items:[{el:{type:"bi.left_right_vertical_adapt",height:this._constant.CONTAINER_HEIGHT,items:{left:[b[0],b[1],b[2]],right:[this.deleteButton]},lhgap:this._constant.LEFT_ITEMS_H_GAP,rhgap:this._constant.LEFT_ITEMS_H_GAP}}],scrolly:false})
},populate:function(b,a,c){this.filterType.setValue(c.filterType);this._refreshFilterWidget(c.filterType,c.filterValue)},_buildConditions:function(){var c=this,d=this.options;if(BI.isNull(d.dId)){return[]}var e=BI.Utils.getDimensionNameByID(d.dId);this.fieldButton=BI.createWidget({type:"bi.text_button",text:e,title:e,width:this._constant.FIELD_NAME_BUTTON_WIDTH,height:this._constant.BUTTON_HEIGHT,textAlign:"left",hgap:this._constant.TEXT_BUTTON_H_GAP});this.fieldButton.on(BI.Controller.EVENT_CHANGE,function(){arguments[2]=c;
c.fireEvent(BI.Controller.EVENT_CHANGE,arguments)});this.filterWidgetContainer=BI.createWidget({type:"bi.left"});this.id=d.id;var b=[];var a=[];switch(BI.Utils.getDimensionGroupByID(d.dId).type){case BICst.GROUP.Y:case BICst.GROUP.M:case BICst.GROUP.W:case BICst.GROUP.S:case BICst.GROUP.D:case BICst.GROUP.WEEK_COUNT:case BICst.GROUP.HOUR:case BICst.GROUP.MINUTE:case BICst.GROUP.SECOND:b=BICst.DIMENSION_FILTER_STRING_COMBO;a=this.getComboItemsValues(b);d.filterType=BI.contains(a,d.filterType)?d.filterType:BICst.DIMENSION_FILTER_STRING.BELONG_VALUE;
break;case BICst.GROUP.YM:case BICst.GROUP.YS:case BICst.GROUP.YW:case BICst.GROUP.YMD:case BICst.GROUP.YMDH:case BICst.GROUP.YMDHM:case BICst.GROUP.YMDHMS:b=BICst.DIMENSION_FILTER_DATE_COMBO;a=this.getComboItemsValues(b);d.filterType=BI.contains(a,d.filterType)?d.filterType:BICst.DIMENSION_FILTER_DATE.BELONG_VALUE;break}this.filterType=BI.createWidget({type:"bi.text_value_down_list_combo",width:this._constant.COMBO_WIDTH,height:this._constant.BUTTON_HEIGHT,items:b});this.filterType.setValue(d.filterType);
this.filterType.on(BI.TextValueDownListCombo.EVENT_CHANGE,function(){c._refreshFilterWidget(c.filterType.getValue()[0]);c._setNodeData({filterType:this.getValue()[0]});d.afterValueChange.apply(c,arguments)});this._refreshFilterWidget(d.filterType,d.filterValue);return[this.fieldButton,this.filterType,this.filterWidgetContainer]},getComboItemsValues:function(a){return BI.flatten(BI.map(a,function(b,c){return BI.map(c,function(e,d){return d.value})}))},_refreshFilterWidget:function(c,a){var b=BI.createWidget();
switch(c){case BICst.DIMENSION_FILTER_STRING.BELONG_VALUE:case BICst.DIMENSION_FILTER_STRING.NOT_BELONG_VALUE:case BICst.DIMENSION_FILTER_DATE.BELONG_VALUE:case BICst.DIMENSION_FILTER_DATE.NOT_BELONG_VALUE:b=this._createStringBelongCombo(a);break;case BICst.DIMENSION_FILTER_STRING.CONTAIN:case BICst.DIMENSION_FILTER_STRING.NOT_CONTAIN:case BICst.DIMENSION_FILTER_DATE.CONTAIN:case BICst.DIMENSION_FILTER_DATE.NOT_CONTAIN:b=this._createStringInput(a);break;case BICst.DIMENSION_FILTER_STRING.IS_NULL:case BICst.DIMENSION_FILTER_STRING.NOT_NULL:case BICst.DIMENSION_FILTER_DATE.IS_NULL:case BICst.DIMENSION_FILTER_DATE.NOT_NULL:b=this.filterWidget=BI.createWidget();
break;case BICst.DIMENSION_FILTER_STRING.BEGIN_WITH:case BICst.DIMENSION_FILTER_STRING.END_WITH:case BICst.DIMENSION_FILTER_DATE.BEGIN_WITH:case BICst.DIMENSION_FILTER_DATE.END_WITH:b=this._createStringInput(a);break;case BICst.DIMENSION_FILTER_STRING.TOP_N:case BICst.DIMENSION_FILTER_STRING.BOTTOM_N:case BICst.DIMENSION_FILTER_DATE.TOP_N:case BICst.DIMENSION_FILTER_DATE.BOTTOM_N:b=this._createNInput(a);break}this.filterWidgetContainer.empty();this.filterWidgetContainer.addItem(b)},_createStringBelongCombo:function(a){var c=this.options,b=this;
this.filterWidget=BI.createWidget({type:"bi.select_dimension_data_combo",dId:c.dId,width:this._constant.WIDGET_WIDTH,height:this._constant.BUTTON_HEIGHT});this.filterWidget.on(BI.SelectDimensionDataCombo.EVENT_CONFIRM,function(){b._setNodeData({filterValue:this.getValue()});c.afterValueChange.apply(b,arguments)});BI.isNotNull(a)&&this.filterWidget.setValue(a);return this.filterWidget},_createStringInput:function(a){var b=this,c=this.options;this.filterWidget=BI.createWidget({type:"bi.sign_editor",cls:"condition-operator-input bi-border",allowBlank:true,height:this._constant.BUTTON_HEIGHT-2,width:this._constant.INPUT_WIDTH});
this.filterWidget.on(BI.SignEditor.EVENT_CONFIRM,function(){b._setNodeData({filterValue:this.getValue()});c.afterValueChange.apply(b,arguments)});BI.isNotNull(a)&&this.filterWidget.setValue(a);return this.filterWidget},_createNInput:function(a){var b=this,d=this.options;this.filterWidget=BI.createWidget({type:"bi.text_editor",validationChecker:function(e){return BI.isPositiveInteger(e)},errorText:BI.i18nText("BI-Please_Input_Positive_Integer"),allowBlank:true,height:this._constant.BUTTON_HEIGHT,width:this._constant.INPUT_WIDTH+2});
this.filterWidget.on(BI.TextEditor.EVENT_CONFIRM,function(){b._setNodeData({filterValue:this.getValue()});d.afterValueChange.apply(b,arguments)});var c=BI.createWidget({type:"bi.vertical_adapt",items:[{type:"bi.label",text:"N="},this.filterWidget]});BI.isNumeric(a)&&this.filterWidget.setValue(a);return c},_setNodeData:function(a){var b=this.options;b.node.set("data",BI.extend(b.node.get("data"),a))},getValue:function(){return{targetId:this.options.dId,filterType:this.filterType.getValue()[0],filterValue:this.filterWidget.getValue()}
}});BI.shortcut("bi.dimension_date_field_filter_item",BI.DimensionDateFieldFilterItem);
BI.SelectDimensionDataCombo=BI.inherit(BI.Widget,{_const:{perPage:10},_defaultConfig:function(){return BI.extend(BI.SelectDimensionDataCombo.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-select-dimension-data-combo",height:28,dId:""})},_init:function(){BI.SelectDimensionDataCombo.superclass._init.apply(this,arguments);var a=this,b=this.options;this.combo=BI.createWidget({type:"bi.multi_select_insert_combo",element:this,itemsCreator:BI.bind(this._itemsCreator,this),valueFormatter:function(c){var e=c;
if(BI.isNotNull(c)&&BI.Utils.getDimensionTypeByID(b.dId)===BICst.TARGET_TYPE.DATE&&(c+"").length>4){if(BI.isNumeric(c)){var d=Date.getDate(BI.parseInt(c));e=d.print("%Y-%X-%d")}}return e},width:b.width,height:b.height});this.dimension={name:BI.Utils.getDimensionNameByID(b.dId),_src:BI.Utils.getDimensionSrcByID(b.dId),group:BI.Utils.getDimensionGroupByID(b.dId),sort:BI.Utils.getDimensionSortByID(b.dId),dimensionMap:BI.Utils.getDimensionMapByDimensionID(b.dId)};switch(BI.Utils.getFieldTypeByDimensionID(b.dId)){case BICst.COLUMN.DATE:this.dimension.type=BICst.TARGET_TYPE.DATE;
break;case BICst.COLUMN.NUMBER:this.dimension.type=BICst.TARGET_TYPE.NUMBER;break;case BICst.COLUMN.STRING:this.dimension.type=BICst.TARGET_TYPE.STRING;break}this.combo.on(BI.MultiSelectCombo.EVENT_CONFIRM,function(){a.fireEvent(BI.SelectDimensionDataCombo.EVENT_CONFIRM)})},_convertDateKeywordToLong:function(c,f){var a=c.match(/\d+/g);var g;switch(f){case BICst.GROUP.YS:if(a.length<2||!Date.checkLegal(c)){}else{var e=Date.parseDateTime(c,"%Y-%X-%d");e.setMonth(e.getQuarterStartMonth());g=Date.getTime(e.getFullYear(),e.getMonth(),e.getDate(),e.getHours(),e.getMinutes(),e.getSeconds())
}break;case BICst.GROUP.YM:if(a.length<2||!Date.checkLegal(c)){}else{var e=Date.parseDateTime(c,"%Y-%X");g=Date.getTime(e.getFullYear(),e.getMonth(),e.getDate(),e.getHours(),e.getMinutes(),e.getSeconds())}break;case BICst.GROUP.YW:if(a.length<2||!Date.checkLegal(c)){}else{var e=Date.parseDateTime(c,"%Y-%X-%d");var d=e.getDay();var h=d===0?6:d-1;var b=e.getDate()-h;g=e.setDate(b<1?1:b)}break;case BICst.GROUP.YMD:if(a.length<3||!Date.checkLegal(c)){}else{var e=Date.parseDateTime(c,"%Y-%X-%d");g=Date.getTime(e.getFullYear(),e.getMonth(),e.getDate(),e.getHours(),e.getMinutes(),e.getSeconds())
}break;case BICst.GROUP.YMDH:if(a.length<5||!Date.checkLegal(c)){}else{var e=Date.parseDateTime(c,"%Y-%X-%d %H");g=Date.getTime(e.getFullYear(),e.getMonth(),e.getDate(),e.getHours(),e.getMinutes(),e.getSeconds())}break;case BICst.GROUP.YMDHM:if(a.length<6||!Date.checkLegal(c)){}else{var e=Date.parseDateTime(c,"%Y-%X-%d %H%M");g=Date.getTime(e.getFullYear(),e.getMonth(),e.getDate(),e.getHours(),e.getMinutes(),e.getSeconds())}break;case BICst.GROUP.YMDHMS:if(a.length<7||!Date.checkLegal(c)){}else{var e=Date.parseDateTime(c,"%Y-%X-%d %H%M%S");
g=Date.getTime(e.getFullYear(),e.getMonth(),e.getDate(),e.getHours(),e.getMinutes(),e.getSeconds())}break}return g},_itemsCreator:function(k,i){var b=this.options,j=this;var a={};var g={};a[b.dId]=this.dimension;g[BICst.REGION.DIMENSION1]=[b.dId];var d=BI.Utils.getAllTargetDimensionIDs(BI.Utils.getWidgetIDByDimensionID(b.dId));BI.each(d,function(l,m){a[m]=Data.SharingPool.get("dimensions",m);delete a[m].filterValue;if(!BI.has(g,BICst.REGION.TARGET1)){g[BICst.REGION.TARGET1]=[]}g[BICst.REGION.TARGET1].push(m)
});var h=BI.Utils.getDimensionGroupByID(j.options.dId);var c=[];if(BI.isNotNull(h)&&(h.type===BICst.GROUP.YMD||h.type===BICst.GROUP.YMDH||h.type===BICst.GROUP.YMDHM||h.type===BICst.GROUP.YMDHMS)&&(k.keywords||k.keyword)){var e=(k.keywords||[]).slice();if(k.keyword){e.push(k.keyword)}var f=BI.any(e,function(l,m){var n=j._convertDateKeywordToLong(m,h.type);if(BI.isNull(n)){return true}else{c.push(n)}});if(f){i({items:[]});return}else{k.keywords=c;k.keyword&&delete k.keyword}}BI.Utils.getWidgetDataByWidgetInfo(a,g,function(l){if(k.type==BI.MultiSelectCombo.REQ_GET_ALL_DATA){i({items:j._createItemsByData(l.value)});
return}if(k.type==BI.MultiSelectCombo.REQ_GET_DATA_LENGTH){i({count:l.value});return}i({items:j._createItemsByData(l.value),hasNext:l.hasNext})},{type:BICst.WIDGET.STRING,page:-1,textOptions:k})},_createItemsByData:function(c){var b=this,a=[];BI.each(c,function(d,f){var g=BI.Utils.getDimensionGroupByID(b.options.dId);var e=BI.Utils.getDimensionSettingsByID(b.options.dId).dateFormat||{};if(BI.isNotNull(g)){var h=BI.Func.formatValueByGroupAndFormatter(f,g.type,e.type);a.push({text:h,value:f,title:h})
}else{a.push({text:f,value:f,title:f})}});return a},_assertValue:function(a){a=a||{};a.type=a.type||BI.Selection.Multi;a.value=a.value||[];return a},setValue:function(a){a=this._assertValue(a);this.combo.setValue(a)},getValue:function(){var a=this.combo.getValue()||{};return{type:a.type,value:a.value,assist:(a.assist||[]).slice(0,20)}},populate:function(){this.combo.populate()}});BI.SelectDimensionDataCombo.EVENT_CONFIRM="SelectDimensionDataCombo.EVENT_CONFIRM";BI.shortcut("bi.select_dimension_data_combo",BI.SelectDimensionDataCombo);
BI.SelectFieldDataCombo=BI.inherit(BI.Widget,{_const:{perPage:10},_defaultConfig:function(){return BI.extend(BI.SelectFieldDataCombo.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-select-field-data-combo",height:28,fieldId:""})},_init:function(){BI.SelectFieldDataCombo.superclass._init.apply(this,arguments);var a=this,b=this.options;this.combo=BI.createWidget({type:"bi.multi_select_insert_combo",element:this,itemsCreator:BI.bind(this._itemsCreator,this),width:b.width,height:b.height});
this.func=BI.Utils.getWidgetDataByDimensionInfo({fieldId:b.fieldId});switch(BI.Utils.getFieldTypeByID(b.fieldId)){case BICst.COLUMN.DATE:this.func.setDimensionType(BICst.TARGET_TYPE.DATE);break;case BICst.COLUMN.NUMBER:this.func.setDimensionType(BICst.TARGET_TYPE.NUMBER);break;case BICst.COLUMN.STRING:this.func.setDimensionType(BICst.TARGET_TYPE.STRING);break}this.combo.on(BI.MultiSelectCombo.EVENT_CONFIRM,function(){a.fireEvent(BI.SelectFieldDataCombo.EVENT_CONFIRM)})},_itemsCreator:function(b,d){var c=this.options,a=this;
a.func.setOptions(b);if(b.times===1){a.func.first(function(e){d({items:a._createItemsByData(e.value),hasNext:e.hasNext})});return}if(b.type===BI.MultiSelectCombo.REQ_GET_ALL_DATA){a.func.all(function(e){d({items:a._createItemsByData(e.value),hasNext:e.hasNext})});return}if(b.type===BI.MultiSelectCombo.REQ_GET_DATA_LENGTH){a.func.all(function(e){d({count:e.value})});return}a.func.next(function(e){d({items:a._createItemsByData(e.value),hasNext:e.hasNext})})},_createItemsByData:function(b){var a=[];
BI.each(b,function(c,d){a.push({text:d,value:d,title:d})});return a},_assertValue:function(a){a=a||{};a.type=a.type||BI.Selection.Multi;a.value=a.value||[];return a},setValue:function(a){a=this._assertValue(a);this.combo.setValue(a)},getValue:function(){var a=this.combo.getValue()||{};return{type:a.type,value:a.value,assist:(a.assist||[]).slice(0,20)}},populate:function(){this.combo.populate()}});BI.SelectFieldDataCombo.EVENT_CONFIRM="SelectFieldDataCombo.EVENT_CONFIRM";BI.shortcut("bi.select_field_data_combo",BI.SelectFieldDataCombo);
BI.DimensionNumberFieldFilterItem=BI.inherit(BI.AbstractFilterItem,{_constant:{LEFT_ITEMS_H_GAP:5,CONTAINER_HEIGHT:40,BUTTON_HEIGHT:30,COMBO_WIDTH:130,FIELD_NAME_BUTTON_WIDTH:110,TEXT_BUTTON_H_GAP:10,INPUT_WIDTH:238,N_INPUT_WIDTH:138,WIDGET_WIDTH:240},_defaultConfig:function(){return BI.extend(BI.DimensionNumberFieldFilterItem.superclass._defaultConfig.apply(this,arguments),{extraCls:"bi-dimension-number-field-item",afterValueChange:BI.emptyFn})},_init:function(){BI.DimensionNumberFieldFilterItem.superclass._init.apply(this,arguments);
var a=this,d=this.options;this.isDimension=false;var c=BI.Utils.getWidgetIDByDimensionID(this.options.dId);if(BI.contains(BI.Utils.getAllDimDimensionIDs(c),this.options.dId)){this.isDimension=true}var b=this._buildConditions();this.deleteButton=BI.createWidget({type:"bi.icon_button",cls:"close-h-font"});this.deleteButton.on(BI.Controller.EVENT_CHANGE,function(){a.fireEvent(BI.Controller.EVENT_CHANGE,BI.Events.DESTROY,d.id,a)});BI.createWidget({type:"bi.vertical",element:this,scrolly:false,items:[{el:{type:"bi.left_right_vertical_adapt",height:this._constant.CONTAINER_HEIGHT,items:{left:[b[0],b[1],b[2]],right:[this.deleteButton]},lhgap:this._constant.LEFT_ITEMS_H_GAP,rhgap:this._constant.LEFT_ITEMS_H_GAP}}],scrolly:false})
},populate:function(b,a,c){this.filterType.setValue(c.filterType);this._refreshFilterWidget(c.filterType,c.filterValue)},_checkFilterType:function(){var a=this.options;var b=BI.pluck(BI.flatten(BICst.DIMENSION_FILTER_STRING_COMBO),"value");if(this.isDimension===false){return a.filterType}else{return BI.contains(b,a.filterType)?a.filterType:BICst.DIMENSION_FILTER_STRING.BELONG_VALUE}},_buildConditions:function(){var a=this,b=this.options;b.filterType=this._checkFilterType();if(BI.isNull(b.dId)){return[]
}var c=BI.Utils.getDimensionNameByID(b.dId);this.fieldButton=BI.createWidget({type:"bi.text_button",text:c,title:c,width:this._constant.FIELD_NAME_BUTTON_WIDTH,height:this._constant.BUTTON_HEIGHT,textAlign:"left",hgap:this._constant.TEXT_BUTTON_H_GAP});this.fieldButton.on(BI.Controller.EVENT_CHANGE,function(){arguments[2]=a;a.fireEvent(BI.Controller.EVENT_CHANGE,arguments)});this.filterWidgetContainer=BI.createWidget({type:"bi.left"});this.id=b.id;this.filterType=BI.createWidget({type:"bi.text_value_down_list_combo",width:this._constant.COMBO_WIDTH,height:this._constant.BUTTON_HEIGHT,items:this.isDimension?BICst.DIMENSION_FILTER_STRING_COMBO:BICst.DIMENSION_TAR_FILTER_NUMBER_COMBO});
this.filterType.setValue(b.filterType);this.filterType.on(BI.TextValueDownListCombo.EVENT_CHANGE,function(){a._refreshFilterWidget(a.filterType.getValue()[0]);a._setNodeData({filterType:a.filterType.getValue()[0]});b.afterValueChange.apply(a,arguments)});this._refreshFilterWidget(b.filterType,this.options.filterValue);return[this.fieldButton,this.filterType,this.filterWidgetContainer]},_refreshFilterWidget:function(c,a){var b=BI.createWidget();switch(c){case BICst.DIMENSION_FILTER_STRING.CONTAIN:case BICst.DIMENSION_FILTER_STRING.NOT_CONTAIN:b=this._createStringInput(a);
break;case BICst.DIMENSION_FILTER_STRING.IS_NULL:case BICst.DIMENSION_FILTER_STRING.NOT_NULL:b=this.filterWidget=BI.createWidget();break;case BICst.DIMENSION_FILTER_STRING.BEGIN_WITH:case BICst.DIMENSION_FILTER_STRING.END_WITH:b=this._createStringInput(a);break;case BICst.DIMENSION_FILTER_STRING.TOP_N:case BICst.DIMENSION_FILTER_STRING.BOTTOM_N:b=this._createNInput(a);break;case BICst.DIMENSION_FILTER_STRING.BELONG_VALUE:case BICst.DIMENSION_FILTER_STRING.NOT_BELONG_VALUE:b=this._createStringBelongCombo(a);
break;case BICst.DIMENSION_FILTER_NUMBER.BELONG_VALUE:case BICst.DIMENSION_FILTER_NUMBER.NOT_BELONG_VALUE:b=this._createNumberIntervalFilter(a);break;case BICst.DIMENSION_FILTER_NUMBER.MORE_THAN_AVG:case BICst.DIMENSION_FILTER_NUMBER.LESS_THAN_AVG:case BICst.DIMENSION_FILTER_NUMBER.IS_NULL:case BICst.DIMENSION_FILTER_NUMBER.NOT_NULL:b=this.filterWidget=BI.createWidget();break;case BICst.DIMENSION_FILTER_NUMBER.TOP_N:case BICst.DIMENSION_FILTER_NUMBER.BOTTOM_N:b=this._createNInput(a);break}this.filterWidgetContainer.empty();
this.filterWidgetContainer.addItem(b)},_createStringInput:function(a){var b=this,c=this.options;this.filterWidget=BI.createWidget({type:"bi.sign_editor",cls:"condition-operator-input bi-border",allowBlank:true,height:this._constant.BUTTON_HEIGHT-2,width:this._constant.INPUT_WIDTH});this.filterWidget.on(BI.SignEditor.EVENT_CONFIRM,function(){b._setNodeData({filterValue:this.getValue()});c.afterValueChange.apply(b,arguments)});BI.isNotNull(a)&&this.filterWidget.setValue(a);return this.filterWidget},_createStringBelongCombo:function(a){var c=this.options,b=this;
this.filterWidget=BI.createWidget({type:"bi.select_dimension_data_combo",dId:c.dId,width:this._constant.WIDGET_WIDTH,height:this._constant.BUTTON_HEIGHT});this.filterWidget.on(BI.SelectDimensionDataCombo.EVENT_CONFIRM,function(){b._setNodeData({filterValue:this.getValue()});c.afterValueChange.apply(b,arguments)});BI.isNotNull(a)&&this.filterWidget.setValue(a);return this.filterWidget},_createNumberIntervalFilter:function(a){var b=this,c=this.options;this.filterWidget=BI.createWidget({type:"bi.number_interval",width:this._constant.INPUT_WIDTH,height:this._constant.BUTTON_HEIGHT});
BI.isNotNull(a)&&this.filterWidget.setValue(a);this.filterWidget.on(BI.NumberInterval.EVENT_CHANGE,function(){b._setNodeData({filterValue:this.getValue()});c.afterValueChange.apply(b,arguments)});return this.filterWidget},_createNumberInput:function(a){var b=this,c=this.options;this.filterWidget=BI.createWidget({type:"bi.text_editor",validationChecker:function(d){return BI.isPositiveInteger(d)},errorText:BI.i18nText("BI-Please_Input_Positive_Integer"),allowBlank:true,height:this._constant.BUTTON_HEIGHT,width:this._constant.N_INPUT_WIDTH+2});
this.filterWidget.on(BI.TextEditor.EVENT_CONFIRM,function(){b._setNodeData({filterValue:this.getValue()});c.afterValueChange.apply(b,arguments)});BI.isNotNull(a)&&BI.isNumeric(a)&&this.filterWidget.setValue(a);return this.filterWidget},_createNInput:function(a){this._createNumberInput(a);return BI.createWidget({type:"bi.vertical_adapt",items:[{type:"bi.label",text:"N="},this.filterWidget]})},_setNodeData:function(a){var b=this.options;b.node.set("data",BI.extend(b.node.get("data"),a))},getValue:function(){return{targetId:this.options.dId,filterType:this.filterType.getValue()[0],filterValue:this.filterWidget.getValue()}
}});BI.shortcut("bi.dimension_number_field_filter_item",BI.DimensionNumberFieldFilterItem);
BI.DimensionNoTypeFieldFilterItem=BI.inherit(BI.AbstractFilterItem,{_constant:{LEFT_ITEMS_H_GAP:5,CONTAINER_HEIGHT:40,CONDITION_TYPE_COMBO_ADJUST:2,BUTTON_HEIGHT:30,TEXT_BUTTON_H_GAP:10,ADD_FIELD_POPUP_WIDTH:230,HEIGHT_MAX:10000,MAX_HEIGHT:500},_defaultConfig:function(){return BI.extend(BI.DimensionNoTypeFieldFilterItem.superclass._defaultConfig.apply(this,arguments),{extraCls:"bi-dimension-no-type-field-item",afterValueChange:BI.emptyFn})},_init:function(){BI.DimensionNoTypeFieldFilterItem.superclass._init.apply(this,arguments);
var a=this,c=this.options;var b=this._buildConditionsNoType();this.deleteButton=BI.createWidget({type:"bi.icon_button",cls:"close-h-font"});this.deleteButton.on(BI.Controller.EVENT_CHANGE,function(){a.fireEvent(BI.Controller.EVENT_CHANGE,BI.Events.DESTROY,c.id,a)});this.itemContainer=BI.createWidget({type:"bi.left_right_vertical_adapt",cls:"item-no-type",height:this._constant.CONTAINER_HEIGHT,items:{left:[b],right:[this.deleteButton]},lhgap:this._constant.LEFT_ITEMS_H_GAP,rhgap:this._constant.LEFT_ITEMS_H_GAP});
BI.createWidget({type:"bi.vertical",element:this,items:[this.itemContainer],scrolly:false})},populate:function(){if(BI.isNotNull(this.typeSelectedItem)){this.typeSelectedItem.populate.apply(this.typeSelectedItem,arguments)}},_buildConditionsNoType:function(){var b=this,c=this.options;var a=BI.createWidget({type:"bi.dimension_filter_select_field",height:this._constant.MAX_HEIGHT,dId:c.dId});this.addCondition=BI.createWidget({type:"bi.combo",isNeedAdjustHeight:true,adjustLength:this._constant.CONDITION_TYPE_COMBO_ADJUST,el:{type:"bi.button",level:"common",height:this._constant.BUTTON_HEIGHT,text:BI.i18nText("BI-Please_Select_Field")},popup:{el:a,minHeight:300,minWidth:228,maxHeight:this._constant.MAX_HEIGHT}});
a.on(BI.DimensionFilterSelectField.EVENT_CLICK_ITEM,function(d){b._onTypeSelected(d)});return this.addCondition},_onTypeSelected:function(b){var c=BI.Utils.getDimensionTypeByID(b);var a=this,e=this.options;var d=BI.DimensionFilterItemFactory.createFilterItemByDimensionType(c);this.itemContainer.destroy();this.itemContainer=null;this.typeSelectedItem=BI.createWidget(d,{element:this,id:e.id,dId:b,node:e.node,afterValueChange:e.afterValueChange});this.typeSelectedItem.on(BI.Controller.EVENT_CHANGE,function(){a.fireEvent(BI.Controller.EVENT_CHANGE,arguments)
});e.node.set("data",BI.extend(e.node.get("data"),{value:d.filterType,filterType:d.filterType,dId:b}))},getValue:function(){if(BI.isNotNull(this.typeSelectedItem)){return this.typeSelectedItem.getValue()}return{filterType:BICst.FILTER_TYPE.EMPTY_CONDITION}}});BI.shortcut("bi.dimension_no_type_field_filter_item",BI.DimensionNoTypeFieldFilterItem);
BI.DimensionFormulaFilterItem=BI.inherit(BI.AbstractFilterItem,{_constant:{LEFT_ITEMS_H_GAP:5,CONTAINER_HEIGHT:40,BUTTON_HEIGHT:28,FIELD_NAME_BUTTON_WIDTH:120,ICON_BUTTON_WIDTH:22,TEXT_BUTTON_H_GAP:15},_defaultConfig:function(){return BI.extend(BI.DimensionFormulaFilterItem.superclass._defaultConfig.apply(this,arguments),{extraCls:"bi-analysis-formula-filter-item"})},_init:function(){BI.DimensionFormulaFilterItem.superclass._init.apply(this,arguments);var a=this,c=this.options;this.id=c.id;var b=this._buildFormula(c.filterValue);
this.deleteButton=BI.createWidget({type:"bi.icon_button",cls:"close-h-font",width:this._constant.ICON_BUTTON_WIDTH});this.deleteButton.on(BI.Controller.EVENT_CHANGE,function(){a.fireEvent(BI.Controller.EVENT_CHANGE,BI.Events.DESTROY,c.id,a)});BI.createWidget({type:"bi.vertical",element:this,scrolly:false,items:[{type:"bi.td",columnSize:[this._constant.FIELD_NAME_BUTTON_WIDTH,"",this._constant.ICON_BUTTON_WIDTH],height:this._constant.CONTAINER_HEIGHT,items:[[b[0],b[1],this.deleteButton]]}],scrolly:false})
},populate:function(b,a,c){this.formula.setValue(c.filterValue)},_buildFormula:function(b){var a=this,c=this.options;this.fulfilLabel=BI.createWidget({type:"bi.text_button",text:BI.i18nText("BI-Basic_Fulfil"),width:this._constant.FIELD_NAME_BUTTON_WIDTH,height:this._constant.BUTTON_HEIGHT,textAlign:"left",hgap:this._constant.TEXT_BUTTON_H_GAP});this.fulfilLabel.on(BI.Controller.EVENT_CHANGE,function(){arguments[1]=BI.FilterPane.FILTER_PANE_CLICK_ITEM;arguments[2]=a;a.fireEvent(BI.Controller.EVENT_CHANGE,arguments)
});this.formula=BI.createWidget({type:"bi.formula_combo",cls:"show-label",items:this._getTargetItems()});this.formula.setValue(a.formula.getValue()||b);this.formula.on(BI.FormulaCombo.EVENT_CHANGE,function(){a._setNodeData({filterValue:this.getValue(),formulaIds:this.getFormulaTargetIds()});c.afterValueChange.apply(a,[a.getValue()])});return[this.fulfilLabel,this.formula]},_getTargetItems:function(){var c=this.options.dId,a=[[]];var d=BI.Utils.getWidgetIDByDimensionID(c);var b=BI.Utils.getAllTargetDimensionIDs(d);
BI.each(b,function(f,g){var e=BICst.COLUMN.STRING;switch(BI.Utils.getDimensionTypeByID(g)){case BICst.TARGET_TYPE.STRING:e=BICst.COLUMN.STRING;break;case BICst.TARGET_TYPE.DATE:e=BICst.COLUMN.DATE;break;case BICst.TARGET_TYPE.NUMBER:case BICst.TARGET_TYPE.COUNTER:case BICst.TARGET_TYPE.FORMULA:case BICst.TARGET_TYPE.YEAR_ON_YEAR_RATE:case BICst.TARGET_TYPE.MONTH_ON_MONTH_RATE:case BICst.TARGET_TYPE.YEAR_ON_YEAR_VALUE:case BICst.TARGET_TYPE.MONTH_ON_MONTH_VALUE:case BICst.TARGET_TYPE.SUM_OF_ABOVE:case BICst.TARGET_TYPE.SUM_OF_ABOVE_IN_GROUP:case BICst.TARGET_TYPE.SUM_OF_ALL:case BICst.TARGET_TYPE.SUM_OF_ALL_IN_GROUP:case BICst.TARGET_TYPE.RANK:case BICst.TARGET_TYPE.RANK_IN_GROUP:e=BICst.COLUMN.NUMBER;
break}a[0].push({text:BI.Utils.getDimensionNameByID(g),value:g,fieldType:e})});return a},_setNodeData:function(a){var b=this.options;b.node.set("data",BI.extend(b.node.get("data"),a))},getFilterId:function(){return this.id},getValue:function(){return{id:this.id,filterType:BICst.FILTER_TYPE.FORMULA,filterValue:this.formula.getValue(),formulaIds:this.formula.getFormulaTargetIds()}}});BI.shortcut("bi.dimension_formula_filter_item",BI.DimensionFormulaFilterItem);
BI.TargetFormulaFilterItem=BI.inherit(BI.AbstractFilterItem,{_constant:{LEFT_ITEMS_H_GAP:5,CONTAINER_HEIGHT:40,BUTTON_HEIGHT:28,FIELD_NAME_BUTTON_WIDTH:120,ICON_BUTTON_WIDTH:22,TEXT_BUTTON_H_GAP:15},_defaultConfig:function(){return BI.extend(BI.TargetFormulaFilterItem.superclass._defaultConfig.apply(this,arguments),{extraCls:"bi-analysis-formula-filter-item"})},_init:function(){BI.TargetFormulaFilterItem.superclass._init.apply(this,arguments);var a=this,c=this.options;this.id=c.id;var b=this._buildFormula(c.filterValue);
this.deleteButton=BI.createWidget({type:"bi.icon_button",cls:"close-h-font",width:this._constant.ICON_BUTTON_WIDTH});this.deleteButton.on(BI.Controller.EVENT_CHANGE,function(){a.fireEvent(BI.Controller.EVENT_CHANGE,BI.Events.DESTROY,c.id,a)});BI.createWidget({type:"bi.vertical",element:this,items:[{type:"bi.td",columnSize:[this._constant.FIELD_NAME_BUTTON_WIDTH,"",this._constant.ICON_BUTTON_WIDTH],height:this._constant.CONTAINER_HEIGHT,items:[[b[0],b[1],this.deleteButton]]}],scrolly:false})},populate:function(b,a,c){this.formula.setValue(c.filterValue)
},_buildFormula:function(b){var a=this,c=this.options;this.fulfilLabel=BI.createWidget({type:"bi.text_button",text:BI.i18nText("BI-Basic_Fulfil"),width:this._constant.FIELD_NAME_BUTTON_WIDTH,height:this._constant.BUTTON_HEIGHT,textAlign:"left",hgap:this._constant.TEXT_BUTTON_H_GAP});this.fulfilLabel.on(BI.Controller.EVENT_CHANGE,function(){arguments[1]=BI.FilterPane.FILTER_PANE_CLICK_ITEM;arguments[2]=a;a.fireEvent(BI.Controller.EVENT_CHANGE,arguments)});this.formula=BI.createWidget({type:"bi.formula_combo",cls:"show-label",items:this._getFieldItems()});
this.formula.setValue(a.formula.getValue()||b);this.formula.on(BI.FormulaCombo.EVENT_CHANGE,function(){a._setNodeData({filterValue:this.getValue()});c.afterValueChange.apply(a,[a.getValue()])});return[this.fulfilLabel,this.formula]},_getFieldItems:function(){var b=this.options.fieldId,a=[[],[],[]];var d=BI.Utils.getTableIdByFieldID(b);var c=BI.Utils.getFieldIDsOfTableID(d);BI.each(c,function(g,e){var f=0;switch(BI.Utils.getFieldTypeByID(e)){case BICst.COLUMN.STRING:f=1;break;case BICst.COLUMN.NUMBER:case BICst.COLUMN.COUNTER:f=0;
break;case BICst.COLUMN.DATE:f=2;break}a[f].push({text:BI.Utils.getFieldNameByID(e),value:BICst.FIELD_ID.HEAD+e,fieldType:BI.Utils.getFieldTypeByID(e)})});return a},_setNodeData:function(a){var b=this.options;b.node.set("data",BI.extend(b.node.get("data"),a))},getFilterId:function(){return this.id},getValue:function(){return{id:this.id,filterType:BICst.FILTER_TYPE.FORMULA,filterValue:this.formula.getValue()}}});BI.shortcut("bi.target_formula_filter_item",BI.TargetFormulaFilterItem);
BI.DimensionFormulaEmptyFilterItem=BI.inherit(BI.AbstractFilterItem,{_constant:{LEFT_ITEMS_H_GAP:5,CONTAINER_HEIGHT:40,CONDITION_TYPE_COMBO_ADJUST:2,BUTTON_HEIGHT:28,FORMULA_V_GAP:10,ADD_FORMULA_POPUP_WIDTH:600,FORMULA_H_GAP:20,HEIGHT_MAX:10000,MAX_HEIGHT:500,MAX_WIDTH:600},_defaultConfig:function(){return BI.extend(BI.DimensionFormulaEmptyFilterItem.superclass._defaultConfig.apply(this,arguments),{extraCls:"bi-analysis-formula-empty-filter-item"})},_init:function(){BI.DimensionFormulaEmptyFilterItem.superclass._init.apply(this,arguments);
var a=this,c=this.options;this.id=c.id;var b=this._buildFormulaEmpty();this.container=BI.createWidget({type:"bi.left",items:[b],hgap:this._constant.LEFT_ITEMS_H_GAP});this.deleteButton=BI.createWidget({type:"bi.icon_button",cls:"close-h-font"});this.deleteButton.on(BI.Controller.EVENT_CHANGE,function(){a.fireEvent(BI.Controller.EVENT_CHANGE,BI.Events.DESTROY,c.id,a)});this.itemContainer=BI.createWidget({type:"bi.left_right_vertical_adapt",cls:"item-no-type",height:this._constant.CONTAINER_HEIGHT,items:{left:[this.container],right:[this.deleteButton]},rhgap:this._constant.LEFT_ITEMS_H_GAP});
BI.createWidget({type:"bi.vertical",element:this,items:[this.itemContainer],scrolly:false})},populate:function(){},_buildFormulaEmpty:function(){var c=this,d=this.options;var a=BI.createWidget({type:"bi.formula_combo_popup",fieldItems:this._getTargetItems()});var b=BI.createWidget({type:"bi.combo",isNeedAdjustHeight:true,isNeedAdjustWidth:false,adjustLength:this._constant.CONDITION_TYPE_COMBO_ADJUST,el:{type:"bi.button",level:"common",height:this._constant.BUTTON_HEIGHT,text:BI.i18nText("BI-Edit_Formula")},popup:{el:{type:"bi.absolute",height:this._constant.MAX_HEIGHT,width:this._constant.ADD_FORMULA_POPUP_WIDTH,items:[{el:a,top:this._constant.FORMULA_V_GAP,left:this._constant.FORMULA_H_GAP,right:this._constant.FORMULA_H_GAP,bottom:this._constant.FORMULA_V_GAP}]},stopPropagation:false,maxHeight:this._constant.MAX_HEIGHT,width:this._constant.MAX_WIDTH}});
a.on(BI.FormulaComboPopup.EVENT_CHANGE,function(){c._onEditFormula(b.getValue()[0]);c._setNodeData({value:BICst.FILTER_TYPE.FORMULA,id:c.id,filterType:BICst.FILTER_TYPE.FORMULA,filterValue:c.getValue().filterValue,formulaIds:this.getFormulaTargetIds()});d.afterValueChange.apply(c,[c.getValue()])});a.on(BI.FormulaComboPopup.EVENT_VALUE_CANCEL,function(){b.hideView()});return b},_getTargetItems:function(){var c=this.options.dId,a=[[]];var d=BI.Utils.getWidgetIDByDimensionID(c);var b=BI.Utils.getAllTargetDimensionIDs(d);
BI.each(b,function(f,g){var e=BICst.COLUMN.STRING;switch(BI.Utils.getDimensionTypeByID(g)){case BICst.TARGET_TYPE.STRING:e=BICst.COLUMN.STRING;break;case BICst.TARGET_TYPE.DATE:e=BICst.COLUMN.DATE;break;case BICst.TARGET_TYPE.COUNTER:case BICst.TARGET_TYPE.NUMBER:case BICst.TARGET_TYPE.FORMULA:case BICst.TARGET_TYPE.YEAR_ON_YEAR_RATE:case BICst.TARGET_TYPE.MONTH_ON_MONTH_RATE:case BICst.TARGET_TYPE.YEAR_ON_YEAR_VALUE:case BICst.TARGET_TYPE.MONTH_ON_MONTH_VALUE:case BICst.TARGET_TYPE.SUM_OF_ABOVE:case BICst.TARGET_TYPE.SUM_OF_ABOVE_IN_GROUP:case BICst.TARGET_TYPE.SUM_OF_ALL:case BICst.TARGET_TYPE.SUM_OF_ALL_IN_GROUP:case BICst.TARGET_TYPE.RANK:case BICst.TARGET_TYPE.RANK_IN_GROUP:e=BICst.COLUMN.NUMBER;
break}a[0].push({text:BI.Utils.getDimensionNameByID(g),value:g,fieldType:e})});return a},_onEditFormula:function(b){this.itemContainer.destroy();this.itemContainer=null;var c=this.options,a=this;this.formulaItem=BI.createWidget({type:"bi.dimension_formula_filter_item",element:this,id:this.options.id,dId:this.options.dId,fieldId:this.options.fieldId,filterType:BICst.FILTER_TYPE.FORMULA,filterValue:b,node:c.node,afterValueChange:c.afterValueChange});this.formulaItem.on(BI.Controller.EVENT_CHANGE,function(){a.fireEvent(BI.Controller.EVENT_CHANGE,arguments)
})},_setNodeData:function(a){var b=this.options;b.node.set("data",BI.extend(b.node.get("data"),a))},getFilterId:function(){return this.id},getValue:function(){if(BI.isNotNull(this.formulaItem)){return this.formulaItem.getValue()}return{id:this.id,filterType:BICst.FILTER_TYPE.EMPTY_FORMULA}}});BI.shortcut("bi.dimension_formula_empty_filter_item",BI.DimensionFormulaEmptyFilterItem);
BI.TargetFormulaEmptyFilterItem=BI.inherit(BI.AbstractFilterItem,{_constant:{LEFT_ITEMS_H_GAP:5,CONTAINER_HEIGHT:40,CONDITION_TYPE_COMBO_ADJUST:2,BUTTON_HEIGHT:28,FORMULA_V_GAP:10,ADD_FORMULA_POPUP_WIDTH:600,FORMULA_H_GAP:20,HEIGHT_MAX:10000,MAX_HEIGHT:500,MAX_WIDTH:600},_defaultConfig:function(){return BI.extend(BI.TargetFormulaEmptyFilterItem.superclass._defaultConfig.apply(this,arguments),{extraCls:"bi-analysis-formula-empty-filter-item"})},_init:function(){BI.TargetFormulaEmptyFilterItem.superclass._init.apply(this,arguments);
var a=this,c=this.options;this.id=c.id;var b=this._buildFormulaEmpty();this.container=BI.createWidget({type:"bi.left",items:[b],hgap:this._constant.LEFT_ITEMS_H_GAP});this.deleteButton=BI.createWidget({type:"bi.icon_button",cls:"close-h-font"});this.deleteButton.on(BI.Controller.EVENT_CHANGE,function(){a.fireEvent(BI.Controller.EVENT_CHANGE,BI.Events.DESTROY,c.id,a)});this.itemContainer=BI.createWidget({type:"bi.left_right_vertical_adapt",cls:"item-no-type",height:this._constant.CONTAINER_HEIGHT,items:{left:[this.container],right:[this.deleteButton]},rhgap:this._constant.LEFT_ITEMS_H_GAP});
BI.createWidget({type:"bi.vertical",element:this,items:[this.itemContainer],scrolly:false})},populate:function(){},_buildFormulaEmpty:function(){var c=this,d=this.options;var a=BI.createWidget({type:"bi.formula_combo_popup",fieldItems:this._getFieldItems()});var b=BI.createWidget({type:"bi.combo",isNeedAdjustHeight:true,isNeedAdjustWidth:false,adjustLength:this._constant.CONDITION_TYPE_COMBO_ADJUST,el:{type:"bi.button",level:"common",height:this._constant.BUTTON_HEIGHT,text:BI.i18nText("BI-Edit_Formula")},popup:{el:{type:"bi.absolute",height:this._constant.MAX_HEIGHT,width:this._constant.ADD_FORMULA_POPUP_WIDTH,items:[{el:a,top:this._constant.FORMULA_V_GAP,left:this._constant.FORMULA_H_GAP,right:this._constant.FORMULA_H_GAP,bottom:this._constant.FORMULA_V_GAP}]},stopPropagation:false,maxHeight:this._constant.MAX_HEIGHT,width:this._constant.MAX_WIDTH}});
a.on(BI.FormulaComboPopup.EVENT_CHANGE,function(){c._onEditFormula(b.getValue()[0]);c._setNodeData({value:BICst.FILTER_TYPE.FORMULA,id:c.id,filterType:BICst.FILTER_TYPE.FORMULA,filterValue:c.getValue().filterValue});d.afterValueChange.apply(c,[c.getValue()])});a.on(BI.FormulaComboPopup.EVENT_VALUE_CANCEL,function(){b.hideView()});return b},_getFieldItems:function(){var b=this.options.fieldId,a=[[],[],[]];var d=BI.Utils.getTableIdByFieldID(b);var c=BI.Utils.getFieldIDsOfTableID(d);BI.each(c,function(g,e){var f=0;
switch(BI.Utils.getFieldTypeByID(e)){case BICst.COLUMN.STRING:f=1;break;case BICst.COLUMN.NUMBER:case BICst.COLUMN.COUNTER:f=0;break;case BICst.COLUMN.DATE:f=2;break}a[f].push({text:BI.Utils.getFieldNameByID(e),value:BICst.FIELD_ID.HEAD+e,fieldType:BI.Utils.getFieldTypeByID(e)})});return a},_onEditFormula:function(b){this.itemContainer.destroy();this.itemContainer=null;var c=this.options,a=this;this.formulaItem=BI.createWidget({type:"bi.target_formula_filter_item",element:this,id:this.options.id,dId:this.options.dId,fieldId:this.options.fieldId,filterType:BICst.FILTER_TYPE.FORMULA,filterValue:b,node:c.node,afterValueChange:c.afterValueChange});
this.formulaItem.on(BI.Controller.EVENT_CHANGE,function(){a.fireEvent(BI.Controller.EVENT_CHANGE,arguments)})},_setNodeData:function(a){var b=this.options;b.node.set("data",BI.extend(b.node.get("data"),a))},getFilterId:function(){return this.id},getValue:function(){if(BI.isNotNull(this.formulaItem)){return this.formulaItem.getValue()}return{id:this.id,filterType:BICst.FILTER_TYPE.EMPTY_FORMULA}}});BI.shortcut("bi.target_formula_empty_filter_item",BI.TargetFormulaEmptyFilterItem);
BI.AuthorityNoTypeFieldFilterItem=BI.inherit(BI.AbstractFilterItem,{_constant:{LEFT_ITEMS_H_GAP:5,CONTAINER_HEIGHT:40,CONDITION_TYPE_COMBO_ADJUST:2,BUTTON_HEIGHT:30,TEXT_BUTTON_H_GAP:10,ADD_FIELD_POPUP_WIDTH:230,HEIGHT_MAX:10000,MAX_HEIGHT:500},_defaultConfig:function(){return BI.extend(BI.AuthorityNoTypeFieldFilterItem.superclass._defaultConfig.apply(this,arguments),{extraCls:"bi-authority-no-type-field-item",afterValueChange:BI.emptyFn})},_init:function(){BI.AuthorityNoTypeFieldFilterItem.superclass._init.apply(this,arguments);
var a=this,c=this.options;var b=this._buildConditionsNoType();this.deleteButton=BI.createWidget({type:"bi.icon_button",cls:"close-h-font"});this.deleteButton.on(BI.Controller.EVENT_CHANGE,function(){a.fireEvent(BI.Controller.EVENT_CHANGE,BI.Events.DESTROY,c.id,a)});this.itemContainer=BI.createWidget({type:"bi.left_right_vertical_adapt",cls:"item-no-type",height:this._constant.CONTAINER_HEIGHT,items:{left:[b],right:[this.deleteButton]},lhgap:this._constant.LEFT_ITEMS_H_GAP,rhgap:this._constant.LEFT_ITEMS_H_GAP});
BI.createWidget({type:"bi.vertical",element:this,items:[this.itemContainer]})},populate:function(){if(BI.isNotNull(this.typeSelectedItem)){this.typeSelectedItem.populate.apply(this.typeSelectedItem,arguments)}},_buildConditionsNoType:function(){var b=this,c=this.options;var a=BI.createWidget({type:"bi.authority_select_data",height:this._constant.MAX_HEIGHT});this.addCondition=BI.createWidget({type:"bi.combo",isNeedAdjustHeight:true,adjustLength:this._constant.CONDITION_TYPE_COMBO_ADJUST,el:{type:"bi.button",level:"common",height:this._constant.BUTTON_HEIGHT,text:BI.i18nText("BI-Please_Select_Field")},popup:{el:a,minWidth:228,maxHeight:this._constant.MAX_HEIGHT}});
a.on(BI.AuthoritySelectData.EVENT_CONFIRM,function(d){b._onTypeSelected(d)});return this.addCondition},_onTypeSelected:function(b){var a=this,d=this.options;var c=BI.AuthorityFilterItemFactory.createFilterItemByFieldType(b.fieldType);this.itemContainer.destroy();this.itemContainer=null;this.typeSelectedItem=BI.createWidget(c,{element:this,_src:{fieldId:b.id},field:b,id:d.id,node:d.node,afterValueChange:d.afterValueChange});this.typeSelectedItem.on(BI.Controller.EVENT_CHANGE,function(){a.fireEvent(BI.Controller.EVENT_CHANGE,arguments)
});d.node.set("data",BI.extend(d.node.get("data"),{value:c.filterType,filterType:c.filterType,_src:{fieldId:b.id},field:b}))},getValue:function(){if(BI.isNotNull(this.typeSelectedItem)){return this.typeSelectedItem.getValue()}return{filterType:BICst.FILTER_TYPE.EMPTY_CONDITION}}});BI.shortcut("bi.authority_no_type_field_filter_item",BI.AuthorityNoTypeFieldFilterItem);
BI.AuthorityStringFieldFilterItem=BI.inherit(BI.AbstractFilterItem,{_constant:{LEFT_ITEMS_H_GAP:5,CONTAINER_HEIGHT:40,BUTTON_HEIGHT:30,COMBO_WIDTH:130,FIELD_NAME_BUTTON_WIDTH:90,TEXT_BUTTON_H_GAP:10,INPUT_WIDTH:200,DATA_TYPE_ERROR:"number-error"},_defaultConfig:function(){return BI.extend(BI.AuthorityStringFieldFilterItem.superclass._defaultConfig.apply(this,arguments),{extraCls:"bi-dimension-string-field-item",afterValueChange:BI.emptyFn})},_init:function(){BI.AuthorityStringFieldFilterItem.superclass._init.apply(this,arguments);
var a=this,c=this.options;var b=this._buildConditions();this.deleteButton=BI.createWidget({type:"bi.icon_button",cls:"close-h-font"});this.deleteButton.on(BI.Controller.EVENT_CHANGE,function(){a.fireEvent(BI.Controller.EVENT_CHANGE,BI.Events.DESTROY,c.id,a)});BI.createWidget({type:"bi.vertical",element:this,items:[{type:"bi.left_right_vertical_adapt",height:this._constant.CONTAINER_HEIGHT,items:{left:[b[0],b[1],b[2]],right:[this.deleteButton]},lhgap:this._constant.LEFT_ITEMS_H_GAP,rhgap:this._constant.LEFT_ITEMS_H_GAP}]})
},populate:function(b,a,c){this.filterType.setValue(c.filterType);this._refreshFilterWidget(c.filterType,c.filterValue)},_buildConditions:function(){var a=this,b=this.options;if(BI.isNull(b._src)){return[]}var c=BI.AuthorityFilterItemFactory.getFilterItemTextById(b.field);this.fieldButton=BI.createWidget({type:"bi.text_button",text:c,title:c,width:this._constant.FIELD_NAME_BUTTON_WIDTH,height:this._constant.BUTTON_HEIGHT,textAlign:"left",hgap:this._constant.TEXT_BUTTON_H_GAP});this.fieldButton.on(BI.Controller.EVENT_CHANGE,function(){arguments[2]=a;
a.fireEvent(BI.Controller.EVENT_CHANGE,arguments)});this.filterWidgetContainer=BI.createWidget({type:"bi.left"});this.id=b.id;this.filterType=BI.createWidget({type:"bi.text_value_down_list_combo",width:this._constant.COMBO_WIDTH,height:this._constant.BUTTON_HEIGHT,items:BICst.AUTHORITY_FILTER_STRING_COMBO});this.filterType.setValue(b.filterType);this.filterType.on(BI.TextValueDownListCombo.EVENT_CHANGE,function(){a._refreshFilterWidget(a.filterType.getValue()[0]);a._setNodeData({filterType:this.getValue()[0]});
b.afterValueChange.apply(a,arguments)});this._refreshFilterWidget(b.filterType,b.filterValue);return[this.fieldButton,this.filterType,this.filterWidgetContainer]},_refreshFilterWidget:function(b,a){switch(b){case BICst.TARGET_FILTER_STRING.BELONG_VALUE:case BICst.TARGET_FILTER_STRING.NOT_BELONG_VALUE:this._createTargetStringBelongCombo(a);break;case BICst.TARGET_FILTER_STRING.BELONG_USER:case BICst.TARGET_FILTER_STRING.NOT_BELONG_USER:this._createLoginInfoCombo(a);break;case BICst.TARGET_FILTER_STRING.CONTAIN:case BICst.TARGET_FILTER_STRING.NOT_CONTAIN:this._createStringInput(a);
break;case BICst.TARGET_FILTER_STRING.IS_NULL:case BICst.TARGET_FILTER_STRING.NOT_NULL:this.filterWidget=BI.createWidget();break;case BICst.TARGET_FILTER_STRING.BEGIN_WITH:case BICst.TARGET_FILTER_STRING.END_WITH:this._createStringInput(a);break}this.filterWidgetContainer.empty();this.filterWidgetContainer.addItem(this.filterWidget)},_createTargetStringBelongCombo:function(a){var b=this,c=this.options;this.filterWidget=BI.createWidget({type:"bi.authority_select_field_data_combo",fieldId:c._src.fieldId,width:200,height:this._constant.BUTTON_HEIGHT});
this.filterWidget.on(BI.AuthoritySelectFieldDataCombo.EVENT_CONFIRM,function(){b._setNodeData({filterValue:this.getValue()});c.afterValueChange.apply(b,arguments)});BI.isNotNull(a)&&this.filterWidget.setValue(a);return this.filterWidget},_createLoginInfoCombo:function(a){var b=this,c=this.options;this.filterWidget=BI.createWidget({type:"bi.login_info_combo",fieldType:BICst.COLUMN.STRING,width:200,height:this._constant.BUTTON_HEIGHT});this.filterWidget.on(BI.LoginInfoCombo.EVENT_CHANGE,function(){b._setNodeData({filterValue:this.getValue()});
c.afterValueChange.apply(b,arguments)});BI.isNotNull(a)&&this.filterWidget.setValue(a);return this.filterWidget},_createStringInput:function(a){var b=this,c=this.options;this.filterWidget=BI.createWidget({type:"bi.sign_editor",cls:"condition-operator-input bi-border",allowBlank:true,height:this._constant.BUTTON_HEIGHT-2,width:this._constant.INPUT_WIDTH-2});this.filterWidget.on(BI.SignEditor.EVENT_CONFIRM,function(){b._setNodeData({filterValue:this.getValue()});c.afterValueChange.apply(b,arguments)
});BI.isNotNull(a)&&this.filterWidget.setValue(a);return this.filterWidget},_setNodeData:function(a){var b=this.options;b.node.set("data",BI.extend(b.node.get("data"),a))},getValue:function(){return{_src:this.options._src,field:this.options.field,filterType:this.filterType.getValue()[0],filterValue:this.filterWidget.getValue()}}});BI.shortcut("bi.authority_string_field_filter_item",BI.AuthorityStringFieldFilterItem);
BI.AuthorityNumberFieldFilterItem=BI.inherit(BI.AbstractFilterItem,{_constant:{LEFT_ITEMS_H_GAP:5,CONTAINER_HEIGHT:40,BUTTON_HEIGHT:30,COMBO_WIDTH:130,FIELD_NAME_BUTTON_WIDTH:90,TEXT_BUTTON_H_GAP:10,INPUT_WIDTH:230},_defaultConfig:function(){return BI.extend(BI.AuthorityNumberFieldFilterItem.superclass._defaultConfig.apply(this,arguments),{extraCls:"bi-dimension-number-field-item",afterValueChange:BI.emptyFn})},_init:function(){BI.AuthorityNumberFieldFilterItem.superclass._init.apply(this,arguments);
var a=this,c=this.options;var b=this._buildConditions();this.deleteButton=BI.createWidget({type:"bi.icon_button",cls:"close-h-font"});this.deleteButton.on(BI.Controller.EVENT_CHANGE,function(){a.fireEvent(BI.Controller.EVENT_CHANGE,BI.Events.DESTROY,c.id,a)});BI.createWidget({type:"bi.vertical",element:this,items:[{el:{type:"bi.left_right_vertical_adapt",height:this._constant.CONTAINER_HEIGHT,items:{left:[b[0],b[1],b[2]],right:[this.deleteButton]},lhgap:this._constant.LEFT_ITEMS_H_GAP,rhgap:this._constant.LEFT_ITEMS_H_GAP}}]})
},populate:function(b,a,c){this.filterType.setValue(c.filterType);this._refreshFilterWidget(c.filterType,c.filterValue)},_buildConditions:function(){var a=this,b=this.options;if(BI.isNull(b._src)){return[]}this.fieldId=b._src.fieldId;var c=BI.AuthorityFilterItemFactory.getFilterItemTextById(b.field);this.fieldButton=BI.createWidget({type:"bi.text_button",text:c,title:c,width:this._constant.FIELD_NAME_BUTTON_WIDTH,height:this._constant.BUTTON_HEIGHT,textAlign:"left",hgap:this._constant.TEXT_BUTTON_H_GAP});
this.fieldButton.on(BI.Controller.EVENT_CHANGE,function(){arguments[2]=a;a.fireEvent(BI.Controller.EVENT_CHANGE,arguments)});this.filterWidgetContainer=BI.createWidget({type:"bi.left"});this.id=b.id;this.filterType=BI.createWidget({type:"bi.text_value_down_list_combo",width:this._constant.COMBO_WIDTH,height:this._constant.BUTTON_HEIGHT,items:BICst.AUTHORITY_FILTER_NUMBER_COMBO});this.filterType.setValue(b.filterType);this.filterType.on(BI.TextValueDownListCombo.EVENT_CHANGE,function(){a._refreshFilterWidget(a.filterType.getValue()[0]);
a._setNodeData({filterType:a.filterType.getValue()[0]});b.afterValueChange.apply(a,arguments)});this._refreshFilterWidget(b.filterType,this.options.filterValue);return[this.fieldButton,this.filterType,this.filterWidgetContainer]},_refreshFilterWidget:function(b,a){switch(b){case BICst.TARGET_FILTER_NUMBER.EQUAL_TO:case BICst.TARGET_FILTER_NUMBER.NOT_EQUAL_TO:this._createNumberInput(a);break;case BICst.TARGET_FILTER_NUMBER.BELONG_VALUE:case BICst.TARGET_FILTER_NUMBER.NOT_BELONG_VALUE:this._createNumberIntervalFilter(a);
break;case BICst.TARGET_FILTER_NUMBER.BELONG_USER:case BICst.TARGET_FILTER_NUMBER.NOT_BELONG_USER:this._createLoginInfoCombo(a);break;case BICst.TARGET_FILTER_NUMBER.IS_NULL:case BICst.TARGET_FILTER_NUMBER.NOT_NULL:this.filterWidget=BI.createWidget();break}this.filterWidgetContainer.empty();this.filterWidgetContainer.addItem(this.filterWidget)},_createNumberIntervalFilter:function(a){var b=this,c=this.options;this.filterWidget=BI.createWidget({type:"bi.number_interval",width:this._constant.INPUT_WIDTH,height:this._constant.BUTTON_HEIGHT});
BI.isNotNull(a)&&this.filterWidget.setValue(a);this.filterWidget.on(BI.NumberInterval.EVENT_CHANGE,function(){b._setNodeData({filterValue:this.getValue()});c.afterValueChange.apply(b,arguments)});return this.filterWidget},_createNumberInput:function(a){var b=this,c=this.options;this.filterWidget=BI.createWidget({type:"bi.text_editor",validationChecker:function(){if(!BI.isNumeric(b.filterWidget.getValue())){return false}},errorText:BI.i18nText("BI-Numerical_Interval_Input_Data"),allowBlank:true,height:this._constant.BUTTON_HEIGHT,width:this._constant.INPUT_WIDTH});
this.filterWidget.on(BI.TextEditor.EVENT_CONFIRM,function(){b._setNodeData({filterValue:this.getValue()});c.afterValueChange.apply(b,arguments)});BI.isNotNull(a)&&this.filterWidget.setValue(a);return BI.createWidget({type:"bi.left",items:[{type:"bi.label",height:this._constant.BUTTON_HEIGHT,text:"N = "},this.filterWidget]})},_createLoginInfoCombo:function(a){var b=this,c=this.options;this.filterWidget=BI.createWidget({type:"bi.login_info_combo",fieldType:BICst.COLUMN.NUMBER,width:200,height:this._constant.BUTTON_HEIGHT});
this.filterWidget.on(BI.LoginInfoCombo.EVENT_CHANGE,function(){b._setNodeData({filterValue:this.getValue()});c.afterValueChange.apply(b,arguments)});BI.isNotNull(a)&&this.filterWidget.setValue(a);return this.filterWidget},_setNodeData:function(a){var b=this.options;b.node.set("data",BI.extend(b.node.get("data"),a))},getValue:function(){return{_src:this.options._src,field:this.options.field,filterType:this.filterType.getValue()[0],filterValue:this.filterWidget.getValue()}}});BI.shortcut("bi.authority_number_field_filter_item",BI.AuthorityNumberFieldFilterItem);
BI.AuthorityDateFieldFilterItem=BI.inherit(BI.AbstractFilterItem,{_constant:{LEFT_ITEMS_H_GAP:5,CONTAINER_HEIGHT:40,BUTTON_HEIGHT:30,COMBO_WIDTH:130,FIELD_NAME_BUTTON_WIDTH:90,TEXT_BUTTON_H_GAP:10,INPUT_WIDTH:230},_defaultConfig:function(){return BI.extend(BI.AuthorityDateFieldFilterItem.superclass._defaultConfig.apply(this,arguments),{extraCls:"bi-authority-date-field-item",afterValueChange:BI.emptyFn})},_init:function(){BI.AuthorityDateFieldFilterItem.superclass._init.apply(this,arguments);var a=this,c=this.options;
var b=this._buildConditions();this.deleteButton=BI.createWidget({type:"bi.icon_button",cls:"close-h-font"});this.deleteButton.on(BI.Controller.EVENT_CHANGE,function(){a.fireEvent(BI.Controller.EVENT_CHANGE,BI.Events.DESTROY,c.id,a)});BI.createWidget({type:"bi.vertical",element:this,items:[{el:{type:"bi.left_right_vertical_adapt",height:this._constant.CONTAINER_HEIGHT,items:{left:[b[0],b[1],b[2]],right:[this.deleteButton]},lhgap:this._constant.LEFT_ITEMS_H_GAP,rhgap:this._constant.LEFT_ITEMS_H_GAP}}]})
},populate:function(b,a,c){this.filterType.setValue(c.filterType);this._refreshFilterWidget(c.filterType,c.filterValue)},_buildConditions:function(){var a=this,b=this.options;if(BI.isNull(b._src)){return[]}var c=BI.AuthorityFilterItemFactory.getFilterItemTextById(b.field);this.fieldButton=BI.createWidget({type:"bi.text_button",text:c,title:c,width:this._constant.FIELD_NAME_BUTTON_WIDTH,height:this._constant.BUTTON_HEIGHT,textAlign:"left",hgap:this._constant.TEXT_BUTTON_H_GAP});this.fieldButton.on(BI.Controller.EVENT_CHANGE,function(){arguments[2]=a;
a.fireEvent(BI.Controller.EVENT_CHANGE,arguments)});this.filterWidgetContainer=BI.createWidget({type:"bi.left"});this.id=b.id;this.filterType=BI.createWidget({type:"bi.text_value_down_list_combo",width:this._constant.COMBO_WIDTH,height:this._constant.BUTTON_HEIGHT,items:BICst.AUTH_FILTER_DATE_COMBO});this.filterType.setValue(b.filterType);this.filterType.on(BI.TextValueDownListCombo.EVENT_CHANGE,function(){a._refreshFilterWidget(a.filterType.getValue()[0]);a._setNodeData({filterType:this.getValue()[0]});
b.afterValueChange.apply(a,arguments)});this._refreshFilterWidget(b.filterType,b.filterValue);return[this.fieldButton,this.filterType,this.filterWidgetContainer]},_refreshFilterWidget:function(a,b){switch(a){case BICst.FILTER_DATE.BELONG_DATE_RANGE:case BICst.FILTER_DATE.NOT_BELONG_DATE_RANGE:this._createTimeRange(b);break;case BICst.FILTER_DATE.BELONG_WIDGET_VALUE:case BICst.FILTER_DATE.NOT_BELONG_WIDGET_VALUE:this._createWidgetTab([BICst.WIDGET.DATE,BICst.WIDGET.YEAR,BICst.WIDGET.QUARTER,BICst.WIDGET.MONTH,BICst.WIDGET.YMD],b);
break;case BICst.FILTER_DATE.LATER_THAN:case BICst.FILTER_DATE.EARLY_THAN:this._createWidgetTab([BICst.WIDGET.YMD],b);break;case BICst.FILTER_DATE.EQUAL_TO:case BICst.FILTER_DATE.NOT_EQUAL_TO:this._createDate(b);break;case BICst.FILTER_DATE.IS_NULL:case BICst.FILTER_DATE.NOT_NULL:this.filterWidget=BI.createWidget();break}this.filterWidgetContainer.empty();this.filterWidgetContainer.addItem(this.filterWidget)},_createWidgetTab:function(b,c){var a=this,d=this.options;this.filterWidget=BI.createWidget({type:"bi.target_date_tab",dateWidgetType:b});
this.filterWidget.on(BI.Tab.EVENT_CHANGE,function(){a._setNodeData({filterValue:this.getValue()});d.afterValueChange.apply(a,arguments)});this.filterWidget.on(BI.TargetDateTab.EVENT_SHOW_CARD_VALUE_CHANGE,function(){a._setNodeData({filterValue:this.getValue()});d.afterValueChange.apply(a,arguments)});if(BI.isNotNull(c)){this.filterWidget.setValue(c)}},_createTimeRange:function(b){var a=this,c=this.options;this.filterWidget=BI.createWidget({type:"bi.custom_time_interval",width:this._constant.INPUT_WIDTH,height:this._constant.TIME_INTERVAL_HEIGHT});
this.filterWidget.on(BI.CustomTimeInterval.EVENT_CHANGE,function(){a._setNodeData({filterValue:this.getValue()});c.afterValueChange.apply(a,arguments)});if(BI.isNotNull(b)){this.filterWidget.setValue(b)}},_createDate:function(b){var a=this,c=this.options;this.filterWidget=BI.createWidget({type:"bi.custom_multi_date_combo",width:this._constant.INPUT_WIDTH});this.filterWidget.on(BI.CustomMultiDateCombo.EVENT_CHANGE,function(){a._setNodeData({filterValue:this.getValue()});c.afterValueChange.apply(a,arguments)
});if(BI.isNotNull(b)){this.filterWidget.setValue(b)}},_setNodeData:function(a){var b=this.options;b.node.set("data",BI.extend(b.node.get("data"),a))},getValue:function(){return{_src:this.options._src,field:this.options.field,filterType:this.filterType.getValue()[0],filterValue:this.filterWidget.getValue()}}});BI.shortcut("bi.authority_date_field_filter_item",BI.AuthorityDateFieldFilterItem);
BI.AuthoritySelectData=BI.inherit(BI.Pane,{_defaultConfig:function(){return BI.extend(BI.AuthoritySelectData.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-authority-select-data",height:30,dId:""})},_init:function(){BI.AuthoritySelectData.superclass._init.apply(this,arguments);var a=this;this.loading();BI.Utils.getData4SelectField4Conf(function(b){a.cacheData=b;a.selectDataPane=BI.createWidget({type:"bi.package_select_data_service",element:a,showRelativeTables:false,showExcelView:false,showDateGroup:false,packageCreator:function(){return BI.Utils.getAllGroupedPackagesTree(b.groups,b.packages)
},tablesCreator:function(c){return a._getTablesStructureByPackId(c)},fieldsCreator:function(d,c){return a._getFieldsStructureByTableId(d)}});a.selectDataPane.on(BI.PackageSelectDataService.EVENT_CLICK_ITEM,function(){a.fireEvent(BI.AuthoritySelectData.EVENT_CONFIRM,arguments)});a.selectDataPane.setPackage(BI.keys(b.packages)[0])},function(){a.loaded()})},_getTableIdByPackageId:function(a){var b=this.cacheData.packages;var c=[];BI.each(b[a].tables,function(d,e){c.push(e.id)});return c},_getTablesStructureByPackId:function(e){var b=this;
var d=[];var a=this.cacheData.translations;var c=b._getTableIdByPackageId(e);BI.each(c,function(f,g){d.push({id:g,type:"bi.select_data_level_node",text:a[g],value:g,isParent:true,open:false,title:a[g]})});return d},_getFieldsStructureByTableId:function(c){var d=[];var a=this.cacheData.fields;var b=this.cacheData.translations;BI.each(a,function(e,f){if(c===f.tableId){var g=b[f.id]||f.fieldName;f.fieldTranName=g;d.push({id:f.id,pId:c,type:"bi.select_data_level_item",fieldType:f.fieldType,text:g,title:g,value:f})
}});return d}});BI.AuthoritySelectData.EVENT_CONFIRM="AuthoritySelectData.EVENT_CONFIRM";BI.shortcut("bi.authority_select_data",BI.AuthoritySelectData);
BI.AuthorityFilterItemFactory={createFilterItemByFieldType:function(a){var c,b;switch(a){case BICst.COLUMN.STRING:c=BICst.TARGET_FILTER_STRING.BELONG_VALUE;b="bi.authority_string_field_filter_item";break;case BICst.COLUMN.NUMBER:case BICst.COLUMN.COUNTER:c=BICst.TARGET_FILTER_NUMBER.BELONG_VALUE;b="bi.authority_number_field_filter_item";break;case BICst.COLUMN.DATE:c=BICst.FILTER_DATE.BELONG_DATE_RANGE;b="bi.authority_date_field_filter_item";break;default:b="bi.authority_no_type_field_filter_item";
break}return{type:b,filterType:c}},createFilterItemByFilterType:function(b){var a="";switch(b){case BICst.TARGET_FILTER_STRING.BELONG_VALUE:case BICst.TARGET_FILTER_STRING.NOT_BELONG_VALUE:case BICst.TARGET_FILTER_STRING.BELONG_USER:case BICst.TARGET_FILTER_STRING.NOT_BELONG_USER:case BICst.TARGET_FILTER_STRING.CONTAIN:case BICst.TARGET_FILTER_STRING.NOT_CONTAIN:case BICst.TARGET_FILTER_STRING.IS_NULL:case BICst.TARGET_FILTER_STRING.NOT_NULL:case BICst.TARGET_FILTER_STRING.BEGIN_WITH:case BICst.TARGET_FILTER_STRING.END_WITH:case BICst.TARGET_FILTER_STRING.NOT_BEGIN_WITH:case BICst.TARGET_FILTER_STRING.NOT_END_WITH:a="bi.authority_string_field_filter_item";
break;case BICst.TARGET_FILTER_NUMBER.EQUAL_TO:case BICst.TARGET_FILTER_NUMBER.NOT_EQUAL_TO:case BICst.TARGET_FILTER_NUMBER.BELONG_VALUE:case BICst.TARGET_FILTER_NUMBER.NOT_BELONG_VALUE:case BICst.TARGET_FILTER_NUMBER.BELONG_USER:case BICst.TARGET_FILTER_NUMBER.NOT_BELONG_USER:case BICst.TARGET_FILTER_NUMBER.IS_NULL:case BICst.TARGET_FILTER_NUMBER.NOT_NULL:case BICst.TARGET_FILTER_NUMBER.LARGE_THAN_CAL_LINE:case BICst.TARGET_FILTER_NUMBER.LARGE_OR_EQUAL_CAL_LINE:case BICst.TARGET_FILTER_NUMBER.SMALL_THAN_CAL_LINE:case BICst.TARGET_FILTER_NUMBER.SMALL_OR_EQUAL_CAL_LINE:case BICst.TARGET_FILTER_NUMBER.TOP_N:case BICst.TARGET_FILTER_NUMBER.BOTTOM_N:a="bi.authority_number_field_filter_item";
break;case BICst.FILTER_DATE.BELONG_DATE_RANGE:case BICst.FILTER_DATE.NOT_BELONG_DATE_RANGE:case BICst.FILTER_DATE.BELONG_WIDGET_VALUE:case BICst.FILTER_DATE.NOT_BELONG_WIDGET_VALUE:case BICst.FILTER_DATE.LATER_THAN:case BICst.FILTER_DATE.EARLY_THAN:case BICst.FILTER_DATE.EQUAL_TO:case BICst.FILTER_DATE.NOT_EQUAL_TO:case BICst.FILTER_DATE.IS_NULL:case BICst.FILTER_DATE.NOT_NULL:a="bi.authority_date_field_filter_item";break;case BICst.FILTER_TYPE.AND:case BICst.FILTER_TYPE.OR:a="bi.filter_expander";
break;case BICst.FILTER_TYPE.EMPTY_CONDITION:a="bi.authority_no_type_field_filter_item";break;default:a="bi.authority_no_type_field_filter_item";break}return{type:a}},getFilterItemTextById:function(b){var a=b.tableTranName||b.tableId;return a+"."+(b.fieldTranName||b.fieldName)}};
BI.AuthoritySelectFieldDataCombo=BI.inherit(BI.Widget,{_const:{perPage:10},_defaultConfig:function(){return BI.extend(BI.SelectFieldDataCombo.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-authority-select-field-data-combo",height:30,fieldId:""})},_init:function(){BI.AuthoritySelectFieldDataCombo.superclass._init.apply(this,arguments);var a=this,b=this.options;this.combo=BI.createWidget({type:"bi.multi_select_combo",element:this,itemsCreator:BI.bind(this._itemsCreator,this)});this.combo.on(BI.MultiSelectCombo.EVENT_CONFIRM,function(){a.fireEvent(BI.AuthoritySelectFieldDataCombo.EVENT_CONFIRM)
})},_getItemsByTimes:function(a,c){var b=[];BI.each(BI.makeArray(100,null),function(d,f){var e=(c-1)*100+d;if(BI.isNotNull(a[e])){b.push(a[e])}});return b},_hasNextByTimes:function(a,b){return b*100<a.length},_itemsCreator:function(b,e){var a=this,d=this.options;if(!this.items){BI.Utils.getConfDataByFieldId(d.fieldId,{type:BICst.REQ_DATA_TYPE.REQ_GET_ALL_DATA},function(f){a.items=BI.map(f,function(h,g){return{text:g,value:g,title:g}});c()})}else{c()}function c(){var f=a.items;var g=(b.keywords||[]).slice();
if(b.keyword){g.push(b.keyword)}BI.each(g,function(k,l){var j=BI.Func.getSearchResult(f,l);f=j.matched.concat(j.finded)});if(b.selectedValues){var h=BI.makeObject(b.selectedValues,true);f=BI.filter(f,function(k,j){return !h[j.value]})}if(b.type==BI.MultiSelectCombo.REQ_GET_ALL_DATA){e({items:f});return}if(b.type==BI.MultiSelectCombo.REQ_GET_DATA_LENGTH){e({count:f.length});return}e({items:a._getItemsByTimes(f,b.times),hasNext:a._hasNextByTimes(f,b.times)})}},setValue:function(a){if(BI.isNull(a)){this.combo.setValue();
return}this.combo.setValue(a)},getValue:function(){var a=this.combo.getValue()||{};return{type:a.type,value:a.value}}});BI.AuthoritySelectFieldDataCombo.EVENT_CONFIRM="AuthoritySelectFieldDataCombo.EVENT_CONFIRM";BI.shortcut("bi.authority_select_field_data_combo",BI.AuthoritySelectFieldDataCombo);
BI.LoginInfoCombo=BI.inherit(BI.Widget,{_defaultConfig:function(){return BI.extend(BI.LoginInfoCombo.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-login-info-combo"})},_init:function(){BI.LoginInfoCombo.superclass._init.apply(this,arguments);var a=this;this.combo=BI.createWidget({type:"bi.single_tree_combo",element:this});this._beforeLoginComboPopup();this.combo.on(BI.SingleTreeCombo.EVENT_BEFORE_POPUPVIEW,function(){a._beforeLoginComboPopup()});this.combo.on(BI.SingleTreeCombo.EVENT_CHANGE,function(){a.fireEvent(BI.LoginInfoCombo.EVENT_CHANGE)
})},_beforeLoginComboPopup:function(){var f=this,g=this.options;var d=BI.Utils.getAuthorityLoginField();var c=g.fieldType;var e=[];if(c===BICst.COLUMN.STRING){e.push({text:BI.i18nText("BI-System_Username"),id:-1,value:BICst.SYSTEM_USER_NAME})}var b=this.combo.getValue();if(BI.isNotNull(d)&&BI.isNotNull(d.id)){var a=d.primKeyMap;BI.each(a,function(m,h){var i="",k="";var l=false;var j=[];BI.each(h,function(n,o){i=o.tableTranName||o.tableId;k=o.tableId;if(o.fieldType===c){j.push({id:o.id,pId:k,text:o.fieldTranName||o.fieldName,value:o.id,selected:b.contains(o.id)});
b.contains(o.id)&&(l=true)}});if(j.length>0){j.push({id:k,isParent:true,text:i,open:l})}e=e.concat(j)});if(e.length===0){e.push({text:BI.i18nText("BI-Basic_Null"),disabled:true})}}this.combo.populate(e)},setValue:function(a){this.combo.setValue(a)},getValue:function(){return this.combo.getValue()[0]}});BI.LoginInfoCombo.EVENT_CHANGE="EVENT_CHANGE";BI.shortcut("bi.login_info_combo",BI.LoginInfoCombo);
BI.GeneralQueryNoTypeFilterItem=BI.inherit(BI.AbstractFilterItem,{_constant:{LEFT_ITEMS_H_GAP:5,CONTAINER_HEIGHT:40,CONDITION_TYPE_COMBO_ADJUST:2,BUTTON_HEIGHT:28,TEXT_BUTTON_H_GAP:10,ADD_FIELD_POPUP_WIDTH:230,HEIGHT_MAX:10000,MAX_HEIGHT:500},_defaultConfig:function(){return BI.extend(BI.GeneralQueryNoTypeFilterItem.superclass._defaultConfig.apply(this,arguments),{extraCls:"bi-target-no-type-field-item",afterValueChange:BI.emptyFn})},_init:function(){BI.GeneralQueryNoTypeFilterItem.superclass._init.apply(this,arguments);
var a=this,c=this.options;var b=this._buildConditionsNoType();this.deleteButton=BI.createWidget({type:"bi.icon_button",cls:"close-h-font"});this.deleteButton.on(BI.Controller.EVENT_CHANGE,function(){a.fireEvent(BI.Controller.EVENT_CHANGE,BI.Events.DESTROY,c.id,a)});this.itemContainer=BI.createWidget({type:"bi.left_right_vertical_adapt",cls:"item-no-type",height:this._constant.CONTAINER_HEIGHT,items:{left:[b],right:[this.deleteButton]},lhgap:this._constant.LEFT_ITEMS_H_GAP,rhgap:this._constant.LEFT_ITEMS_H_GAP});
BI.createWidget({type:"bi.vertical",element:this,items:[this.itemContainer],scrolly:false})},populate:function(a){if(BI.isNotNull(this.typeSelectedItem)){this.typeSelectedItem.populate.apply(this.typeSelectedItem,arguments)}},_buildConditionsNoType:function(){var b=this,c=this.options;var a=BI.createWidget({type:"bi.general_query_select_data_tab",height:this._constant.MAX_HEIGHT});this.addCondition=BI.createWidget({type:"bi.combo",isNeedAdjustHeight:true,adjustLength:this._constant.CONDITION_TYPE_COMBO_ADJUST,el:{type:"bi.button",level:"common",height:this._constant.BUTTON_HEIGHT,text:BI.i18nText("BI-Please_Select_Field")},popup:{el:a,minHeight:300,minWidth:228,maxHeight:this._constant.MAX_HEIGHT}});
a.on(BI.GeneralQuerySelectDataTab.EVENT_CHANGE,function(d){b._onTypeSelected(d);b.options.afterValueChange()});return this.addCondition},_onTypeSelected:function(c){var a=BI.Utils.getFieldTypeByID(c);var b=this,e=this.options;var d=BI.TargetFilterItemFactory.createFilterItemByFieldType(a);this.itemContainer.destroy();this.itemContainer=null;this.typeSelectedItem=BI.createWidget(d,{element:this,_src:{fieldId:c,relation:c.relation||[]},id:this.options.id,node:e.node,afterValueChange:e.afterValueChange});
this.typeSelectedItem.on(BI.Controller.EVENT_CHANGE,function(){b.fireEvent(BI.Controller.EVENT_CHANGE,arguments)});e.node.set("data",BI.extend(e.node.get("data"),{value:d.filterType,filterType:d.filterType,_src:{fieldId:c}}))},getValue:function(){if(BI.isNotNull(this.typeSelectedItem)){return this.typeSelectedItem.getValue()}return{filterType:BICst.FILTER_TYPE.EMPTY_CONDITION}}});BI.shortcut("bi.general_query_no_type_filter_item",BI.GeneralQueryNoTypeFilterItem);
BI.DetailCustomGroupPopup=BI.inherit(BI.BarPopoverSection,{_defaultConfig:function(){return BI.extend(BI.DetailCustomGroupPopup.superclass._defaultConfig.apply(this,arguments),{width:600,height:500})},_init:function(){BI.DetailCustomGroupPopup.superclass._init.apply(this,arguments)},rebuildNorth:function(c){var d=this.options.dId;var a=BI.Utils.getFieldNameByID(BI.Utils.getFieldIDByDimensionID(d));var b=BI.i18nText("BI-Custom_Group_Detail",a);BI.createWidget({type:"bi.label",element:c,text:b,height:50,textAlign:"left",lgap:10});
return true},rebuildCenter:function(a){this.customgroup=BI.createWidget({element:a,dId:this.options.dId,type:"bi.custom_group"})},populate:function(){var d=BI.Utils.getDimensionGroupByID(this.options.dId);var a=d.details;var b=d.ungroup2Other;var c=d.ungroup2OtherName;this.customgroup.populate(a,b,c)},end:function(){var a=this;var d=this.options.dId;var c=a.customgroup.getValue();var b=BI.Utils.getSeriesAccumulationByDimensionID(d);c.type=BICst.GROUP.CUSTOM_GROUP;if(b.type!==BICst.SERIES_ACCUMULATION.EXIST){this.fireEvent(BI.DetailCustomGroupPopup.EVENT_CHANGE,c)
}else{BI.Msg.confirm("",BI.i18nText("BI-Ensure_Custom_Group"),function(e){if(e===true){a.fireEvent(BI.DetailCustomGroupPopup.EVENT_CHANGE,c)}})}}});BI.DetailCustomGroupPopup.EVENT_CHANGE="EVENT_CHANGE";BI.shortcut("bi.detail_custom_group_popup",BI.DetailCustomGroupPopup);
BI.DetailNumberCustomGroupPopup=BI.inherit(BI.BarPopoverSection,{_defaultConfig:function(){return BI.extend(BI.DetailNumberCustomGroupPopup.superclass._defaultConfig.apply(this,arguments),{width:600,height:500,btns:[BI.i18nText(BI.i18nText("BI-Basic_Save")),BI.i18nText("BI-Basic_Cancel")]})},_init:function(){BI.DetailNumberCustomGroupPopup.superclass._init.apply(this,arguments)},rebuildNorth:function(a){var b=this.options.dId;Data.BufferPool.getNumberFieldMinMaxValueById(BI.Utils.getFieldIDByDimensionID(b),function(e){var c=e.max;
var d=e.min;BI.createWidget({type:"bi.label",element:a,text:BI.i18nText("BI-Grouping_Setting_Detail",d,c),height:50,textAlign:"left",lgap:10})});return true},rebuildCenter:function(a){var c=this.options.dId;var b=this;this.group=BI.createWidget({type:"bi.number_custom_group",dId:c});this.group.on(BI.NumberIntervalCustomGroup.EVENT_ERROR,function(){b.sure.setWarningTitle(BI.i18nText("BI-Correct_The_Errors_Red"));b.sure.setEnable(false)});this.group.on(BI.NumberIntervalCustomGroup.EVENT_VALID,function(){b.sure.setValue(BI.i18nText("BI-Basic_Save"));
b.sure.setEnable(true)});this.group.on(BI.NumberIntervalCustomGroup.EVENT_EMPTY_GROUP,function(){b.sure.setValue(BI.i18nText("BI-Basic_Save"));b.sure.setEnable(false)});BI.createWidget({type:"bi.vertical",element:a,items:[this.group]});return true},populate:function(){this.group.populate(BI.Utils.getDimensionGroupByID(this.options.dId))},end:function(){this.fireEvent(BI.DetailNumberCustomGroupPopup.EVENT_CHANGE,this.group.getValue())}});BI.DetailNumberCustomGroupPopup.EVENT_CHANGE="EVENT_CHANGE";
BI.shortcut("bi.detail_number_custom_group_popup",BI.DetailNumberCustomGroupPopup);
BI.CustomSortPopup=BI.inherit(BI.BarPopoverSection,{_defaultConfig:function(){return BI.extend(BI.CustomSortPopup.superclass._defaultConfig.apply(this,arguments),{width:600,height:500})},_init:function(){BI.CustomSortPopup.superclass._init.apply(this,arguments)},rebuildNorth:function(a){BI.createWidget({type:"bi.label",element:a,text:BI.i18nText("BI-Drag_To_Sort"),height:50,textAlign:"left",lgap:10});return true},rebuildCenter:function(a){this.customsort=BI.createWidget({element:a,dId:this.options.dId,type:"bi.custom_sort_pane"})
},populate:function(){this.customsort.populate()},end:function(){var a=this.customsort.getValue()||{};this.fireEvent(BI.CustomSortPopup.EVENT_CHANGE,a)}});BI.CustomSortPopup.EVENT_CHANGE="EVENT_CHANGE";BI.shortcut("bi.custom_sort_popup",BI.CustomSortPopup);
BI.AndOrFilterExpander=BI.inherit(BI.Widget,{_defaultConfig:function(){return BI.extend(BI.AndOrFilterExpander.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-target-filter",el:{},popup:{}})},_init:function(){BI.AndOrFilterExpander.superclass._init.apply(this,arguments);var a=this,b=this.options;this.expander=BI.createWidget({type:"bi.filter_expander",element:this,el:b.el,popup:b.popup,id:b.id,value:b.value});this.expander.on(BI.Controller.EVENT_CHANGE,function(){a.fireEvent(BI.Controller.EVENT_CHANGE,arguments)
})},populate:function(){this.expander.populate.apply(this.expander,arguments)},getValue:function(){var a=this.expander.getValue();return{filterType:a.type,filterValue:a.value,id:a.id}}});BI.AndOrFilterExpander.EVENT_CHANGE="EVENT_CHANGE";BI.shortcut("bi.andor_filter_expander",BI.AndOrFilterExpander);
BI.TargetFilter=BI.inherit(BI.Widget,{_defaultConfig:function(){return BI.extend(BI.TargetFilter.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-target-filter",dId:""})},_init:function(){BI.TargetFilter.superclass._init.apply(this,arguments);var a=this,b=this.options;this.filter=BI.createWidget({type:"bi.filter",itemCreator:function(d){var c=BI.TargetFilterItemFactory.createFilterItemByFilterType(d.value);d.type=c.type;d.fieldId=BI.Utils.getFieldIDByDimensionID(b.dId);d.afterValueChange=function(){a.fireEvent(BI.TargetFilter.EVENT_CHANGE)
}},expander:{type:"bi.andor_filter_expander"},element:this});this.filter.on(BI.Filter.EVENT_CHANGE,function(){a.fireEvent(BI.TargetFilter.EVENT_CHANGE)})},transformConditions2Tree:function(b){var a=this;BI.each(b,function(c,d){d.id||(d.id=BI.UUID());d.value=d.filterType;if(d.filterType===BICst.FILTER_TYPE.AND||d.filterType===BICst.FILTER_TYPE.OR){d.children=d.filterValue;a.transformConditions2Tree(d.children)}})},populate:function(){var b=this.options;var a=BI.Utils.getDimensionFilterValueByID(b.dId);
if(BI.isNotEmptyObject(a)){a=[a]}else{a=[]}this.transformConditions2Tree(a);this.filter.populate(a)},getValue:function(){return this.filter.getValue()}});BI.TargetFilter.EVENT_CHANGE="EVENT_CHANGE";BI.shortcut("bi.target_filter",BI.TargetFilter);
BI.DimensionFilter=BI.inherit(BI.Widget,{_defaultConfig:function(){return BI.extend(BI.DimensionFilter.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-dimension-filter",dId:""})},_init:function(){BI.DimensionFilter.superclass._init.apply(this,arguments);var a=this,b=this.options;this.filter=BI.createWidget({type:"bi.filter",itemCreator:function(d){var c=BI.DimensionFilterItemFactory.createFilterItemByFilterType(d.value);d.type=c.type;if(BI.has(d,"targetId")){d.dId=d.targetId}d.dId=d.dId||b.dId;
d.afterValueChange=function(){a.fireEvent(BI.DimensionFilter.EVENT_CHANGE)}},expander:{type:"bi.andor_filter_expander"},element:this});this.filter.on(BI.Filter.EVENT_CHANGE,function(){a.fireEvent(BI.DimensionFilter.EVENT_CHANGE)})},transformConditions2Tree:function(b){var a=this;BI.each(b,function(c,d){d.id||(d.id=BI.UUID());d.value=d.filterType;if(d.filterType===BICst.FILTER_TYPE.AND||d.filterType===BICst.FILTER_TYPE.OR){d.children=d.filterValue;a.transformConditions2Tree(d.children)}})},populate:function(){var b=this.options;
var a=BI.Utils.getDimensionFilterValueByID(b.dId);if(BI.isNotEmptyObject(a)){a=[a]}else{a=[]}this.transformConditions2Tree(a);this.filter.populate(a)},getValue:function(){return this.filter.getValue()}});BI.DimensionFilter.EVENT_CHANGE="EVENT_CHANGE";BI.shortcut("bi.dimension_filter",BI.DimensionFilter);
BI.SummaryTargetFilter=BI.inherit(BI.Widget,{_defaultConfig:function(){return BI.extend(BI.SummaryTargetFilter.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-target-filter",dId:""})},_init:function(){BI.SummaryTargetFilter.superclass._init.apply(this,arguments);var a=this,b=this.options;this.filter=BI.createWidget({type:"bi.filter",el:{type:"bi.filter_operation",selections:[BICst.FILTER_OPERATION_CONDITION]},itemCreator:function(c){c.type="bi.target_table_filter_item";c.dId=b.dId;c._src={fieldId:BI.Utils.getFieldIDByDimensionID(b.dId)};
if(c.value===BICst.FILTER_TYPE.EMPTY_CONDITION){c.value=BICst.TARGET_FILTER_NUMBER.BELONG_VALUE;c.filterType=BICst.TARGET_FILTER_NUMBER.BELONG_VALUE;c.filterValue={value:[]};c.node.set("data",c)}},expander:{type:"bi.andor_filter_expander"},element:this,dId:b.dId})},_transformConditions2Tree:function(b){var a=this;BI.each(b,function(c,d){d.id||(d.id=BI.UUID());d.value=d.filterType;if(d.filterType===BICst.FILTER_TYPE.AND||d.filterType===BICst.FILTER_TYPE.OR){d.children=d.filterValue;a._transformConditions2Tree(d.children)
}})},populate:function(){var c=this.options;var a=BI.Utils.getWidgetFilterValueByID(BI.Utils.getWidgetIDByDimensionID(c.dId));var b=a[c.dId]||[];b=BI.isArray(b)?b:[b];this._transformConditions2Tree(b);this.filter.populate(b)},getValue:function(){return this.filter.getValue()}});BI.shortcut("bi.target_summary_filter",BI.SummaryTargetFilter);
BI.TargetTableFilterItem=BI.inherit(BI.AbstractFilterItem,{_constant:{LEFT_ITEMS_H_GAP:5,CONTAINER_HEIGHT:40,BUTTON_HEIGHT:30,COMBO_WIDTH:130,FIELD_NAME_BUTTON_WIDTH:90,TEXT_BUTTON_H_GAP:10,INPUT_WIDTH:230},_defaultConfig:function(){return BI.extend(BI.TargetTableFilterItem.superclass._defaultConfig.apply(this,arguments),{extraCls:"bi-analysis-target-table-filter-item",afterValueChange:BI.emptyFn})},_init:function(){BI.TargetTableFilterItem.superclass._init.apply(this,arguments);var a=this,c=this.options;
var b=this._buildConditions();this.deleteButton=BI.createWidget({type:"bi.icon_button",cls:"close-h-font"});this.deleteButton.on(BI.Controller.EVENT_CHANGE,function(){a.fireEvent(BI.Controller.EVENT_CHANGE,BI.Events.DESTROY,c.id,a)});BI.createWidget({type:"bi.vertical",element:this,items:[{el:{type:"bi.left_right_vertical_adapt",height:this._constant.CONTAINER_HEIGHT,items:{left:[b[0],b[1],b[2]],right:[this.deleteButton]},lhgap:this._constant.LEFT_ITEMS_H_GAP,rhgap:this._constant.LEFT_ITEMS_H_GAP}}]})
},populate:function(b,a,c){this.filterType.setValue(c.filterType);this._refreshFilterWidget(c.filterType,c.filterValue)},_buildConditions:function(){var b=this,c=this.options;if(BI.isNull(c._src)){return[]}this.dId=c.dId;var a=BI.Utils.getDimensionNameByID(this.dId);this.fieldButton=BI.createWidget({type:"bi.text_button",text:a,title:a,width:this._constant.FIELD_NAME_BUTTON_WIDTH,height:this._constant.BUTTON_HEIGHT,textAlign:"left",hgap:this._constant.TEXT_BUTTON_H_GAP});this.fieldButton.on(BI.Controller.EVENT_CHANGE,function(){arguments[2]=b;
b.fireEvent(BI.Controller.EVENT_CHANGE,arguments)});this.filterWidgetContainer=BI.createWidget({type:"bi.left"});this.id=c.id;this.filterType=BI.createWidget({type:"bi.text_value_down_list_combo",width:this._constant.COMBO_WIDTH,height:this._constant.BUTTON_HEIGHT,items:BICst.TARGET_FILTER_NUMBER_COMBO});this.filterType.setValue(c.filterType);this.filterType.on(BI.TextValueDownListCombo.EVENT_CHANGE,function(){b._refreshFilterWidget(b.filterType.getValue()[0]);b._setNodeData({filterType:b.filterType.getValue()[0]});
c.afterValueChange.apply(b,arguments)});this._refreshFilterWidget(c.filterType,this.options.filterValue);return[this.fieldButton,this.filterType,this.filterWidgetContainer]},_refreshFilterWidget:function(b,a){switch(b){case BICst.TARGET_FILTER_NUMBER.EQUAL_TO:case BICst.TARGET_FILTER_NUMBER.NOT_EQUAL_TO:this._createNumberInput(a);break;case BICst.TARGET_FILTER_NUMBER.BELONG_VALUE:case BICst.TARGET_FILTER_NUMBER.NOT_BELONG_VALUE:this._createNumberIntervalFilter(a);break;case BICst.TARGET_FILTER_NUMBER.BELONG_USER:case BICst.TARGET_FILTER_NUMBER.NOT_BELONG_USER:this._createNumberIntervalFilter(a);
break;case BICst.TARGET_FILTER_NUMBER.IS_NULL:case BICst.TARGET_FILTER_NUMBER.NOT_NULL:this.filterWidget=BI.createWidget();break}this.filterWidgetContainer.empty();this.filterWidgetContainer.addItem(this.filterWidget)},_createNumberIntervalFilter:function(a){var b=this,c=this.options;this.filterWidget=BI.createWidget({type:"bi.number_interval",width:this._constant.INPUT_WIDTH,height:this._constant.BUTTON_HEIGHT});BI.isNotNull(a)&&this.filterWidget.setValue(a);this.filterWidget.on(BI.NumberInterval.EVENT_CHANGE,function(){b._setNodeData({filterValue:this.getValue()});
c.afterValueChange.apply(b,arguments)});return this.filterWidget},_createNumberInput:function(a){var b=this,c=this.options;this.filterWidget=BI.createWidget({type:"bi.text_editor",validationChecker:function(){if(!BI.isNumeric(b.filterWidget.getValue())){return false}},errorText:BI.i18nText("BI-Numerical_Interval_Input_Data"),allowBlank:true,height:this._constant.BUTTON_HEIGHT,width:this._constant.INPUT_WIDTH});this.filterWidget.on(BI.TextEditor.EVENT_CONFIRM,function(){b._setNodeData({filterValue:this.getValue()});
c.afterValueChange.apply(b,arguments)});BI.isNotNull(a)&&this.filterWidget.setValue(a);return BI.createWidget({type:"bi.left",items:[{type:"bi.label",height:this._constant.BUTTON_HEIGHT,text:"N = "},this.filterWidget]})},_setNodeData:function(a){var b=this.options;b.node.set("data",BI.extend(b.node.get("data"),a))},getValue:function(){return{_src:this.options._src,filterType:this.filterType.getValue()[0],filterValue:this.filterWidget.getValue()}}});BI.shortcut("bi.target_table_filter_item",BI.TargetTableFilterItem);
BI.GeneralQueryFilter=BI.inherit(BI.Widget,{_defaultConfig:function(){return BI.extend(BI.GeneralQueryFilter.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-general-query-filter",dId:""})},_init:function(){BI.GeneralQueryFilter.superclass._init.apply(this,arguments);var a=this,b=this.options;this.filter=BI.createWidget({type:"bi.filter",el:{type:"bi.filter_operation",selections:[BICst.FILTER_OPERATION_CONDITION]},itemCreator:function(d){var c=BI.TargetFilterItemFactory.createFilterItemByFilterType(d.value);
if(d.value===BICst.FILTER_TYPE.EMPTY_CONDITION){c.type="bi.general_query_no_type_filter_item"}d.type=c.type;d.fieldId=b.fieldId;d.afterValueChange=function(){a.fireEvent(BI.GeneralQueryFilter.EVENT_CHANGE)}},expander:{type:"bi.andor_filter_expander"},element:this});this.filter.on(BI.Filter.EVENT_CHANGE,function(){a.fireEvent(BI.GeneralQueryFilter.EVENT_CHANGE)})},_transformConditions2Tree:function(b){var a=this;BI.each(b,function(c,d){d.id||(d.id=BI.UUID());d.value=d.filterType;if(d.filterType===BICst.FILTER_TYPE.AND||d.filterType===BICst.FILTER_TYPE.OR){d.children=d.filterValue;
a._transformConditions2Tree(d.children)}})},populate:function(a){a=BI.isArray(a)?a:[a];this._transformConditions2Tree(a);this.filter.populate(a)},getValue:function(){return this.filter.getValue()}});BI.GeneralQueryFilter.EVENT_CHANGE="EVENT_CHANGE";BI.shortcut("bi.general_query_filter",BI.GeneralQueryFilter);
BI.DetailTableFilter=BI.inherit(BI.Widget,{_defaultConfig:function(){return BI.extend(BI.DetailTableFilter.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-detail-table-filter"})},_init:function(){BI.DetailTableFilter.superclass._init.apply(this,arguments);var a=this,c=this.options;var b=c.dId;this.filter=BI.createWidget({type:"bi.filter",el:{type:"bi.filter_operation",selections:[BICst.FILTER_OPERATION_CONDITION]},itemCreator:function(e){var d=BI.Utils.getFieldTypeByDimensionID(b);switch(d){case BICst.COLUMN.STRING:e.type="bi.target_string_field_filter_item";
break;case BICst.COLUMN.NUMBER:e.type="bi.target_number_field_filter_item";break;case BICst.COLUMN.DATE:e.type="bi.date_field_filter_item";break}e.fieldId=BI.Utils.getFieldIDByDimensionID(b);e._src={fieldId:BI.Utils.getFieldIDByDimensionID(b)};if(e.value===BICst.FILTER_TYPE.EMPTY_CONDITION){switch(d){case BICst.COLUMN.STRING:e.value=BICst.TARGET_FILTER_STRING.BELONG_VALUE;e.filterType=BICst.TARGET_FILTER_STRING.BELONG_VALUE;break;case BICst.COLUMN.NUMBER:e.value=BICst.TARGET_FILTER_NUMBER.BELONG_VALUE;
e.filterType=BICst.TARGET_FILTER_NUMBER.BELONG_VALUE;break;case BICst.COLUMN.DATE:e.value=BICst.FILTER_DATE.BELONG_DATE_RANGE;e.filterType=BICst.FILTER_DATE.BELONG_DATE_RANGE;break}e.filterValue={value:[]};e.node.set("data",e)}},expander:{type:"bi.andor_filter_expander"},element:this,dId:b})},_transformConditions2Tree:function(b){var a=this;BI.each(b,function(c,d){d.id||(d.id=BI.UUID());d.value=d.filterType;if(d.filterType===BICst.FILTER_TYPE.AND||d.filterType===BICst.FILTER_TYPE.OR){d.children=d.filterValue;
a._transformConditions2Tree(d.children)}})},populate:function(){var c=this.options;var a=BI.Utils.getWidgetFilterValueByID(BI.Utils.getWidgetIDByDimensionID(c.dId));var b=a[c.dId]||[];b=BI.isArray(b)?b:[b];this._transformConditions2Tree(b);this.filter.populate(b)},getValue:function(){return this.filter.getValue()}});BI.shortcut("bi.detail_table_filter",BI.DetailTableFilter);
BI.AuthorityFilter=BI.inherit(BI.Widget,{_defaultConfig:function(){return BI.extend(BI.AuthorityFilter.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-authority-filter"})},_init:function(){BI.AuthorityFilter.superclass._init.apply(this,arguments);var a=this,b=this.options;this.filter=BI.createWidget({type:"bi.filter",element:this,el:{type:"bi.filter_operation",selections:[BICst.FILTER_OPERATION_CONDITION]},itemCreator:function(d){var c=BI.AuthorityFilterItemFactory.createFilterItemByFilterType(d.value);
if(d.value===BICst.FILTER_TYPE.EMPTY_CONDITION){c.type="bi.authority_no_type_field_filter_item"}d.type=c.type},expander:{type:"bi.andor_filter_expander"}})},_transformConditions2Tree:function(b){var a=this;BI.each(b,function(c,d){d.id||(d.id=BI.UUID());d.value=d.filterType;if(d.filterType===BICst.FILTER_TYPE.AND||d.filterType===BICst.FILTER_TYPE.OR){d.children=d.filterValue;a._transformConditions2Tree(d.children)}})},populate:function(a){a=a||[];this._transformConditions2Tree(a);this.filter.populate(a)
},getValue:function(){var a=this.filter.getValue()[0];if(BI.isNotNull(a)){return this.parseFilter(a)}},parseFilter:function(c){var b=this;var e=c.filterType,h=c.filterValue;if(BI.isEmptyObject(h)){return c}if(e===BICst.FILTER_TYPE.AND||e===BICst.FILTER_TYPE.OR){BI.each(h,function(j,k){b.parseFilter(k)})}if(e===BICst.FILTER_DATE.BELONG_DATE_RANGE||e===BICst.FILTER_DATE.NOT_BELONG_DATE_RANGE){var g=h.startDetail,a=h.endDetail;if(BI.isNull(g)){delete h.start}else{h.startDetail=g;h.start=d(g)}if(BI.isNull(a)){delete h.end
}else{h.endDetail=a;h.end=d(a)}}if(e===BICst.FILTER_DATE.EQUAL_TO||e===BICst.FILTER_DATE.NOT_EQUAL_TO){h=f(h);h.values=d(h);h.group=BICst.GROUP.YMD}return c;function f(i){i=i||{};i.type=i.type||BICst.DATE_TYPE.MULTI_DATE_CALENDAR;return i}function d(l){var o=l.type,p=l.value;var n=Date.getDate();var k=n.getFullYear(),m=n.getMonth(),i=n.getDate();if(BI.isNull(o)&&BI.isNotNull(l.year)){return Date.getTime(l.year,l.month,l.day)}var j;switch(o){case BICst.DATE_TYPE.MULTI_DATE_YEAR_PREV:return Date.getTime(k-1*p,m,i);
case BICst.DATE_TYPE.MULTI_DATE_YEAR_AFTER:return Date.getTime(k+1*p,m,i);case BICst.DATE_TYPE.MULTI_DATE_YEAR_BEGIN:return Date.getTime(k,1,1);case BICst.DATE_TYPE.MULTI_DATE_YEAR_END:return Date.getTime(k,11,31);case BICst.DATE_TYPE.MULTI_DATE_MONTH_PREV:j=Date.getDate().getBeforeMultiMonth(p);return Date.getTime(j.getFullYear(),j.getMonth(),j.getDate(),j.getHours(),j.getMinutes(),j.getSeconds());case BICst.DATE_TYPE.MULTI_DATE_MONTH_AFTER:j=Date.getDate().getAfterMultiMonth(p);return Date.getTime(j.getFullYear(),j.getMonth(),j.getDate(),j.getHours(),j.getMinutes(),j.getSeconds());
case BICst.DATE_TYPE.MULTI_DATE_MONTH_BEGIN:return Date.getTime(k,m,1);case BICst.DATE_TYPE.MULTI_DATE_MONTH_END:return Date.getTime(k,m,(n.getLastDateOfMonth()).getDate());case BICst.DATE_TYPE.MULTI_DATE_QUARTER_PREV:j=Date.getDate().getBeforeMulQuarter(p);return Date.getTime(j.getFullYear(),j.getMonth(),j.getDate(),j.getHours(),j.getMinutes(),j.getSeconds());case BICst.DATE_TYPE.MULTI_DATE_QUARTER_AFTER:j=Date.getDate().getAfterMulQuarter(p);return Date.getTime(j.getFullYear(),j.getMonth(),j.getDate(),j.getHours(),j.getMinutes(),j.getSeconds());
case BICst.DATE_TYPE.MULTI_DATE_QUARTER_BEGIN:j=Date.getDate().getQuarterStartDate();return Date.getTime(j.getFullYear(),j.getMonth(),j.getDate(),j.getHours(),j.getMinutes(),j.getSeconds());case BICst.DATE_TYPE.MULTI_DATE_QUARTER_END:j=Date.getDate().getQuarterEndDate();return Date.getTime(j.getFullYear(),j.getMonth(),j.getDate(),j.getHours(),j.getMinutes(),j.getSeconds());case BICst.DATE_TYPE.MULTI_DATE_WEEK_PREV:j=n.getOffsetDate(-7*p);return Date.getTime(j.getFullYear(),j.getMonth(),j.getDate(),j.getHours(),j.getMinutes(),j.getSeconds());
case BICst.DATE_TYPE.MULTI_DATE_WEEK_AFTER:j=n.getOffsetDate(7*p);return Date.getTime(j.getFullYear(),j.getMonth(),j.getDate(),j.getHours(),j.getMinutes(),j.getSeconds());case BICst.DATE_TYPE.MULTI_DATE_DAY_PREV:j=n.getOffsetDate(-1*p);return Date.getTime(j.getFullYear(),j.getMonth(),j.getDate(),j.getHours(),j.getMinutes(),j.getSeconds());case BICst.DATE_TYPE.MULTI_DATE_DAY_AFTER:j=n.getOffsetDate(1*p);return Date.getTime(j.getFullYear(),j.getMonth(),j.getDate(),j.getHours(),j.getMinutes(),j.getSeconds());
case BICst.DATE_TYPE.MULTI_DATE_DAY_TODAY:return Date.getTime(k,m,i);case BICst.DATE_TYPE.MULTI_DATE_CALENDAR:return Date.getTime(l.year,l.month,l.day)}}}});BI.shortcut("bi.authority_filter",BI.AuthorityFilter);
BI.DetailSelectDataLevel0Node=BI.inherit(BI.Widget,{_defaultConfig:function(){return BI.extend(BI.DetailSelectDataLevel0Node.superclass._defaultConfig.apply(this,arguments),{extraCls:"bi-detail-select-data-level0-node",id:"",pId:"",layer:0,open:false,height:25})},_init:function(){BI.DetailSelectDataLevel0Node.superclass._init.apply(this,arguments);var a=this,b=this.options;this.node=BI.createWidget({type:"bi.select_data_level_node",element:this,layer:b.layer,id:b.id,pId:b.pId,open:b.open,text:b.text,value:b.value,keyword:b.keyword,title:b.title});
this.ids=[];this.node.on(BI.Controller.EVENT_CHANGE,function(){a.fireEvent(BI.Controller.EVENT_CHANGE,arguments)})},doRedMark:function(){this.node.doRedMark.apply(this.node,arguments)},unRedMark:function(){this.node.unRedMark.apply(this.node,arguments)},setSelected:function(a){return this.node.setSelected(a)},isSelected:function(){return this.node.isSelected()},isOpened:function(){return this.node.isOpened()},setOpened:function(a){this.node.setOpened(a)},_createSetValue:function(c){var b=this,d=[];
var a=BI.Utils.getFieldIDsWithCountFieldIdOfTableID(this.options.id);BI.each(BI.Utils.getPrimaryRelationTablesByTableID(this.options.id),function(e,f){a=BI.concat(a,BI.Utils.getFieldIDsWithCountFieldIdOfTableID(f))});BI.each(c,function(f,g){if(a.contains(g.fieldId||g)){if(BI.isString(g)){d.push(BI.Utils.getFieldNameByID(g));b.ids.push(g)}else{if(BI.isNotNull(g.fieldId)){var e=BI.Utils.getFieldNameByID(g.fieldId);b.ids.push(g.fieldId);if(BI.isNotNull(g.group)){switch(g.group.type){case BICst.GROUP.Y:e+=BI.i18nText("BI-Tip_Brackets",BI.i18nText("BI-Basic_Year"));
break;case BICst.GROUP.M:e+=BI.i18nText("BI-Tip_Brackets",BI.i18nText("BI-Basic_Month"));break;case BICst.GROUP.YMD:e+=BI.i18nText("BI-Tip_Brackets",BI.i18nText("BI-YMD_Date"));break;case BICst.GROUP.S:e+=BI.i18nText("BI-Tip_Brackets",BI.i18nText("BI-Basic_Quarter"));break;case BICst.GROUP.W:e+=BI.i18nText("BI-Tip_Brackets",BI.i18nText("BI-Week_XingQi"));break;case BICst.GROUP.D:e+=BI.i18nText("BI-Tip_Brackets",BI.i18nText("BI-Date_Day"));break;case BICst.GROUP.WEEK_COUNT:e+=BI.i18nText("BI-Tip_Brackets",BI.i18nText("BI-Week_Count"));
break;case BICst.GROUP.YMDH:e+=BI.i18nText("BI-Tip_Brackets",BI.i18nText("BI-Basic_YMDH"));break;case BICst.GROUP.YMDHM:e+=BI.i18nText("BI-Tip_Brackets",BI.i18nText("BI-Basic_YMDHM"));break;case BICst.GROUP.YMDHMS:e+=BI.i18nText("BI-Tip_Brackets",BI.i18nText("BI-Detail_Date"));break;case BICst.GROUP.HOUR:e+=BI.i18nText("BI-Tip_Brackets",BI.i18nText("BI-Hour_Sin"));break;case BICst.GROUP.MINUTE:e+=BI.i18nText("BI-Tip_Brackets",BI.i18nText("BI-Basic_Minute"));break;case BICst.GROUP.SECOND:e+=BI.i18nText("BI-Tip_Brackets",BI.i18nText("BI-Basic_Seconds"));
break;case BICst.GROUP.YM:e+=BI.i18nText("BI-Tip_Brackets",BI.i18nText("BI-Year_Month"));break;case BICst.GROUP.YS:e+=BI.i18nText("BI-Tip_Brackets",BI.i18nText("BI-Year_Quarter"));break;case BICst.GROUP.YW:e+=BI.i18nText("BI-Tip_Brackets",BI.i18nText("BI-Year_Week"));break}}d.push(e)}}}});return d},setValue:function(c){var b=this;this.ids=[];var a=BI.Utils.getFieldIDsWithCountFieldIdOfTableID(this.options.id);BI.each(BI.Utils.getPrimaryRelationTablesByTableID(this.options.id),function(d,e){a=BI.concat(a,BI.Utils.getFieldIDsWithCountFieldIdOfTableID(e))
});BI.each(this._broadcasts,function(d,e){e()});this._broadcasts=[];BI.each(c,function(d,e){if(a.contains(e.fieldId||e)){var f;if(BI.isString(e)){f=BI.Broadcasts.on(BICst.BROADCAST.SRC_PREFIX+e,function(){BI.defer(function(){BI.remove(b.ids,e);b.node.setValue(b._createSetValue(b.ids))})});b._broadcasts.push(f)}else{f=BI.Broadcasts.on(BICst.BROADCAST.SRC_PREFIX+e.fieldId,function(){BI.defer(function(){BI.remove(b.ids,e.fieldId);b.node.setValue(b._createSetValue(b.ids))})});b._broadcasts.push(f)}}});
this.node.setValue(this._createSetValue(c))},_setEnable:function(a){BI.DetailSelectDataLevel0Node.superclass._setEnable.apply(this,arguments);!a&&this.node.isOpened()&&this.node.triggerCollapse()},destroyed:function(){BI.each(this._broadcasts,function(b,a){a()});this._broadcasts=[]}});BI.shortcut("bi.detail_select_data_level_node",BI.DetailSelectDataLevel0Node);
BI.DetailSelectDataLevel1DateNode=BI.inherit(BI.Widget,{_defaultConfig:function(){return BI.extend(BI.DetailSelectDataLevel1DateNode.superclass._defaultConfig.apply(this,arguments),{extraCls:"bi-detail-select-data-level1-date-node",id:"",pId:"",layer:1,open:false,height:25})},_init:function(){BI.DetailSelectDataLevel0Node.superclass._init.apply(this,arguments);var a=this,b=this.options;this.node=BI.createWidget({type:"bi.select_data_level1_date_node",element:this,layer:b.layer,id:b.id,pId:b.pId,open:b.open,text:b.text,value:b.value,keyword:b.keyword,title:b.title});
this.node.on(BI.Controller.EVENT_CHANGE,function(){a.fireEvent(BI.Controller.EVENT_CHANGE,arguments)})},doRedMark:function(){this.node.doRedMark.apply(this.node,arguments)},unRedMark:function(){this.node.unRedMark.apply(this.node,arguments)},setSelected:function(a){return this.node.setSelected(a)},isSelected:function(){return this.node.isSelected()},isOpened:function(){return this.node.isOpened()},setOpened:function(a){this.node.setOpened(a)},setValue:function(a){this.node.setValue(a)},_setEnable:function(a){BI.DetailSelectDataLevel1DateNode.superclass._setEnable.apply(this,arguments);
!a&&this.node.isOpened()&&this.node.triggerCollapse()}});BI.shortcut("bi.detail_select_data_level1_date_node",BI.DetailSelectDataLevel1DateNode);
BI.DetailSelectDataLevel1MoreDateNode=BI.inherit(BI.NodeButton,{_defaultConfig:function(){return BI.extend(BI.DetailSelectDataLevel1MoreDateNode.superclass._defaultConfig.apply(this,arguments),{extraCls:"bi-detail-select-data-level1-date-node bi-select-data-level1-date-node  bi-list-item",id:"",pId:"",open:false,height:25})},_init:function(){BI.DetailSelectDataLevel1MoreDateNode.superclass._init.apply(this,arguments);var a=this,b=this.options;this.button=BI.createWidget({type:"bi.text_item",text:b.text,value:b.value,keyword:b.keyword,height:b.height,textLgap:10,textRgap:5});
this.checkbox=BI.createWidget({type:"bi.tree_group_node_checkbox"});this.checkbox.on(BI.Controller.EVENT_CHANGE,function(c){if(c===BI.Events.CLICK){a.setSelected(a.isSelected())}a.fireEvent(BI.Controller.EVENT_CHANGE,arguments)});this.button.on(BI.Controller.EVENT_CHANGE,function(){a.fireEvent(BI.Controller.EVENT_CHANGE,arguments)});BI.createWidget({type:"bi.htape",element:this,items:[{el:{type:"bi.layout"},width:65},{el:this.button},{el:this.checkbox,width:25}]})},doRedMark:function(){this.button.doRedMark.apply(this.button,arguments)
},unRedMark:function(){this.button.unRedMark.apply(this.button,arguments)},doClick:function(){BI.DetailSelectDataLevel1MoreDateNode.superclass.doClick.apply(this,arguments);this.checkbox.setSelected(this.isOpened())},setOpened:function(a){BI.DetailSelectDataLevel1MoreDateNode.superclass.setOpened.apply(this,arguments);this.checkbox.setSelected(a)},setValue:function(a){BI.DetailSelectDataLevel1MoreDateNode.superclass.setValue.apply(this,arguments)}});BI.shortcut("bi.detail_select_data_level1_more_date_node",BI.DetailSelectDataLevel1MoreDateNode);
BI.SelectDataRelationTablesNode=BI.inherit(BI.NodeButton,{_defaultConfig:function(){return BI.extend(BI.SelectDataRelationTablesNode.superclass._defaultConfig.apply(this,arguments),{extraCls:"bi-select-data-relation-table-node bi-list-item",id:"",pId:"",open:false,height:25})},_init:function(){BI.SelectDataRelationTablesNode.superclass._init.apply(this,arguments);var a=this,b=this.options;this.text=BI.createWidget({type:"bi.label",cls:"relation-table-node",textAlign:"left",whiteSpace:"nowrap",textHeight:b.height,height:b.height,hgap:b.hgap,text:b.text,value:b.value,py:b.py});
BI.createWidget({type:"bi.htape",element:this,items:[{width:23,el:BI.createWidget()},{el:this.text}]})},doRedMark:function(){this.text.doRedMark.apply(this.text,arguments)},unRedMark:function(){this.text.unRedMark.apply(this.text,arguments)},doClick:function(){BI.SelectDataRelationTablesNode.superclass.doClick.apply(this,arguments)},setOpened:function(a){BI.SelectDataRelationTablesNode.superclass.setOpened.apply(this,arguments)},setValue:function(a){BI.SelectDataRelationTablesNode.superclass.setValue.apply(this,arguments)
}});BI.shortcut("bi.select_data_relation_tables_node",BI.SelectDataRelationTablesNode);
BI.DetailSelectDataLevel2DateNode=BI.inherit(BI.NodeButton,{_defaultConfig:function(){return BI.extend(BI.DetailSelectDataLevel2DateNode.superclass._defaultConfig.apply(this,arguments),{extraCls:"bi-detail-select-data-level2-date-node bi-select-data-level1-date-node  bi-list-item",id:"",pId:"",open:false,height:25})},_init:function(){BI.DetailSelectDataLevel2DateNode.superclass._init.apply(this,arguments);var a=this,b=this.options;this.button=BI.createWidget({type:"bi.icon_text_item",cls:"select-data-field-date-group-font",text:b.text,value:b.value,keyword:b.keyword,height:b.height,textLgap:10,textRgap:5});
this.checkbox=BI.createWidget({type:"bi.tree_group_node_checkbox"});this.checkbox.on(BI.Controller.EVENT_CHANGE,function(c){if(c===BI.Events.CLICK){a.setSelected(a.isSelected())}a.fireEvent(BI.Controller.EVENT_CHANGE,arguments)});this.button.on(BI.Controller.EVENT_CHANGE,function(){a.fireEvent(BI.Controller.EVENT_CHANGE,arguments)});BI.createWidget({type:"bi.htape",element:this,items:[{el:{type:"bi.layout"},width:40},{el:this.button},{el:this.checkbox,width:25}]})},doRedMark:function(){this.button.doRedMark.apply(this.button,arguments)
},unRedMark:function(){this.button.unRedMark.apply(this.button,arguments)},doClick:function(){BI.DetailSelectDataLevel2DateNode.superclass.doClick.apply(this,arguments);this.checkbox.setSelected(this.isOpened())},setOpened:function(a){BI.DetailSelectDataLevel2DateNode.superclass.setOpened.apply(this,arguments);this.checkbox.setSelected(a)},setValue:function(a){BI.DetailSelectDataLevel2DateNode.superclass.setValue.apply(this,arguments)}});BI.shortcut("bi.detail_select_data_level2_date_node",BI.DetailSelectDataLevel2DateNode);
BI.DetailSelectDataLevel2MoreDateNode=BI.inherit(BI.NodeButton,{_defaultConfig:function(){return BI.extend(BI.DetailSelectDataLevel2MoreDateNode.superclass._defaultConfig.apply(this,arguments),{extraCls:"bi-detail-select-data-level2-date-node bi-select-data-level1-date-node  bi-list-item",id:"",pId:"",open:false,height:25})},_init:function(){BI.DetailSelectDataLevel2MoreDateNode.superclass._init.apply(this,arguments);var a=this,b=this.options;this.button=BI.createWidget({type:"bi.text_item",text:b.text,value:b.value,keyword:b.keyword,height:b.height,textLgap:10,textRgap:5});
this.checkbox=BI.createWidget({type:"bi.tree_group_node_checkbox"});this.checkbox.on(BI.Controller.EVENT_CHANGE,function(c){if(c===BI.Events.CLICK){a.setSelected(a.isSelected())}a.fireEvent(BI.Controller.EVENT_CHANGE,arguments)});this.button.on(BI.Controller.EVENT_CHANGE,function(){a.fireEvent(BI.Controller.EVENT_CHANGE,arguments)});BI.createWidget({type:"bi.htape",element:this,items:[{el:{type:"bi.layout"},width:85},{el:this.button},{el:this.checkbox,width:25}]})},doRedMark:function(){this.button.doRedMark.apply(this.button,arguments)
},unRedMark:function(){this.button.unRedMark.apply(this.button,arguments)},doClick:function(){BI.DetailSelectDataLevel2MoreDateNode.superclass.doClick.apply(this,arguments);this.checkbox.setSelected(this.isOpened())},setOpened:function(a){BI.DetailSelectDataLevel2MoreDateNode.superclass.setOpened.apply(this,arguments);this.checkbox.setSelected(a)},setValue:function(a){BI.DetailSelectDataLevel2MoreDateNode.superclass.setValue.apply(this,arguments)}});BI.shortcut("bi.detail_select_data_level2_more_date_node",BI.DetailSelectDataLevel2MoreDateNode);
BI.RelationTableExpander=BI.inherit(BI.Widget,{_defaultConfig:function(){return BI.extend(BI.RelationTableExpander.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-relation-table-expander",el:{},popup:{items:[],itemsCreator:BI.emptyFn}})},_init:function(){BI.RelationTableExpander.superclass._init.apply(this,arguments);var a=this,b=this.options;this.trigger=BI.createWidget(b.el);this.expander=BI.createWidget({type:"bi.expander",element:this,el:this.trigger,popup:BI.extend({type:"bi.select_data_loader"},b.popup)});
this.expander.on(BI.Controller.EVENT_CHANGE,function(c){a.trigger.setValue(this.getValue());a.fireEvent(BI.Controller.EVENT_CHANGE,arguments)})},doBehavior:function(){this.trigger.doRedMark.apply(this.trigger,arguments);this.expander.doBehavior.apply(this.expander,arguments)},setValue:function(a){this.expander.setValue(a)},getValue:function(){return this.expander.getValue()||[]},getAllButtons:function(){return this.expander.getView().getAllButtons()},showView:function(){this.expander.showView()},hideView:function(){this.expander.hideView()
},isExpanded:function(){return this.expander.isExpanded()},getAllLeaves:function(){return this.expander.getAllLeaves()},getNodeById:function(a){return this.expander.getNodeById(a)},getNodeByValue:function(a){return this.expander.getNodeByValue(a)}});BI.shortcut("bi.relation_table_expander",BI.RelationTableExpander);
BI.RelationTablesExpander=BI.inherit(BI.Widget,{_defaultConfig:function(){return BI.extend(BI.RelationTablesExpander.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-relation-tables-expander",el:{},popup:{items:[],itemsCreator:BI.emptyFn}})},_init:function(){BI.RelationTablesExpander.superclass._init.apply(this,arguments);var a=this,b=this.options;this.trigger=BI.createWidget(b.el);this.expander=BI.createWidget({type:"bi.expander",element:this,el:this.trigger,popup:BI.extend({type:"bi.select_data_loader"},b.popup)});
this.expander.on(BI.Controller.EVENT_CHANGE,function(c){if(a.trigger.isVisible()){a.trigger.setVisible(false)}a.fireEvent(BI.Controller.EVENT_CHANGE,arguments)});this.expander.on(BI.Expander.EVENT_CHANGE,function(){a.trigger.setValue(this.getValue())});this.expander.on(BI.Expander.EVENT_COLLAPSE,function(){this.getView().hideView()})},doBehavior:function(){this.trigger.doRedMark.apply(this.trigger,arguments);this.expander.doBehavior.apply(this.expander,arguments)},setValue:function(a){this.expander.setValue(a)
},getValue:function(){return this.expander.getValue()||[]},getAllButtons:function(){return this.expander.getView().getAllButtons()},showView:function(a){var c=this.expander.getView();if(c){BI.each(c.getAllButtons(),function(d,b){b.showView&&b.showView(a)})}},hideView:function(a){var c=this.expander.getView();this.trigger.setVisible(true);this.expander.hideView();if(c){BI.each(c.getAllButtons(),function(d,b){b.hideView&&b.hideView(a)})}},isExpanded:function(){return this.expander.isExpanded()},getAllLeaves:function(){return this.expander.getAllLeaves()
},getNodeById:function(a){return this.expander.getNodeById(a)},getNodeByValue:function(a){return this.expander.getNodeByValue(a)}});BI.shortcut("bi.relation_tables_expander",BI.RelationTablesExpander);
BI.PackageSelectDataService=BI.inherit(BI.Widget,{_const:{FIELD_GAP:25,DATE_GROUP:[BICst.GROUP.YMD,BICst.GROUP.Y,BICst.GROUP.S,BICst.GROUP.M,BICst.GROUP.W,BICst.GROUP.D],COMBINE_DATE_GROUP:[BICst.GROUP.WEEK_COUNT,BICst.GROUP.HOUR,BICst.GROUP.MINUTE,BICst.GROUP.SECOND,BICst.GROUP.YS,BICst.GROUP.YM,BICst.GROUP.YW,BICst.GROUP.YMDH,BICst.GROUP.YMDHM,BICst.GROUP.YMDHMS]},_defaultConfig:function(){return BI.extend(BI.PackageSelectDataService.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-package-select-data-service",wId:"",isDefaultInit:true,chooseType:BI.Selection.Multi,showRelativeTables:false,showExcelView:false,showDateGroup:false,showTime:false,packageCreator:function(){return BI.Utils.getAllGroupedPackagesTreeJSON()
},tablesCreator:function(){return[]},fieldsCreator:function(){return[]}})},_init:function(){BI.PackageSelectDataService.superclass._init.apply(this,arguments);var a=this,d=this.options;var b=d.packageCreator();this.searcher=BI.createWidget({type:"bi.select_data_searcher",element:this,packages:b,itemsCreator:function(i,h){if(BI.isKey(i.searchType)&&BI.isKey(i.keyword)){var f=a._getSearchResult(i.searchType,i.keyword,i.packageId);h(f.finded,f.matched);return}if(!i.node){h(a._getTablesStructureByPackId(i.packageId));
return}if(BI.isKey(i.node._keyword)){h(a._getFieldsStructureByTableIdAndKeyword(i.node.id,i.node._keyword),i.node._keyword);return}if(BI.isNotNull(i.node.isParent)){if(i.node.fieldType===BICst.COLUMN.DATE){var g=BI.clone(i.node);delete g.children;delete g.isParent;g.type=g._type;h(a._buildDateChildren(i.node.pId,g));return}h(a._getFieldsStructureByTableId(i.node.id))}}});this.searcher.on(BI.SelectDataSearcher.EVENT_CLICK_PACKAGE,function(){var f=this.getPackageId();BI.Utils.setCurrentSelectPackageID(f)
});this.searcher.on(BI.SelectDataSearcher.EVENT_CLICK_ITEM,function(i,g){if(d.chooseType===BI.Selection.Single){if(g.isSelected()===true){a.searcher.setValue(g.getValue())}else{a.searcher.setValue([])}}if(BI.isKey(d.wId)){var f=a.searcher.getValue();var h=[];BI.each(f,function(k,j){if(BI.isObject(j)){j=j.fieldId}var l=BI.Utils.getTableIdByFieldID(j);h.push(l)});BI.Broadcasts.send(BICst.BROADCAST.DIMENSIONS_PREFIX+d.wId,h)}a.fireEvent(BI.PackageSelectDataService.EVENT_CLICK_ITEM,arguments)});if(d.isDefaultInit===true){var e=BI.Utils.getCurrentSelectPackageID(d.wId);
this.searcher.setPackage(e)}var c=function(){b=d.packageCreator();a.searcher.populatePackages(b)};this._broadcasts=[];if(BI.isKey(d.wId)){this._broadcasts.push(BI.Broadcasts.on(BICst.BROADCAST.PACKAGE_PREFIX+d.wId,c))}this._broadcasts.push(BI.Broadcasts.on(BICst.BROADCAST.PACKAGE_PREFIX,c))},_getTitleByTableId:function(b){var a=BI.Utils.getTableNameByID(b);return BI.Utils.getPackageNameByID(BI.Utils.getPackageIDByTableID(b))+"."+a||""},_getTitleByFieldId:function(b){var d=BI.Utils.getFieldNameByID(b);
var c=BI.Utils.getTableIdByFieldID(b);var a=BI.Utils.getTableNameByID(c);return BI.Utils.getPackageNameByID(BI.Utils.getPackageIDByTableID(c))+"."+a+"."+d||""},_getSearchResult:function(h,g,d){var l=this,b=this.options;var e=[],c=[];if(h&BI.SelectDataSearchSegment.SECTION_ALL){var f=this._getAllPackageIds()}else{var f=[d]}var j=f.length===1;if(h&BI.SelectDataSearchSegment.SECTION_TABLE){var m=[];BI.each(f,function(p,o){var n=l._getTablesStructureByPackId(o,{isRelation:false,isSearching:true});m.push(BI.Func.getSearchResult(n,g))
});BI.each(m,function(n,o){e=e.concat(o.finded);c=c.concat(o.matched)})}else{var m=[],a={},k=[],i={};BI.each(f,function(q,p){k=l._getTablesStructureByPackId(p,{isRelation:false,isSearching:true});var o=[];BI.each(k,function(s,t){var r=l._getFieldsStructureByTableId(t.id||t.value,{keyword:g,isSearching:true});BI.each(r,function(u,v){i[v.id||v.value]=t});o=o.concat(r)});var n=BI.Func.getSearchResult(o,g);m.push(n)});BI.each(m,function(n,o){BI.each(o.matched.concat(o.finded),function(q,p){if(!a[p.pId]){if(BI.Utils.getTableNameByID(p.pId)){var r=l._getTitleByTableId(p.pId)
}else{if(BI.Utils.getFieldNameByID(p.pId)){var r=l._getTitleByFieldId(p.pId)}}e.push(BI.extend({id:p.pId,wId:b.wId,text:BI.Utils.getTableNameByID(p.pId)||BI.Utils.getFieldNameByID(p.pId)||"",title:r,value:p.pId,type:"bi.detail_select_data_level_node",layer:0},i[p.id||p.value],{isParent:true,open:true,_keyword:g}));a[p.pId]=true}});c=c.concat(o.matched)})}return{finded:e,matched:c}},_getAllPackageIds:function(){var d=this.options;var c=d.packageCreator();c=BI.Tree.transformToTreeFormat(c);var b=new BI.Tree();
b.initTree(c);var a=[];b.traverse(function(e){if(e.isLeaf()){a.push(e.id||e.value)}});return a},_getTablesStructureByPackId:function(f,e){e=e||{};var a=this,h=this.options;var d=[];var c=h.tablesCreator(f,e);var g=BI.pluck(c,"id");var b=c;if(e.isRelation===true){BI.each(g,function(l,k){var j=BI.pluck(b,"id");var i=BI.filter(h.tablesCreator(k,{isRelaion:true}),function(n,m){return !BI.contains(j,m.id)});b=BI.concat(b,i)})}BI.each(b,function(l,m){var j=BI.contains(g,m.id)?(BI.Utils.getTableNameByID(m.id)||""):(BI.Utils.getTableNameByID(m.id)||"")+"("+BI.i18nText("BI-Relation_Table")+")";
var k=BI.extend({id:m.id,wId:h.wId,type:"bi.detail_select_data_level_node",layer:0,text:j,title:a._getTitleByTableId(m.id),value:m.id,isParent:true,open:false},m);if(f===BICst.BUSSINESS_PACK_ID){k.lastModifyTime=BI.Utils.getTableLastModifyTimeByID(m.id)}d.push(k)});if(f===BICst.BUSSINESS_PACK_ID){d=BI.sortBy(d,"lastModifyTime").reverse()}this.primaryFieldIds=BI.Utils.getAllPrimaryKeyByTableIds(BI.pluck(c,"id"));return d},_getFieldsStructureByTableId:function(e,c){c=c||{};var b=this,g=this.options;
var f=this._getFieldStructureOfOneTable(e,c);if(g.showRelativeTables===true){var d=g.tablesCreator(e,{isRelation:true});BI.remove(d,function(j,h){return h.id===e});if(BI.isNotEmptyArray(d)){var a=[];BI.each(d,function(h,j){a.push({id:j.id,pId:BI.PackageSelectDataService.RELATION_TABLE,type:"bi.relation_table_expander",el:BI.extend({type:"bi.detail_select_data_level_node",layer:1,wId:g.wId,text:BI.Utils.getTableNameByID(j.id)||"",title:b._getTitleByTableId(j.id),value:j.id},j,{isParent:true,open:false}),popup:{type:"bi.select_data_loader",items:b._getFieldStructureOfOneTable(j.id,BI.extend(c,{isRelation:true}))}})
});f.push({type:"bi.relation_tables_expander",el:{id:BI.PackageSelectDataService.RELATION_TABLE,pId:e,wId:g.wId,type:"bi.select_data_relation_tables_node",text:BI.i18nText("BI-More_Foreign_Table")+">>",title:BI.i18nText("BI-More_Foreign_Table"),value:BI.PackageSelectDataService.RELATION_TABLE,isParent:true,open:false},popup:{items:a}})}}return f},_getFieldsStructureByTableIdAndKeyword:function(c,f){var h=[];var i=this,b=this.options;var e=b.fieldsCreator(c,{keyword:f,isSearching:true});var d={},a={};
var g=BI.PackageSelectDataService.getAllRelativeFields(c,e,a);BI.each(g,function(l,m){var n=m.id;var o=BI.Utils.getFieldNameByID(n)||"";if(b.showDateGroup===true&&BI.Utils.getFieldTypeByID(n)===BICst.COLUMN.DATE){var k="bi.detail_select_data_level_item";h.push(d[n]={id:n,pId:c,wId:b.wId,_type:m.type||k,type:"bi.detail_select_data_level1_date_node",layer:1,fieldType:BI.Utils.getFieldTypeByID(n),text:o,title:i._getTitleByFieldId(n),value:n,isParent:true});h=h.concat(i._buildDateChildren(c,m))}else{h.push(d[n]=BI.extend({id:n,pId:c,wId:b.wId,type:"bi.detail_select_data_level_item",layer:1,fieldType:BI.Utils.getFieldTypeByID(n),text:o,title:i._getTitleByFieldId(n),value:n,drag:i._createDrag(o)},m))
}});if(BI.isNotEmptyObject(a)){BI.each(e,function(k,l){var n=l.id;if(BI.isNotEmptyArray(a[n])){var m=BI.Utils.getFieldNameByID(n)||"";h.push({id:n,pId:c,type:"bi.expander",text:m,el:BI.extend({wId:b.wId,text:m,title:i._getTitleByFieldId(n),keyword:f,fieldType:BI.Utils.getFieldTypeByID(n),value:n},l,{type:"bi.select_data_level1_date_node",layer:1,isParent:true,open:false}),popup:{type:"bi.select_data_loader",items:i._getSelfCircleFieldsByFieldId(n,a[n]||[])}})}})}var j=BI.Func.getSearchResult(h,f);
e=j.matched.concat(j.finded);h=[];BI.each(e,function(k,l){if(d[l.pId]){h.push(d[l.pId])}h.push(l)});return h},_getSelfCircleFieldsByFieldId:function(b,g,c){c=c||{};var a=this,f=this.options;g||(g=[]);var d=BI.Utils.getTableIdByFieldID(b);var e=[];BI.each(g,function(h,j){var k=j.id;var l=BI.Utils.getFieldNameByID(k)||"";e.push(BI.extend({id:k,pId:d,wId:f.wId,type:"bi.detail_select_data_level_item",layer:c.isRelation?3:2,fieldType:BI.Utils.getFieldTypeByID(k),text:l,title:a._getTitleByFieldId(k),value:k,drag:a._createDrag(l,true)},j))
});return e},_getFieldStructureOfOneTable:function(e,b){b=b||{};var k=[];var m=this,d=this.options,j=this._const;var l=[],h=[];if(d.showExcelView===true){var f=BI.Utils.getExcelViewByTableId(e);if(BI.isNotNull(f)&&BI.isNotEmptyObject(f.positions)){BI.each(f.positions,function(n,c){l.push(n);h.push(BI.Utils.getFieldTypeByID(n));console.log(BI.Utils.getWidgetTypeByID(d.wId))});m._judgeExcelView(k,h,e)}}var g=d.fieldsCreator(e,b);if((g.length===1&&BI.Utils.getFieldTypeByID(g[0].id))===BICst.COLUMN.COUNTER){k.push({type:"bi.label",value:BI.UUID(),text:BI.i18nText("BI-Basic_(Empty)"),pId:e,id:BI.UUID(),wId:d.wId,textAlign:"left",lgap:b.isRelation?j.FIELD_GAP*2:j.FIELD_GAP,disabled:true});
return k}if(g.length===0){k.push({type:"bi.label",value:BI.UUID(),text:BI.i18nText("BI-No_Useable_Fields"),pId:e,id:BI.UUID(),wId:d.wId,textAlign:"left",lgap:b.isRelation?j.FIELD_GAP*2:j.FIELD_GAP,disabled:true});return k}var a={};var i=BI.PackageSelectDataService.getAllRelativeFields(e,g,a);BI.each(i,function(n,o){var p=o.id;if(l.contains(p)){return}var q=BI.Utils.getFieldNameByID(p)||"";if(d.showDateGroup===true&&BI.Utils.getFieldTypeByID(p)===BICst.COLUMN.DATE){var c="bi.detail_select_data_level_item";
if(b.isRelation===true){k.push({id:p,pId:e,type:"bi.expander",el:{type:"bi.detail_select_data_level2_date_node",layer:2,wId:d.wId,_type:o.type||c,text:q,title:m._getTitleByFieldId(p),value:p,isParent:true,open:false},popup:{type:"bi.select_data_loader",items:m._buildDateChildren(e,o,b.isRelation)}})}else{k.push({id:p,pId:e,wId:d.wId,_type:o.type||c,type:"bi.detail_select_data_level1_date_node",layer:1,fieldType:BI.Utils.getFieldTypeByID(p),text:q,title:m._getTitleByFieldId(p),value:p,isParent:true})
}}else{k.push(BI.extend({id:p,pId:e,wId:d.wId,type:"bi.detail_select_data_level_item",layer:b.isRelation?2:1,fieldType:BI.Utils.getFieldTypeByID(p),text:q,title:m._getTitleByFieldId(p),value:p,drag:m._createDrag(q)},o))}});if(BI.isNotEmptyObject(a)){BI.each(g,function(c,n){var p=n.id;if(BI.isNotEmptyArray(a[p])){var o=BI.Utils.getFieldNameByID(p)||"";k.push({id:p,pId:e,type:"bi.expander",text:o,el:BI.extend({wId:d.wId,text:o,title:m._getTitleByFieldId(p),fieldType:BI.Utils.getFieldTypeByID(p),value:p},n,{type:b.isRelation?"bi.select_data_level2_date_node":"bi.select_data_level1_date_node",layer:b.isRelation?2:1,isParent:true,open:false}),popup:{type:"bi.select_data_loader",items:m._getSelfCircleFieldsByFieldId(p,a[p]||[],b)}})
}})}return k},_judgeExcelView:function(g,c,e){var d=this,f=this.options,b=BI.Utils.getWidgetTypeByID(f.wId);if(b===BICst.WIDGET.STRING||b===BICst.WIDGET.LIST_LABEL||b===BICst.WIDGET.STRING_LIST){var a=BI.some(c,function(h,j){if(j===BICst.COLUMN.STRING){return true}return false});a&&d._addExcelView(g,e)}else{if(b===BICst.WIDGET.DATE_PANE||b===BICst.WIDGET.DATE||b===BICst.WIDGET.YEAR||b===BICst.WIDGET.QUARTER||b===BICst.WIDGET.MONTH||b===BICst.WIDGET.YMD){var a=BI.some(c,function(h,j){if(j===BICst.COLUMN.DATE){return true
}return false});a&&d._addExcelView(g,e)}else{if(b===BICst.WIDGET.NUMBER||b===BICst.WIDGET.INTERVAL_SLIDER){var a=BI.some(c,function(h,j){if(j===BICst.COLUMN.NUMBER){return true}return false});a&&d._addExcelView(g,e)}else{d._addExcelView(g,e)}}}},_addExcelView:function(c,a){var b=this.options;c.push({id:BI.UUID(),pId:a,type:"bi.excel_view",tableId:a,wId:b.wId})},_createDrag:function(d,b){var a=this,c=this.options;return{cursor:BICst.cursorUrl,cursorAt:{left:5,top:5},drag:function(g,f){},helper:function(){var h=d;
var e=a.searcher.getValue();if(e.length>1){h=BI.i18nText("BI-All_Field_Count",e.length)}var g=BI.map(e,function(j,i){if(BI.has(i,"group")){k=BICst.DATE_GROUP[i.group.type]+"("+BI.Utils.getFieldNameByID(i.fieldId)+")";return{name:k,_src:{id:i.fieldId+i.group.type,fieldId:i.fieldId,tableId:BI.Utils.getTableIdByFieldID(i.fieldId)},type:BI.Utils.getDimensionTypeByFieldID(i.fieldId),group:{type:i.group.type}}}var k=BI.Utils.getFieldNameByID(i);if(c.wId&&BI.Utils.isControlWidgetByWidgetId(c.wId)){k=BI.Utils.getTableNameByID(BI.Utils.getTableIdByFieldID(i))+"."+k
}return{name:k,_src:{id:i,fieldId:i,tableId:BI.Utils.getTableIdByFieldID(i)},notShowNull:b||false,type:BI.Utils.getDimensionTypeByFieldID(i)}});var f=BI.createWidget({type:"bi.helper",data:{data:g},text:h});BI.createWidget({type:"bi.absolute",element:"body",items:[{el:f}]});return f.element},start:function(e,f){BI.Broadcasts.send(BICst.BROADCAST.FIELD_DRAG_START,f.helper.data("data"))},stop:function(e,f){BI.Broadcasts.send(BICst.BROADCAST.FIELD_DRAG_STOP)}}},_createDateSubTypeItem:function(e,b,c){var g=this.options;
c=c||{};c.field=c.field||{};var a=c.field.id||c.field.value;var f="bi.detail_select_data_level_item";var d=2;switch((e<<1)|b){case 0:f="bi.detail_select_data_level_item";d=2;break;case 1:f="bi.detail_select_data_level_item";d=3;break;case 2:f="bi.detail_select_data_level_item";d=3;break;case 3:f="bi.detail_select_data_level_item";d=4;break}return BI.extend({wId:g.wId,type:f,fieldType:BICst.COLUMN.DATE,drag:c.drag},c.field,{id:a+c.groupType,pId:a,text:c.text,title:c.title,layer:d,value:{fieldId:a,group:{type:c.groupType}}})
},_buildDateChildren:function(d,i,j){var b=this.options,h=this._const,l=this;j=j||false;var g=i.id||i.value;var k=i.text||BI.Utils.getFieldNameByID(g)||"";var e=this._createDrag(k);var f=this._getTitleByFieldId(g)+".";var a=[];BI.each(h.DATE_GROUP,function(c,m){a.push(l._createDateSubTypeItem(j,false,{drag:e,field:i,text:BICst.DATE_GROUP[m],title:f+BICst.DATE_GROUP[m],groupType:m}))});a.push({id:BI.UUID(),pId:g,type:"bi.expander",el:{type:j?"bi.detail_select_data_level2_more_date_node":"bi.detail_select_data_level1_more_date_node",wId:b.wId,text:BI.i18nText("BI-More_Group"),title:BI.i18nText("BI-More_Group"),value:BI.UUID(),isParent:true,open:false},popup:{type:"bi.select_data_loader",items:BI.map(h.COMBINE_DATE_GROUP,function(c,m){return l._createDateSubTypeItem(j,true,{drag:e,field:i,text:BICst.DATE_GROUP[m],title:f+BICst.DATE_GROUP[m],groupType:m})
})}});return a},setPackage:function(a){this.searcher.setPackage(a)},setEnabledValue:function(a){this.searcher.setEnabledValue(a)},stopSearch:function(){this.searcher.stopSearch()},populate:function(){this.searcher.populate.apply(this.searcher,arguments)},destroyed:function(){BI.each(this._broadcasts,function(b,a){a()});this._broadcasts=[]}});BI.PackageSelectDataService.EVENT_CLICK_ITEM="EVENT_CLICK_ITEM";BI.extend(BI.PackageSelectDataService,{RELATION_TABLE:"__relation_table__",getAllRelativeFields:function(g,a,h){h=h||{};
var b=[];var f=new Set(),c=[],e={},d={};BI.each(a,function(k,l){var m=BI.Utils.getOriginalFieldNameByID(l.id);if(m){var j=m.split("-")[0];e[m]=l.id;if(f.has(j)){c.push(j)}else{f.add(j)}}});if(c.length>0&&BI.every(c,function(k,j){return e[j]!=null})){BI.each(a,function(l,m){var n=BI.Utils.getOriginalFieldNameByID(m.id);var j=n.split("-")[0];var k=c.contains(j);if(j!==n&&k){if(!d[j]){d[j]=[]}d[j].push(m)}else{if(!k){b.push(m)}}});BI.each(d,function(j,i){h[e[j]]=i})}else{b=a}return b}});BI.shortcut("bi.package_select_data_service",BI.PackageSelectDataService);
BI.SimpleSelectDataService=BI.inherit(BI.Widget,{_defaultConfig:function(){return BI.extend(BI.SimpleSelectDataService.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-simple-select-data-service",isDefaultInit:false,tablesCreator:function(){return[]},fieldsCreator:function(){return[]}})},_init:function(){BI.SimpleSelectDataService.superclass._init.apply(this,arguments);var a=this,b=this.options;this.searcher=BI.createWidget({type:"bi.simple_select_data_searcher",element:this,itemsCreator:function(e,d){if(BI.isKey(e.searchType)&&BI.isKey(e.keyword)){var c=a._getSearchResult(e.searchType,e.keyword);
d(c.finded,c.matched);return}if(!e.node){d(a._getTablesStructure());return}if(BI.isKey(e.node._keyword)){d(a._getFieldsStructureByTableIdAndKeyword(e.node.id,e.node._keyword),e.node._keyword);return}if(BI.isNotNull(e.node.isParent)){d(a._getFieldsStructureByTableId(e.node.id))}}});this.searcher.on(BI.SelectDataSearcher.EVENT_CLICK_ITEM,function(d,c){a.fireEvent(BI.SimpleSelectDataService.EVENT_CLICK_ITEM,arguments)});if(b.isDefaultInit===true){this.populate()}},_getTitleByFieldId:function(b){var d=BI.Utils.getFieldNameByID(b);
var c=BI.Utils.getTableIdByFieldID(b);var a=BI.Utils.getTableNameByID(c);return a+"."+d||""},_getSearchResult:function(g,e){var j=this,b=this.options;var d=[],c=[];if(g&BI.SelectDataSearchSegment.SECTION_TABLE){var f=j._getTablesStructure();var k=BI.Func.getSearchResult(f,e);d=k.finded;c=k.matched}else{var a={},h={};var i=b.tablesCreator();var f=[];BI.each(i,function(m,n){var l=j._getFieldsStructureByTableId(n.id||n.value);BI.each(l,function(o,p){h[p.id||p.value]=n});f=f.concat(l)});var k=BI.Func.getSearchResult(f,e);
BI.each(k.matched.concat(k.finded),function(m,l){if(!a[l.pId]){d.push(BI.extend({id:l.pId,wId:b.wId,text:BI.Utils.getTableNameByID(l.pId)||BI.Utils.getFieldNameByID(l.pId)||"",title:BI.Utils.getTableNameByID(l.pId)||BI.Utils.getFieldNameByID(l.pId)||"",value:l.pId,type:"bi.simple_select_data_level0_node",layer:0},h[l.id||l.value],{isParent:true,open:true,_keyword:e}));a[l.pId]=true}});c=c.concat(k.matched)}return{finded:d,matched:c}},_getTablesStructure:function(){var a=this,d=this.options;var c=[];
var b=d.tablesCreator();BI.each(b,function(e,f){c.push(BI.extend({id:f.id,type:"bi.simple_select_data_level0_node",layer:0,text:BI.Utils.getTableNameByID(f.id)||"",title:BI.Utils.getTableNameByID(f.id)||"",value:f.id,isParent:true,open:false},f))});return c},_getFieldsStructureByTableIdAndKeyword:function(c,f){var h=[];var i=this,b=this.options;var e=b.fieldsCreator(c);var d={},a={};var g=BI.PackageSelectDataService.getAllRelativeFields(c,e,a);BI.each(g,function(k,l){var m=l.id;var n=BI.Utils.getFieldNameByID(m)||"";
h.push(d[m]=BI.extend({id:m,pId:c,wId:b.wId,type:"bi.detail_select_data_level_item",layer:1,fieldType:BI.Utils.getFieldTypeByID(m),text:n,title:i._getTitleByFieldId(m),value:m},l))});if(BI.isNotEmptyObject(a)){BI.each(e,function(k,l){var n=l.id;if(BI.isNotEmptyArray(a[n])){var m=BI.Utils.getFieldNameByID(n)||"";h.push({id:n,pId:c,type:"bi.expander",text:m,el:BI.extend({wId:b.wId,text:m,keyword:f,title:i._getTitleByFieldId(n),fieldType:BI.Utils.getFieldTypeByID(n),value:n},l,{type:"bi.select_data_level1_date_node",layer:1,isParent:true,open:false}),popup:{type:"bi.select_data_loader",items:i._getSelfCircleFieldsByFieldId(n,a[n]||[])}})
}})}var j=BI.Func.getSearchResult(h,f);e=j.matched.concat(j.finded);h=[];BI.each(e,function(k,l){if(d[l.pId]){h.push(d[l.pId])}h.push(l)});return h},_getSelfCircleFieldsByFieldId:function(b,f){var a=this,e=this.options;f||(f=[]);var c=BI.Utils.getTableIdByFieldID(b);var d=[];BI.each(f,function(g,h){var j=h.id;var k=BI.Utils.getFieldNameByID(j)||"";d.push(BI.extend({id:j,pId:c,wId:e.wId,type:"bi.detail_select_data_level_item",layer:2,fieldType:BI.Utils.getFieldTypeByID(j),text:k,title:a._getTitleByFieldId(j),value:j},h))
});return d},_getFieldsStructureByTableId:function(e){var h=[];var d=this,g=this.options;var c=[];var a=g.fieldsCreator(e);var f={};var b=BI.PackageSelectDataService.getAllRelativeFields(e,a,f);BI.each(b,function(j,k){var l=k.id;if(c.contains(l)){return}var m=BI.Utils.getFieldNameByID(l)||"";h.push(BI.extend({id:l,pId:e,wId:g.wId,type:"bi.detail_select_data_level_item",layer:1,fieldType:BI.Utils.getFieldTypeByID(l),text:m,title:d._getTitleByFieldId(l),value:l},k))});if(BI.isNotEmptyObject(f)){BI.each(a,function(j,k){var m=k.id;
if(BI.isNotEmptyArray(f[m])){var l=BI.Utils.getFieldNameByID(m)||"";h.push({id:m,pId:e,type:"bi.expander",text:l,el:BI.extend({wId:g.wId,text:l,title:d._getTitleByFieldId(m),fieldType:BI.Utils.getFieldTypeByID(m),value:m},k,{type:"bi.select_data_level1_date_node",layer:1,isParent:true,open:false}),popup:{type:"bi.select_data_loader",items:d._getSelfCircleFieldsByFieldId(m,f[m]||[])}})}})}return h},setEnabledValue:function(a){this.searcher.setEnabledValue(a)},stopSearch:function(){this.searcher.stopSearch()
},populate:function(){this.searcher.populate.apply(this.searcher,arguments)}});BI.SimpleSelectDataService.EVENT_CLICK_ITEM="EVENT_CLICK_ITEM";BI.shortcut("bi.simple_select_data_service",BI.SimpleSelectDataService);
BI.UploadExcelButton=BI.inherit(BI.Button,{_defaultConfig:function(){return BI.extend(BI.UploadExcelButton.superclass._defaultConfig.apply(this,arguments),{progressEL:BICst.BODY_ELEMENT,level:"common"})},_init:function(){BI.UploadExcelButton.superclass._init.apply(this,arguments);this._fillFile()},_fillFile:function(){var a=this;this.file=BI.createWidget({type:"bi.upload_file_with_progress",progressEL:this.options.progressEL,accept:"*.csv;*.xls;*.xlsx"});this.file.on(BI.UploadFileWithProgress.EVENT_CHANGE,function(){this.upload()
});this.file.on(BI.UploadFileWithProgress.EVENT_UPLOADED,function(){var b=this.getValue();a.fireEvent(BI.UploadExcelButton.EVENT_AFTER_UPLOAD,b)});BI.createWidget({type:"bi.absolute",element:this,items:[{el:this.file,top:0,left:0,right:0,bottom:0}]})},setText:function(a){BI.UploadExcelButton.superclass.setText.apply(this,arguments);this._fillFile()},upload:function(){this.file.upload()}});BI.UploadExcelButton.EVENT_AFTER_UPLOAD="EVENT_AFTER_UPLOAD";BI.shortcut("bi.upload_excel_button",BI.UploadExcelButton);
BI.ExcelTipCombo=BI.inherit(BI.Widget,{constants:{TIP_WIDTH:24,TIP_HEIGHT:24,TIP_POPUP_WIDTH:520,TIP_POPUP_HEIGHT:420,TIP_POPUP_EXAMPLE_WIDTH:480,TIP_POPUP_EXAMPLE_HEIGHT:240,TIP_POPUP_COMMENT_HEIGHT:20,TIP_POPUP_GAP:15},_defaultConfig:function(){return BI.extend(BI.ExcelTipCombo.superclass._defaultConfig.apply(this,arguments),{baseCls:"bi-excel-tip-combo"})},_init:function(){BI.ExcelTipCombo.superclass._init.apply(this,arguments);var b=BI.createWidget({type:"bi.icon_button",cls:"excel-upload-tip-font tip-combo-trigger bi-list-item-simple",width:this.constants.TIP_WIDTH,height:this.constants.TIP_HEIGHT});
var a=BI.createWidget({type:"bi.vertical",cls:"tip-combo-popup",items:[{type:"bi.label",height:this.constants.TIP_POPUP_GAP},{type:"bi.label",text:BI.i18nText("BI-Basic_Attention"),textAlign:"left",cls:"popup-tip-label bi-tips",height:this.constants.TIP_POPUP_COMMENT_HEIGHT},{type:"bi.label",text:BI.i18nText("BI-Upload_Excel_Version"),textAlign:"left",height:this.constants.TIP_POPUP_COMMENT_HEIGHT},{type:"bi.label",text:BI.i18nText("BI-Upload_Excel_Format"),textAlign:"left",height:this.constants.TIP_POPUP_COMMENT_HEIGHT},{type:"bi.label",text:BI.i18nText("BI-Upload_Excel_First_Sheet"),textAlign:"left",height:this.constants.TIP_POPUP_COMMENT_HEIGHT},{type:"bi.label",text:BI.i18nText("BI-Upload_Excel_Name_Value"),textAlign:"left",height:this.constants.TIP_POPUP_COMMENT_HEIGHT},{type:"bi.label",text:BI.i18nText("BI-Basic_Example"),textAlign:"left",cls:"popup-tip-label bi-tips",height:25},{type:"bi.center_adapt",cls:"example-excel-icon",items:[{type:"bi.icon",width:this.constants.TIP_POPUP_EXAMPLE_WIDTH,height:this.constants.TIP_POPUP_EXAMPLE_HEIGHT}]},{type:"bi.label",height:this.constants.TIP_POPUP_GAP}],hgap:this.constants.TIP_POPUP_GAP});
BI.createWidget({type:"bi.combo",element:this,trigger:"hover",isNeedAdjustWidth:false,isNeedAdjustHeight:false,offsetStyle:"center",el:b,popup:{el:a,maxHeight:this.constants.TIP_POPUP_HEIGHT,width:this.constants.TIP_POPUP_WIDTH}})}});BI.shortcut("bi.excel_tip_combo",BI.ExcelTipCombo);
BI.TableChartManagerAspect=function(){var c=this;var d=function(){if(!c.tipPane){c.tipPane=BI.createWidget({type:"bi.layout",height:100});c.textLabel=BI.createWidget({type:"bi.label",text:BI.i18nText("BI-Empty_Widget_Tip"),cls:"empty-widget-tip bi-tips",height:30});c.contactAdmin=BI.createWidget({type:"bi.label",text:BI.i18nText("BI-Please_Contact_Admin"),cls:"contact-admin-tip bi-tips",height:30});c.mainPane=BI.createWidget({type:"bi.center_adapt",cls:"widget-tip-pane",items:[{type:"bi.vertical",width:"100%",items:[c.tipPane,c.textLabel,c.contactAdmin]}]});
BI.createWidget({type:"bi.absolute",element:c,scrollable:false,items:[{el:c.mainPane,top:0,left:0,right:0,bottom:0}]})}};var a=function(){if(BI.Utils.isQueryControlExist()&&BI.isNull(BI.Utils.getControlFilters())){return" "}var f=c.options;var e=f.wId,g=f.status;var l=BI.Utils.getWidgetViewByID(e);var n=true;var j=0,h=0,m=0,k=0,i=0;BI.each(l,function(p,o){if(BI.Utils.isDimensionRegion1ByRegionType(p)){BI.each(o,function(q,r){BI.Utils.isDimensionUsable(r)&&BI.Utils.isDimensionValidByDimensionID(r)&&j++
})}else{if(BI.Utils.isDimensionRegion2ByRegionType(p)){BI.each(o,function(q,r){BI.Utils.isDimensionUsable(r)&&h++})}else{if(BI.Utils.isTargetRegion1ByRegionType(p)){BI.each(o,function(q,r){BI.Utils.isDimensionUsable(r)&&m++})}else{if(BI.Utils.isTargetRegion2ByRegionType(p)){BI.each(o,function(q,r){BI.Utils.isDimensionUsable(r)&&k++})}else{if(BI.Utils.isTargetRegion3ByRegionType(p)){BI.each(o,function(q,r){BI.Utils.isDimensionUsable(r)&&i++})}}}}}});switch(BI.Utils.getWidgetTypeByID(e)){case BICst.WIDGET.TABLE:(j+h+m+k+i)===0&&(n="table-group-tip-background");
break;case BICst.WIDGET.CROSS_TABLE:(j+h+m+k+i)===0&&(n="table-cross-tip-background");break;case BICst.WIDGET.COMPLEX_TABLE:(j+h+m+k+i)===0&&(n="table-complex-tip-background");break;case BICst.WIDGET.DOT:!(m>0&&k>0)&&(n="dot-tip-background");break;case BICst.WIDGET.AXIS:!((m>0||k>0||i>0))&&(n="axis-tip-background");break;case BICst.WIDGET.LINE:!(m>0||k>0||i>0)&&(n="line-tip-background");break;case BICst.WIDGET.AREA:!(m>0||k>0||i>0)&&(n="area-tip-background");break;case BICst.WIDGET.ACCUMULATE_AXIS:!((m>0||k>0||i>0))&&(n="axis-accu-tip-background");
break;case BICst.WIDGET.ACCUMULATE_AREA:!(m>0||k>0||i>0)&&(n="area-accu-tip-background");break;case BICst.WIDGET.ACCUMULATE_RADAR:!(j>0&&(m>0||k>0||i>0))&&(n="radar-accu-tip-background");break;case BICst.WIDGET.PERCENT_ACCUMULATE_AXIS:!((m>0||k>0||i>0))&&(n="axis-percent-tip-background");break;case BICst.WIDGET.PERCENT_ACCUMULATE_AREA:!(m>0||k>0||i>0)&&(n="area-percent-tip-background");break;case BICst.WIDGET.COMPARE_AXIS:!((m>0||k>0||i>0))&&(n="axis-compare-tip-background");break;case BICst.WIDGET.COMPARE_AREA:!(m>0||k>0||i>0)&&(n="area-compare-tip-background");
break;case BICst.WIDGET.FALL_AXIS:!(j>0&&(m>0||k>0||i>0))&&(n="axis-fall-tip-background");break;case BICst.WIDGET.RANGE_AREA:!(m>0||k>0||i>0)&&(n="area-range-tip-background");break;case BICst.WIDGET.BAR:!((m>0||k>0||i>0))&&(n="bar-tip-background");break;case BICst.WIDGET.ACCUMULATE_BAR:!((m>0||k>0||i>0))&&(n="bar-accu-tip-background");break;case BICst.WIDGET.COMPARE_BAR:!((m>0||k>0||i>0))&&(n="bar-compare-tip-background");break;case BICst.WIDGET.COMBINE_CHART:!((m>0||k>0||i>0))&&(n="combine-tip-background");
break;case BICst.WIDGET.RADAR:!(j>0&&(m>0||k>0||i>0))&&(n="radar-tip-background");break;case BICst.WIDGET.DONUT:m===0&&(n="donut-tip-background");break;case BICst.WIDGET.MULTI_AXIS_COMBINE_CHART:!((m>0||k>0||i>0))&&(n="combine-m-tip-background");break;case BICst.WIDGET.FORCE_BUBBLE:!(j>0&&(m>0||k>0||i>0))&&(n="bubble-force-tip-background");break;case BICst.WIDGET.FUNNEL:m===0&&(n="funnel-tip-background");break;case BICst.WIDGET.WORD_CLOUD:(j===0||m===0)&&(n="word-cloud-tip-background");break;case BICst.WIDGET.GIS_MAP:!(b(e,BICst.REGION.DIMENSION1,l)&&m>0)&&(n="map-gis-tip-background");
break;case BICst.WIDGET.HEAT_MAP:!(b(e,BICst.REGION.DIMENSION1,l)&&m>0)&&(n="map-heat-tip-background");break;case BICst.WIDGET.LINE_MAP:!(b(e,BICst.REGION.DIMENSION1,l)&&b(e,BICst.REGION.DIMENSION2,l)&&m>0)&&(n="map-line-tip-background");break;case BICst.WIDGET.MAP:!(j>0&&(m>0||k>0||i>0))&&(n="map-tip-background");break;case BICst.WIDGET.PIE:m===0&&(n="pie-tip-background");break;case BICst.WIDGET.MULTI_PIE:m===0&&(n="multi-pie-tip-background");break;case BICst.WIDGET.RECT_TREE:m===0&&(n="rect-tree-tip-background");
break;case BICst.WIDGET.DASHBOARD:m===0&&(n="dashboard-tip-background");break}return n};function b(k,j,e){j=parseInt(j);var i=BI.Utils.getWidgetRegionsByID(k)[j];if(i&&i.useLonLat){var g=0,h=0;BI.each(e[j+1],function(l,m){BI.Utils.isDimensionUsable(m)&&BI.Utils.isDimensionValidByDimensionID(m)&&(g++)});BI.each(e[j+2],function(l,m){BI.Utils.isDimensionUsable(m)&&BI.Utils.isDimensionValidByDimensionID(m)&&(h++)});return g&&h}else{var f=0;BI.each(e[j],function(l,m){BI.Utils.isDimensionUsable(m)&&BI.Utils.isDimensionValidByDimensionID(m)&&(f++)
});return f}}BI.aspect.before(this,"populate",function(){var g=a();if(g!==true){d();c.mainPane.setVisible(true);c.textLabel.setText(BI.i18nText("BI-Empty_Widget_Tip"));c.contactAdmin.setVisible(false);c.tipPane.element.removeClass().addClass(g);c.textLabel.setVisible(c.options.status===BICst.WIDGET_STATUS.EDIT);return}if(!BI.Utils.isAllFieldsExistByWidgetID(c.options.wId)){d();c.mainPane.setVisible(true);c.textLabel.setVisible(true);var f=BI.i18nText("BI-Data_Miss_Tip");var e="data-miss-background";
if(BI.Utils.isNoAuthFieldExistByWidgetID(c.options.wId)){f=BI.i18nText("BI-No_Data_Auth_Tip");e="no-data-auth-background"}c.textLabel.setText(f);c.contactAdmin.setVisible(true);c.tipPane.element.removeClass().addClass(e);return}c.mainPane&&c.mainPane.setVisible(false)})};
BI.DetailTableAspect=function(){var a=this;var b=function(){if(!a.tipPane){a.tipPane=BI.createWidget({type:"bi.layout",height:100});a.textLabel=BI.createWidget({type:"bi.label",text:BI.i18nText("BI-Empty_Widget_Tip"),cls:"empty-widget-tip bi-tips",height:30});a.contactAdmin=BI.createWidget({type:"bi.label",text:BI.i18nText("BI-Please_Contact_Admin"),cls:"contact-admin-tip bi-tips",height:30});a.mainPane=BI.createWidget({type:"bi.center_adapt",cls:"widget-tip-pane",items:[{type:"bi.vertical",width:"100%",items:[a.tipPane,a.textLabel,a.contactAdmin]}]});
BI.createWidget({type:"bi.absolute",element:a,scrollable:false,items:[{el:a.mainPane,top:0,left:0,right:0,bottom:0}]})}};BI.aspect.before(this,"populate",function(){var f=BI.Utils.getAllUsableDimensionIDs(a.options.wId);var e="table-detail-tip-background";if(f.length===0){b();a.mainPane.setVisible(true);a.textLabel.setText(BI.i18nText("BI-Empty_Widget_Tip"));a.contactAdmin.setVisible(false);a.tipPane.element.removeClass().addClass(e);a.textLabel.setVisible(a.options.status===BICst.WIDGET_STATUS.EDIT);
return}if(!BI.Utils.isAllFieldsExistByWidgetID(a.options.wId)){b();a.mainPane.setVisible(true);a.textLabel.setVisible(true);var d=BI.i18nText("BI-Data_Miss_Tip");var c="data-miss-background";if(BI.Utils.isNoAuthFieldExistByWidgetID(a.options.wId)){d=BI.i18nText("BI-No_Data_Auth_Tip");c="no-data-auth-background"}a.textLabel.setText(d);a.contactAdmin.setVisible(true);a.tipPane.element.removeClass().addClass(c);return}a.mainPane&&a.mainPane.setVisible(false)})};
(function(){var a=function(c,b){BI.Plugin.registerObject(c,function(d){b.apply(d,arguments)})};a("bi.table_chart_manager",BI.TableChartManagerAspect);a("bi.detail_table",BI.DetailTableAspect)})();
$(function(){if(BI.isIE9Below()){$("html").addClass("ie9below")}});
/**
 * Created by hyp on 2016/8/4.
 */
DirectPool = {
    // "table":Data.SharingPool.get("fields")
    share: {},
    put: function (key, value) {
        this.share[key] = value;
    },

    cat: function () {
        var args = Array.prototype.slice.call(arguments, 0),
            copy = this.share;
        for (var i = 0; i < args.length; i++) {
            copy = copy[args[i]];
        }
        return copy;
    },

    get: function () {
        return BI.deepClone(this.cat.apply(this, arguments));
    },
};
//螺旋分析使用 MyPool
MyPool = {
    source: {},
    groups: {},
    packages: {},
    connections: {"connectionSet": []},
    relations: {},
    translations: {},
    tables: {},
    fields: {},
    excel_views: {},
    fieldInfo: {}
};
BIPool = Pool;
Direct = {};

Direct.Utils = {
    getTableIDBySplit_ :function (fieldId) {
        return fieldId ? fieldId.split("_")[0] : "";
    },
    replaceAllUnderline:function (tableName) {
        // 替换掉所有下划线
        return tableName ? tableName.replace(/_/g,"[5f]") : "";
    },
    createFieldId: function (newTableId,oldTableId,fieldId) {
        // var fieldId = field.id;
        return fieldId ? fieldId.replace(oldTableId,newTableId) : "";
    },
    getEnv:function () {
        var isAnalysis = (typeof (BI.Dezi) !== "undefined");
        this.getEnv = function () {
            return isAnalysis;
        };
        return isAnalysis;
    },
    fillFieldInfo:function (tableInfos) {
        var allFields = BIPool.fields || {};
        var tables = BIPool.tables;
        var isAna = Direct.Utils.getEnv();
        BI.each(tableInfos, function (index, tableInfo) {
            var id = tableInfo.id;
            if (id !== null) {
                if (tables[id]) {
                    BI.each(tableInfo.fields, function (index1, fieldArr) {
                        BI.each(fieldArr, function (index2, field) {
                            field.tableId = id;
                            allFields[field.id] = field;
                            !isAna && (field.isUsable = true);
                        })
                    });
                    tables[id].fields = tableInfo.fields;
                    BI.each(tableInfo.translations, function (key, value) {
                        BIPool.translations[key] = value;
                    })

                }
            }
        });
        BIPool.fields = allFields;
    },
    // 从conf.js里挪过来
    getSheetStyleSheet: function () {
        var styleTag = document.createElement('style'),
            styleSheet;
        // Append style element to head
        document.head.appendChild(styleTag);
        styleSheet = styleTag.sheet ? styleTag.sheet : styleTag.styleSheet;
        this.getSheetStyleSheet = function () {
            return styleSheet;
        };
        return styleSheet;
    },

    delStyle2StyleSheet: function delStyle2StyleSheet(index) {
        var styleSheet = this.getSheetStyleSheet();
        if (styleSheet.deleteRule) {
            styleSheet.deleteRule(index);
        } else if (styleSheet.removeRule) {
            styleSheet.removeRule(index);
        }
    },

    add1Style2StyleSheet: function add1Style2StyleSheet(ruleStyle, index) {
        var styleSheet = this.getSheetStyleSheet();
        if (styleSheet.insertRule) {   // all browsers, except IE before version 9
            styleSheet.insertRule(ruleStyle, index || 0);
        } else {  // Internet Explorer before version 9
            if (styleSheet.addRule) {
                styleSheet.addRule(ruleStyle, 0);
            }
        }
        // styleSheet.insertRule(ruleStyle, styleSheet.cssRules.length);
    },

    isCircleField: function (fieldID) {
        var tableID = BI.Utils.getTableIdByFieldID(fieldID);
        var fields = BI.Utils.getFieldsByTableId(tableID);
        var newFields = Direct.PackageSelectDataService.getAllRelativeFields(tableID, fields);
        var isCircleFieldFlag = true;
        BI.each(newFields, function (index, item) {
            var fid = item.id;
            if (fid == fieldID) {
                isCircleFieldFlag = false;
            }
        });
        return isCircleFieldFlag;
    },
    setParameter2Use: function (isBefore) {
        var widgets = Data.SharingPool.get("widgets");

        function changeWidgetType(item) {
            if (item.isParameter) {
                if (isBefore) {
                    (item.type === 32 || item.type === 100000) && (item.type = 100000);
                    (item.type === 52 || item.type === 200000) && (item.type = 200000);
                    (item.type == 48 || item.type == 300000) && (item.type = 300000);
                    (item.type === 51 || item.type === 400000) && (item.type = 400000);
                    (item.type === 49 || item.type === 500000) && (item.type = 500000);
                    (item.type == BICst.WIDGET.STRING_LIST || item.type == 600000) && (item.type = 600000 );
                    (item.type === BICst.WIDGET.LIST_LABEL || item.type === 700000) && (item.type = 700000);
                    (item.type === BICst.WIDGET.DATE_PANE || item.type === 800000) && (item.type = 800000);
                } else {
                    (item.type === 32 || item.type === 100000) && (item.type = 32);
                    (item.type === 52 || item.type === 200000) && (item.type = 52);
                    (item.type == 48 || item.type == 300000) && (item.type = 48 );
                    (item.type === 51 || item.type === 400000) && (item.type = 51);
                    (item.type === 49 || item.type === 500000) && (item.type = 49);
                    (item.type == BICst.WIDGET.STRING_LIST || item.type == 600000) && (item.type = BICst.WIDGET.STRING_LIST );
                    (item.type === BICst.WIDGET.LIST_LABEL || item.type === 700000) && (item.type = BICst.WIDGET.LIST_LABEL);
                    (item.type === BICst.WIDGET.DATE_PANE || item.type === 800000) && (item.type = BICst.WIDGET.DATE_PANE);
                }
            }
        }

        BI.each(widgets, function (index, item) {
            changeWidgetType(item);
        })
        Data.SharingPool.put("widgets", widgets);

        if (isBefore) {

        }
    },
    getDirectDate: function (parseValue, consultDate) {
        var dateValue;
        if (parseValue.type === BICst.DATE_TYPE.MULTI_DATE_PARAM) {
            dateValue = parseComplexDateForParam(parseValue.value);
            // return dateValue;
        } else {
            dateValue = parseComplexDateCommon(parseValue, consultDate);
        }
        if (BI.isNull(dateValue)) {
            return {};
        }
        var dateResult = Date.getDate(dateValue);
        return {
            year: dateResult.getFullYear(),
            month: dateResult.getMonth(),
            day: dateResult.getDate()
        };
        function parseComplexDateForParam(value) {
            var widgetInfo = value.widgetInfo,
                offset = value.offset;
            if (BI.isNull(widgetInfo) || BI.isNull(offset)) {
                return;
            }
            var paramDate;
            var wWid = widgetInfo.wId,
                se = widgetInfo.startOrEnd;
            if (BI.isNotNull(wWid) && BI.isNotNull(se)) {
                var wWValue = BI.Utils.getWidgetValueByID(wWid);
                if (BI.isNull(wWValue) || BI.isEmptyObject(wWValue)) {
                    return;
                }
                if (se === BI.MultiDateParamPane.start && BI.isNotNull(wWValue.start)) {
                    paramDate = parseComplexDateCommon(wWValue.start);
                }
                if (se === BI.MultiDateParamPane.end && BI.isNotNull(wWValue.end)) {
                    paramDate = parseComplexDateCommon(wWValue.end);
                }
            } else {
                if (BI.isNull(widgetInfo.wId) || BI.isNull(BI.Utils.getWidgetValueByID(widgetInfo.wId))) {
                    return;
                }
                paramDate = parseComplexDateCommon(BI.Utils.getWidgetValueByID(widgetInfo.wId));
            }
            if (BI.isNotNull(paramDate)) {
                return parseComplexDateCommon(offset, Date.getDate(paramDate));
            }
        }

        function parseComplexDateCommon(v, consultedDate) {
            var type = v.type,
                value = v.value;
            var date = BI.isNull(consultedDate) ? Date.getDate() : consultedDate;
            var currY = date.getFullYear(),
                currM = date.getMonth(),
                currD = date.getDate();
            date = Date.getDate(date.getFullYear(), date.getMonth(), date.getDate());
            if (BI.isNull(type) && isValidDate(v)) {
                return Date.getTime(v.year, v.month, v.day);
            }
            var offsetDate;
            switch (type) {
                case BICst.DATE_TYPE.MULTI_DATE_YEAR_PREV:
                    return Date.getTime(currY - 1 * value, currM, currD);
                case BICst.DATE_TYPE.MULTI_DATE_YEAR_AFTER:
                    return Date.getTime(currY + 1 * value, currM, currD);
                case BICst.DATE_TYPE.MULTI_DATE_YEAR_BEGIN:
                    return Date.getTime(currY, 0, 1);
                case BICst.DATE_TYPE.MULTI_DATE_YEAR_END:
                    return Date.getTime(currY, 11, 31);

                case BICst.DATE_TYPE.MULTI_DATE_MONTH_PREV:
                    offsetDate = date.getBeforeMultiMonth(value);
                    return Date.getTime(offsetDate.getFullYear(), offsetDate.getMonth(), offsetDate.getDate(), offsetDate.getHours(), offsetDate.getMinutes(), offsetDate.getSeconds());
                case BICst.DATE_TYPE.MULTI_DATE_MONTH_AFTER:
                    offsetDate = date.getAfterMultiMonth(value);
                    return Date.getTime(offsetDate.getFullYear(), offsetDate.getMonth(), offsetDate.getDate(), offsetDate.getHours(), offsetDate.getMinutes(), offsetDate.getSeconds());
                case BICst.DATE_TYPE.MULTI_DATE_MONTH_BEGIN:
                    offsetDate = Date.getDate(currY, currM, 1);
                    return Date.getTime(offsetDate.getFullYear(), offsetDate.getMonth(), offsetDate.getDate(), offsetDate.getHours(), offsetDate.getMinutes(), offsetDate.getSeconds());
                case BICst.DATE_TYPE.MULTI_DATE_MONTH_END:
                    offsetDate = Date.getDate(currY, currM, (date.getLastDateOfMonth()).getDate());
                    return Date.getTime(offsetDate.getFullYear(), offsetDate.getMonth(), offsetDate.getDate(), offsetDate.getHours(), offsetDate.getMinutes(), offsetDate.getSeconds());
                case BICst.DATE_TYPE.MULTI_DATE_QUARTER_PREV:
                    offsetDate = date.getBeforeMulQuarter(value);
                    return Date.getTime(offsetDate.getFullYear(), offsetDate.getMonth(), offsetDate.getDate(), offsetDate.getHours(), offsetDate.getMinutes(), offsetDate.getSeconds());
                case BICst.DATE_TYPE.MULTI_DATE_QUARTER_AFTER:
                    offsetDate = date.getAfterMulQuarter(value);
                    return Date.getTime(offsetDate.getFullYear(), offsetDate.getMonth(), offsetDate.getDate(), offsetDate.getHours(), offsetDate.getMinutes(), offsetDate.getSeconds());
                case BICst.DATE_TYPE.MULTI_DATE_QUARTER_BEGIN:
                    offsetDate = date.getQuarterStartDate();
                    return Date.getTime(offsetDate.getFullYear(), offsetDate.getMonth(), offsetDate.getDate(), offsetDate.getHours(), offsetDate.getMinutes(), offsetDate.getSeconds());
                case BICst.DATE_TYPE.MULTI_DATE_QUARTER_END:
                    offsetDate = date.getQuarterEndDate();
                    return Date.getTime(offsetDate.getFullYear(), offsetDate.getMonth(), offsetDate.getDate(), offsetDate.getHours(), offsetDate.getMinutes(), offsetDate.getSeconds());
                case BICst.DATE_TYPE.MULTI_DATE_WEEK_PREV:
                    offsetDate = date.getOffsetDate(-7 * value);
                    return Date.getTime(offsetDate.getFullYear(), offsetDate.getMonth(), offsetDate.getDate(), offsetDate.getHours(), offsetDate.getMinutes(), offsetDate.getSeconds());
                case BICst.DATE_TYPE.MULTI_DATE_WEEK_AFTER:
                    offsetDate = date.getOffsetDate(7 * value);
                    return Date.getTime(offsetDate.getFullYear(), offsetDate.getMonth(), offsetDate.getDate(), offsetDate.getHours(), offsetDate.getMinutes(), offsetDate.getSeconds());
                case BICst.DATE_TYPE.MULTI_DATE_DAY_PREV:
                    offsetDate = date.getOffsetDate(-1 * value);
                    return Date.getTime(offsetDate.getFullYear(), offsetDate.getMonth(), offsetDate.getDate(), offsetDate.getHours(), offsetDate.getMinutes(), offsetDate.getSeconds());
                case BICst.DATE_TYPE.MULTI_DATE_DAY_AFTER:
                    offsetDate = date.getOffsetDate(1 * value);
                    return Date.getTime(offsetDate.getFullYear(), offsetDate.getMonth(), offsetDate.getDate(), offsetDate.getHours(), offsetDate.getMinutes(), offsetDate.getSeconds());
                case BICst.DATE_TYPE.MULTI_DATE_DAY_TODAY:
                    return Date.getTime();
                case BICst.DATE_TYPE.MULTI_DATE_CALENDAR:
                    return Date.getTime(value.year, value.month, value.day);

            }
        }

        function isValidDate(v) {
            return BI.isNotNull(v.year) && BI.isNotNull(v.month) && BI.isNotNull(v.day);
        }
    },
    checkIsWidgetUseParameter:function (wId) {
        var widgets = Data.SharingPool.get("widgets");
        var widget = widgets[wId];
        return widget && widget["isParameter"];
    },
    aspect4Parameter: function () {
        //拦截是否参数 控件 两用
        BI.aspect.before(BI.Utils, "getControlCalculations", function () {
            if (!DirectPool.get("isparameter2use")) {//如果控件不是两用
                Direct.Utils.setParameter2Use("before" === "before");
            }
        });
        BI.aspect.after(BI.Utils, "getControlCalculations", function () {
            if (!DirectPool.get("isparameter2use")) {//如果控件不是两用
                Direct.Utils.setParameter2Use("after" === "before");
            }
        });
        // 拦截 Data.Req.reqWidgetSettingByData 将参数加上
        // 添加 widgetId 保证后台导出Excel 同一个组件
        BI.aspect.before(Data.Req, "reqWidgetSettingByData", function (data, callback) {
            if (!Direct.Utils.isRealTime()) {
                return;
            }
            parametervaluefilter = {};
            var widgetName = data.widget.name;
            var widgetId;
            var widgets = Data.SharingPool.get("widgets");
            BI.any(widgets, function (index, item) {
                var currentWidgetName = BI.Utils.getWidgetNameByID(index);
                if (widgetName === currentWidgetName) {
                    widgetId = index;
                    data.widget.widgetId = index;
                    return true;
                }
            })
            BI.each(widgets, function (index, item) {
                if (widgetId !== index) {
                    if (item.type == BICst.WIDGET.STRING || item.type == 100000) {//文本
                        if (item.isParameter) {
                            if (item.parameterText != null && item.parameterText != "") {
                                parametervaluefilter[item.parameterText] = {
                                    value: item.value,
                                    parameter_type: Direct.ParameterPool.parameter[item.parameterText],
                                };
                            }
                        }
                    } else if (item.type == BICst.WIDGET.YMD || item.type == 200000) {//日期
                        if (item.isParameter) {
                            item.value || (item.value = {});
                            if (item.value && item.parameterText != null && item.parameterText != "") {
                                parametervaluefilter[item.parameterText] = {
                                    value: {type: 3, value: Direct.Utils.getDirectDate(item.value)},
                                    parameter_type: Direct.ParameterPool.parameter[item.parameterText],
                                };
                            }
                        }
                    } else if (item.type == BICst.WIDGET.DATE || item.type == 300000) {//日期区间
                        if (item.isParameter) {
                            item.value || (item.value = {});
                            if (item.value && item.parameterText != null &&
                                item.parameterText.value1 != null &&
                                item.parameterText.value1 != "") {
                                var start = item.value.start || {};
                                var end = item.value.end || {};
                                parametervaluefilter[item.parameterText.value1] = {
                                    value: {type: 3, value: Direct.Utils.getDirectDate(start)},
                                    parameter_type: Direct.ParameterPool.parameter[item.parameterText.value1],
                                };
                                parametervaluefilter[item.parameterText.value2] = {
                                    value: {type: 3, value: Direct.Utils.getDirectDate(end)},
                                    parameter_type: Direct.ParameterPool.parameter[item.parameterText.value2],
                                };
                            }
                        }
                    } else if (item.type == BICst.WIDGET.MONTH || item.type == 400000) {//年月
                        if (item.isParameter) {
                            item.value || (item.value = {});
                            if (item.value && item.parameterText != null &&
                                item.parameterText.value1 != null &&
                                item.parameterText.value1 != "") {
                                parametervaluefilter[item.parameterText.value1] = {
                                    value: {value: [item.value.year], type: 0},
                                    parameter_type: Direct.ParameterPool.parameter[item.parameterText.value1],
                                };
                                parametervaluefilter[item.parameterText.value2] = {
                                    value: {value: [item.value.month + 1], type: 0},
                                    parameter_type: Direct.ParameterPool.parameter[item.parameterText.value2],
                                };
                            }
                        }
                    } else if (item.type == BICst.WIDGET.YEAR || item.type == 500000) {//年空间
                        if (item.isParameter) {
                            if (item.parameterText != null && item.parameterText != "")
                                parametervaluefilter[item.parameterText] = {
                                    value: {type: 0, value: [item.value]},
                                    parameter_type: Direct.ParameterPool.parameter[item.parameterText],
                                };
                        }
                    } else if (item.type == BICst.WIDGET.STRING_LIST || item.type == 600000) {//文本
                        if (item.isParameter) {
                            if (item.parameterText != null && item.parameterText != "")
                                parametervaluefilter[item.parameterText] = {
                                    value: item.value,
                                    parameter_type: Direct.ParameterPool.parameter[item.parameterText],
                                };
                        }
                    } else if (item.type == BICst.WIDGET.LIST_LABEL || item.type == 700000) {//文本
                        if (item.isParameter) {
                            if (item.parameterText != null && item.parameterText != "")
                                parametervaluefilter[item.parameterText] = {
                                    value: item.value,
                                    parameter_type: Direct.ParameterPool.parameter[item.parameterText],
                                };
                        }
                    } else if (item.type == BICst.WIDGET.DATE_PANE || item.type == 800000) {//日期面板
                        if (item.isParameter) {
                            item.value || (item.value = {});
                            if (item.value && item.parameterText != null && item.parameterText != "") {
                                parametervaluefilter[item.parameterText] = {
                                    value: {type: 3, value: Direct.Utils.getDirectDate(item.value)},
                                    parameter_type: Direct.ParameterPool.parameter[item.parameterText],
                                };
                            }
                        }
                    }
                }
            });
            data.widget.parameter = parametervaluefilter;
        });
    },
    exportExcelById: function (wId) {
        var self = BI.Utils;
        // BI.requestAsync("fr_bi_dezi", "save_widget", {widget: self.getWidgetCalculationByID(wId)}, function () {
        var url = BI.servletURL + "?op=realtime&cmd=bi_export_excel&sessionID=" + Data.SharingPool.get("sessionID") + "&name="
            + window.encodeURIComponent(BI.cjkEncode(self.getWidgetNameByID(wId))) + "&widgetId=" + wId + "&len=" + (BI.Utils.getAllUsableDimDimensionIDs(wId).length+BI.Utils.getAllUsableTargetDimensionIDs(wId).length);

        window.open(url, "_blank");
        // }, function () {
        // })
    },
    isTableUseableInWidget: function (wid, tableId) {
        function checkWidget(widgetType) {
            return widgetType == BICst.WIDGET.NUMBER/*数值*/
                || widgetType == BICst.WIDGET.STRING/*文本*/
                || widgetType == BICst.WIDGET.YEAR/*年份*/
                || widgetType == BICst.WIDGET.YMD/*日期*/
                || widgetType == BICst.WIDGET.DATE/*日期区间*/
                || widgetType == BICst.WIDGET.DATE_PANE/*日期面板*/
                || widgetType == BICst.WIDGET.MONTH/*年月*/
                || widgetType == BICst.WIDGET.INTERVAL_SLIDER
            /*区间滑块*/
        }

        var widgetType;
        var allIds = [], targetIds, dimIds;
        if (wid && Data.SharingPool.get("widgets", wid) && Data.SharingPool.get("widgets", wid, "view")) {
            dimIds = BI.Utils.getAllDimDimensionIDs(wid);
            targetIds = BI.Utils.getAllTargetDimensionIDs(wid);
            allIds = dimIds.concat(targetIds);
            widgetType = Data.SharingPool.cat("widgets", wid, "type");
        }
        if (allIds.length > 0) {
            var tableIds = {};
            var oneTable;
            var allTableIds = {}, targetTableIds = {}, dimTableIds = {};
            BI.each(allIds, function (index, item) {
                var tId = BI.Utils.getTableIDByDimensionID(item);
                if (tId == null) {
                    return;
                }
                oneTable = tId;
                allTableIds[tId] = tId;
            })
            BI.each(targetIds, function (index, item) {
                var tId = BI.Utils.getTableIDByDimensionID(item);
                if (tId == null) {//派生指标
                    return;
                }
                targetTableIds[tId] = tId;
            })
            BI.each(dimIds, function (index, item) {
                var tId = BI.Utils.getTableIDByDimensionID(item);
                dimTableIds[tId] = tId;
                allTableIds[tId] = tId;
            })

            if (checkWidget(widgetType)) {
                return true;
                // tableIds = Direct.RelationsFactory.getDetailRelationTableIds.call(Direct.RelationsFactory, allTableIds, oneTable);
            } else {
                tableIds = Direct.RelationsFactory.getRelationsTables.call(Direct.RelationsFactory, allTableIds, dimTableIds, targetTableIds, oneTable);
            }
            if (tableIds[tableId]) {
                return true;
            } else {
                return false;
            }
        } else {
            return true;
        }
    },
    is2Parameters: function (widgetType) {
        if (widgetType == BICst.WIDGET.DATE
            || widgetType == BICst.WIDGET.MONTH
        ) {
            return true;
        }
        return false;
    },
    isParameterWidgetByType: function (widgetType) {
        //文本类
        if (widgetType == BICst.WIDGET.STRING
            || widgetType == BICst.WIDGET.LIST_LABEL
            || widgetType == BICst.WIDGET.STRING_LIST
        ) {
            return true;
        }
        //数值类
        // if(widgetType==BICst.WIDGET.NUMBER
        //     || widgetType==BICst.WIDGET.INTERVAL_SLIDER){
        //     return true;
        // }
        // 日期类
        if (widgetType == BICst.WIDGET.DATE_PANE
            || widgetType == BICst.WIDGET.DATE
            || widgetType == BICst.WIDGET.YEAR
            || widgetType == BICst.WIDGET.MONTH
            || widgetType == BICst.WIDGET.YMD
        ) {
            return true;
        }
        return false;
    },
    isParameterWidget: function (wId) {
        var widgetType = BI.Utils.getWidgetTypeByID(wId);
        return Direct.Utils.isParameterWidgetByType(widgetType);
    },
    getConfAllPackageIDs: function () {
        return BI.keys(DirectPool.get("package"));
    },
    getConfPackageGroupIDs: function () {
        return BI.keys(DirectPool.get("groups"));
    },
    getAuthorityLoginField: function () {
        var authoritySettings = DirectPool.get("authority_settings");
        return authoritySettings["loginField"];
    },
    getFieldNameByFieldId4Conf: function (fieldId) {
        if (!Pool.fields[fieldId] && fieldId.split("_").length > 1) {
            BI.Utils.getFieldIDsOfTableID(fieldId.split("_")[0]);
        }
        var field = DirectPool.get("fields", fieldId) || {};
        var translations = DirectPool.get("translations");
        var trans = translations[fieldId] || field.fieldName
        if (!trans && DirectPool.get("DirectMultiPathConf")) {
            trans = DirectPool.get("DirectMultiPathConf")["translations"][fieldId];
        }
        if (!trans) {
            trans = Pool["translations"][fieldId] || (Pool.fields[fieldId] && Pool.fields[fieldId]["fieldName"]);
        }
        return trans;
    },
    getAuthorityRoles: function () {
        var authority_settings = DirectPool.get("authority_settings") || {};
        return authority_settings && authority_settings.allRoles;
    },
    getPackageAuthorityByID: function (pid) {
        var authority_settings = DirectPool.get("authority_settings") || {};
        return authority_settings.packagesAuth && authority_settings.packagesAuth[pid];
    },
    getAllGroupedPackagesTree: function () {
        var groupMap = DirectPool.get("groups"), packages = DirectPool.get("packages");
        return BI.Utils.getAllGroupedPackagesTree(groupMap, packages);
    },
    changeToHumpNaming: function () {
        return {
            changeField: function (field) {
                if (field) {
                    field["classType"] = field["class_type"];
                    field["fieldName"] = field["field_name"];
                    field["fieldType"] = field["field_type"];
                    field["isEnable"] = field["is_enable"];
                    field["tableId"] = field["table_id"];
                    field["isUsable"] = field["is_usable"];
                }
                return field;
            },
            changeMutiPathField: function (data) {
                BI.each(data, function (index, paths) {
                    function addHumpNaming(paths) {
                        BI.each(paths, function (ind, path) {
                            BI.each(path, function (ide, keys) {
                                BI.each(keys, function (iden, field) {
                                    field['fieldId'] = field['field_id'];
                                    field['tableId'] = field['table_id'];
                                    field['fieldName'] = field['field_name'];
                                });
                            });
                        });
                    }

                    if (index == "availableRelations" || index == "disabledRelations") {
                        addHumpNaming(paths);
                    } else if (index == "relations") {
                        BI.each(paths, function (it, item) {
                            addHumpNaming(item);
                        })
                    }

                });
            }
        };
    },
    getDimensionIDsFromDimensions: function (wid) {
        var result = [];
        var widget = Data.SharingPool.get("widgets", wid);
        var dimensions = widget && widget.dimensions;
        BI.each(dimensions, function (dimId, dim) {
            result.push(dimId);
        });
        return result;
    },
    getPrimaryRelationTablesByTableID: function (tableId) {
        var copyVector = Direct.RelationsFactory.getCopyVector()[tableId] || {};
        var primaryTables = [];
        BI.each(copyVector["forward"], function (index, item) {
            primaryTables.push(item);
        });
        return BI.uniq(primaryTables);
    },
    isPackageExist: function (packageId) {
        return Pool.packages[packageId] ? true : false;
    },

    getETLTableData: function (table) {
        var result = Direct.Utils.getJoinFieldInfo4Tables(table);
        // var result = BI.requestSync("realtime", "get_join_field_info_4_tables", table);
        return result;
    },
    reqCircleLayerLevelInfoByTableAndCondition: function (table, layerInfo, callback, complete) {
        // table.tableType = "join";
        BI.requestAsync("realtime", "create_fields_union", {
            table: table,
            idFieldName: layerInfo.idFieldName,
            parentIdFieldName: layerInfo.parentIdFieldName,
            divideLength: layerInfo.divide_length,
            fetchUnionLength: layerInfo.fetch_union_length
        }, function (res) {
            callback(res);
        }, complete);
    },
    getCircleLayerLevelInfo: function (table, layerInfo, callback, complete) {
        Direct.Utils.reqCircleLayerLevelInfoByTableAndCondition(table, layerInfo,
            function (res) {
                callback(res);
            }, complete);
    },
    isAllFieldsExistByWidgetID: function (wid) {
        var self = this;
        var allDimIds = this.getAllDimensionIDs(wid);
        var generateTarget;
        return !BI.some(allDimIds, function (i, dId) {
            generateTarget = {};
            return checkDimension(dId)
        });

        function checkDimension(dId) {
            generateTarget[dId] || (generateTarget[dId] = {});
            var dType = BI.Utils.getDimensionTypeByID(dId);
            if (dType === BICst.TARGET_TYPE.STRING ||
                dType === BICst.TARGET_TYPE.NUMBER ||
                dType === BICst.TARGET_TYPE.DATE ||
                dType === BICst.TARGET_TYPE.COUNTER) {
                var fieldId = BI.Utils.getFieldIDByDimensionID(dId);
                if (BI.isNull(Pool.fields[fieldId])) {
                    return true;
                }
            } else {
                //计算指标
                var expression = BI.Utils.getExpressionByDimensionID(dId);
                var fIds = expression.ids;
                return BI.some(fIds, function (j, fId) {
                    var id = BI.Utils.getFieldIDByDimensionID(fId);
                    if (BI.isNotNull(self.getDimensionTypeByID(fId))) {
                        if (!generateTarget[dId][fId]) {
                            generateTarget[dId][fId] = fId;
                            var result = checkDimension(fId);
                            if (generateTarget[fId][dId]) {
                                result = false;
                            }
                            BI.each(generateTarget[fId], function (index1, item1) {
                                // if(generateTarget[dId])
                                generateTarget[dId][index1] = item1;
                            });
                            return result;
                        } else {
                            return false;
                        }
                    } else if (BI.isNull(Pool.fields[id])) {
                        return false;
                    }

                });
            }
        }
    },

    checkDimensionType: function (type) {
        return (type === BICst.TARGET_TYPE.STRING ||
            type === BICst.TARGET_TYPE.NUMBER ||
            type === BICst.TARGET_TYPE.DATE ||
            type === BICst.TARGET_TYPE.COUNTER);
    },

    getTableFieldIdsJson: function (fieldIds) {
        var jsonData = [], json = {}, tableIds = [];
        for (var i = 0; i < fieldIds.length; ++i) {
            tableIds[i] = Direct.Utils.getTableIDbyFieldID(fieldIds[i]);
            jsonData.push(tableIds[i], fieldIds[i]);
        }
        tableIds = BI.uniq(tableIds);
        for (i = 0; i < tableIds.length; ++i) {
            var temp = [];
            for (var j = 0; j < jsonData.length; j += 2) {
                if (tableIds[i] === jsonData[j]) {
                    temp.push(jsonData[j + 1]);
                }
            }
            json[tableIds[i]] = temp;
        }
        return json;
    },

    isNoAuthFieldExistByWidgetID: function (wid) {
        if ("-999" === DirectPool.get("userId")) {
            return false;
        }
        var self = this;
        var allDimIds = this.getAllDimensionIDs(wid);
        var fieldIds = [];
        getFieldIds(allDimIds, fieldIds);
        fieldIds = BI.uniq(fieldIds);
        var json = Direct.Utils.getTableFieldIdsJson(fieldIds);
        var flag = false;
        Direct.Utils.checkTablesByTableIds({tableData: json}, function (res) {
            BI.each(res, function (id, info) {
                MyPool.fieldInfo[id] = {};
                MyPool.fieldInfo[id].isExist = info.isExist;
                MyPool.fieldInfo[id].hasPermission = info.hasPermission;
                if (!flag && info.isExist && !info.hasPermission) {
                    flag = true;
                }
            });
        });
        return flag;

        function getFieldIds(allDimIds, fieldIds) {
            for (var i = 0; i < allDimIds.length; ++i) {
                var dType = BI.Utils.getDimensionTypeByID(allDimIds[i]);
                if (Direct.Utils.checkDimensionType(dType)) {
                    var fieldId = BI.Utils.getFieldIDByDimensionID(allDimIds[i]);
                    if (BI.isNotNull(fieldId)) {
                        fieldIds.push(fieldId);
                    }
                } else {
                    var expression = BI.Utils.getExpressionByDimensionID(allDimIds[i]);
                    var dIds = expression.ids;
                    if (BI.isNotNull(dType)) {
                        getFieldIds(dIds, fieldIds);
                    }
                }
            }
        }
    },

    _isNoAuthFieldExistByWidget: function (widget) {
        if ("-999" === DirectPool.get("userId")) {
            return false;
        }
        var flag = false;
        var self = this;
        var allDims = widget.dimensions;
        var fieldIds = [];
        getFieldIds(allDims, fieldIds);
        fieldIds = BI.uniq(fieldIds);

        var json = Direct.Utils.getTableFieldIdsJson(fieldIds);
        Direct.Utils.checkTablesByTableIds({tableData: json}, function (res) {
            flag = BI.some(res, function (id, info) {
                if (info.isExist && !info.hasPermission) {
                    return true;
                }
            });
        });
        return flag;

        function getFieldIds(allDims, fieldIds) {
            BI.each(allDims, function (id, dimension) {
                var dType = dimension.type;
                var fieldId;
                if (Direct.Utils.checkDimensionType(dType)) {
                    fieldId = dimension._src.fieldId;
                    if (BI.isNotNull(fieldId)) {
                        fieldIds.push(fieldId);
                    }
                } else {
                    var expression = dimension._src.expression;
                    var dIds = expression.ids;
                    for (var i = 0; i < dIds.length; ++i) {
                        var type = widget.dimensions[dIds[i]].type;
                        if (Direct.Utils.checkDimensionType(type)) {
                            fieldId = widget.dimensions[dIds[i]]._src.fieldId;
                            if (BI.isNotNull(fieldId)) {
                                fieldIds.push(fieldId);
                            }
                        } else if (BI.isNotNull(dType)) {
                            var dim = {};
                            dim[dIds[i]] = widget.dimensions[dIds[i]];
                            getFieldIds(dim, fieldIds)
                        }
                    }
                }
            });
        }
    },

    addUrlParameter: function (parametervaluefilter) {
        var commonParameters = ["cmd", "createBy", "edit", "id", "op"];
        var url = location.search;
        var urlParameters = {};
        if (url.indexOf("?") !== -1) {
            var str = url.substr(1);
            var strList = str.split("&");
            BI.each(strList, function (index, parameter) {
                var value = parameter.split("=");
                urlParameters[decodeURI(value[0])] = decodeURI(value[1]);
            });
        }
        BI.each(urlParameters, function (id, value) {
            if (!commonParameters.contains(id) && BI.isNull(parametervaluefilter[id])) {
                var val = [];
                val[0] = value;
                parametervaluefilter[id] = {
                    value: {value: val, type: 0, assist: val},
                    parameter_type: 1
                }
            }
        });
    },

    maskCube: function () {
        var isAllDirect = false;
        Direct.Utils.getIsAllDirect({data: "get"}, function (res) {
            if (res && res.isAllDirect) {
                isAllDirect = res.isAllDirect;
            }
        });

        DirectPool.put("isAllDirect",isAllDirect);
        // if (isAllDirect) {
            if (typeof (BI.FineBIService) !== "undefined") {
                BI.FineBIService.prototype._createItems = function () {
                    return DirectPool.get("BI.FineBIService.prototype._createItems").apply(this, arguments);
                };
            }
            if (typeof (BI.BusinessPackageAddSwitcher) !== "undefined") {
                BI.BusinessPackageAddSwitcher.prototype._init = function () {
                    return DirectPool.get("BI.BusinessPackageAddSwitcher.prototype._init").apply(this, arguments);
                };
            }
        // }
    },

    maskGlobalUpdate: function () {
        var hasGlobalUpdate = false;
        Direct.Utils.getHasGlobalUpdate(function (res) {
            if (res && res.hasGlobalUpdate) {
                hasGlobalUpdate = res.hasGlobalUpdate;
            }
        });

        DirectPool.put("hasGlobalUpdate", hasGlobalUpdate);
    },

    // 覆盖
    getForeignRelationTablesByTableID: function (tableId) {
        var foreignTables = [];
        // 不能用Pool.relations，否则会导致其他用到Pool.relations的地方出问题
        BI.each(MyPool.relations[tableId], function (tId, relations) {
            if (BI.isNotNull(relations)) {
                foreignTables.push(tId);
            }
        });
        return BI.uniq(foreignTables);
    },

    isConfig: function (data, callback, complete) {
        var res = BI.requestSync("realtime", "permission_config", data)//, function (res) {
        callback(res.result);
    },
    getConfDataByFieldId: function (data, callback, complete) {
        BI.requestAsync("realtime", "get_field_value_by_field_id", data, function (res) {
            callback(res.value);
        }, complete);
    },
    checkTablesByTableIds: function (data, callback) {
        var res = BI.requestSync("realtime", "check_tables_by_table_ids", data);
        callback(res);
    },
    saveLoginField: function (data, callback, complete) {
        BI.requestAsync("realtime", "save_login_field", data, function (res) {
            callback();
        }, complete)
    },
    savePackageAuthority: function (data, callback, complete) {
        BI.requestAsync("realtime", "save_package_authority", data, function (res) {
            callback(res);
        }, complete);
    },
    getAllETLTableNames: function (pId, tId) {
        var packages = DirectPool.get("DirectPackages");
        var names = [];
        BI.each(packages, function (index, item) {
            if (index == pId) {
                BI.each(item.tables, function (ind, ite) {
                    if (tId != ite["id"]) {
                        var name = item.translations[ite["id"]];
                        name && (names.push(name));
                    }
                })
            }
        });
        return names;
    },
    getTablesOfOnePackage: function (pId) {
        var packages = DirectPool.get("DirectPackages");//['packages'];
        var tables = [];
        BI.each(packages, function (index, item) {
            if (index == pId) {
                tables = BI.clone(item.tables);
            }
        });
        return tables;
    },
    getPackageNameOfOnePackage: function (pId) {
        var name = "默认业务包名";
        var packages = DirectPool.get("DirectPackages");

        // var packages = DirectPool.get("DirectPool")['packages'];
        // var name = "默认业务包名";
        BI.each(packages, function (index, item) {
            if (index == pId) {
                name = item.name;
            }
        });
        return name;
    },
    isRealTime: function () {
        return DirectPool.get("isrealtime") === "true";
        // return true;
    },
    //
    getTableIDbyFieldID: function (fieldId) {
        var strs = fieldId.split("_");
        if (strs.length == 2) {
            return strs[0];
        } else if (strs.length == 3) {
            return strs[0] + "_" + strs[1];
        }
        // if (BI.isNotNull(BIPool.fields[fieldId])) {
        //     return BIPool.fields[fieldId].tableId;
        // } else if (BI.isNotNull(MyPool.fields[fieldId])) {
        //     return MyPool.fields[fieldId].tableId;
        // }
    },

    init: function () {
        //替换函数
        BI.Utils.createDistinctName = BI.Utils.createDistinctName || BI.Func.createDistinctName;

        // 获取所有模板
        Data.Req.reqAllTemplates = function () {
            DirectPool.get("Data.Req.reqAllTemplates").apply(this, arguments);
        };

        if (Direct.Utils.isRealTime()) {
            Data.Req.reqWidgetByName = function () {
                DirectPool.get("Data.Req.reqWidgetByName").apply(this, arguments);
            };


            // cube常量 驼峰 更改
            BICst.JSON_KEYS.TABLE_TYPE = "tableType"
            DirectPool.get("BI.Utils.XXXX")();
            //屏蔽新建螺旋分析
            BI.Plugin.relieveObject('bi.data_style_tab');

            // if (typeof BIConf != "undefined") {
            //     //覆盖函数
            //     BI.RelationPaneModel.prototype.getParsedRelation = function () {
            //         DirectPool.get("BI.RelationPaneModel.getParsedRelation").call(this, arguments);
            //     }
            // }
            //注册新建分析编辑页面里面
            if (typeof (BI.Dezi) != "undefined") {
                //before after 如 文本控件 选择字段时 会发全局广播 获取数据集字段  由于直连是action请求字段  会导致一系列问题
                BI.aspect.before(BI.DetailSelectDataLevel0Node.prototype,"_createSetValue",function () {
                    BI.Utils.getFieldIDsOfTableID = DirectPool.get("getFieldIDsOfTableIDNoSearch")
                });
                BI.aspect.after(BI.DetailSelectDataLevel0Node.prototype,"_createSetValue",function () {
                    BI.Utils.getFieldIDsOfTableID = DirectPool.get("getFieldIDsOfTableIDWithSearch")
                });
                BI.aspect.before(BI.DetailSelectDataLevel0Node.prototype,"setValue",function () {
                    BI.Utils.getFieldIDsOfTableID = DirectPool.get("getFieldIDsOfTableIDNoSearch")
                });
                BI.aspect.after(BI.DetailSelectDataLevel0Node.prototype,"setValue",function () {
                    BI.Utils.getFieldIDsOfTableID = DirectPool.get("getFieldIDsOfTableIDWithSearch")
                });



                BI.aspect.before(BI.DetailSelectDataLevel0Node.prototype,"_createSetValue",function () {
                    BI.Utils.getFieldIDsWithCountFieldIdOfTableID = DirectPool.get("getFieldIDsWithCountFieldIdOfTableIDNoSearch")
                });
                BI.aspect.after(BI.DetailSelectDataLevel0Node.prototype,"_createSetValue",function () {
                    BI.Utils.getFieldIDsWithCountFieldIdOfTableID = DirectPool.get("getFieldIDsWithCountFieldIdOfTableIDWithSearch")
                });
                BI.aspect.before(BI.DetailSelectDataLevel0Node.prototype,"setValue",function () {
                    BI.Utils.getFieldIDsWithCountFieldIdOfTableID = DirectPool.get("getFieldIDsWithCountFieldIdOfTableIDNoSearch")
                });
                BI.aspect.after(BI.DetailSelectDataLevel0Node.prototype,"setValue",function () {
                    BI.Utils.getFieldIDsWithCountFieldIdOfTableID = DirectPool.get("getFieldIDsWithCountFieldIdOfTableIDWithSearch")
                });

                //组件复用 绑定参数复制
                BI.DragWidgetitem.prototype._init = function () {
                    DirectPool.get("BI.DragWidgetitem.prototype._init").apply(this,arguments);
                };

                //屏蔽复杂表 
                // BICst.DASHBOARD_WIDGETS[0][0]['children'].splice(2, 1);
                //屏蔽年季度控件
                BICst.DASHBOARD_WIDGETS[2][3]['children'].splice(2, 1);
                //屏蔽 区间滑块控件
                //BICst.DASHBOARD_WIDGETS[2][1]['children'].splice(1, 1);
                //屏蔽 树标签过滤组件
                //BICst.DASHBOARD_WIDGETS[2][2]['children'].splice(1, 1);
                //屏蔽 组件复用
                // BI.DragIconGroup.prototype._init = function () {
                //     BI.DragIconGroup.superclass._init.apply(this, arguments);
                //     var self = this, o = this.options, c = this._const, icons = [];
                //
                //     var config = BI.deepClone(BICst.DASHBOARD_WIDGETS);
                //     // config.push([{
                //     //     text: BI.i18nText("BI-Basic_Reuse"),
                //     //     title: BI.i18nText("BI-Reuse_Widget_Control"),
                //     //     value: -1,
                //     //     cls: "drag-reuse-icon",
                //     //     iconHeight: 24,
                //     //     iconWidth: 24
                //     // }]);
                //     var conf = this._formatConfig(config);
                //
                //     var gps = [];
                //     BI.each(conf, function (i, items) {
                //         if (i > 0) {
                //             gps.push(BI.createWidget({
                //                 type: "bi.center_adapt",
                //                 height: 12,
                //                 items: [{
                //                     type: "bi.label",
                //                     height: 1,
                //                     width: 60,
                //                     cls: "widget-generator-gap bi-border-bottom"
                //                 }]
                //             }));
                //         }
                //         gps.push(self._createOneGroupIcons(items));
                //     });
                //
                //     BI.createWidget({
                //         type: "bi.horizontal_auto",
                //         element: this,
                //         items: [{
                //             type: "bi.horizontal_auto",
                //             width: o.width,
                //             height: "100%",
                //             scrolly: true,
                //             items: [{
                //                 type: 'bi.vertical',
                //                 width: 80,
                //                 items: gps
                //             }]
                //         }]
                //     });
                // }
                // 覆盖掉file-font的样式
                Direct.Utils.add1Style2StyleSheet(".file-font .b-font{*zoom: expression( this.runtimeStyle['zoom'] = '1',this.innerHTML = '&#xe6af;');}", 0);
                Direct.Utils.add1Style2StyleSheet(".file-font .b-font:before {content: \"\\e6af\";color: #fbb03b;}", 1);
                Direct.Utils.add1Style2StyleSheet(".file-font.native .b-font:before,.real-time-font.disabled .b-font:before {content: \"\\e6af\";color: #fbb03b;}", 2);

                // 替换组件复用界面的判断业务包权限的函数
                BI.ReusePane.prototype._isNoAuthFieldExistByWidget = this._isNoAuthFieldExistByWidget;

                //屏蔽复用维度/指标
                BI.DetailSelectData.prototype.constants.DETAIL_TAB_HEIGHT = 0;
                BICst.DETAIL_FIELD_REUSE_TAB = [];

                //屏蔽preview按钮
                BI.aspect.after(BI.DetailSelectDataLevelItem.prototype, "_init", function () {
                    this.previewBtn.destroy();
                });
                //文本控件 字段预览
                BI.aspect.after(BI.SelectStringLevel0Item.prototype, "_init", function () {
                    this.previewBtn.destroy();
                });
                // 数值 字段预览
                BI.aspect.after(BI.SelectNumberLevel0Item.prototype, "_init", function () {
                    this.previewBtn.destroy();
                });
                // 日期 字段预览
                BI.aspect.after(BI.SelectDateLevel0Item.prototype, "_init", function () {
                    this.previewBtn.destroy();
                });

                //todo
                // //联动
                // BI.Linkage.prototype._refreshDragContainer = function () {
                //     return DirectPool.get("BI.Linkage.prototype._refreshDragContainer").call(this, arguments);
                // };

                //选择字段 添加灰化逻辑
                BI.aspect.after(BI.DetailSelectDataLevel0Node.prototype, "_init", function () {
                    var self = this, o = this.options;
                    //全局维度增删事件
                    BI.Broadcasts.on(BICst.BROADCAST.DIMENSIONS_PREFIX, function () {
                        self.setEnable(Direct.Utils.isTableUseableInWidget(o.wId, o.value));
                    });
                    //全局组件增删事件
                    BI.Broadcasts.on(BICst.BROADCAST.WIDGETS_PREFIX, function () {
                        self.setEnable(Direct.Utils.isTableUseableInWidget(o.wId, o.value));
                    });
                    self.setEnable(Direct.Utils.isTableUseableInWidget(o.wId, o.value));
                })
                //树控件 灰化
                BI.aspect.after(BI.AbstractTreeSelectDataNode.prototype, "_init", function () {
                    this.destroyed();
                    var self = this, o = this.options;
                    //全局维度增删事件
                    BI.Broadcasts.on(BICst.BROADCAST.DIMENSIONS_PREFIX, function () {
                        self.setEnable(Direct.Utils.isTableUseableInWidget(o.wId, o.value));
                    });
                    //全局组件增删事件
                    BI.Broadcasts.on(BICst.BROADCAST.WIDGETS_PREFIX, function () {
                        self.setEnable(Direct.Utils.isTableUseableInWidget(o.wId, o.value));
                    });
                    self.setEnable(Direct.Utils.isTableUseableInWidget(o.wId, o.value));
                })

                // //复制到分组
                // BI.createWidget({type:"bi.custom_group"}).__proto__._init = function () {
                //     DirectPool.get("BI.CustomGroup.prototype._init").call(this, arguments);
                // }
                // BI.CustomGroup.prototype._init = function () {
                //     DirectPool.get("BI.CustomGroup.prototype._init").call(this, arguments);
                // }
//todo
                //bidezi 导出Excel 明细表拦截
                BIDezi.DetailTableView.prototype._createTools = function () {
                    DirectPool.get("BIDezi.DetailTableView.prototype._createTools").call(this, arguments);
                };
                //分组表 交叉表
                BIDezi.WidgetView.prototype._createTools = function () {
                    DirectPool.get("BIDezi.WidgetView.prototype._createTools").call(this, arguments);
                };

                //Excel表相关
                Data.Req.reqCheckExcelUpdate = function () {
                };
                Data.Req.reqExcelLastModifiedDataById = function (data, callback, complete) {
                    BI.requestAsync("realtime", "get_excel_file_create_time", data, function (res) {
                        callback(res);
                    }, complete)
                };

                // // 分组表 交叉表  刷新数据
                // BIDezi.WidgetView.prototype.refresh = function () {
                //     DirectPool.get("BIDezi.WidgetView.prototype.refresh").call(this, arguments);
                // };

                //查询按钮
                // if (DirectPool.get("isConfigSearchFirst")) {
                //     BIDezi.QueryView = Direct.QueryView;
                // }

                // //覆盖对象
                // BIDezi.StringDetailView = Direct.StringDetailView;
                // BIDezi.StringWidgetView = Direct.StringWidgetView;
                // BIDezi.DetailView = Direct.DetailView;

                // BIDezi.PaneView = Direct.PaneView;
                //*///覆盖函数
                BIDezi.DetailView.prototype._buildCenter = function () {
                    return DirectPool.get("BIDezi.DetailView.prototype._buildCenter").call(this, arguments);
                }

                //覆盖组件复用的_init
                // BI.DragWidgetitem.prototype._init = function () {
                //     return DirectPool.get("BI.DragWidgetitem.prototype._init").call(this, arguments);
                // }


                BI.Utils.isAllFieldsExistByWidgetID = this.isAllFieldsExistByWidgetID;

                //文本类控件 添加参数功能
                BI.StringRegionsManager.prototype._createDimensionRegionHeader = function () {
                    return DirectPool.get("BIDezi.XXX.prototype._createDimensionRegionHeader").call(this, arguments);
                }

                //文本下拉过滤组件
                //文本标签过滤组件
                // 文本列表过滤组件
                function checkParameterTextChange(model,widget) {
                    function putWidgetValueByWId(wId, newVar) {
                        var widgets = Data.SharingPool.cat("widgets");
                        var tempWidget = widgets[wId];
                        if (BI.isNotNull(tempWidget)) {
                            tempWidget["value"] = newVar;
                            Data.SharingPool.put("widgets", widgets);
                        }
                    }
                    model.on("change", function (changed, prev, context, options) {
                        if (BI.has(changed, "isParameter") && DirectPool.get("noSelectAllOnParameter")){
                            widget.combo && widget.combo.setValue();
                            widget.combo && widget.model.set("value", widget.combo.getValue());

                            var newVar = null//{"type":1,"value":[],"assist":[]};
                            var wId = model.get("id");
                            widget.stringList && widget.model.set("value", newVar);
                            widget.stringList && putWidgetValueByWId(wId, newVar);
                            widget.stringList && widget.stringList.populate();

                            widget.listLabel && widget.model.set("value", null);
                            widget.listLabel && widget.listLabel.populate();
                        }
                        if (BI.has(changed, "parameterText") || BI.has(changed, "isParameter")) {
                            BI.Utils.broadcastAllWidgets2Refresh();
                        }
                    });
                }

                BI.aspect.after(BIDezi.StringListDetailView.prototype, "_createRegion", function () {
                    checkParameterTextChange(this.model,this);
                    DirectPool.put("model:" + this.model.get("id"), this.model);
                });
                BI.aspect.after(BIDezi.ListLabelDetailView.prototype, "_createRegion", function () {
                    checkParameterTextChange(this.model,this);
                    DirectPool.put("model:" + this.model.get("id"), this.model);
                });
                BI.aspect.after(BIDezi.StringDetailView.prototype, "_createRegion", function () {
                    checkParameterTextChange(this.model,this);
                    DirectPool.put("model:" + this.model.get("id"), this.model);
                });

                //数值类型控件
                BI.NumberRegionsManager.prototype._createDimensionRegionHeader = function () {
                    return DirectPool.get("BIDezi.XXX.prototype._createDimensionRegionHeader").call(this, arguments);
                }
                // 数值区间过滤组件
                BI.aspect.after(BIDezi.NumberDetailView.prototype, "_createRegion", function () {
                    checkParameterTextChange(this.model,this);
                    DirectPool.put("model:" + this.model.get("id"), this.model);
                });
                //区间滑块
                BI.aspect.after(BIDezi.IntervalSliderDetailView.prototype, "_createRegion", function () {
                    checkParameterTextChange(this.model,this);
                    DirectPool.put("model:" + this.model.get("id"), this.model);
                });
                // 日期类型控件
                BI.DateRegionsManager.prototype._createDimensionRegionHeader = function () {
                    return DirectPool.get("BIDezi.XXX.prototype._createDimensionRegionHeader").call(this, arguments);
                }
                // 日期区间
                BI.aspect.after(BIDezi.DateRangeDetailView.prototype, "_createRegion", function () {
                    checkParameterTextChange(this.model,this);
                    DirectPool.put("model:" + this.model.get("id"), this.model);
                });

                //年月过滤组件
                BI.aspect.after(BIDezi.YearMonthDetailView.prototype, "_createRegion", function () {
                    checkParameterTextChange(this.model,this);
                    DirectPool.put("model:" + this.model.get("id"), this.model);
                });
                //日期过滤组件
                BI.aspect.after(BIDezi.DateDetailView.prototype, "_createRegion", function () {
                    checkParameterTextChange(this.model,this);
                    DirectPool.put("model:" + this.model.get("id"), this.model);
                });
                //日期面板过滤组件
                BI.aspect.after(BIDezi.DatePaneDetailView.prototype, "_createRegion", function () {
                    checkParameterTextChange(this.model,this);
                    DirectPool.put("model:" + this.model.get("id"), this.model);
                });
                //年份过滤控件
                BI.aspect.after(BIDezi.YearDetailView.prototype, "_createRegion", function () {
                    checkParameterTextChange(this.model,this);
                    DirectPool.put("model:" + this.model.get("id"), this.model);
                });


                // BIDezi.YearDetailView.prototype._createRegion = function () {
                //     return DirectPool.get("BIDezi.XXX.prototype._createRegion").call(this, arguments);
                // }
                //
                // BIDezi.DateRangeDetailView.prototype._createRegion = function () {
                //     return DirectPool.get("BIDezi.XXX.prototype._createRegion").call(this, arguments);
                // }
                // BIDezi.YearMonthDetailView.prototype._createRegion = function () {
                //     return DirectPool.get("BIDezi.XXX.prototype._createRegion").call(this, arguments);
                // }
                // BIDezi.DateDetailView.prototype._createRegion = function () {//日期控件
                //     return DirectPool.get("BIDezi.XXX.prototype._createRegion").call(this, arguments);
                // }


                // BIDezi.DateWidgetView.prototype._render = function () {//日期控件
                //     return DirectPool.get("BIDezi.DateWidgetView.prototype._render").call(this, arguments);
                // }

                BIDezi.DimensionView.prototype._checkDimensionValid = function () {
                    return DirectPool.get("BIDezi.DimensionView.prototype._checkDimensionValid").call(this, arguments);
                }

                //明细表标红逻辑
                BI.aspect.after(BIDezi.DetailDimensionView.prototype, "refresh", function () {
                    var isRed = DirectPool.get("BIDezi.DetailDimensionView.prototype.refresh").call(this, arguments);
                    if (isRed) {
                        this.editor.setWarningTitle(BI.i18nText("Direct-Please_Check_Relations"));
                    }
                })

                BIDezi.TargetView.prototype.refresh = function () {
                    return DirectPool.get("BIDezi.TargetView.prototype.refresh").call(this, arguments);
                }

                //替换新建分析中更新excel文件的函数
                BI.UpdateExcelCombo.prototype._updateExcelTableDate = function () {
                    return DirectPool.get("BI.UpdateExcelCombo.prototype._updateExcelTableDate").apply(this, arguments);
                };
                // 加个提示框
                BIDezi.PaneView.prototype._createNorth = function () {
                    // BI.Msg.toast(BI.i18nText("Direct-Click2View_RealData"), "success");
                    return DirectPool.get("BIDezi.PaneView.prototype._createNorth").call(this, arguments);
                };
            }
            if (typeof BI.Show != "undefined") {

                // // /*屏蔽全局 导出Excel
                // BIShow.PaneView.prototype._createNorth = function () {
                //     // BI.Msg.toast(BI.i18nText("Direct-Click2View_RealData"), "success");
                //     return DirectPool.get("BIShow.PaneView.prototype._createNorth").call(this, arguments);
                // };*/

                //维度预览界面报红逻辑
                BIShow.DimensionView.prototype._checkDimensionValid = function () {
                    return DirectPool.get("BIDezi.DimensionView.prototype._checkDimensionValid").call(this, arguments);
                };
                BI.aspect.after(BIShow.DetailDimensionView.prototype, "refresh", function () {
                    var isRed = DirectPool.get("BIDezi.DetailDimensionView.prototype.refresh").call(this, arguments);
                    if (isRed) {
                        this.editor.setWarningTitle(BI.i18nText("Direct-Please_Check_Relations"));
                    }
                })

                BIShow.TargetView.prototype.refresh = function () {
                    return DirectPool.get("BIDezi.TargetView.prototype.refresh").call(this, arguments);
                }

                //数值字段  选为维度 默认相同值作为一组
                // BI.aspect.after(BI.DimensionNumberComboShow.prototype, "defaultItems", function (items) {
                //     var groups = items[1];
                //     var tempgroups = [];
                //     tempgroups.push(groups[1]);
                //     tempgroups.push(groups[0]);
                //     items[1] = tempgroups;
                // });

                // BI.aspect.after(BI.DimensionNumberComboShow.prototype, "_assertSort", function (val) {
                //     val.type = BICst.SORT.CUSTOM;
                // });

                //屏蔽 汇总表预览, 详细设置中日期字段不应可切为季度和星期显示
                // BI.aspect.after(BI.DimensionDateComboShow.prototype, "defaultItems", function (items) {
                //     var item = items[0];
                //     item && item.remove(item[4]);
                //     item && item.remove(item[2]);
                // });

                // BIShow.PaneView = Direct.PaneView;
                //覆盖
                BIShow.View.prototype._init = function () {
                    DirectPool.get("BIShow.View._init").call(this, arguments);
                };
//todo
                BIShow.DetailTableView.prototype._createTools = function () {
                    DirectPool.get("BIShow.DetailTableView.prototype._createTools").call(this, arguments);
                };

                BIShow.WidgetView.prototype._createTools = function () {
                    DirectPool.get("BIShow.WidgetView._createTools").call(this, arguments);
                };
                //屏蔽 季度日期
                // BI.DimensionDateComboShow.prototype.defaultItems = function () {
                //     return DirectPool.get("BI.DimensionDateComboShow.prototype.defaultItems").apply(this,arguments);
                // }
                // BIShow.StringWidgetView = Direct.StringWidgetView;
            }
            if (typeof BI.Show != "undefined" || typeof (BI.Dezi) != "undefined") {
                Data.Req.reqJumpFieldInfo = function (data, callback, complete) {
                    BI.requestAsync("realtime", "get_jump_field_info", data, function (res) {
                        callback(res);
                    }, complete);
                };

                BI.Utils.isNoAuthFieldExistByWidgetID = this.isNoAuthFieldExistByWidgetID;
                // 用tableId获取其关联路径上的所有N端的表
                BI.Utils.getForeignRelationTablesByTableID = this.getForeignRelationTablesByTableID;
                //屏蔽全选
                if(DirectPool.get("noSelectAllOnParameter")){
                    BI.ListLabel.prototype.addItems = function () {
                        DirectPool.get("BI.ListLabel.prototype.addItems").apply(this,arguments);
                    };
                    BI.SelectList.prototype._init = function () {
                        DirectPool.get("BI.SelectList.prototype._init").apply(this,arguments);
                    };
                    BI.SelectListLabel.prototype.populate = function () {
                        DirectPool.get("BI.SelectListLabel.prototype.populate").apply(this,arguments);
                    }

                    BI.SelectDataStringList.prototype._itemsCreator = function () {
                        DirectPool.get("BI.SelectDataStringList.prototype._itemsCreator").apply(this,arguments);
                    };

                    BI.SelectDataStringList.prototype.getValue = function () {
                        return DirectPool.get("BI.SelectDataStringList.prototype.getValue").apply(this,arguments);
                    };

                }

                //全局导出excel 替换连接
                BI.GlobalExport.prototype._exportRequest =  function (cmd, data, imgData) {
                    BI.Func.doActionByForm(BI.servletURL + "?op=realtime&cmd=" + cmd, BI.extend(data, {
                        base64: imgData.replaceAll('data:image/png;base64,', ''),
                        reportName: Data.SharingPool.get('reportName'),
                        sessionID: Data.SharingPool.get("sessionID")
                    }));
                };

                //注册添加公式
                BI.Plugin.registerWidget("bi.filter_operation", function (el) {
                    if (Direct.Utils.isRealTime()) {
                        return BI.extend({}, el, {type: "direct.filter_operation"});
                    }
                });

                //屏蔽添加公式
                BI.aspect.after(BI.DimensionFilterPopup.prototype, "rebuildNorth", function () {
                    var o = this.options;
                    var wId = BI.Utils.getWidgetIDByDimensionID(o.dId);
                    var widgetType = BI.Utils.getWidgetTypeByID(wId);
                    if(widgetType != BICst.WIDGET.DETAIL){
                        DirectPool.put("Dezi.currentClickType","dimension");
                    }else {
                        DirectPool.put("Dezi.currentClickType","target");
                    }
                });
                BI.aspect.after(BI.TargetFilterPopup.prototype, "rebuildNorth", function () {
                    DirectPool.put("Dezi.currentClickType","target");
                });

                // //仅有列表头的时候(有指标) 修正数据
                // BI.CrossTableModel.prototype.createTableAttrs = function () {
                //     DirectPool.get("BI.CrossTableModel.prototype.createTableAttrs").apply(this, arguments);
                // }
                //检测当前 widget 是否所有字段被删除
                DirectPool.get("changeAspect4WidgetTip")();

                //导出Excel 覆盖
                // BI.Utils.exportExcelById = Direct.Utils.exportExcelById;
                Direct.ParameterPool.initPool();
                function checkDimissions(dimensions, view) {

                    BI.each(dimensions, function (dimId, item) {
                        var isUseDim = Direct.RelationsFactory.getIsUsedDimensions(dimId);
                        if (isUseDim == null) {
                            var widgetId = BI.Utils.getWidgetIDByDimensionID(dimId);
                            Direct.RelationsFactory.setUsedDimensionsByWid(widgetId);
                            isUseDim = Direct.RelationsFactory.getIsUsedDimensions(dimId);
                        }
                        if (isUseDim == false) {
                            delete dimensions[dimId];
                            BI.each(view, function (viewId, item) {
                                view[viewId].remove(dimId);
                            })
                        }
                    });
                }

                Data.Req.reqWidgetSettingByData = function (data, callback, complete, op) {
                    function doComplete() {
                        if (typeof complete == "function") {
                            complete();
                        }
                    }

                    op = op || {};
                    var fn = "requestAsync";
                    if (op.sync === true) {
                        fn = "requestSync";
                    }
                    var dimensions = data.widget.dimensions || {};
                    var view = data.widget.view || {};
                    checkDimissions(dimensions, view);
                    if (dimensions && JSON.stringify(dimensions) == "{}") {// 自定义排序 自定义分组  （自定义分组指标只有 计算指标时   ）
                        callback({"data": {c: []}, "page": [0, 0, 0, 0, 1]});
                        doComplete();
                        return;
                    }
                    data.sessionID = Data.SharingPool.get("sessionID");
                    var name = "isClickSearch." + ((data.widget && data.widget.name) || "");
                    if (DirectPool.get(name) && data.widget &&
                        (data.widget.type != BICst.WIDGET.STRING
                        && data.widget.type != BICst.WIDGET.TREE
                        && data.widget.type != BICst.WIDGET.TREE_LIST
                        && data.widget.type != BICst.WIDGET.GENERAL_QUERY)) {
                        if (data.widget.type == BICst.WIDGET.DETAIL) {
                            callback({"data": {value: []}, "size": 0, "row": 0});
                        } else {
                            callback({"data": {}, "page": [0, 0, 0, 0, 1]});
                        }
                        doComplete();
                        DirectPool.put(name, false);
                    } else {
                        BI[fn]("realtime", "widget_setting", data, function (res) {
                            try {//为了防止 后台异常抛了空对象  前端没有检查 造成异常 捕获 传出空值
                                callback(res);
                            } catch (e) {
                                console.log("Exception: " + JSON.stringify(data) + "  " + e);
                                console.log("data: " + JSON.stringify(res || {}));
                                callback({"data": {}, "page": [0, 0, 0, 0, 1]});
                            }
                        }, complete);
                    }
                }
                BIReq.reqWidgetSettingByData = Data.Req.reqWidgetSettingByData;
                Direct.Utils.aspect4Parameter();
                // //自定义分组 自定义排序 获取列值时 WidgetSetting 修改
                // BI.aspect.before(BI.Utils, "getWidgetDataByWidgetInfo", function (dimensions, view, callback, options) {
                //     checkDimissions(dimensions, view);
                // });

                Pool = {
                    source: {},
                    groups: {},
                    packages: {},
                    connections: {"connectionSet": []},
                    relations: {},
                    translations: {},
                    tables: {},
                    fields: {},
                    excelView: {},
                    timeZone: Pool.timeZone
                };
                BIPool = Pool;
                // //数值维度 默认分组类型为 groupType === BICst.GROUP.ID_GROU
                BI.aspect.after(BI.Utils, "getDimensionGroupByID", function (group, did) {
                    if (JSON.stringify(group) == "{}") {
                        var dimensionType = BI.Utils.getDimensionTypeByID(did[0]);
                        var isTarget = BI.Utils.isTargetByDimensionID(did[0]);
                        if (!isTarget && dimensionType == BICst.TARGET_TYPE.NUMBER) {
                            group["type"] = BICst.GROUP.ID_GROUP;
                        }
                    }
                });

                //获取最大最小值
                Data.Req.reqDeziNumberFieldMinMaxValueByfieldId = function (data, callback, complete) {
                    BI.requestAsync("realtime", "dezi_get_field_min_max_value", data, function (res) {
                        callback(res);
                    }, complete);
                    // callback({"min": "UNKNOWN", "max": "UNKNOWN"});
                };
                //数值字段 做维度 自定义分组 屏蔽自动 只保留自定义
                // BI.extend(BI.NumberIntervalCustomGroupTab, {
                //     Type_Group_Custom: BICst.NUMBER_INTERVAL_CUSTOM_GROUP_CUSTOM,
                //     Type_Group_Auto: BICst.NUMBER_INTERVAL_CUSTOM_GROUP_CUSTOM
                // });
                // BI.extend(BI.NumberIntervalCustomGroupCombo, {
                //     Type_Custom: BICst.NUMBER_INTERVAL_CUSTOM_GROUP_CUSTOM,
                //     Type_Auto: BICst.NUMBER_INTERVAL_CUSTOM_GROUP_CUSTOM
                // });
                // BICst.NUMBER_INTERVAL_CUSTOM_GROUP = [{
                //     text: BI.i18nText("BI-Basic_Custom"),
                //     value: BICst.NUMBER_INTERVAL_CUSTOM_GROUP_CUSTOM
                // }];

                //预览和编辑都需要修改的地方
                BI.i18n["BI-Error_Concat_Us"] = BI.i18nText("Direct-Error_Concat_Us");
                BI.i18n["BI-Data_Miss_Tip"] = BI.i18nText("Direct-Data_Miss_Tip");
                //多指标过滤  可选表扩展到所有关联字表
                BI.Utils.getPrimaryRelationTablesByTableID = function () {
                    return Direct.Utils.getPrimaryRelationTablesByTableID.apply(this, arguments);
                };

                //明细表表头和数据对应 获取row

                BI.DetailTable.prototype._createRowItem = function () {
                    return DirectPool.get("BI.DetailTable.prototype._createRowItem").apply(this, arguments);
                };

                //替换新建分析中更新excel文件的函数
                // BI.UpdateExcelCombo.prototype._updateExcelTableDate = function () {
                //     return DirectPool.get("BI.UpdateExcelCombo.prototype._updateExcelTableDate").apply(this, arguments);
                // };
                //治标 让联动能用
                BI.TargetBodyNormalCell.prototype._createTargetText = function () {
                    return DirectPool.get("BI.TargetBodyNormalCell.prototype._createTargetText").apply(this, arguments);
                };
                // 无穷符号的样式
                BI.TargetBodyNormalCell.prototype._getIconByStyleAndMark = function () {
                    return DirectPool.get("BI.TargetBodyNormalCell.prototype._getIconByStyleAndMark").apply(this, arguments);
                };
                BI.TargetBodyNormalCell.prototype._init = function () {
                    return DirectPool.get("BI.TargetBodyNormalCell.prototype._init").apply(this, arguments);
                };

                //获取下钻元素 不包含标红字段
                BI.ChartDrillCell.prototype.populate = function () {
                    return DirectPool.get("BI.ChartDrillCell.prototype.populate").apply(this, arguments);
                };

                DirectPool.put("BI.Utils.isDimensionUsable", BI.Utils.isDimensionUsable);
                BI.Utils.isDimensionUsable = function (did) {
                    var res = DirectPool.get("BI.Utils.isDimensionUsable").call(this, did);
                    var widgetId = BI.Utils.getWidgetIDByDimensionID(did);
                    var widgetType = BI.Utils.getWidgetTypeByID(widgetId);
                    if (res /*&& widgetType != BICst.WIDGET.DETAIL*/) {//明细表都有效
                        if (Direct.RelationsFactory.getIsUsedDimensions(did) == null) {
                            var wid = BI.Utils.getWidgetIDByDimensionID(did);
                            Direct.RelationsFactory.setUsedDimensionsByWid(wid);
                        }
                        return Direct.RelationsFactory.getIsUsedDimensions(did);
                    }
                    return res;
                    // }else{
                    //     return false;
                    // }
                };

                //联动问题
                BI.aspect.before(BI.ChartDisplay.prototype,"_doLinkage",function () {
                    BI.Utils.isCalculateTargetByDimensionID = DirectPool.get("BI.Utils.isCalculateTargetByDimensionID");
                });
                BI.aspect.after(BI.ChartDisplay.prototype,"_doLinkage",function () {
                    BI.Utils.isCalculateTargetByDimensionID = DirectPool.get("Direct.Utils.isCalculateTargetByDimensionID");
                });
                DirectPool.put("BI.Utils.isCalculateTargetByDimensionID", BI.Utils.isCalculateTargetByDimensionID);
                DirectPool.put("Direct.Utils.isCalculateTargetByDimensionID", function (did) {
                    var res = DirectPool.get("BI.Utils.isCalculateTargetByDimensionID").call(this, did);
                    var wId = BI.Utils.getWidgetIDByDimensionID(did);
                    var type = BI.Utils.getWidgetTypeByID(wId);
                    if (type == BICst.WIDGET.DETAIL) {
                        return res;
                    }
                    return true;
                });
                BI.Utils.isCalculateTargetByDimensionID = DirectPool.get("Direct.Utils.isCalculateTargetByDimensionID");

            }

            // 根据isAllDirect屏蔽cube的更新 屏蔽添加cube的业务包
            if (typeof (BI.Show) == "undefined" && typeof (BI.Dezi) == "undefined") {
                Direct.Utils.maskCube();
            }

        }
        
        Direct.Utils.maskGlobalUpdate();
        if (typeof (BIConf) != "undefined" && typeof (BIConf.Views) != "undefined") {
            if (DirectPool.get("hasGlobalUpdate")) {
                BIConf.Views.route("/Direct-Distribute_Updates_Setting", "BIConf.UpdateDirectPaneView");
            }
        }

        Direct.Utils.updatePool();
        Direct.Utils.updateMyPool();
        if (Direct.Utils.isRealTime() && (typeof (BI.Show) !== "undefined" || typeof (BI.Dezi) !== "undefined")) {
            // 第一次进编辑或者预览界面的时候 一次请求获取所有要获取的字段信息
            Direct.Utils.firstUpdateTableData();
        }
        Direct.Utils.updateTableData();
        if (Direct.Utils.isRealTime()) {

            // BI.any(BICst.DASHBOARD_WIDGETS[2], function (num, item) {
            //     if (item && item.value == BICst.WIDGET.GENERAL_QUERY) {
            //         BICst.DASHBOARD_WIDGETS[2].splice(num, 1);
            //         return true;
            //     }
            // })
            // var len = BICst.CAL_TARGET_TYPE.length;
            // BICst.CAL_TARGET_TYPE.splice(1,len-1);
            // BICst.DIMENSION_FILTER_DATE_COMBO[4]&&BICst.DIMENSION_FILTER_DATE_COMBO.splice(4,1);
            // BICst.DIMENSION_FILTER_STRING_COMBO[4]&&BICst.DIMENSION_FILTER_STRING_COMBO.splice(4,1);
        }
    }
    ,
    reqTablesOfDirectPackage: function (pId, callback) {
        var res = BI.requestSync("realtime", "get_tables_of_direct_package", {});
        callback(res);
    },
    reqUpdatePackages: function (data, callback) {
        BI.requestAsync("realtime", "update_packageInfo", data, function (res) {
            callback(res)
        });
    },
    reqTableDetail: function (pId, callback) {
        var res = BI.requestSync("realtime", "get_table_detail", {id: pId});
        // callback(res);
        return res;
    },
    reqMyPoolData: function (pId, callback) {
        var res = BI.requestSync("realtime", "direct_get_connection_names", {});
        callback(res);
    },
    reqTablesofConnection: function (packageName, callback) {
        BI.requestAsync("realtime", "tables_by_connection", {connectionName: packageName}, function (res) {
                callback(res);
                var reqTablesofConnection = DirectPool.get("reqTablesofConnection");
                DirectPool.put("reqTablesofConnection", null);
                reqTablesofConnection && reqTablesofConnection();
            }
        )
    },
    // reqConnections: function (pId, callback) {
    //     var res = BI.requestSync("realtime", "get_tables_of_direct_package", {
    //     });
    //     callback(res);
    // },
    reqUpdateTablesOfDirectPackage: function (data, callback) {
        BI.requestAsync("realtime", "update_tables_of_direct_package", data, function (res) {
            callback(res);
        })
    },
    reqAddTablesOfDirectPackage: function (data, callback) {
        var res = BI.requestSync("realtime", "add_tables_of_direct_package", data)
        callback(res);
    },
    reqUpdateExcelData: function (data, callback) {
        var res = BI.requestSync("realtime", "update_excel_data", data);
        callback(res);
    },
    reqDelTablesOfDirectPackage: function (tables, callback) {
        var res = BI.requestSync("realtime", "del_tables_of_direct_package", tables)
        callback(res);
    },
    deleteETLTable: function (id, callback) {
        var res = BI.requestSync("realtime", "del_etl_table_of_direct_package", {id: id}, function (res) {
        });
        callback(res);
    },
    stringToHex: function (str) {
        var val = "";
        for (var i = 0; i < str.length; i++) {
            val += str.charCodeAt(i).toString(16);
        }
        return val;
    },
    updatePool: function () {
        if (Direct.Utils.isRealTime()/*BI.Utils.isRealTime()*/) {
            this.reqTablesOfDirectPackage("", this.replacePool);
        }

    },
    replacePool: function (data) {
        // function replacePool(data) {
        DirectPool.put("DirectPackages", data.packages);
        var pacakges = data.packages;
        var tables = {};
        var translations = {};
        BI.each(data.packages, function (index, item) {
            BI.each(item.tableData, function (it, tabledata) {
                tables[it] = BI.clone(tabledata);
            })
            BI.each(item.translations, function (name, trans) {
                translations[name] = trans;
            })
        });
        Pool.packages = pacakges;
        Pool.tables = tables;
        Pool.translations = translations;
        Pool.groups = data.groups || {};
        Pool.relations = data.relations;
        Pool.connNames = data.connNames;
        Pool.noAuthFields = {};
        Pool.fields = {};
        if (data.relations) {
            BI.each(data.relations["translations"], function (index, item) {
                Pool.translations[index] = item;
            })
        }
        Pool.foreignRelations = {};
        DirectPool.put("DirectPool", Pool);//时时更新
        DirectPool.put("packages", Pool.packages);
        DirectPool.put("noAuthFields", Pool.noAuthFields);
        DirectPool.put("relations", Pool.relations);
        DirectPool.put("groups", Pool.groups);
        DirectPool.put("translations", Pool.translations);
        DirectPool.put("fields", Pool.fields);
        DirectPool.put("tables", Pool.tables);

        Direct.RelationsFactory.setRelations(data.relations);
        if (BI.Dezi || BI.Show) {
            Direct.RelationsFactory.init(data.relations);
        }
    },
    updateMyPool: function () {
        if (Direct.Utils.isRealTime()/*BI.Utils.isRealTime()*/) {
            this.reqMyPoolData("", replacePool);
        }
        function replacePool(data) {
            var result = data.result || {};
            // var table = data.tableData||{};
            MyPool.packages = result.packages;
            MyPool.tables = result.tables;
            // BI.each(table.tableData,function (num,item) {
            //     MyPool.tables[num]=item;
            // })
            // MyPool.groups={};
            // MyPool.relations={};
            MyPool.translations = result.translations || {};
            BI.each(result.translations, function (num, item) {
                MyPool.translations[num] = item;
            });
            // 给MyPool加上relations，表层格式和BI的Pool.relations保持一致
            BI.each(Direct.RelationVectors, function (id, backward) {
                MyPool.relations[id] = backward.backward;
            });
            MyPool.foreignRelations = {};
        }
    },
    /*updateDirectPool:function () {
     if (Direct.Utils.isRealTime()/!*BI.Utils.isRealTime()*!/) {
     this.reqTablesOfDirectPackage ("", replacePool) ;
     }
     function replacePool(data) {
     var res = data.direct||{};
     var table = data.tableData||{};
     Pool.packages={"direct-package":{"tables":res.tableIds,"name":"直连业务包","id":"direct-package","position":1470724384697},
     "server-package":{"tables":table.tableIds,"name":"服务器数据集","id":"server-package","position":1470724384697}};
     Pool.tables=res.tableData;
     BI.each(table.tableData,function (num,item) {
     Pool.tables[num]=item;
     })
     Pool.groups={};
     Pool.relations={};
     Pool.translations=res.translations;
     BI.each(table.translations,function (num,item) {
     Pool.translations[num]=item;
     })
     Pool.foreignRelations = {};
     }
     },*/
    updateTableData: function () {
        if (Direct.Utils.isRealTime()/*BI.Utils.isRealTime()*/) {
            var widgets = DirectPool.get("popConfig") && DirectPool.get("popConfig").widgets;
            BI.each(widgets, function (key, value) {
                if (value.dimensions) {
                    BI.each(value.dimensions, function (key2, value2) {
                        var tableid = value2 && value2["_src"] && value2["_src"].tableId;
                        if (tableid) {
                            BI.Utils.getFieldIDsOfTableID(tableid)
                        }
                    })
                }
            })
        }
    },
    firstUpdateTableData: function () {
        if (Direct.Utils.isRealTime()/*BI.Utils.isRealTime()*/) {
            var widgets = DirectPool.get("popConfig") && DirectPool.get("popConfig").widgets;
            var i = 0, tableIds = [], tableId;
            BI.each(widgets, function (key, value) {
                if (value.dimensions) {
                    BI.each(value.dimensions, function (key2, value2) {
                        tableId = value2 && value2["_src"] && value2["_src"].tableId;
                        // var tableid = value2 && value2["_src"] && value2["_src"].tableId;
                        // 要考虑计算指标取到的tableId为undefined的情况
                        if (tableId) {
                            tableIds[i++] = tableId;
                        }
                    });
                }
            });
            // 拿到模板里所有的要获取的tableId
            if (tableIds.length > 0) {
                tableIds = BI.uniq(tableIds);
                var x = [];
                for (var j = 0; j < tableIds.length; ++j) {
                    x[j] = {id: tableIds[j]};
                }
                Direct.Utils.getFieldsByTableIds(x);
            }
        }
    },
    getServerTablesDetailInfoByTables: function (tables, callback) {
        BI.requestAsync("realtime", "get_server_table_info", {tables: tables}, function (res) {
            callback(res);
        });
    },
    getTablesDetailInfoByTables: function (tables, callback) {
        var connectionTablesDetailInfoByTables = DirectPool.get("getConnectionTablesDetailInfoByTables");//异步获取
        if (connectionTablesDetailInfoByTables) {
            DirectPool.put("getConnectionTablesDetailInfoByTables", null);
            BI.requestAsync("realtime", "get_table_info_4_tables", {tables: tables}, function (res) {
                callback(res);
                connectionTablesDetailInfoByTables();
            });
        } else {
            var res = BI.requestSync("realtime", "get_table_info_4_tables", {tables: tables});
            callback(res);
        }
    },

    getFieldsInfoByTables: function (tables, callback) {
        var connectionTablesDetailInfoByTables = DirectPool.get("getConnectionTablesDetailInfoByTables");//异步获取
        if (connectionTablesDetailInfoByTables) {
            DirectPool.put("getConnectionTablesDetailInfoByTables", null);
            BI.requestAsync("realtime", "get_field_info_4_tables", {tables: tables}, function (res) {
                callback(res);
                connectionTablesDetailInfoByTables();
            });
        } else {
            var res = BI.requestSync("realtime", "get_field_info_4_tables", {tables: tables});
            callback(res);
        }
    },
    getConnectionTablesDetailInfoByTables: function (tables, callback) {
        var connectionTablesDetailInfoByTables = DirectPool.get("getConnectionTablesDetailInfoByTables");
        if (connectionTablesDetailInfoByTables) {
            DirectPool.put("getConnectionTablesDetailInfoByTables", null);
            BI.requestAsync("realtime", "get_connection_field_info_4_tables", tables, function (res) {
                callback(res);
                connectionTablesDetailInfoByTables();
            });
        } else {
            var res = BI.requestSync("realtime", "get_connection_field_info_4_tables", tables);
            callback(res);
        }

    },

    refreshTablesDetailInfoByTableIds: function (tables, callback, complete) {
        BI.requestAsync("realtime", "refresh_field_info_4_tables", {tables: tables}, function (res) {
            callback(res);
        }, complete);
    },
    getServerSetPreviewBySql: function (data, callback) {
        BI.requestAsync("realtime", "preview_server_link", data, function (res) {
            callback(res);
        })
    },
    getParameterPool: function (parameterpool, callback) {
        var res = BI.requestSync("realtime", "get_all_sql_parameters", {parameterpool: parameterpool}, function (res) {
        });
        callback(res);
    },

    addCircleFields: function (tables, callback, complete) {
        BI.requestAsync("realtime", "add_circle_fields", {tables: tables}, function (res) {
            callback(res);
        }, complete);
    },

    getLinksAndDirectPackages4Conf: function (callback, complete) {
        BI.requestAsync("realtime", "get_links_packages", {}, function (res) {
            callback(res);
        }, complete)
    },

    reqDistributedTableStatusCheck: function (table, callback, complete) {
        BI.requestAsync("realtime", "check_distributed_table_status", {table: table}, function (res) {
            callback(res);
        }, complete)
    },

    getUpdatePreviewSqlResult: function (data, callback, complete) {
        BI.requestAsync("realtime", "get_preview_table_update", data, function (res) {
            callback(res);
        }, complete)
    },

    reqGenerateDistributedTable: function (tableInfo, id, callback, complete) {
        BI.requestAsync("realtime", "set_distributed_table_generate", {
                baseTableSourceId: tableInfo.baseTable.md5,
                isETL: tableInfo.isETL,
                tableId: id,
                updateType: tableInfo.updateType
            },
            function (res) {
                callback(res);
            }, complete)
        ;
    },

    saveDistributedPath: function (path, callback, complete) {
        BI.requestAsync("realtime", "set_distributed_path", {fileName: path}, function (res) {
            callback(res);
        }, complete);
    },

    checkDistributedPath: function (path, callback, complete) {
        BI.requestAsync("realtime", "check_distributed_path", {fileName: path}, function (res) {
            callback(res.distributedPath);
        }, complete)
    },

    getDistributedPath: function (callback, complete) {
        BI.requestAsync("realtime", "get_distributed_path", {}, function (res) {
            callback(res.distributedPath);
        }, complete);
    },

    getDistributedLogData: function (callback, complete) {
        BI.requestAsync("realtime", "get_distributed_log", {}, function (res) {
            callback(res);
        }, complete)
    },

    generateDistributed: function (callback, complete) {
        BI.requestAsync("realtime", "set_distribute_generate", {}, function (res) {
            callback(res);
        }, complete);
    },

    getDistributedNeedUpdate: function (callback, complete) {
        BI.requestAsync("realtime", "get_distributed_need_update", {}, function (res) {
            callback(res.isNeedUpdate);
        }, complete)
    },

    getUpdateSettingBySourceId:function (data, callback, complete) {
        BI.requestAsync("realtime", "get_update_setting", data, function (res) {
            callback(res);
        }, complete);
    },

    modifyUpdateSetting: function (data, callback, complete) {
        BI.requestAsync("realtime", "modify_update_setting", data, function (res) {
            callback(res);
        }, complete)
    },

    getIsAllDirect: function (data, callback) {
        BI.requestSync("realtime", "realtime_flag", {realtime: data}, function (res) {
            callback(res);
        });
    },

    getHasGlobalUpdate: function (callback) {
        BI.requestSync("realtime", "has_global_update", {}, function (res) {
            callback(res);
        });
    },

    reqAllTableNames: function (callback) {
        BI.requestSync("realtime", "get_all_tableNames", {}, function (res) {
            callback(res);
        });
    }
    // getTablesByPackId: function (packId, callback, complete) {
    //     BI.requestAsync("realtime", "get_brief_tables_of_one_package", {id: packId}, function (res) {
    //         callback(res);
    //     }, complete)
    // }

}

;
(function () {
    var initBIUtils = function () {
        DirectPool.put("isConnectionFlag", false);
        Direct.Utils.getFieldIDsOfTableID4StringLevel=function (tableId) {
            if (BI.isNotNull(Pool.tables[tableId])) {
                var fields = Pool.tables[tableId].fields;
                if(!fields){
                    return [];
                }
                return BI.pluck(fields[0].concat(fields[1]).concat(fields[2]), "id");
            }
        };

        Direct.Utils.getFieldIDsWithCountFieldIdOfTableID = BI.Utils.getFieldIDsWithCountFieldIdOfTableID;
        DirectPool.put("getFieldIDsWithCountFieldIdOfTableIDNoSearch",function (tableId) {
            if (BI.isNotNull(Pool.tables[tableId])) {
                var fields = Pool.tables[tableId].fields;
                if(!fields){
                    return [];
                }
                return BI.pluck(fields[0].concat(fields[1]).concat(fields[2]).concat(fields[3]), "id");
            }
        });
        BI.Utils.getFieldIDsWithCountFieldIdOfTableID = function (tableId) {
            getFieldsByTableid(tableId);
            return Direct.Utils.getFieldIDsWithCountFieldIdOfTableID.call(BI.Utils, tableId);
        };
        DirectPool.put("getFieldIDsWithCountFieldIdOfTableIDWithSearch",BI.Utils.getFieldIDsWithCountFieldIdOfTableID);



        Direct.Utils.getFieldIDsOfTableID = BI.Utils.getFieldIDsOfTableID;
        DirectPool.put("getFieldIDsOfTableIDNoSearch",function (tableId) {
            if (BI.isNotNull(Pool.tables[tableId])) {
                var fields = Pool.tables[tableId].fields;
                if(!fields){
                    return [];
                }
                return BI.pluck(fields[0].concat(fields[1]).concat(fields[2]), "id");
            }
        });
        BI.Utils.getFieldIDsOfTableID = function (tableId) {
            getFieldsByTableid(tableId);
            return Direct.Utils.getFieldIDsOfTableID.call(BI.Utils, tableId);
        };
        DirectPool.put("getFieldIDsOfTableIDWithSearch",BI.Utils.getFieldIDsOfTableID);
        Direct.Utils.getStringFieldIDsOfTableID = BI.Utils.getStringFieldIDsOfTableID;
        BI.Utils.getStringFieldIDsOfTableID = function (tableId) {
            getFieldsByTableid(tableId);
            return Direct.Utils.getStringFieldIDsOfTableID.call(BI.Utils, tableId);
        };
        Direct.Utils.getDateFieldIDsOfTableID = BI.Utils.getDateFieldIDsOfTableID;
        BI.Utils.getDateFieldIDsOfTableID = function (tableId) {
            getFieldsByTableid(tableId);
            return Direct.Utils.getDateFieldIDsOfTableID.call(BI.Utils, tableId);
        };
        Direct.Utils.getNumberFieldIDsOfTableID = BI.Utils.getNumberFieldIDsOfTableID;
        BI.Utils.getNumberFieldIDsOfTableID = function (tableId) {
            getFieldsByTableid(tableId);
            return Direct.Utils.getNumberFieldIDsOfTableID.call(BI.Utils, tableId);
        };
        Direct.Utils.getFieldIDsWithCountFieldIdOfTableID = BI.Utils.getFieldIDsWithCountFieldIdOfTableID;
        BI.Utils.getFieldIDsWithCountFieldIdOfTableID = function (tableId) {
            getFieldsByTableid(tableId);
            return Direct.Utils.getFieldIDsWithCountFieldIdOfTableID.call(BI.Utils, tableId);
        };
        Direct.Utils.getTableIdByFieldID = BI.Utils.getTableIdByFieldID;
        BI.Utils.getTableIdByFieldID = function (fieldId) {
            if (fieldId != null)
                getFieldsByTableid(fieldId.split("_")[0]);
            return Direct.Utils.getTableIdByFieldID.call(BI.Utils, fieldId);
        };

        //新建分析里的EXCEL更新
        Direct.Utils.getFieldsByTableId = BI.Utils.getFieldsByTableId;
        BI.Utils.getFieldsByTableId =  function (tableId) {
            getFieldsByTableid(tableId);
            return Direct.Utils.getFieldsByTableId.call(BI.Utils, tableId);
        };

        function getFieldsByTableid(tableId) {
            function initNoFields() {
                var table = Pool.tables[tableId];
                table.fields = [[], [], []];
            }

            if (Direct.Utils.isRealTime()/*BI.Utils.isRealTime()*/) {
                var table = Pool.tables[tableId];
                if (table && (table.fields == null || table.fields.length == 0)) {
                    initNoFields();
                    if (!DirectPool.get("isConnectionFlag")) {//业务包or数据库
                        // var isAnalysis = false;
                        // if (typeof (BI.Dezi) != "undefined") {
                        //     isAnalysis = true;
                        // }
                        Direct.Utils.getFieldsInfoByTables([{
                            id: tableId,
                        }], function (res) {
                            // var data1 = res && res[0];
                            Direct.Utils.fillFieldInfo(res||[]);
                            // function fillTableInfo(data) {
                            //     !data && (data = {fields: [[], [], []]});
                            //     var allFields = BIPool.fields || {};
                            //     if (isAnalysis) {
                            //         BI.each(data.fields, function (i, fs) {
                            //             BI.each(fs, function (j, field) {
                            //                 field.tableId = tableId;
                            //                 // field = Direct.Utils.changeToHumpNaming().changeField(field);
                            //                 // field.id = Direct.Utils.stringToHex(tableId+field.fieldName);
                            //                 allFields[field.id] = field;
                            //             });
                            //         });
                            //     } else {
                            //         BI.each(data.fields, function (i, fs) {
                            //             BI.each(fs, function (j, field) {
                            //                 field.tableId = tableId;
                            //                 field.isUsable = true;
                            //                 allFields[field.id] = field;
                            //             });
                            //         });
                            //     }
                            //     BIPool.currentTableId = tableId;
                            //     table.fields = data.fields;
                            //     BIPool.fields = allFields;
                            //     // Pool.translations=Pool.translations/*BI.deepClone(Pool.temptranslations)*/;
                            //     var tabletranslations = data.translations || {};
                            //     BI.each(tabletranslations, function (id, value) {
                            //         BIPool.translations[id] = value;
                            //     })
                            // }
                        });
                    } else {
                        var conn = Pool.tables[tableId]["package"], tabname = Pool.tables[tableId]["name"];
                        Direct.Utils.getConnectionTablesDetailInfoByTables({
                            connectionName: conn,
                            tableName: tabname,
                            id: tableId
                        }, function (res) {
                            var data = (res && res["result"]) || {fields: [[], [], []]};
                            var allFields = MyPool.fields || {};
                            BI.each(data.fields, function (i, fs) {
                                BI.each(fs, function (j, field) {
                                    field.id = tableId + "_" + field.id;
                                    field.tableId = tableId;
                                    field.type = "db";
                                    // field.id = Direct.Utils.stringToHex(tableId+field.fieldName);
                                    // field = Direct.Utils.changeToHumpNaming().changeField(field);
                                    allFields[field.id] = field;
                                    MyPool.translations[field.id] = field.fieldName;
                                });
                            });
                            // Pool.currentTableId = tableId;
                            table.fields = data.fields;
                            MyPool.fields = allFields;
                        });
                    }
                }
            }
        }

        function getFieldsByTableIds(tableIds) {
            if (!DirectPool.get("isConnectionFlag")) {//业务包or数据库
                var tableIdArray = BI.deepClone(tableIds);
                var tables = Pool.tables;
                Direct.Utils.getFieldsInfoByTables(tableIds, function (res) {
                    // 从后台获取的数据是个数组
                    var data = res;
                    !data && (data = []);
                    Direct.Utils.fillFieldInfo(data);
                    // var allFields = BIPool.fields || {};
                    // for (var i = 0; i < data.length; ++i) {
                    //     // 要考虑无业务包权限时，后台可以返回数据，但tables里是没有那张表的
                    //     if (BI.has(tables, tableIdArray[i].id)) {
                    //         BI.each(data[i].fields, function (i, fs) {
                    //             BI.each(fs, function (j, field) {
                    //                 // field.tableId = tableIds[i].id;
                    //                 // field = Direct.Utils.changeToHumpNaming().changeField(field);
                    //                 // field.id = Direct.Utils.stringToHex(tableId+field.fieldName);
                    //                 allFields[field.id] = field;
                    //             });
                    //         });
                    //         tables[tableIdArray[i].id].fields = data[i].fields;
                    //         var tableTranslations = data[i].translations || {};
                    //         BI.each(tableTranslations, function (id, value) {
                    //             BIPool.translations[id] = value;
                    //         });
                    //     }
                    // }
                    // // BIPool.currentTableId = tableIds;
                    // BIPool.fields = allFields;
                    // Pool.translations=Pool.translations/*BI.deepClone(Pool.temptranslations)*/;
                });
            }
        }

        BI.Utils.isRealTime = function () {
            return Direct.Utils.isRealTime();
        }
        Direct.Utils.getFieldsByTableid = getFieldsByTableid;
        Direct.Utils.getFieldsByTableIds = getFieldsByTableIds;
    };
    DirectPool.put("BI.Utils.XXXX", initBIUtils);

    var reqAllTemplates = function (callback, complete) {
        function deleteDirectTemplates(items) {
            // if(!Direct.Utils.isRealTime())
            //获取当前模板的description
            var item, i = 0;
            if (Direct.Utils.isRealTime()) {
                for (i = 0; i < items.length; ++i) {
                    item = items[i];
                    if (BI.isNotNull(item.createBy) && item.description !== "true") {
                        items.splice(i, 1);
                        --i;
                    }
                }
            } else {
                for (i = 0; i < items.length; ++i) {
                    item = items[i];
                    if (BI.isNotNull(item.createBy) && item.description === "true") {
                        items.splice(i, 1);
                        --i;
                    }
                }
            }
        }

        BI.requestAsync('fr_bi', 'get_folder_report_list_4_reuse', {}, function (items) {
            deleteDirectTemplates(items);
            callback(items);
        }, complete)
    };
    DirectPool.put("Data.Req.reqAllTemplates", reqAllTemplates);

    var reqWidgetByName = function (name, callback, complete) {
        BI.requestAsync("realtime", "get_search_widgets", {name: name}, function (res) {
            callback(res);
        }, complete);
    };

    DirectPool.put("Data.Req.reqWidgetByName",reqWidgetByName);


    var _createRowItem = function (rowValues, index, widgetOptions, dimensionMap) {
        var self = this;
        var dimensionIds = BI.Utils.getWidgetViewByID(this.options.wId)[BICst.REGION.DIMENSION1];
        var dimensionIds2 = [];
        BI.each(dimensionIds, function (ii, item) {
            var isUsedDimensions = Direct.RelationsFactory.getIsUsedDimensions(item);
            if (isUsedDimensions == null) {
                var wid = BI.Utils.getWidgetIDByDimensionID(item);
                Direct.RelationsFactory.setUsedDimensionsByWid(wid);
                isUsedDimensions = Direct.RelationsFactory.getIsUsedDimensions(item);
            }
            if (isUsedDimensions) {
                dimensionIds2.push(item);
            }
        })
        var rowItems = [];
        // BI.each(rowValues, function (i, rowValue) {
        //     // if (BI.Utils.isDimensionUsable(dimensionIds2[i])) {
        //     //     rowItems.push({
        //     //         type: "bi.detail_table_cell",
        //     //         dId: dimensionIds[i],
        //     //         text: BI.isNull(rowValue) ? "" : rowValue,
        //     //         styles: BI.SummaryTableHelper.getBodyStyles(self._getThemeColor(), self._getTableStyle(), index)
        //     //     })
        //     // }
        // });
        var count = 0;
        BI.each(widgetOptions.dimensionIds, function (i, dId) {
            if (BI.Utils.isDimensionUsable(dId)) {
                rowItems.push(self._createOneCell(index, BI.isNull(rowValues[count]) ? "" : rowValues[count], dId, widgetOptions, dimensionMap));
                count++;
            }
        });

        return rowItems;
    };
    DirectPool.put("BI.DetailTable.prototype._createRowItem", _createRowItem);

    var _updateExcelTableDate = function () {
        var self = this;
        var oldTableId = this.options.tableId;
        var newExcelFullName = this.popup.getExcelFullName();
        var data = {
            tableId: oldTableId,
            newExcelFullName: newExcelFullName
        };
        this.combo.setEnable(false);
        this.trigger.setFailState();
        var id = data.tableId;
        var tableData = {};
        tableData[id] = {};
        tableData[id]["fullFileName"] = data.newExcelFullName;
        var json = {
            tables: [{id: id}],
            tableData: tableData/*this.getTablesData()*/,
            tableType: "excel"
        };
        Direct.Utils.reqUpdateExcelData(json, function (res) {
            console.log(res);
            self.combo.setEnable(true);
            self.trigger.setSuccessState();
        });
        // Data.Req.reqUpdateExcelTableCube(data, function (state) {
        //     console.log(data);
        //     self.state = state.state;
        // }, function () {
        //     if (BI.isNotNull(self.state) && self.state === 0) {
        //         self.fireEvent(BI.UpdateExcelCombo.EXCEL_UPDATE_START);
        //         self._createCheckInterval();
        //     } else {
        //         self.trigger.setText(BI.i18nText("BI-Excel_Update_Fail"));
        //         self.trigger.setFailState();
        //     }
        // })
    };
    DirectPool.put("BI.UpdateExcelCombo.prototype._updateExcelTableDate", _updateExcelTableDate);

})();


BI.Plugin.registerWidget("bi.select_data_search_result_pane", function (el) {
    if (Direct.Utils.isRealTime()) {
        return BI.extend({}, el, {type: "direct.select_data_search_result_pane"});
    }
});

Direct.Cst = {
    isSqlTable:function (type) {
       return this.SQL_TABLE==type;
    },
    isJoinTable:function (type) {
        return this.JOIN_TABLE==type;
    },
    isServerTable:function (type) {
        return this.SERVER_TABLE==type;
    },
    isDistributeTable:function (type) {
        return this.DISTRIBUTE_TABLE==type;
    },
    isCircleTable:function (type) {
        return this.CIRCLE_TABLE==type;
    },
    __FR_Direct_Server__: "__FR_BI_SERVER__",
    Direct_JoinTable: "__FR_Direct_JoinTable__",
    FIELDID_RECORD_NUMBER: "8f97b617f36ee4e0",
    __FR_BI_SERVER__: "__FR_BI_SERVER__",
    __FR_DIRECT_DATABASE__: "__FR_DIRECT_DATABASE__",
    SERVER_TABLE_ID: "tableDataPackage",
    JOIN_TABLE:"join",
    EXCEL_TABLE:"excel",
    CIRCLE_TABLE:"circle",
    SERVER_TABLE:"server",
    DATABASE_TABLE:"database",
    DISTRIBUTE_TABLE:"distributed-data",
    SQL_TABLE:"sql",

    NEED_UPDATE: "distributed_need_update_"
};
/**
 * 搜索结果面板
 *
 * Created by GUY on 2015/9/16.
 * @class BI.SelectDataSearchResultPane
 * @extends BI.Widget
 */
Direct.SelectDataSearchResultPane = BI.inherit(BI.Widget, {
    _defaultConfig: function () {
        return BI.extend(Direct.SelectDataSearchResultPane.superclass._defaultConfig.apply(this, arguments), {
            baseCls: "bi-select-data-search-result-pane bi-searcher-view bi-card",
            itemsCreator: BI.emptyFn
        });
    },

    _init: function () {
        Direct.SelectDataSearchResultPane.superclass._init.apply(this, arguments);
        var self = this, o = this.options;

        this.segment = BI.createWidget({
            type: "direct.select_data_search_segment",
            cls: "search-result-toolbar"
        });
        this.segment.on(Direct.SelectDataSearchSegment.EVENT_CHANGE, function (v) {
            self.fireEvent(BI.SelectDataSearchResultPane.EVENT_SEARCH_TYPE_CHANGE,v);
        });

        this.resultPane = BI.createWidget({
            type: "bi.searcher_view",
            matcher: {
                type: "bi.select_data_tree",
                itemsCreator: o.itemsCreator
            },
            searcher: {
                type: "bi.select_data_tree",
                itemsCreator: o.itemsCreator
            }
        });
        this.resultPane.on(BI.SearcherView.EVENT_CHANGE, function () {
            self.fireEvent(BI.SelectDataSearchResultPane.EVENT_CHANGE, arguments);
        });

        BI.createWidget({
            type: "bi.vtape",
            element: this.element,
            items: [{
                el: this.segment,
                height: 60
            }, {
                type: "bi.border",
                cls: "search-result-line bi-border-top",
                height: 2
            }, {
                type: "bi.border",
                cls: "search-result-line bi-border-top",
                height: 1
            }, {
                type: "bi.absolute",
                items: [{
                    el: this.resultPane,
                    left: 0,
                    right: 0,
                    top: 0,
                    bottom: 0
                }]
            }]
        });
    },

    startSearch: function () {

    },

    stopSearch: function () {

    },

    empty: function () {
        this.resultPane.empty();
    },

    populate: function (searchResult, matchResult, keyword) {
        this.resultPane.populate.apply(this.resultPane, arguments);
    },

    setValue: function (v) {
        this.resultPane.setValue(v);
    },

    getSegmentValue: function () {
        return this.segment.getValue();
    },

    getValue: function () {
        return this.resultPane.getValue();
    }
});
BI.SelectDataSearchResultPane.EVENT_CHANGE = "EVENT_CHANGE";
BI.SelectDataSearchResultPane.EVENT_SEARCH_TYPE_CHANGE = "EVENT_SEARCH_TYPE_CHANGE";
BI.shortcut('direct.select_data_search_result_pane', Direct.SelectDataSearchResultPane);
/**
 * Created by hyp on 2016/11/22.
 */
;(function (direct) {
    var lastTables;
    var copy = {};
    var bigTables = {};
    var usedDimensions = {};
    direct.RelationsFactory = {
        getCopyVector: function () {
            return BI.deepClone(copy["vector"]);
        },
        setUsedDimensions: function (did, flag) {
            usedDimensions[did] = flag;
        },
        //获取维度是否可用 覆盖BI.Utils.is?UsedDimensions
        getIsUsedDimensions: function (did) {
            return usedDimensions[did];
        },
        //根据wid 设置所有维度指标是否可用
        setUsedDimensionsByWid: function (wid) {
            var widget = Data.SharingPool.get("widgets", wid);
            if (widget)
                if (/*widget.type === BICst.WIDGET.DETAIL &&*/ widget.type === BICst.WIDGET.TREE//这里将明细表排除在外 明细表都有效
                /*||widget.type===BICst.WIDGET.STRING/!*文本类控件*!/
                 ||widget.type===BICst.WIDGET.STRING/!*文本类控件*!/*/) {
                } else {
                    var tIds = BI.Utils.getAllTargetDimensionIDs(wid);
                    var tables = {}
                    BI.each(tIds, function (index, item) {
                        var id = BI.Utils.getTableIDByDimensionID(item);
                        tables[id] = id;
                    })
                    var allIds = [], targetIds, dimIds;
                    dimIds = BI.Utils.getAllDimDimensionIDs(wid);
                    targetIds = BI.Utils.getAllTargetDimensionIDs(wid);
                    var allTableIds = {}, targetTableIds = {}, dimTableIds = {};
                    var targetMap = {};
                    BI.each(targetIds, function (index, item) {
                        var tId = BI.Utils.getTableIDByDimensionID(item);
                        targetMap[item] = tId;
                        if (tId == null) {
                            return;
                        }
                        targetTableIds[tId] = tId;
                        allTableIds[tId] = tId;
                    })
                    var dimMap = {}
                    BI.each(dimIds, function (index, item) {
                        var tId = BI.Utils.getTableIDByDimensionID(item);
                        dimMap[item] = tId;
                        if (tId == null) {
                            return;
                        }
                        dimTableIds[tId] = tId;
                        allTableIds[tId] = tId;
                    })

                    BI.each(dimMap, function (index, item) {
                        if (item == null) {//明细表的计算指标
                            function checkCreatedTarget(did) {
                                generateTarget[did] || (generateTarget[did] = {});
                                var expression = BI.Utils.getExpressionByDimensionID(did);//被删除的数据集
                                if (!expression) {//被删除的数据集
                                    return false;
                                }
                                var ids = Data.SharingPool.get("dimensions", did, "_src", "expression", "ids");
                                var flag = true;
                                BI.each(ids, function (index, item) {
                                    var id = BI.Utils.getTableIDByDimensionID(item);
                                    if (id == null) {
                                        if (!generateTarget[did][item]) {
                                            generateTarget[did][item] = item;
                                            if (!checkCreatedTarget(item)) {
                                                flag = false;
                                            }
                                            if (generateTarget[item][did]) {
                                                flag = false;
                                            }
                                            BI.each(generateTarget[item], function (index2, item2) {
                                                generateTarget[did][index2] = index2;
                                            });
                                        }//避免派生指标相互引用，出现循环
                                    } else {
                                        if (!Direct.RelationsFactory.isDimensionWithRelation.call(
                                                Direct.RelationsFactory, allTableIds, dimTableIds, targetTableIds, id)) {
                                            flag = false;
                                        }
                                    }
                                })
                                return flag;
                            }

                            var generateTarget = {};
                            var flag = checkCreatedTarget(index);
                            Direct.RelationsFactory.setUsedDimensions(index, flag);
                        } else if (Direct.RelationsFactory.isDimensionWithRelation.call(
                                Direct.RelationsFactory, allTableIds, dimTableIds, targetTableIds, item)) {
                            // widget.dimensions[index].used = true;
                            Direct.RelationsFactory.setUsedDimensions(index, true);
                        } else if (widget.dimensions[index].used != null) {
                            Direct.RelationsFactory.setUsedDimensions(index, false);
                        } else if (widget.dimensions[index].used == null) {
                            Direct.RelationsFactory.setUsedDimensions(index, true);
                        }
                    })
                    BI.each(targetMap, function (index, item) {
                        var fieldId = BI.Utils.getFieldIDByDimensionID(index);
                        if (Direct.RelationsFactory.isTargetWithRelation.call(
                                Direct.RelationsFactory, allTableIds, dimTableIds, targetTableIds, item, fieldId)) {
                            // widget.dimensions[index].used = true;
                            Direct.RelationsFactory.setUsedDimensions(index, true);
                        } else if (widget.dimensions[index].used != null) {
                            Direct.RelationsFactory.setUsedDimensions(index, false);
                        } else if (widget.dimensions[index].used == null) {
                            Direct.RelationsFactory.setUsedDimensions(index, true);
                        }

                        if (item == null) {
                            // var ids = Data.SharingPool.get("dimensions", index, "_src", "expression", "ids");
                            // var flag = true;
                            // BI.each(ids, function (index, item) {
                            //     var fieldId = BI.Utils.getFieldIDByDimensionID(item);
                            //     var tableId = BI.Utils.getTableIDByDimensionID(item);
                            //     if (!Direct.RelationsFactory.isTargetWithRelation.call(
                            //             Direct.RelationsFactory, allTableIds, dimTableIds, targetTableIds, tableId, fieldId)) {
                            //         flag = false;
                            //     }
                            // })
                            function checkCreatedTarget(did) {
                                generateTarget[did] || (generateTarget[did] = {});
                                var expression = BI.Utils.getExpressionByDimensionID(did);//被删除的数据集
                                if (!expression) {//被删除的数据集
                                    return false;
                                }
                                var ids = Data.SharingPool.get("dimensions", did, "_src", "expression", "ids");
                                var flag = true;
                                BI.each(ids, function (index, item) {
                                    var id = BI.Utils.getTableIDByDimensionID(item);
                                    if (id == null) {
                                        if (!generateTarget[did][item]) {
                                            generateTarget[did][item] = item;
                                            if (!checkCreatedTarget(item)) {
                                                flag = false;
                                            }
                                            if (generateTarget[item][did]) {
                                                flag = false;
                                            }
                                            BI.each(generateTarget[item], function (index2, item2) {
                                                generateTarget[did][index2] = index2;
                                            });
                                        }//避免派生指标相互引用，出现循环
                                    } else if (!Direct.RelationsFactory.isTargetWithRelation.call(
                                            Direct.RelationsFactory, allTableIds, dimTableIds, targetTableIds, id, fieldId)) {
                                        flag = false;
                                    }
                                })
                                return flag;
                            }

                            var generateTarget = {};
                            var flag = checkCreatedTarget(index);
                            Direct.RelationsFactory.setUsedDimensions(index, flag);
                        }
                        // widget.dimensions[index].used = flag;
                    })
                }
        },
        setRelations: function (relations) {
            copy['relations'] = relations;
        },
        setAllTables: function (vector) {
            BI.each(Pool.tables, function (index, item) {
                vector[index] || (vector[index] = {
                    backward: {},
                    forward: {},
                    before: {},
                    next: {},
                    forwardLen: 0,
                    relations: {}
                });
            });
        },
        init: function (relations) {
            relations = BI.clone(relations);
            var vector = {};
            bigTables = {};
            if (!relations || JSON.stringify(relations) == "{}") {
                copy['vector'] = vector;
                return;
            }
            if (relations["primaryTable"]) {
                this._setPrimaryTable(relations["primaryTable"]);
            }
            // this.relations = relations;
            this._getVector(relations, vector);
            this._setAllRelations(vector);
            this._setOne2One(relations, vector);
            this.setAllTables(vector);
            copy['vector'] = vector;
            direct.RelationVectors = vector;
        },

        _setOne2One: function (relations, vector) {
            var one2OneList = [];
            BI.each(vector, function (index, item) {
                if (!listContainTable(one2OneList, index)) {
                    var one2One = {};
                    getOne2One(index, vector, one2One);
                    one2OneList.push(one2One);
                }
            });
            copy2One2One(one2OneList, vector);

            function copy2One2One(one2OneList, vector) {
                function setAllForward(item, forward, backward) {
                    var allForward = {};
                    BI.each(item, function (id, name) {
                        BI.each(vector[id][forward], function (forid, forname) {
                            allForward[forid] = forid;
                        })
                    })
                    BI.each(item, function (id, name) {
                        BI.each(item, function (id2, item2) {
                            if (!vector[id][forward]) {
                                vector[id][forward] = {};
                            }
                            if (id != id2) {
                                (vector[id][forward][item2] = item2);
                            }
                        });
                        BI.each(allForward, function (forid, forname) {
                            if (id != forid) {
                                vector[id][forward] && (vector[id][forward][forid] = forid);
                                vector[id]["relations"][forid] = forid
                            }
                        });
                        BI.each(vector[id][forward], function (id2, item2) {
                            BI.each(vector[id][backward], function (id3, item3) {
                                if (id2 != id3) {
                                    vector[id3][forward][id2] = id2;
                                    vector[id3]["relations"][id2] = id2;
                                }
                            });
                        });
                        BI.each(vector[id][backward], function (id2, item2) {
                            BI.each(vector[id][forward], function (id3, item3) {
                                if (id2 != id3) {
                                    vector[id3][backward][id2] = id2;
                                    vector[id3]["relations"][id2] = id2;
                                }
                            });
                        });
                    })
                }

                BI.each(one2OneList, function (index, item) {
                    setAllForward(item, "forward", "backward");
                    setAllForward(item, "backward", "forward");
                })
            }

            function listContainTable(one2OneList, table) {
                var flag = false;
                BI.each(one2OneList, function (index, item) {
                    if (item[table]) {
                        flag = true;
                    }
                })
                return flag;
            };
            function getOne2One(table, vector, one2One) {
                if (vector[table]["next"]) {
                    BI.each(vector[table]["next"], function (index, item) {
                        if (vector[index]["next"] && vector[index]["next"][table] && one2One[index] == null) {
                            one2One[table] = table;
                            one2One[index] = index;
                            getOne2One(index, vector, one2One);
                        }
                    })
                }
                return one2One;
            };
        },

        _setPrimaryTable: function (prarr) {
            BI.each(prarr, function (index, item) {
                bigTables[item] = item;
            })
        },

        checkIsMultiPath: function (relations) {
            if (!relations) {
                return false;
            }
            var vector = {};
            this._getVector(relations, vector);
            this.tempVector = vector;
            return this._checkMulti(vector);
        },

        _checkMulti: function (vector) {
            for (var table in vector) {
                if (this._setDotRelations(vector, table)) {
                    return true;
                }
            }
            return false;//this._setDotRelations(vector, tableid);
        },

        //灰化：所有已与当前表建立过关联关系的表灰化 setRelations使用
        //设置关联
        getExistRelation: function (table) {
            var tables = {};
            var treeValue = DirectPool.get("Direct.RelationPane._refreshTree");
            BI.each(treeValue,function (index, item) {
                if(item.fieldId){
                    var tableId = Direct.Utils.getTableIdByFieldID(item.fieldId);
                    tables[tableId] = tableId;
                }
            })
            if (!this.tempVector[table]) {
                return tables;
            }
            BI.each(this.tempVector[table]['before'], function (index, item) {
                tables[index] = index;
            })
            BI.each(this.tempVector[table]['next'], function (index, item) {
                tables[index] = index;
            })
            return tables;
        },

        getDetailRelationTableIds: function (tables, oneTable) {
            return tables;
            if (!copy['vector'][oneTable]) {
                return tables;
            }
            var tableIds = {};
            // var table = "";
            BI.each(copy['vector'][oneTable]['forward'], function (index, item) {
                var flag = true;
                BI.each(tables, function (index2, item2) {
                    if (!copy['vector'][index2]['forward'] || !copy['vector'][index2]['forward'][index]) {
                        flag = false;
                    }
                })
                if (flag) {
                    tableIds[index] = index;
                }
            })
            BI.each(tables, function (index, item) {
                tableIds[index] = index;
            })
            tables = {};
            BI.each(tableIds, function (index, item) {
                BI.each(copy['vector'][index]['backward'], function (index2, item2) {
                    tables[index2] = index2;
                })
                tables[index] = index;
            })
            return tables;

        },

        isTargetWithRelation: function (allTableIds, dimTableIds, targetTableIds, table, fieldId) {
            if (table == null) {
                return false;
            }
            this.getRelationsTables(allTableIds, dimTableIds, targetTableIds, table);
            function checkIsRootTable() {
                var flag = true;
                // if (copy['vector'][table]
                //     && copy['vector'][table]['backward'] != null) {
                //     BI.each(copy['vector'][table]['backward'], function (index, item) {
                //         if (lastTables.allTableIds[item] != null) {
                //             if (lastTables.targetTableIds[item]) {
                //                 flag = false;
                //             }
                //             if (!copy['vector'][item]["backward"] || (copy['vector'][item]["backward"]
                //                 && copy['vector'][item]["backward"][table] == null)) {
                //                 flag = false;
                //             }
                //         }
                //     })
                // }
                var publicTable = lastTables.publicTable;
                if (copy['vector'][table]
                    && copy['vector'][table]['forward'] != null) {
                    // if (!copy['vector'][table]['forward'][lastTables.publicTable]) {
                    //     flag = false;
                    // }
                    if (dimTableIds[publicTable]) {//公共主表为维度
                        if (publicTable != table && (!copy['vector'][table]['forward'][publicTable])) {
                            flag = false;
                        }
                    }
                    BI.each(dimTableIds, function (index, dimId) {// 公共主表 包含的所有维度 指标都应该包含
                        if (copy['vector'][publicTable]['forward'][dimId] && (!copy['vector'][table]['forward'][dimId])) {
                            flag = false;
                        }
                    });
                    if (copy['vector'][table]['forward'][publicTable]) {//当前表的字表包含公共主表时 指标有效
                        return true;
                    }
                    if (JSON.stringify(dimTableIds) == "{}") {//不拖维度时  任意拖指标
                        return true;
                    }
                } else {
                    flag = false;
                }
                return flag;
            }

            if (lastTables.publicTable == table) {
                return true;
            }
            return checkIsRootTable();
            // if (lastTables) {
            //     var publicTable = lastTables['publicTable'];
            //     if(fieldId && fieldId.split(Direct.Cst.FIELDID_RECORD_NUMBER).length > 1){
            //         return checkIsRootTable();
            //     }
            //     if (publicTable == table) {
            //         if (fieldId == null || (fieldId && fieldId.split(Direct.Cst.FIELDID_RECORD_NUMBER).length <= 1)) {//不是记录数
            //             return true;
            //         } else {
            //             // var len = 0;
            //             // BI.each(lastTables.allTableIds, function (index, item) {
            //             //     len++;
            //             // })
            //             // if (len <= 1) {
            //             //     return true;
            //             // }
            //             return false;
            //         }
            //     } else {
            //         if (bigTables[table] || (copy['vector'][publicTable]
            //                 && copy['vector'][publicTable]['forward'][table] != null
            //                 && copy['vector'][publicTable]['backward'][table] != null
            //             ) || (copy['vector'][publicTable]
            //             && copy['vector'][publicTable]['forward'][table] == null)) {
            //
            //             return true;
            //         }
            //         return false
            //     }
            // }
        },

        //判断当前表是否和指标表有关联
        isDimensionWithRelation: function (allTableIds, dimTableIds, targetTableIds, table) {
            this.getRelationsTables(allTableIds, dimTableIds, targetTableIds, table);
            if (lastTables) {
                var publicTable = lastTables['publicTable'];
                if (publicTable && table && publicTable == table) {
                    return true;
                } else {
                    if (copy['vector'][publicTable]) {
                        if (copy['vector'][publicTable]['forward'] && copy['vector'][publicTable]['forward'][table]) {
                            return true;
                        }
                    }
                    return false
                }
            }


            // var flag = true;
            // var allequal = true;
            // BI.each(tables,function (index,item) {
            //     if(item!=table){
            //         allequal = false;
            //     }
            //     if (copy['vector'][item]) {
            //         if(!copy['vector'][item]['relations'][table]){
            //             flag = false;
            //         }
            //     }else if(item!=table){
            //         flag = false;
            //     }
            // })
            // return allequal || flag;
            // if(allequal){
            //     return true;
            // }
            // if(flag){
            //     return
            // }

        },
        isRelationsChanged: function (allTableIds, dimTableIds, targetTableIds, oneTable) {
            this.getRelationsTables(allTableIds, dimTableIds, targetTableIds, oneTable);
            return lastTables.relationChanged;
        },

        getRelationsTables: function (allTableIds, dimTableIds, targetTableIds, oneTable) {
            //屏蔽多数据集
            if (false) {
                var tables = {};
                tables[oneTable] = oneTable;
                lastTables = {
                    publicTable: oneTable,
                    tables: tables,
                    dimTableIds: dimTableIds,
                    targetTableIds: targetTableIds,
                    allTableIds: allTableIds
                };
                return tables;
            }
            //屏蔽多数据集
            var relationChanged = false;
            // var hasRelation = false;

            //筛选掉不在不在关联上的表
            dimTableIds = getRelationedTables(dimTableIds);
            targetTableIds = getRelationedTables(targetTableIds);
            allTableIds = getRelationedTables(allTableIds);

            function getRelationedTables(tables) {
                // var myrelationTables = {};
                var i = 0, flag = false;
                BI.each(tables, function (index, item) {
                    i++;
                    if (copy['vector'][item]) {
                        // myrelationTables[index] = item;
                        oneTable = item;
                        // hasRelation = true;
                    } else {
                        copy['vector'][item] = {
                            backward: {},
                            forward: {},
                            before: {},
                            next: {},
                            forwardLen: 0,
                            relations: {}
                        }
                        flag = true;
                    }
                })
                if (i > 1 && flag) {//有多个表而且存在表不在关联之内
                    relationChanged = true;
                }
                return tables;
            }

            var tables = {};
            if(!oneTable && JSON.stringify(allTableIds)=="{}"){//如果只有 计算指标 无字段
                BI.each(Pool.tables,function (tableID,item) {
                   tables[tableID] = tableID;
                });
                lastTables = {
                    publicTable: oneTable,
                    tables: tables,
                    dimTableIds: dimTableIds,
                    targetTableIds: targetTableIds,
                    allTableIds: allTableIds
                };
                return tables;
            }
            // if (!hasRelation) {
            //     tables[oneTable] = oneTable;
            //     lastTables = {
            //         publicTable: oneTable,
            //         tables: tables,
            //         dimTableIds: dimTableIds,
            //         targetTableIds: targetTableIds,
            //         relationChanged: relationChanged,
            //         allTableIds: allTableIds
            //     };
            //     return tables;
            // }

            function isEqual(a, b) {
                var isq = true;
                BI.each(a, function (i, item) {
                    if (!b[item]) {
                        isq = false;
                    }
                })
                BI.each(b, function (i, item) {
                    if (!a[item]) {
                        isq = false;
                    }
                })
                return isq;
            }

            if (lastTables) {
                var equal = true;
                if (isEqual(lastTables['dimTableIds'], dimTableIds) && isEqual(lastTables['targetTableIds'], targetTableIds)) {
                    return lastTables["tables"];
                }

            }


            var bigTargetLen = 0, bigDimLen = 0;
            var bigTargetArr = [], bigDimArr = [], bigTarget, bigDim;

            var targetHasDimLen = {}, num = {};
            BI.each(targetTableIds, function (index, item) {
                var i = 0;
                if (copy['vector'][item]['forward'])
                    BI.each(dimTableIds, function (index2, item2) {
                        if (copy['vector'][item]['forward'][item2]) {
                            i++;
                        }
                    })
                if (bigTargetLen < i) {
                    bigTargetLen = i;
                }
                targetHasDimLen[item] = i;
                if (num[i] != null) {
                    num[i].push(item);
                } else {
                    num[i] = [];
                    num[i].push(item);
                }

            })
            for (var i = 0; i <= bigTargetLen; i++) {
                if (num[i]) {
                    var isContain = false;
                    BI.each(num[i], function (index, item) {
                        BI.each(targetHasDimLen, function (id, len) {
                            if (len > i && copy['vector'][id]['forward'][item]) {
                                isContain = true;
                            }
                        })
                    })
                    bigTargetArr = num[i];
                    if (!isContain) {
                        bigTargetLen = i;
                        break;
                    }
                }
            }
            // BI.each(targetTableIds, function (index, item) {
            //     var i = 0;
            //     if (copy['vector'][item]['forward'])
            //         BI.each(dimTableIds, function (index2, item2) {
            //             if (copy['vector'][item]['forward'][item2]) {
            //                 i++;
            //             }
            //         })
            //     if (bigTargetLen < i) {
            //         bigTargetLen = i;
            //         bigTargetArr = [];
            //         bigTargetArr.push(item);
            //     } else if (bigTargetLen == i) {
            //         bigTargetArr.push(item);
            //     }
            // })
            BI.each(dimTableIds, function (index, item) {
                var i = 1;
                if (copy['vector'][item]['forward'])
                    BI.each(dimTableIds, function (index2, item2) {
                        if (copy['vector'][item]['forward'][item2]) {
                            i++;
                        }
                    })
                if (bigDimLen < i) {
                    bigDimLen = i;
                    bigDimArr = [];
                    bigDimArr.push(item);
                } else if (bigDimLen == i) {
                    bigDimArr.push(item);
                }
            })
            bigDim = compareString(bigDimArr);
            if (bigDim && copy['vector'][bigDim]['forward']) {
                var flag = true;
                BI.each(targetTableIds, function (i, item) {
                    if (!copy['vector'][bigDim]['forward'][item] && item != bigDim) {
                        flag = false;
                    }
                })
                //baohanle所有指标
                if (flag) {
                    BI.each(copy['vector'][bigDim]['relations'], function (i, item) {
                        tables[item] = item;
                    })
                    tables[bigDim] = bigDim;
                    lastTables = {
                        publicTable: bigDim,
                        tables: tables,
                        dimTableIds: dimTableIds,
                        targetTableIds: targetTableIds,
                        relationChanged: relationChanged,
                        allTableIds: allTableIds
                    };
                    return tables;
                }
            }
            var smallTargetTables = [];
            var smallTargetForwardLen = copy['vector'][bigTargetArr[0]] && copy['vector'][bigTargetArr[0]]['forwardLen'];
            BI.each(bigTargetArr, function (i, item) {
                if (copy['vector'][item]['forwardLen'] < smallTargetForwardLen) {
                    smallTargetForwardLen = copy['vector'][item]['forwardLen'];
                    smallTargetTables = [];
                    smallTargetTables.push(item);
                } else if (copy['vector'][item]['forwardLen'] == smallTargetForwardLen) {
                    smallTargetTables.push(item);
                }
            })
            var smallTarget = compareString(smallTargetTables);
            var publicTable;
            // var isPublic = true;
            //
            // BI.each(copy['vector'][smallTarget]['forward'],function (i,item) {
            //     BI.each(dimTableIds,function (index2,item2) {
            //         if(item==item2){
            //             var i=1;
            //             BI.each(dimTableIds,function (i3,item3) {
            //                 if(copy['vector'][item2]['forward'][item3]){
            //                     i++;
            //                 }
            //             })
            //             if(i>=bigTargetLen){
            //                 isPublic=false;
            //             }
            //         }
            //     })
            // })
            // BI.each(copy['vector'][smallTarget]['forward'], function (i, item) {
            //     if (dimTableIds[item] && (bigDim != item && !copy['vector'][bigDim]['forward'][item])) {
            //         isPublic = false;
            //     }
            // })
            // if (isPublic) {
            //     publicTable = smallTarget;
            // } else {
            BI.each(copy['vector'][smallTarget]['forward'], function (i, item) {
                var i = 0;
                if (dimTableIds[item]) {
                    i++;
                    if (copy['vector'][item]['forward'])
                        BI.each(dimTableIds, function (index2, item2) {
                            if (copy['vector'][item]['forward'][item2]) {
                                i++;
                            }
                        })
                }
                if (i == bigTargetLen) {
                    publicTable = item;
                }
            })
            publicTable || (publicTable = smallTarget);
            // }
            var availableTarget = [publicTable];
            BI.each(targetTableIds, function (i, item) {
                if (copy['vector'][item]['forward'] && copy['vector'][item]['forward'][publicTable]) {
                    availableTarget.push(item)
                }
            })
            BI.each(availableTarget, function (i, item) {
                BI.each(copy['vector'][item]['relations'], function (i2, item2) {
                    tables[item2] = item2;
                })
                tables[item] = item;
            });
            //对应灰化逻辑
            var shouldContainDims = {};
            var shouldContainDimsLen = 0;
            if (dimTableIds[publicTable]) {//公共主表为维度
                shouldContainDims[publicTable] = publicTable;
                shouldContainDimsLen++;
            }
            BI.each(dimTableIds, function (index, dimId) {// 公共主表 包含的所有维度 指标都应该包含
                if (copy['vector'][publicTable]['forward'] && copy['vector'][publicTable]['forward'][dimId]) {
                    shouldContainDims[dimId] = dimId;
                    shouldContainDimsLen++;
                }
            });
            // if (shouldContainDimsLen > 0) {
            BI.each(copy['vector'], function (tId, item) {
                var shouldContain = true;
                BI.each(shouldContainDims, function (index, dimId) {// 公共主表 包含的所有维度 指标都应该包含
                    if (!copy['vector'][tId]['forward'] || (!copy['vector'][tId]['forward'][dimId])) {
                        shouldContain = false;
                    }
                });
                if (shouldContain) {
                    tables[tId] = tId;
                }
            });
            // }

            lastTables = {
                publicTable: publicTable,
                tables: tables,
                dimTableIds: dimTableIds,
                targetTableIds: targetTableIds,
                relationChanged: relationChanged,
                allTableIds: allTableIds
            };
            return tables;
            function compareString(arr) {
                var big = arr[0];
                BI.each(arr, function (i, item) {
                    if (big < item) {
                        big = item;
                    }
                })
                return big;
            }

            // var smallForwardLen
            // BI.each(bigArr,function (index,item) {
            //
            // })


        },


        getRelationTableIds: function (tables, oneTable) {
            if (!copy['vector'][oneTable]) {
                return tables;
            }

            var tableIds = {};
            var table = "";
            var bigForward = oneTable;
            var len = copy['vector'][tab] && copy['vector'][tab]['forwardLen'] || 0;
            for (var tab in tables) {
                if (copy['vector'][tab] && (copy['vector'][tab]['forwardLen'] > len)) {
                    len = copy['vector'][tab]['forwardLen'];
                    bigForward = tab;
                }
                // table = one;
                // tableIds[one] = one;
            }
            tableIds[bigForward] = bigForward;
            BI.each(copy['vector'][bigForward]['relations'], function (index, item) {
                tableIds[item] = item;
            });

            return tableIds;


            // for (var one in tables) {
            //     table = one;
            //     tableIds[one] = one;
            // }
            // //如果表 没有在关联里面；
            // if (!copy['vector'][table]) {
            //     return tableIds;
            // }
            // BI.each(copy['vector'][table]['relations'], function (index, item) {
            //     var flag = true;
            //     for (var tab in tables) {
            //         if (!copy['vector'][tab] || !copy['vector'][tab]['relations'][item]) {
            //             flag = false;
            //         }
            //         if (copy['vector'][tab] && copy['vector'][tab]['next'] && copy['vector'][tab]['next'][item]) {
            //             flag = true;
            //         }
            //     }
            //     if (flag) {
            //         tableIds[item] = item;
            //     }
            // })
            // return tableIds;
        },
        _getVector: function (relations, vector) {
            for (var i = 0; i < relations.connectionSet.length; i++) {
                var relation = relations.connectionSet[i];
                /**i:n  和 n:1 问题*/
                var foreignKey = relation['primaryKey']['fieldId'];
                var primaryKey = relation['foreignKey']['fieldId'];
                var foreignTable = foreignKey.split('_')[0];
                var primaryTable = primaryKey.split('_')[0];
                if (foreignTable === primaryTable) {
                    continue;
                }

                vector[foreignTable] || (vector[foreignTable] = {});
                vector[primaryTable] || (vector[primaryTable] = {});

                vector[foreignTable]['before'] || (vector[foreignTable]['before'] = {});
                vector[primaryTable]['next'] || (vector[primaryTable]['next'] = {});

                vector[foreignTable]['before'][primaryTable] = primaryTable;
                vector[primaryTable]['next'][foreignTable] = foreignTable;
            }
        },

        _setDotRelations: function (vectors, targetDot) {
            var isMultiPath = false;
            if (!vectors[targetDot] || vectors[targetDot]['relations']) {
                return isMultiPath;
            } else {
                if (!vectors[targetDot]['forward']) {
                    vectors[targetDot]['forward'] = {};
                    setForward(vectors, targetDot, targetDot);
                    vectors[targetDot]['forwardLen'] = Object.keys(vectors[targetDot]['forward']).length;
                }
                if (!vectors[targetDot]['backward']) {
                    vectors[targetDot]['backward'] = {}
                    setBackward(vectors, targetDot, targetDot);
                }
                _joinBackwardAndForward();
                return isMultiPath;
            }
            function _joinBackwardAndForward() {
                vectors[targetDot]['relations'] = {};
                for (var table in vectors[targetDot]['forward']) {
                    vectors[targetDot]['relations'][table] = table;
                }
                for (var table in vectors[targetDot]['backward']) {
                    vectors[targetDot]['relations'][table] = table;
                }
            }

            function setForward(vectors, targetDot, passDot, passBeforeTable) {
                for (var table in vectors[passDot]['next']) {
                    if (vectors[targetDot]['forward'][table] || table == targetDot) {
                        if (table != targetDot && table != passBeforeTable/*(!vectors[passDot]['before'] || !vectors[passDot]['before'][table])*/) {
                            isMultiPath = true;
                        }
                    } else {
                        vectors[targetDot]['forward'][table] = table;
                        setForward(vectors, targetDot, table, passDot);
                    }
                }
            }

            function setBackward(vectors, targetDot, passDot) {
                for (var table in vectors[passDot]['before']) {
                    if (vectors[targetDot]['backward'][table] || table == targetDot) {
                        // if (table != targetDot && (!vectors[passDot]['next'] || !vectors[passDot]['next'][table])) {
                        //     isMultiPath = true;
                        // }
                        // return;
                    } else {
                        vectors[targetDot]['backward'][table] = table;
                        setBackward(vectors, targetDot, table);
                    }
                }
            }

        },

        _setAllRelations: function (vectors) {
            for (var table in vectors) {
                this._setDotRelations(vectors, table);
            }
        }
    }


})(Direct || (Direct = {}))